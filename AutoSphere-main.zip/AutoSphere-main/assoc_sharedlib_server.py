#========================================================
# Role: Adding new shared library
# Author: Jeffrey Apiado; Sunil Kumar
# Created: 8-28-19
# Version 1.1
# Modification history:
# 8-27-2019           Initial draft          Jeffrey/Sunil
# 8-28-2019           Avoid duplication      Jeffrey
# ========================================================
import sys

__FILE__ = "assoc_sharedlib_server.py"
class sharedlib:
      def __init__(self, libname):
           self.libname = libname
           self.servers = AdminTask.listServers('[-serverType APPLICATION_SERVER ]').splitlines()

      def assoc2server(self):
          for srv in self.servers:
                 gidvar = self.__varFormat_value(srv)
                 print "CONSTRUCT argument to pass: %s" % gidvar
                 gid = AdminConfig.getid(gidvar)
                 classloader = self.__getLoader(gid)
                 print "ClassLoader: %s" % classloader
                 jjj = self.__getSharedLib_inLoader(classloader)
                 ppp = self.newListing(jjj, self.libname)
                 if ppp != []:
                     self.__createLIBREF(classloader, ppp)
                 else:
                     print "No changes made - Library Name already exist!"
                 print "=================== done ========================="
      

      def __varFormat_value(self, _srv):
          servern, prop = _srv.split("(")
          print "SERVER NAME: %s ===============================================" % servern
          rest = prop.split("/")
          STR = "/"
          for line in rest:
            if line.startswith("cells") or line.startswith("nodes") or line.startswith("servers"):
               STR += line[0:-1].capitalize() + ":"
            elif line.find("|") > -1:
               s, xml = line.split("|")
               STR += s + "/"
            else:
               STR += line + "/"
          return STR
         
      def __getLoader(self, loadClass):
          cl = AdminConfig.list('Classloader', loadClass)
          return cl

      def __createLIBREF(self, cloader, careshare):
          cleanID = cloader.strip()
          if len(careshare) > 1:
                 for c in careshare:
                    dual = c[0]
                    print AdminConfig.create('LibraryRef',cleanID, [['libraryName',dual]])
          else:
                    single = careshare[0]
                    print AdminConfig.create('LibraryRef',cleanID, [['libraryName',single]])
          print "Saving  changes !!!!!!!!!!!"
          AdminConfig.save()
  
      def __getSharedLib_inLoader(self, loader):
          holder = []
          line = AdminConfig.showAttribute(loader, 'libraries')
          if line.find(" ") != -1:
             splitter = line.split(" ")
             for item in splitter:
                 if item.find("[") != -1:
                    item = item[1:].strip()
                 elif item.find("]") != -1:
                    item = item[:-1].strip()
                 xxx = AdminConfig.showAttribute(item,'libraryName')
                 holder.append(xxx)
                    
          else:
             if line.startswith("[") and line.endswith("]"):
                     var = line[1:-1]
                     item = var.strip()
             else:
                  item = line
             yyy = AdminConfig.showAttribute(item,'libraryName')
             holder.append(yyy)
          return holder

      def newListing(self, fromSys, fromUser):     
           ARRAYY = []
           for item in fromUser:
               if item in fromSys:
                  continue
               else:
                  ARRAYY.append(item)
           return ARRAYY

if __name__ == "__main__":
     if len(sys.argv) > 0:
            shrlib = sys.argv
     elif len(sys.argv) == 0:
         print "------------------------USAGE----------------"
         print "Invoke %s with wsadmin.sh" % __FILE__
         print "syntax: %s [optional: for shared libary name]" % __FILE__
         print "           [default to: PM_SHARED_LIBRARY]"    
         print "---------------------------------------------"
         sys.exit(0)
     print "Using shared library name: %s" % shrlib
     obj = sharedlib(shrlib)
     obj.assoc2server()
