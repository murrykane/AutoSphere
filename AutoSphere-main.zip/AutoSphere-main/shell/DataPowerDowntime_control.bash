#!/bin/bash
#
# Murry Kane
# Version 1.0
# DataPowerDowntime_control used to Enable/Disable Monitoring in the DataPower API
#
# Modification History
# Who                 Date         Notes
#__________________________________________________________________________________________________
# Murry Kane          02/25/2021   Initial Version
#__________________________________________________________________________________________________

# source in the env setup script
if [ ! -z "${PROJ_PATH}" ]
then
  . ${PROJ_PATH}/shell/functions > /dev/null 2>&1
elif [ -s /opt/jenkins/AutoSphere/shell/functions ]
then
  . /opt/jenkins/AutoSphere/shell/functions > /dev/null 2>&1
elif [ -s /nfs/it-pam/scripts/functions ]
then
  . /nfs/it-pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/pam/scripts/functions ]
then
  . ~/pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/.mkane01/scripts/functions ]
then
  . ~/.mkane01/scripts/functions > /dev/null 2>&1
else
  echo "********************************************************************************"
  echo "*  ERROR: Can not define ENV as PROJ_PATH can't be found, exiting...."
  echo "********************************************************************************"
  exit 5
fi

APPLNAME="DataPowerDowntime_control"
eval LOGFILE=${NIGHTLY_LOG_DIR}/${APPLNAME}.${DATETIME_STAMP}.log
WASNAME="websphr"
ROOTUSER="root"
SVCNAME="websphr"
rc=0
timeout=90
shortSleep=5
SLEEP_TIME=60
set_logging Y 
START_DATE_TIME=$(date +%d-%b-%H:%M) 
#npe_dp_servers="npe-dp-sac-node1 npe-dp-las-node1 npe-xg-node1 ppe-dp-las-node1 ppe-dp-sac-node1 ppe-xg-node1 stg-xg-node1 stg-xg-node2 stg-xg-node3"
#npe_dp_servers="npe-dp-sac-node1 npe-dp-las-node1 npe-xg-node1 ppe-dp-las-node1 ppe-dp-sac-node1 ppe-xg-node1 stg-xg-node1 stg-xg-node2 stg-xg-node3 stg-dp-node1 stg-dp-node2 stg-dp-node3"
npe_dp_servers="npe-dp-sac-node1 npe-dp-las-node1 npe-xg-node1 ppe-dp-las-node1 ppe-xg-node1 stg-xg-node1 stg-xg-node2 stg-xg-node3"
prod_dp_servers="npe-dp-sac-node1"
dp_servers=""

usage() { echo "Usage: $0 [-e <npe|prod|all>] [-a <start|end]" 1>&2; exit 1; }

log_msg "Script started at ${START_DATE_TIME}"

while getopts ":e:a:" o; do
    case "${o}" in
        e)
          env=$(tolower ${OPTARG})
          if [ ${env} == 'prod' ] || [ ${env} == 'npe' ] || [ ${env} == 'all' ]  
          then
            if [ ${env} == 'prod' ]
            then
              dp_servers=${prod_dp_servers}
            fi
            if [ ${env} == 'npe' ]
            then
              dp_servers=${npe_dp_servers}
            fi
            if [ ${env} == 'all' ]
            then
              dp_servers="${npe_dp_servers} ${prod_dp_servers}"
            fi
          else
            usage
          fi
          ;;
        a)
          action=$(tolower ${OPTARG})
          if [ ${action} == 'start' ] || [ ${action} == 'end' ]  
          then
            :
          else
            usage
          fi
          ;;
        *)
            usage
            ;;
    esac
done
shift $((OPTIND-1))

if [ -z "${env}" ] || [ -z "${action}" ] || [ -z "${dp_servers}" ] ; then
    usage
fi

if [ "${CURR_USER}" != "${SVCNAME}" ]
then
  log_msg "You must be ${SVCNAME} to execute this script, ABORTING!"
  chmod 666 ${LOGFILE} 2>/dev/null
  exit 5
else
  log_msg "Running as user [${CURR_USER}]"
  log_msg "Environment = [${env}] and Action = [${action}]"
  chmod 666 ${LOGFILE} 2>/dev/null
fi

getDataPowerCredential()
{
  getUserStr=""
  getPassStr=""
  getKeyStr=""
  the_user=""
  the_pass=""

  #lets get the username/passord
  the_user_str=$(cat ${CFG_DIR}/sre_passwords.properties | grep -i "datapower_user" | awk -F"~#~=" '{print $2}')
  the_pass_str=$(cat ${CFG_DIR}/sre_passwords.properties | grep -i "datapower_pass" | awk -F"~#~=" '{print $2}')
  the_key_str=$(cat ${CFG_DIR}/sre_passwords.properties | grep -i "datapower_encryptKey" | awk -F"~#~=" '{print $2}')

  log_msg "Found user string is [${the_user_str}]"
  log_msg "Password string is [${the_pass_str}]"
  log_msg "Key string is [${the_key_str}]"

  if [ -z "${the_user_str}" ] || [ -z "${the_pass_str}" ] || [ -z "${the_key_str}" ]
  then
    echo "Could not get data needed from the property file"
  else
    the_pass=$(python -c "from SRESecurity import *;the_password = decryptStringWithKey(\"t.log\", \"$the_pass_str\", \"$the_key_str\");print(\"%s\" % the_password)")
    the_user=$(python -c "from SRESecurity import *;the_user = decryptStringWithKey(\"t.log\", \"${the_user_str}\", \"${the_key_str}\");print(\"%s\" % the_user)")
  fi

}

# get the credentials...
getDataPowerCredential
if [ -z "${the_user}" ] || [ -z "${the_pass}" ]
then
  log_msg "ERROR: We could not get the credentials for DataPower rest calls, exiting!"
  exit 7
fi

#log_msg "User Name: ${the_user}"
#log_msg "User Password: ${the_pass}"

#########################################################################
# functions....
startDowntime()
{

  server=${1}
  
  log_msg "Attempting request for server: ${server}"
  
  #mbk may need to add these --connect-timeout 60 (seconds) and --max-time 180 (seconds)
  url_status=$(curl --insecure --data-binary @${CFG_DIR}/soma_disableESBLogTarget.xml -u "${the_user}:${the_pass}" https://${server}:5550/service/mgmt/current | tee -a ${LOGFILE} 2>&1)
  rc=${PIPESTATUS[0]}
  
  log_msg ""
  if [ ${rc} -eq 0 ]
  then
    log_msg "No complete failure occurred for CURL call"
  else
    log_msg "ERROR: Could NOT complete CURL call action ${action} for environment ${env}, exiting with RC = ${rc}!"
    exit ${rc}
  fi
  
  log_msg "CURL return is: ${url_status}"
  
  status=$(toupper `echo "${url_status}" | awk -F':result>' '{print $2}' | awk -F'</dp' '{print $1}'`)
  
  log_msg "CURL return status is [${status}]"
  
  if [ "${status}" != "OK" ] 
  then
    log_msg "ERROR: CURL call failed, exiting!" 
    exit 18
  else
    log_msg "Success, CURL call completed succesfully"
  fi
  
}

endDowntime()
{

  log_msg "Attempting request for server: ${server}"
  
  #mbk may need to add these --connect-timeout 60 (seconds) and --max-time 180 (seconds)
  url_status=$(curl --insecure --data-binary @${CFG_DIR}/soma_enableESBLogTarget.xml -u "${the_user}:${the_pass}" https://${server}:5550/service/mgmt/current | tee -a ${LOGFILE} 2>&1)
  rc=${PIPESTATUS[0]}
  
  log_msg ""
  if [ ${rc} -eq 0 ]
  then
    log_msg "No complete failure occurred for CURL call"
  else
    log_msg "ERROR: Could NOT complete CURL call action ${action} for environment ${env}, exiting with RC = ${rc}!"
    exit ${rc}
  fi
  
  log_msg "CURL return is: ${url_status}"
  
  status=$(toupper `echo "${url_status}" | awk -F':result>' '{print $2}' | awk -F'</dp' '{print $1}'`)
  
  log_msg "CURL return status is [${status}]"
  
  if [ "${status}" != "OK" ]  
  then
    log_msg "ERROR: CURL call failed, exiting!" 
    exit 19
  else
    log_msg "Success, CURL call completed succesfully"
  fi

}


log_msg "Determining action to take..."

if [ ${action} == 'start' ]
then
  for server in $(echo "${dp_servers}")
  do
    log_msg "Working on DISABLE Monitoring for server: [${server}]"
    startDowntime ${server}
  done
elif [ ${action} == 'end' ]
then
  for server in $(echo "${dp_servers}")
  do
    log_msg "Working on ENABLE Monitoring for server: [${server}]"
    endDowntime ${server}
  done
else
  usage
fi


log_msg "#*********************************************************************************"
log_msg "Successfully Completed ${APPLNAME} for ${action} action on environment ${env}"
log_msg "#*********************************************************************************"


END_DATE_TIME=$(date +%d-%b-%H:%M)

log_msg "Script ended at ${END_DATE_TIME}"

exit 0