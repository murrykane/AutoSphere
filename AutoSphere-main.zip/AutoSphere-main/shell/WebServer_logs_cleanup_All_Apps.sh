#!/bin/bash
# 
# Murry Kane
# Version 1.1
# remove_apache_logs - used to clean up apache logs and other files
# update - modified to capture the log path
# 
# Modification History
# Who                 Date         Notes
#__________________________________________________
# Murry Kane          06/24/2019   Initial Version
# Jeff/Sunil          07/16/2019   Revised Version
#__________________________________________________

option_count=${#}
days_in=${1}
days_to_keep=7
rc=0
remove_count=0

# source in the env setup script
if [ ! -z "${PROJ_PATH}" ]
then
  . ${PROJ_PATH}/shell/functions > /dev/null 2>&1
elif [ -s /opt/jenkins/AutoSphere/shell/functions ]
then
  . /opt/jenkins/AutoSphere/shell/functions > /dev/null 2>&1
elif [ -s /nfs/it-pam/scripts/functions ]
then
  . /nfs/it-pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/pam/scripts/functions ]
then
  . ~/pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/.mkane01/scripts/functions ]
then
  . ~/.mkane01/scripts/functions > /dev/null 2>&1
else
  echo "********************************************************************************"
  echo "*  ERROR: Can not define ENV as PROJ_PATH can't be found, exiting...."
  echo "********************************************************************************"
  exit 5
fi

if [ -s ${PAM_SHELL_DIR}/was_functions ]
then
  . ${PAM_SHELL_DIR}/was_functions > /dev/null 2>&1
else
  echo "ERROR: Could not find the was_functions here: [${PAM_SHELL_DIR}/was_functions], exiting!"
  exit 6
fi

APPLNAME="remove_apache_logs"
eval LOGFILE=${NIGHTLY_LOG_DIR}/${APPLNAME}.${DATE_STAMP}.log
WASNAME="websphr"
ROOTUSER="root"
rc=0
timeout=90
shortSleep=5

usage()
{
    echo "${0} optional parm 1 (days to purge) one day = 1  two days = 2"
    echo "Example: ${0} 3"
}

if [ "${CURR_USER}" != "${WASNAME}" ]
then
    log_msg "You must be ${WASNAME} to execute this script, ABORTING!"
    exit 5
fi

case ${option_count} in
    0) days_to_keep=${days_to_keep}
        ;;
    1)
       # lets validate its a number
        re='^[-0-9]+$'
        if ! [[ ${days_in} =~ $re ]] ; then
            log_msg "You did not supply a number for parameter 1, please see usage below"
            usage
            exit
        else
            days_to_keep=${days_in}
        fi
        ;;
    *) usage
        exit
        ;;
esac


#checking for HTTP plugin file since its always in a different mount location....
check_it=$(ps -ef | grep httpd | grep -v grep | grep websphr | grep ".conf" | head -1)
if [ "${check_it}" == "" ]
then
  log_msg "This is not an IHS server, no need to check for Plugin logs"
else
  log_msg "This looks to be an IHS server, checking for cleanup of Plugin logs..."
   var1=$(echo "${check_it}" | awk -F'start -f' '{print $2}')
    var2=$(grep "ErrorLog" $var1 | grep -v "#" | awk '{print $3'})
     PLUGIN_DIR=$(echo $var2 | sed 's/\/error.*//')
  log_msg "File system '${PLUGIN_DIR}' BEFORE free space is: `df -Ph ${PLUGIN_DIR} | tail -1 | awk '{print $4}'` with percent free `df -Ph ${PLUGIN_DIR} | awk '{print $5}' | tail -1`"
  if [ -e ${PLUGIN_DIR} ]
  then
    log_msg "Checking for Plugin files in ${PLUGIN_DIR}"
    if [ ${days_to_keep} -eq 0 ]
    then
      find ${PLUGIN_DIR}"/" -maxdepth 7 -type f \( -name "core.[0-9][0-9][0-9]*" -o -name "http_plugin.log.*"  -o -name "access.log.*" -o -name "error.log.*" -o -name "SystemOut_*.log" -o -name "http_access*.log" -o -name "verbose*.txt*" -o -name "verbose*.log" -o -name "SystemErr_*.log" -o -name "javacore*.txt" -o -name "heapdump*.phd" -o -name "Snap*.trc" \) -print0 2>/dev/null |while IFS= read -r -d $'\0' file
      do
        log_msg "Working on file: ${file}"
        # lets rm the files
        rm ${file}  
      done
    else
      find ${PLUGIN_DIR}"/" -maxdepth 7 -type f \( -name "core.[0-9][0-9][0-9]*" -o -name "http_plugin.log.*"  -o -name "access.log.*" -o -name "error.log.*" -o -name "SystemOut_*.log" -o -name "http_access*.log" -o -name "verbose*.txt*" -o -name "verbose*.log" -o -name "SystemErr_*.log" -o -name "javacore*.txt" -o -name "heapdump*.phd" -o -name "Snap*.trc" \) -daystart -mtime +"${days_to_keep}" -print0 2>/dev/null |while IFS= read -r -d $'\0' file
      do
        log_msg "Working on file: ${file}"
        # lets rm the files
        rm ${file}  
      done 
    fi      
  else
    log_msg "Plugin directory ${PLUGIN_DIR} does not exist!"
  fi
  log_msg "File system '${PLUGIN_DIR}' NEW free space is: `df -Ph ${PLUGIN_DIR} | tail -1 | awk '{print $4}'` with percent free `df -Ph ${PLUGIN_DIR} | awk '{print $5}' | tail -1`"  
fi

log_msg "${0} Completed Succesfully."

exit 0
