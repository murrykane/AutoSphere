#!/bin/sh
#export PART_TYPE=Dmgr
#while [[ $# -ne 0 ]]
#do
#	case $1 in
#		-type*)
#			PART_TYPE=$2
#			;;
#		*)
#			;;
#	esac
#	shift 2
#done
#1. portal  2.dmgr 3. ihs 4.db2
. /etc/virtualimage.properties
PART_TYPE=`cat /etc/bsc-vmimage.properties | grep PART | cut -d'=' -f2`

if [[ "$PART_TYPE" = "PORTAL" ]]; then
    echo "Stopping portal before cleanup"
       if [[ "$PRIMARY" = "true" ]]; then
       su $PORTAL_USER -c "$WAS_PROFILE_ROOT/bin/stopServer.sh WebSphere_Portal -username $PORTAL_USER -password $WAS_password"
       else
       su $PORTAL_USER -c "$WAS_PROFILE_ROOT/bin/stopServer.sh WebSphere_Portal_$NODE_NAME -username $PORTAL_USER -password $WAS_password"
       fi
       su $PORTAL_USER -c "$WAS_PROFILE_ROOT/bin/stopNode.sh -username $PORTAL_USER -password $WAS_password"
        echo "Removing DB2"
	rm -rf /opt/ibm/db2
	echo "Removing IHS"
	rm -rf /opt/IBM/HTTPServer
	rm -rf /opt/IBM/WebSphere/Plugins
	echo "Removing Dmgr profile"
	rm -rf /opt/IBM/WebSphere/Profiles/Dmgr01
	echo "Removing DB2 instance home directory"
        rm -rf /home/db2inst1/db2inst1
	echo "Starting portal after cleanup"
        su $PORTAL_USER -c "$WAS_PROFILE_ROOT/bin/startNode.sh"
        if [[ "$PRIMARY" = "true" ]]; then
        su $PORTAL_USER -c "$WAS_PROFILE_ROOT/bin/startServer.sh WebSphere_Portal"
        else
        $PORTAL_USER -c "$WAS_PROFILE_ROOT/bin/startServer.sh WebSphere_Portal_$NODE_NAME"
        fi
fi

if [[ "$PART_TYPE" = "DMGR" ]]; then
	echo "Stopping dmgr before cleanup"
	su virtuser -c "$PROFILE_ROOT/Dmgr01/bin/stopManager.sh"
	echo "Removing DB2"
	rm -rf /opt/ibm/db2
	echo "Removing IHS"
	rm -rf /opt/IBM/HTTPServer
	rm -rf /opt/IBM/WebSphere/Plugins
	echo "Removing Portal Server"
	rm -rf /opt/IBM/WebSphere/PortalServer 
	echo "Removing wp_profile"
	rm -rf /opt/IBM/WebSphere/Profiles/wp_profile
	echo "Removing Config Wizard"
	rm -rf /opt/IBM/WebSphere/Profiles/cw_profile
	echo "Removing DB2 instance home directory"
        rm -rf /home/db2inst1/db2inst1
	echo "Starting dmgr after cleanup"
	su virtuser -c "$PROFILE_ROOT/Dmgr01/bin/startManager.sh"
fi

if [[ "$PART_TYPE" = "IHS" ]]; then
        echo "Stopping ihs before cleanup"
	su virtuser -c "/opt/IBM/HTTPServer/bin/apachectl stop"
	echo "Removing DB2"
	rm -rf /opt/ibm/db2
	echo "Removing Portal Server"
	rm -rf /opt/IBM/WebSphere/PortalServer 
	echo "Removing wp_profile"
	rm -rf /opt/IBM/WebSphere/Profiles/wp_profile
	echo "Removing Config Wizard"
	rm -rf /opt/IBM/WebSphere/Profiles/cw_profile
	echo "Removing DB2 instance home directory"
        rm -rf /home/db2inst1/db2inst1
	echo " Removing Profiles"
	rm -rf /opt/IBM/WebSphere/Profiles
	echo "Removing WAS"
	rm -rf /opt/IBM/WebSphere/AppServer
	echo "Removing Dmgr profile"
	rm -rf /opt/IBM/WebSphere/Profiles/Dmgr01
	echo "Starting ihs after cleanup"
	su virtuser -c "opt/IBM/HTTPServer/bin/apachectl start"
fi

if [[ "$PART_TYPE" = "DB2" ]]; then
        echo "Stopping db2 before cleanup"
        echo "Removing IHS"
	rm -rf /opt/IBM/HTTPServer
	rm -rf /opt/IBM/WebSphere/Plugins
	echo "Removing Portal Server"
	rm -rf /opt/IBM/WebSphere/PortalServer 
	echo "Removing wp_profile"
	rm -rf /opt/IBM/WebSphere/Profiles/wp_profile
	echo "Removing Config Wizard"
	rm -rf /opt/IBM/WebSphere/Profiles/cw_profile
	echo "Removing WAS"
	rm -rf /opt/IBM/WebSphere/AppServer
	echo "Removing Dmgr profile"
	rm -rf /opt/IBM/WebSphere/Profiles/Dmgr01
	echo " Removing Profiles"
	rm -rf /opt/IBM/WebSphere/Profiles
	echo "Starting db2 after cleanup"
fi
