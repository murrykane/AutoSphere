#!/bin/bash
# 
# Murry Kane
# Version 1.0
# RemoveXMLFiles.sh
# 
# Modification History
# Who                 Date         Notes
#__________________________________________________
# Murry Kane          04/26/2018   Initial Version
#
# Notes:
# This will rename all *.xml files in ${XML_DIR} except
# for the folder name passed in for argument 1.
#
# Examples: RemoveXMLFiles.sh -k prt
#           RemoveXMLFiles.sh -k broker
#           RemoveXMLFiles.sh -k csadmin
#__________________________________________________
#
#


# source in the env setup script
if [ ! -z "${PROJ_PATH}" ]
then
  . ${PROJ_PATH}/shell/functions > /dev/null 2>&1
elif [ -s /opt/jenkins/AutoSphere/shell/functions ]
then
  . /opt/jenkins/AutoSphere/shell/functions > /dev/null 2>&1
elif [ -s /nfs/it-pam/scripts/functions ]
then
  . /nfs/it-pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/pam/scripts/functions ]
then
  . ~/pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/.mkane01/scripts/functions ]
then
  . ~/.mkane01/scripts/functions > /dev/null 2>&1
else
  echo "********************************************************************************"
  echo "*  ERROR: Can not define ENV as PROJ_PATH can't be found, exiting...."
  echo "********************************************************************************"
  exit 5
fi


APPLNAME="RemoveXMLFiles"
eval LOGFILE=${NIGHTLY_LOG_DIR}/${APPLNAME}.${DATE_STAMP}.log
WASNAME="websphr"
rc=0
SAVE_DIR=`pwd`

usage()
{
    echo "${0} -k {directory to keep}"
    echo ""
    echo "Examples ${0} -k broker"
    echo "The above will delete all XML files except the ones in the broker folder from [${XML_DIR}/broker/*.xml]"
    echo ""
    exit 0
}

while getopts "k:" o; do
    case "${o}" in
        k)
          #echo "here we are...."
          keepDir=${OPTARG}
          keepPath=${XML_DIR}/${keepDir}
          #echo "The directory you supplied [${keepDir}] Full Path: [${XML_DIR}/${keepDir}]"
          if [ -d ${keepPath} ] 
          then
            :
          else
            echo "The directory you supplied [${keepDir}] does not exist here: [${XML_DIR}/${keepDir}]"
            usage
          fi
          ;;
        *)
            echo "* section...."
            usage
            ;;
    esac
done
shift $((OPTIND-1))

#echo "env ${env} loc ${loc} action ${action}"
if [ -z "${keepDir}" ]; then
    #echo "empty value...."
    usage
fi

if [ "${CURR_USER}" != "${WASNAME}" ]
then
    log_msg "You must be ${WASNAME} to execute this script, ABORTING!"
    exit 5
fi

find ${XML_DIR}"/" -maxdepth 7 -type f \( -name "*.xml" \) -not -path "${XML_DIR}/${keepDir}/*" -print0 2>/dev/null |while IFS= read -r -d $'\0' file
do
  log_msg "Working on file: ${file}"
  # lets rename the files
  mv ${file} ${file}.bck
done

log_msg "Successfully completed ${APPLNAME}"
