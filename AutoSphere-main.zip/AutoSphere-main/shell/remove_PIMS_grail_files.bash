#!/bin/bash
# 
# Murry Kane
# Version 1.0
# remove_PIMS_grail_files.bash
# 
# Modification History
# Who                 Date         Notes
#__________________________________________________
# Murry Kane          04/14/2021   Initial Version
#
#__________________________________________________

option_count=${#}
days_in=${1}
days_to_keep=0
rc=0
remove_count=0

# source in the env setup script
if [ ! -z "${PROJ_PATH}" ]
then
  . ${PROJ_PATH}/shell/functions > /dev/null 2>&1
elif [ -s /opt/jenkins/AutoSphere/shell/functions ]
then
  . /opt/jenkins/AutoSphere/shell/functions > /dev/null 2>&1
elif [ -s /nfs/it-pam/scripts/functions ]
then
  . /nfs/it-pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/pam/scripts/functions ]
then
  . ~/pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/.mkane01/scripts/functions ]
then
  . ~/.mkane01/scripts/functions > /dev/null 2>&1
else
  echo "********************************************************************************"
  echo "*  ERROR: Can not define ENV as PROJ_PATH can't be found, exiting...."
  echo "********************************************************************************"
  exit 5
fi

if [ -s ${PAM_SHELL_DIR}/was_functions ]
then
  . ${PAM_SHELL_DIR}/was_functions > /dev/null 2>&1
else
  echo "ERROR: Could not find the was_functions here: [${PAM_SHELL_DIR}/was_functions], exiting!"
  exit 6
fi

APPLNAME="remove_PIMS_grail_files"
eval LOGFILE=${NIGHTLY_LOG_DIR}/${APPLNAME}.${DATE_STAMP}.log
WASNAME="websphr"
ROOTUSER="root"
rc=0
timeout=90
shortSleep=5
mount_point="/tmp/grails"

usage()
{
    echo "${0} optional parm 1 (days to purge) one day = 1  two days = 2"
    echo "Example: ${0} 3"
}

if [ "${CURR_USER}" != "${WASNAME}" ]
then
    log_msg "You must be ${WASNAME} to execute this script, ABORTING!"
    exit 5
fi

case ${option_count} in
    0) days_to_keep=${days_to_keep}
        ;;
    1)
       # lets validate its a number
        re='^[-0-9]+$'
        if ! [[ ${days_in} =~ $re ]] ; then
            log_msg "You did not supply a number for parameter 1, please see usage below"
            usage
            exit
        else
            days_to_keep=${days_in}
        fi
        ;;
    *) usage
        exit
        ;;
esac


# validate the mount point was found....
if [ "${mount_point}" == "" ]
then
    log_msg "Missing MOUNT POINT for grail files for PIMS, as it was not found!"
    exit 1
else
    log_msg "Found the following mount point [${mount_point}] to check for files to be removed."
fi

log_msg "File system '${mount_point}' free space is: `df -Ph ${mount_point} | tail -1 | awk '{print $4}'` with percent free `df -Ph ${mount_point} | awk '{print $5}' | tail -1` Using keep days ${days_to_keep}"

# may want to include core.* files...
find ${mount_point} -maxdepth 7 -type d \( -name "searchable-index" \) -print0 2>/dev/null |while IFS= read -r -d $'\0' file
do
    echo "Working on file: ${file}" 
    log_msg "Working on file: ${file}"
    # lets rm the files
    rm -R ${file} >> ${LOGFILE} 2>&1
    rc=$?
    if [ ${rc} -ne 0 ]
    then
      log_msg "ERROR: Please review the log file, received the following return code on attempt: [${rc}]!"
    else  
      #log_msg "Success...."
      :
    fi   
done

log_msg "File system '${mount_point}' NEW free space is: `df -Ph ${mount_point} | tail -1 | awk '{print $4}'` with percent free `df -Ph ${mount_point} | awk '{print $5}' | tail -1`"

log_msg "${0} Completed Succesfully."

exit 0
