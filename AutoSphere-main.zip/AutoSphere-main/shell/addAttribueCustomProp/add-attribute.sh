#!/bin/sh
. /etc/virtualimage.properties

echo " --> Installing WIMSYSTEM EAR "
cd $WAS_PROFILE_ROOT/ConfigEngine
./ConfigEngine.sh wp-la-install-ear -DWasPassword=$ldapadminpwd -DPortalAdminPwd=$ldapadminpwd -DServerName=dmgr -DNodeName=DefaultDmgrNode_1
echo " --> EAR installed "

echo " --> Restarting the DMGR "
echo ${DMGR_HOST}
/usr/bin/expect  <<EOD
set timeout -1
spawn ssh -q -o StrictHostKeyChecking=no $DMGR_USERID@$DMGR_HOST
expect  "*assword: "
send "$PORTAL_PASSWORD\r"
expect "$ "
send "/opt/IBM/WebSphere/Profiles/Dmgr01/bin/stopManager.sh -username $ldapadminuserid  -password $ldapadminpwd\r"
expect "$ "
send "/opt/IBM/WebSphere/Profiles/Dmgr01/bin/startManager.sh\r"
expect "$ "
send "exit\r"
EOD

echo " --> Running wp-add-property task to add the custom attribute(userPrincipalName) "
echo ${HOSTNAME}
/usr/bin/expect  <<EOD
set timeout -1
spawn ssh -q -o StrictHostKeyChecking=no $PORTAL_ADMIN_USER@$HOSTNAME
expect  "*assword: "
send "$PORTAL_PASSWORD\r"
expect "$ "
send "/opt/IBM/WebSphere/Profiles/wp_profile/ConfigEngine/ConfigEngine.sh wp-add-property -Dla.providerURL=corbaloc:iiop:$DMGR_HOST:9809 -Dla.propertyName=userPrincipalName -Dla.entityTypes=PersonAccount -Dla.dataType=String -Dla.multiValued=false -DrepositoryId=devportal -DWasPassword=$ldapadminpwd \r"
expect "*entity: "
send "$ldapadminuserid\r"
expect "*assword: "
send "$ldapadminpwd\r"
expect "$ "
send "exit\r"
EOD

