#!/bin/bash
# 
# Murry Kane
# Version 1.0
# rotate_logs_plugin.sh
# 
# Modification History
# Who                 Date         Notes
#__________________________________________________
# Murry Kane          03/26/2017   Initial Version
#
#__________________________________________________
#
#


# source in the env setup script
if [ ! -z "${PROJ_PATH}" ]
then
  . ${PROJ_PATH}/shell/functions > /dev/null 2>&1
elif [ -s /opt/jenkins/AutoSphere/shell/functions ]
then
  . /opt/jenkins/AutoSphere/shell/functions > /dev/null 2>&1
elif [ -s /nfs/it-pam/scripts/functions ]
then
  . /nfs/it-pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/pam/scripts/functions ]
then
  . ~/pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/.mkane01/scripts/functions ]
then
  . ~/.mkane01/scripts/functions > /dev/null 2>&1
else
  echo "********************************************************************************"
  echo "*  ERROR: Can not define ENV as PROJ_PATH can't be found, exiting...."
  echo "********************************************************************************"
  exit 5
fi


APPLNAME="rotate_logs_plugin"
eval LOGFILE=${NIGHTLY_LOG_DIR}/${APPLNAME}.${DATE_STAMP}.log
WASNAME="websphr"
rc=0
SOURCE_FILE=http_plugin.log
TARGET_FILE=http_plugin.log.`date +%Y-%m-%d_%H_%M_%S`
SAVE_DIR=`pwd`

usage()
{
    echo "${0}"
}

if [ "${CURR_USER}" != "${WASNAME}" ]
then
    log_msg "You must be ${WASNAME} to execute this script, ABORTING!"
    exit 5
fi

#checking for HTTP plugin file since its always in a different mount location....
check_it=$(ps -ef | grep httpd | grep -v grep | grep ${WASNAME} | grep "k start" | head -1)
if [ "${check_it}" == "" ]
then
  log_msg "This is not an IHS server, no need to check for Plugin logs"
  log_msg "Successfully completed ${APPLNAME}"
  exit 0
else
  log_msg "This looks to be an IHS server, checking for cleanup of Plugin logs..."
  #first try and find the servers that have the 'start -f' with different mount point then /opt/WebSphere 
  PLUGIN_DIR=$(echo "${check_it}" | awk -F'start -f' '{print $2}' | awk -F'/' '{print $1"/"$2"/"$3}')
  if [ "${PLUGIN_DIR}" == "//" ]
  then
    #need to try and find it the other way, when running on /opt/WebSphere 
    PLUGIN_DIR=$(echo "${check_it}" | awk -F'httpd -d' '{print $2}' | awk -F'/' '{print $1"/"$2"/"$3}')
    if [ "${PLUGIN_DIR}" == "//" ]
    then
      log_msg "ERROR: Can't find the PLUGIN File to rotate!"
      exit 11
    else
      if [ -e ${PLUGIN_DIR} ]
      then
        log_msg "Checking for Plugin files in ${PLUGIN_DIR}"
        PLUGIN_FILE=`find ${PLUGIN_DIR}"/" -name "${SOURCE_FILE}" -print 2>/dev/null`
      else
        log_msg "Plugin directory ${PLUGIN_DIR} does not exist!"
      fi
    fi
  else
    log_msg "Checking for Plugin files in ${PLUGIN_DIR}"
    PLUGIN_FILE=`find ${PLUGIN_DIR}"/" -name "${SOURCE_FILE}" -print 2>/dev/null`  
  fi
fi

#log_msg "Plugin file is ${PLUGIN_FILE}"

if [ -n "${PLUGIN_FILE}" ]
then
  log_msg "Plugin file is ${PLUGIN_FILE}"
else
  log_msg "Could NOT find the ${SOURCE_FILE} on this system, exiting!"
  exit 10
fi

PLUGIN_DIRECTORY=`dirname ${PLUGIN_FILE}`
cd ${PLUGIN_DIRECTORY}
cp $SOURCE_FILE $TARGET_FILE
cat /dev/null>$SOURCE_FILE
current=`date +%s`
last_modified=`stat -c "%Y" $SOURCE_FILE`
if [ $(($current-$last_modified)) -le 10 ]; then
     log_msg "Plugin Log rotation is successful"
else
     log_msg "Aborted Plugin Log rotation"
fi

cd ${SAVE_DIR}
log_msg "Successfully completed ${APPLNAME}"
