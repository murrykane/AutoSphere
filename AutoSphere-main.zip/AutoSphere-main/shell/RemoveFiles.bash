#!/bin/bash
# 
# Murry Kane
# Version 1.0
# RemoveFiles.bash - This script will remove files from a provided input directory for provided file extensions
#                  2 arguments passed
#                     1) directory path for files to be removed
#                     2) file extenstions to remove (.log,.txt,.sav)
# 
# Modification History
# Who                 Date         Notes
#__________________________________________________
# Murry Kane          08/05/2019   Initial Version
#
#__________________________________________________


# source in the env setup script
if [ ! -z "${PROJ_PATH}" ]
then
  . ${PROJ_PATH}/shell/functions > /dev/null 2>&1
elif [ -s /opt/jenkins/AutoSphere/shell/functions ]
then
  . /opt/jenkins/AutoSphere/shell/functions > /dev/null 2>&1
elif [ -s /nfs/it-pam/scripts/functions ]
then
  . /nfs/it-pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/pam/scripts/functions ]
then
  . ~/pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/.mkane01/scripts/functions ]
then
  . ~/.mkane01/scripts/functions > /dev/null 2>&1
else
  echo "********************************************************************************"
  echo "*  ERROR: Can not define ENV as PROJ_PATH can't be found, exiting...."
  echo "********************************************************************************"
  exit 5
fi

APPLNAME="RemoveFiles"
eval LOGFILE=${NIGHTLY_LOG_DIR}/${APPLNAME}.${DATE_STAMP}.log
WASNAME="websphr"
ROOT_USER="root"
AVAYA_USER="avaya"
days_to_remove=7
rc=0

usage()
{
  echo "${0} {full path to remove files from} {file extension to remove}"
  echo "Example ${0} /opt/jenkins/AutoSphere/logs .log"
}

if [ "${CURR_USER}" != "${WASNAME}" ]
then
    log_msg "You must be ${WASNAME} to execute this script, ABORTING!"
    exit 5
fi

if [ "${HOST_NAME}" == "" ]
then
  log_msg "ERROR: Local Host name is empty, exiting 1"
  exit 1
fi

case ${option_count} in
    0) 
      usaage
      exit
      ;;
    1)
      usage
      exit
      ;;
    2)
      # lets validate its a number
      LOG_DIR=${1}
      FILE_EXT=${2}
      ;;
    *) 
      usage
      exit
      ;;
esac

log_msg "LOG_DIR is ${LOG_DIR} and FILE_EXT is ${FILE_EXT}"


if [ -e "${LOG_DIR}" ]
then
  log_msg "Starting the file search in [$LOG_DIR] for extension [${FILE_EXT}]"
  find "${LOG_DIR}" -maxdepth 1 -type f -name "*${FILE_EXT}" -mtime +"${days_to_remove}" -print0 2>/dev/null |while IFS= read -r -d $'\0' file
  do
    log_msg "Working on remove of file: ${file}"
    rm ${FILE} >> ${LOGFILE} 2>&1
    rc=$?
    if [ ${rc} -ne 0 ]
    then
      log_msg "ERROR: Please review the log file, received the following return code on REMOVE attempt: [${rc}]!"
    else  
      #log_msg "The ZIP completted for Logs"
      :
    fi
  done    
fi


log_msg "Completed ${APPLNAME} successfully"



