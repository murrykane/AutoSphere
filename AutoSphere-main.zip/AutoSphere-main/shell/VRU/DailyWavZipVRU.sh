#/bin/bash

SacPath=`cat /nfs/it-pam/Script_Support/tmp/SacPath`
MyAppPath=`cat /nfs/it-pam/Script_Support/tmp/MyAppPath`

#ZipIdentifier=`cat /nfs/it-pam/Script_Support/tmp/ZipIdentifier`
ZipPath=/perform/local/Nuance/Nuance/callLogs/

HNAME=`hostname -s`
DAY=`/bin/date +%d`
#DAY=08
NumMonth=`/bin/date +%m`
Month=`/bin/date +%B`
Year=`/bin/date +%Y`

ZipIdentifier=$HNAME-$Year$NumMonth$DAY
echo $ZipIdentifier
#exit

if [ -e "$SacPath" ]
then
	cd "$SacPath"
	zip -r $ZipPath$ZipIdentifier-Wav.zip .
	chmod 644 $ZipPath$ZipIdentifier-Wav.zip
fi

if [ -e "$MyAppPath" ]
then
	cd "$MyAppPath"
	zip -r $ZipPath$ZipIdentifier-Log.zip .
	chmod 644 $ZipPath$ZipIdentifier-Log.zip 
fi
