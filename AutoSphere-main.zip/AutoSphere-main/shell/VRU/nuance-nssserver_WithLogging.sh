#!/bin/bash
#
# Murry Kane
# Version 1.0
# start_vru - used to start the CCIU/VRU for LAS-Vegas and SAC servers 
# 
# Modification History
# Who                 Date         Notes
#__________________________________________________
# Murry Kane          01/20/2017   Initial Version
#
#__________________________________________________
#
#####################################################################
# chkconfig: 2345 99 10
# description: Nuance Watcher Daemon start/stop script
#


# source in the env setup script
if [ ! -z "${PROJ_PATH}" ]
then
  #echo "proj_path is defined...."
  . ${PROJ_PATH}/scripts/functions > /dev/null 2>&1
elif [ -s /nfs/it-pam/scripts/functions ]
then
  #echo "found /nfs/it-pam mount point"
  . /nfs/it-pam/scripts/functions > /dev/null 2>&1
elif [ -s ~websphr/pam/scripts/functions ]
then
  #echo "found ~/pam/scripts/functions 
  . ~websphr/pam/scripts/functions > /dev/null 2>&1
elif [ -s ~websphr/.mkane01/scripts/functions ]
then
  #echo "found in murry's directory...."
  . ~websphr/.mkane01/scripts/functions > /dev/null 2>&1
elif [ -s ../functions ]
then
  . ../functions 2>&1
else
  echo "********************************************************************************"
  echo "*  ERROR: Can not define ENV as PROJ_PATH can't be found, exiting...."
  echo "********************************************************************************"
  exit 3
fi

APPLNAME="nuance-nssserver"
LOGFILE=${NIGHTLY_LOG_DIR}/${APPLNAME}.${DATE_STAMP}.log
WASNAME="websphr"
ROOT_USER="root"
rc=0
nuance_proc="nuance-server"
nss_server_proc="NSSserver"
lmgr_proc="lmgrd"

usage()
{
  echo "Usage: $0 { start | stop | status | restart | emergencystop }"
}

save_dir=$PWD

#turn off console output
set_logging N 

if [ "${CURR_USER}" != "${ROOT_USER}" ]
then
    log_msg "You must be ${ROOT_USER} to execute this script, ABORTING!"
    exit 5
fi

if [ "${HOST_NAME}" == "" ]
then
  log_msg "Local Host name is empty, exiting 1"
  exit 1
fi

#
# Source function library
#
#. /etc/rc.d/init.d/functions

# source function library
if [ -f /etc/init.d/functions ]
then
    . /etc/init.d/functions
fi

#
# Define success/failure functions
#
nuance_success() { success; echo; touch /var/lock/subsys/${nuance_proc}; }
server_success() { success; echo; touch /var/lock/subsys/${nss_server_proc} ; }
nuance_stop() { success; echo; rm -f /var/lock/subsys/${nuance_proc}; }
server_stop() { success; echo; rm -f /var/lock/subsys/${nss_server_proc} ; }
nuance_failure() { failure; echo; rm -f /var/lock/subsys/${nuance_proc}; }
server_failure() { failure; echo; rm -f /var/lock/subsys/${nss_server_proc}; }
#status_wd() { status watcher-daemon; }

#
# Needed paths
#
SPEECH_PATH="/usr/local/Nuance/Speech_Server/server"
NUANCE_HOME="/perform/local/Nuance"
NSSSERVER_ENV="/usr/local/Nuance/Speech_Server/server/SETUP-env.sh"
NUANCE_ENV="/etc/profile.d/100-SETUP-nuance-common-permanent.sh"
NUANCE_BIN="/usr/local/Nuance/Recognizer_Service/amd64/bin"

# source in needed environment
if [ -s "${NUANCE_ENV}" ]
then  
  log_msg "Sourcing in the ${NUANCE_ENV}"
  source ${NUANCE_ENV}
else
  log_msg "ERROR: The needed source found to source in is not found: [${NUANCE_ENV}],exiting!"
  exit 1
fi
if [ -s "${NSSSERVER_ENV}" ]
then
  log_msg "Sourcing in the ${NSSSERVER_ENV}"
  source ${NSSSERVER_ENV}
else
  log_msg "ERROR: The needed source found to source in is not found: [${NSSSERVER_ENV}],exiting!"
  exit 1
fi

#
# start_nssserver function
#
start_nssserver()
{
  #turn ON console output
  set_logging Y
  # lets first validate if the nuance and nss_server_proc are already running!
  #check_it=`ps -ef | egrep -i 'lmg|nrs|nss' | grep -v sssd_nss| grep -v grep`
  check_it=`ps -ef | egrep -i "${nuance_proc}|${nss_server_proc}" | egrep -v "swilmgrd|grep|sssd_nss|su -s /bin/bash nuance|${APPLNAME}"`
  if [ "${check_it}" == "" ]
  then
    log_msg "Everything is stopped for [${nuance_proc} and ${nss_server_proc}] continuing with startup..."
  else
    log_msg "ERROR: Something is already running check the following [${check_it}], exiting"
    exit 5
  fi

  # lets make sure the lmgrd process is running first!
  check_it=`ps -ef | egrep -i "${lmgr_proc}" | egrep -v "swilmgrd|grep|${0} lmgrd"`
  if [ "${check_it}" == "" ]
  then
    log_msg "ERROR: Trying to start process [${nuance_proc} and ${nss_server_proc}] the required [${lmgr_proc}] is not running!"
    exit 5
  else
    log_msg "INFO: The required ${lmgr_proc} is running, continue start on: [${nuance_proc} and ${nss_server_proc}]"
  fi

  if [ -d ${SPEECH_PATH} ]
  then
    cd ${SPEECH_PATH}
    if [ -f "${NUANCE_HOME}/speechServer_start.out.bkp" ]
    then
      log_msg "Removing ${NUANCE_HOME}/speechServer_start.out.bkp ..."
      rm ${NUANCE_HOME}/speechServer_start.out.bkp 2>/dev/null
    fi
    if [ -f "${NUANCE_HOME}/speechServer_start.out" ]
    then
      log_msg "Renaming ${NUANCE_HOME}/speechServer_start.out to ${NUANCE_HOME}/speechServer_start.out.bkp"
      mv ${NUANCE_HOME}/speechServer_start.out ${NUANCE_HOME}/speechServer_start.out.bkp 2>/dev/null
    fi
    log_msg "Issuing 'sh ./start' now..."
    nohup sh ./start > /dev/null &
    rc=$?
    if [ ${rc} -ne 0 ]
    then
      log_msg "ERROR: Please check if the 'sh ./start' started correctly or not the RC returned from the command was: [${rc}]!"
      server_failure
      # leave out for now, see how it runs the first time.... MBK Added back....
      exit ${rc}  
    else  
      log_msg "The 'sh ./start' process has been started successfully"
      server_success
    fi
    if [ -s "${NUANCE_HOME}/recog_start.out.bkp" ]
    then
      log_msg "Removing ${NUANCE_HOME}/recog_start.out.bkp"
      rm ${NUANCE_HOME}/recog_start.out.bkp 2>/dev/null
    fi
    if [ -f "${NUANCE_HOME}/recog_start.out" ]
    then
      log_msg "Moving ${NUANCE_HOME}/recog_start.out to ${NUANCE_HOME}/recog_start.out.bkp"
      mv ${NUANCE_HOME}/recog_start.out ${NUANCE_HOME}/recog_start.out.bkp 2>/dev/null
    fi
    log_msg "Starting nuance-server now..."
		if [ -d ${NUANCE_BIN} ]
		then
			cd ${NUANCE_BIN}
			if [ -a ${nuance_proc} ]
			then
				nohup ./${nuance_proc} -servlet nrs -port 8200 -nthreads 150 > /dev/null &
				rc=$?
				if [ ${rc} -ne 0 ]
				then
					log_msg "ERROR: Please check if the nuance-server started correctly or not the RC returned from the command was: [${rc}]!"
					nuance_failure
					# leave out for now, see how it runs the first time.... MBK Added back....
					exit ${rc}  
				else  
					log_msg "The nuance-server process has been started successfully"
					nuance_success
				fi
			else
				log_msg "The ${nuance_proc} is not present in directory [${NUANCE_BIN}], can not start it, exiting!"
				exit 5
			fi
		else
			log_msg "The required directory [${NUANCE_BIN}] for ${nuance_proc} is not found!, exiting!"
		fi
  else
    log_msg "ERROR: The needed directory not found[${SPEECH_PATH}],exiting!"
    exit 1
  fi

}

#
# stop_nssserver function
#
stop_nssserver()
{
  #turn ON console output
  set_logging Y
  # server 1 through 4 kill nuance and nss_server processes
  PID=`ps -ef | grep "${nuance_proc}" | grep -v grep | awk '{print $2}'`
  log_msg "Found PID [${PID}] for ${nuance_proc} process"
  if [ "${PID}" != "" ]
  then
    log_msg "Killing ${nuance_proc} with PID ${PID}"
    kill ${PID}
    nuance_stop
  else
    log_msg "ISSUE: unable to find PID for ${nuance_proc}!, either its already stopped or we could not find the process!"
    nuance_failure
  fi

  PID=`ps -ef | grep "${nss_server_proc}" | grep -v grep | egrep '^nuance' | awk '{print $2}'`
  log_msg "Found PID [${PID}] for ${nss_server_proc} process"
  if [ "${PID}" != "" ]
  then
    log_msg "Killing ${nss_server_proc} with PID ${PID}"
    kill ${PID}
    server_stop
  else
    log_msg "ISSUE: unable to find PID for ${nss_server_proc}!, either its already stopped or we could not find the process!"
    server_failure
  fi

}

#
# emergencystop_nssserver function
#
emergencystop_nssserver()
{
  #turn ON console output
  set_logging Y
  # server 1 through 4 kill nuance and nss_server processes
  PID=`ps -ef | grep "${nuance_proc}" | grep -v grep | awk '{print $2}'`
  log_msg "Found PID [${PID}] for ${nuance_proc} process"
  if [ "${PID}" != "" ]
  then
    log_msg "Killing ${nuance_proc} with PID ${PID}"
    kill -9 ${PID}
    nuance_stop
  else
    log_msg "ISSUE: unable to find PID for ${nuance_proc}!, either its already stopped or we could not find the process!"
    nuance_failure
  fi

  PID=`ps -ef | grep "${nss_server_proc}" | grep -v grep | egrep '^nuance' | awk '{print $2}'`
  log_msg "Found PID [${PID}] for ${nss_server_proc} process"
  if [ "${PID}" != "" ]
  then
    log_msg "Killing ${nss_server_proc} with PID ${PID}"
    kill -9 ${PID}
    server_stop
  else
    log_msg "ISSUE: unable to find PID for ${nss_server_proc}!, either its already stopped or we could not find the process!"
    server_failure
  fi

}

#
# status_nssserver function
#
status_nssserver()
{
  # enable logging
  set_logging y
  echo
  # server 1 through 4 kill nuance and nss_server processes
  PID=`ps -ef | grep "${nuance_proc}" | grep -v grep | awk '{print $2}'`
  if [ "${PID}" != "" ]
  then
    log_msg "${nuance_proc}: is runnning"
  else
    log_msg "${nuance_proc}: NOT running"
  fi

  PID=`ps -ef | grep "${nss_server_proc}" | grep -v grep | egrep '^nuance' | awk '{print $2}'`
  if [ "${PID}" != "" ]
  then
    log_msg "${nss_server_proc}: is running"
  else
    log_msg "${nss_server_proc}: NOT running"
  fi
  echo
}

#
# Evaluate $1 to determine which operation we are to perform
#
case "$1" in

  #
  # Stop watcher daemon
  #
  stop)
    stop_nssserver
  ;;

  #
  # Emergency Stop watcher daemon
  #
  emergencystop)
    emergencystop_nssserver
  ;;
  #
  # Start watcher daemon
  #
  start)  
    start_nssserver
  ;;
  # 
  # restart 
  #
  restart)
    stop_nssserver
    start_nssserver
  ;;
  
  #
  # Status watcher daemon
  #
  status)
    status_nssserver
  ;;

  #
  # Command-line Syntax Error
  #
  *)
    usage
    exit 1
  ;;
esac