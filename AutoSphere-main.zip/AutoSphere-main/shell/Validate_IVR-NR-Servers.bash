#!/bin/bash
#
# Murry Kane
# Version 1.0
# Validate_IVR-NR-Servers.bash used to validate a the IVR/NR servers for Nuance Avaya application
#
# Modification History
# Who                 Date         Notes
#__________________________________________________________________________________________________
# Murry Kane          10/21/2020   Initial Version
#__________________________________________________________________________________________________
#

# source in the env setup script
if [ ! -z "${PROJ_PATH}" ]
then
  . ${PROJ_PATH}/shell/functions > /dev/null 2>&1
elif [ -s /opt/jenkins/AutoSphere/shell/functions ]
then
  . /opt/jenkins/AutoSphere/shell/functions > /dev/null 2>&1
elif [ -s /nfs/it-pam/scripts/functions ]
then
  . /nfs/it-pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/pam/scripts/functions ]
then
  . ~/pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/.mkane01/scripts/functions ]
then
  . ~/.mkane01/scripts/functions > /dev/null 2>&1
else
  echo "********************************************************************************"
  echo "*  ERROR: Can not define ENV as PROJ_PATH can't be found, exiting...."
  echo "********************************************************************************"
  exit 5
fi

APPLNAME="Validate_IVR-NR-Servers"
eval LOGFILE=${NIGHTLY_LOG_DIR}/${APPLNAME}.${DATETIME_STAMP}.log
WASNAME="websphr"
ROOTUSER="root"
PAMNAME="svcpam"
SRENAME="svcsre"
#UNITNames="nuance-licmgr.service nuance-watcher.service"

rc=0
set_logging Y 
START_DATE_TIME=$(date +%d-%b-%H:%M)
#user_str='snow_user'
#pass_str='snow_pass'
#key_str='snow_encryptKey'

usage() { echo "Usage: $0 [-s <running>|<stopped>] [-e <environment Examples: VRUN33|VRUH72|VRUH63|VRUH70|INTERACTIVE>" 1>&2; exit 1; }

log_msg "Script started at ${START_DATE_TIME}"

while getopts ":s:e:" o; do
    case "${o}" in
        s)
          state=$(tolower ${OPTARG})
          if [ ${state} == 'running' ] || [ ${state} == 'stopped' ]  
          then
            :
          else
            usage
          fi
          ;;
        e)
          environment=$(toupper ${OPTARG})
          echo "Using environment [${environment}]"
          ;;
        *)
            usage
            ;;
    esac
done
shift $((OPTIND-1))

if [ -z "${state}" ] ; then
    usage
fi

if [ -z "${environment}" ] 
then
  usage
fi

if [ "${CURR_USER}" != "${SRENAME}" ] && [ "${CURR_USER}" != "${PAMNAME}" ]
then
  log_msg "You must be ${SRENAME} or ${PAMNAME} to execute this script, ABORTING!"
  chmod 666 ${LOGFILE} 2>/dev/null
  exit 5
else
  log_msg "Running as user [${CURR_USER}]"
  log_msg "State to check is [${state}] for environment [${environment}]"
  chmod 666 ${LOGFILE} 2>/dev/null
fi

#lets get the username/passord
#first source in the functions for SNOW
if [ -s ${PAM_SHELL_DIR}/snow_functions ]
then
  . ${PAM_SHELL_DIR}/snow_functions > /dev/null 2>&1
  #getURI Base
  getSNowInstance
  log_msg "Using URL Base [${URL_INST}]"
  if [ -z "${URL_INST}" ]
  then
    log_msg "Empty URL base for SNOW, exiting!"
    exit 6
  fi
  #now get the user/password
  getSNowCredential
  if [ -z "${snow_user}" ] || [ -z "${snow_pass}" ]
  then
    log_msg "We could not get the credentials for SNOW rest call, exiting!"
    exit 7
  fi
else
  log_msg "SNOW functions could not be found(${PAM_SHELL_DIR}/snow_functions), exiting!"
  exit 4
fi

if [ -z "${snow_user}" ] || [ -z "${snow_pass}" ] 
then
  log_msg "Could not identify user name and password, exiting!"
  exit 11
fi

log_msg "Found SNOW REST user string to be: [${snow_user}]"


#########################################################################
# functions....
get-CMDB-Info()
{

  #cmdb_rel_ci_list.do?sysparm_query=child.nameLIKENuance%20Speech%20Suite%5Eparent.nameSTARTSWITH
  #uri="${URL_INST}/api/now/table/cmdb_rel_ci?sysparm_query=parent.nameLIKEIVR-VRU%5Echild.nameSTARTSWITHdmgr%40%5Eparent.nameSTARTSWITH${environment}%5Eparent.operational_status%3D1%5Echild.operational_status%3D1%5Eparent.install_status%3D11%5Echild.install_status%3D11&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=child&sysparm_limit=1000"
  uri="${URL_INST}/api/now/table/cmdb_rel_ci?sysparm_query=child.nameLIKENuance%20Speech%20App%20Server%5Eparent.nameSTARTSWITH${environment}%5Eparent.operational_status%3D1%5Echild.operational_status%3D1%5Eparent.install_status%3D11%5Echild.install_status%3D11&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=child&sysparm_limit=1000"
 
  log_msg "Using URL [${uri}]"
  querySNowApi "${uri}" "${snow_user}" "${snow_pass}" "${LOGFILE}"
  
  log_msg "CURL call returned: ${url_status}"
  
  if [ -z "${url_status}" ]
  then
    log_msg "Returned no rows for CMDB call, exiting!"
    exit 10
  fi

  status=$(tolower `echo "${url_status}" | awk -F':' '{print $4}' | awk -F',' '{print $1}' | awk -F'"' '{print $2}'`)
  error_code=$(echo "${url_status}" | awk -F':' '{print $5}' | awk -F',' '{print $1}' | awk -F'"' '{print $2}')
  log_msg "CURL return status is [${status}] with return code [${error_code}]"
  
  if [ "${error_code}" == "failure" ]
  then
    log_msg "Failure for CMDB call, please review the logs: exiting!"
    exit 12
  fi
  
  rows_returned=$(echo "${url_status}" | awk -F'"child":' '{print NF-1}')
  log_msg "Returned CI's from CDMB call is [${rows_returned}]"
  serverArray=''
  
  #check if returned rows is > 0
  
  if [ ${rows_returned} -gt 0 ]
  then
    log_msg "Result of CI's returned from CMDB is greater then 0"
  else
    log_msg "Result of CI's returned from CMDB is NOT greater then 0, exiting!"
    exit 13
  fi
  
  for (( i = 1; i <= ${rows_returned}; i++ ))
  do
    log_msg "Working on loop [${i}]"
    test=$(echo "${url_status}" | awk -F'{"result":' '{print $2}' | cut -d',' -f$i)
    log_msg "For loop [$i] found ${test}"
    server=$(echo "${test}" | cut -d'"' -f4 | cut -d@ -f2)
    log_msg "Server is ${server}"
    
    if [ -z "${server}" ]
    then
      log_msg "Something went wrong trying to parse the returned REST call for server name, exiting!"
      exit 14
    fi
    
    if [ -z "${serverArray}" ]
    then
      serverArray="${server}"
    else
      serverArray="${serverArray} ${server}"
    fi
  done
  
  log_msg "Server Array is [${serverArray}]"

}
check_running()
{
  #mbk need to find running processes 
  # /bin/sh /opt/asr/Nuance/Common/x86/bin/run watcher-daemon
  #    child watcher-daemon  ( watcher-daemon watcher.Modules=snmp wm.snmp.MibDirs=/opt/asr/Nuance/Common/data/mibs watcher.DaemonBroadcastAddress=127.0.0.1)  
  #    
      #nuance    3309  3308  0 Sep17 ?        00:45:01 watcher-daemon watcher.Modules=snmp wm.snmp.MibDirs=/opt/asr/Nuance/Common/data/mibs watcher.DaemonBroadcastAddress=127.0.0.1
      #nuance    3379  3309  0 Sep17 ?        00:16:12 fta config.ServiceID=cd12969d-0a22-2213-02da-788b5a4079a5 config.LoggingLevel=STATUS config.ManagementStationHost=localhost:8080
      #nuance    3390  3309  0 Sep17 ?        00:44:51 nuance-server -servlet nrs -port 8200 -DDiagFileName=/var/local/Nuance/system/diagnosticLogs/nrs1.log -DSWIUSERCFG=/var/local/Nuance/system/config/User-nrs01.xml config.ServiceID=cd1296c3-0a22-2213-02da-788b8db6c7ab config.LoggingLevel=STATUS -nthreads 96 config.ManagementStationHost=localhost:8080
      #nuance    3533  3309  0 Sep17 ?        00:21:29 nuance-server -servlet nvs -port 9200 -DDiagFileName=/var/local/Nuance/system/diagnosticLogs/nvs-server1.log nserver.nvs.VocalizerUserCfgFile=/var/local/Nuance/system/config/User-nvs01.xml config.ServiceID=cd1296ba-0a22-2213-02da-788be4ca7b01 config.LoggingLevel=STATUS config.ManagementStationHost=localhost:8080
      #nuance    3637  3309  1 Sep17 ?        14:27:43 NSSserver -u /var/local/Nuance/system/config/User_nss01.txt config.ServiceID=cd1296d5-0a22-2213-02da-788b999d0277 config.LoggingLevel=STATUS config.ManagementStationHost=localhost:8080
  #
  #
  # lmgrd with 1 child process (swilmgrd)
  #   
       #root      1107     1  0 Oct09 ?        00:00:07 /opt/asr/Nuance/license_manager/components/lmgrd -c /opt/asr/Nuance/Nuance/uapp3372p.lic -l /opt/asr/Nuance/license_manager/license/nuance-licmgr.log
       #root      1112  1107  0 Oct09 ?        00:01:12 swilmgrd -T uapp3372p.bsc.bscal.com 11.14 3 -c :/opt/asr/Nuance/Nuance/uapp3372p.lic: -srv dOggvqwT0MKNEyJFrpLLGHSNygy1VruxX1Ekm23jk9Ng0EymXz9ejWOy2hE0v8j --lmgrd_start 5f80fa18 -vdrestart 0

  lic_check=`/bin/systemctl is-active nuance-licmgr.service`
  lic_rc=$?
  watch_check=`/bin/systemctl is-active nuance-watcher.service`
  watch_rc=$?

  #mbk checking primary way...
  if [ ${lic_rc} -eq 0 ] && [ "${lic_check}" == "active" ]
  then
    echo "   SystemD states nuance-licmgr.service is runnning"
  else
    echo "   ERROR: SystemD states that nuance-licmgr.service is NOT running, exiting!"
    exit 1
  fi
  if [ ${watch_rc} -eq 0 ] && [ "${watch_check}" == "active" ]
  then
    echo "   SystemD states nuance-watcher.service is runnning"
  else
    echo "   ERROR: SystemD states that nuance-watcher.service is NOT running, exiting!"
    exit 1
  fi

  #mbk secondary checks below
  watchPID=$(ps -ef | grep -v grep | grep "run watcher-daemon" | awk '{print $2}' | head -1)
  if [ -z "${watchPID}" ]
  then
    echo "   Could not find the MAIN Watch Dog PID, exiting!"
    exit 2
  else
    watchChildPID=$(ps -ef | grep -v grep | grep ${watchPID} | grep -v "run watcher-daemon" | awk '{print $2}'| head -1)
  fi
  watchChildrenPIDs=$(ps -ef | grep ${watchChildPID} | grep -v grep | awk '{print $2"~"$3}' | grep -v "^${watchChildPID}" | wc -l)
  if [ ${watchChildrenPIDs} -ge 4 ]
  then
    echo "   All Grand Children processes were found with count [${watchChildrenPIDs}] for Grand Parent [${watchPID}] for Parent [${watchChildPID}]"
  else
    echo "   Could not find the Child/Grand children for the Watch Dog Service, exiting!"
    exit 3
  fi
  
  #Check License Manager
  licPID=$(ps -ef | grep -v grep | grep "/lmgrd" | awk '{print $2}' | head -1)
  swiLicPID=$(ps -ef | grep -v grep | grep ${licPID} | awk '{print $2"~"$3}' | grep -v "^${licPID}" | awk -F~ '{print $1}' )
  if [ -z "${licPID}" ] || [ -z "${swiLicPID}" ]
  then
    echo "   Could not find the needed LICMGR processes running, exiting!"
    exit 4
  else
    echo "   License Manager with PID [${licPID}] with child [${swiLicPID}] are running"
  fi
  
  exit 0
  
}

check_stopped()
{
  #mbk need to find running processes 
  # /bin/sh /opt/asr/Nuance/Common/x86/bin/run watcher-daemon
  #    child watcher-daemon  ( watcher-daemon watcher.Modules=snmp wm.snmp.MibDirs=/opt/asr/Nuance/Common/data/mibs watcher.DaemonBroadcastAddress=127.0.0.1)  
  #    
      #nuance    3309  3308  0 Sep17 ?        00:45:01 watcher-daemon watcher.Modules=snmp wm.snmp.MibDirs=/opt/asr/Nuance/Common/data/mibs watcher.DaemonBroadcastAddress=127.0.0.1
      #nuance    3379  3309  0 Sep17 ?        00:16:12 fta config.ServiceID=cd12969d-0a22-2213-02da-788b5a4079a5 config.LoggingLevel=STATUS config.ManagementStationHost=localhost:8080
      #nuance    3390  3309  0 Sep17 ?        00:44:51 nuance-server -servlet nrs -port 8200 -DDiagFileName=/var/local/Nuance/system/diagnosticLogs/nrs1.log -DSWIUSERCFG=/var/local/Nuance/system/config/User-nrs01.xml config.ServiceID=cd1296c3-0a22-2213-02da-788b8db6c7ab config.LoggingLevel=STATUS -nthreads 96 config.ManagementStationHost=localhost:8080
      #nuance    3533  3309  0 Sep17 ?        00:21:29 nuance-server -servlet nvs -port 9200 -DDiagFileName=/var/local/Nuance/system/diagnosticLogs/nvs-server1.log nserver.nvs.VocalizerUserCfgFile=/var/local/Nuance/system/config/User-nvs01.xml config.ServiceID=cd1296ba-0a22-2213-02da-788be4ca7b01 config.LoggingLevel=STATUS config.ManagementStationHost=localhost:8080
      #nuance    3637  3309  1 Sep17 ?        14:27:43 NSSserver -u /var/local/Nuance/system/config/User_nss01.txt config.ServiceID=cd1296d5-0a22-2213-02da-788b999d0277 config.LoggingLevel=STATUS config.ManagementStationHost=localhost:8080
  #
  #
  # lmgrd with 1 child process (swilmgrd)
  #   
       #root      1107     1  0 Oct09 ?        00:00:07 /opt/asr/Nuance/license_manager/components/lmgrd -c /opt/asr/Nuance/Nuance/uapp3372p.lic -l /opt/asr/Nuance/license_manager/license/nuance-licmgr.log
       #root      1112  1107  0 Oct09 ?        00:01:12 swilmgrd -T uapp3372p.bsc.bscal.com 11.14 3 -c :/opt/asr/Nuance/Nuance/uapp3372p.lic: -srv dOggvqwT0MKNEyJFrpLLGHSNygy1VruxX1Ekm23jk9Ng0EymXz9ejWOy2hE0v8j --lmgrd_start 5f80fa18 -vdrestart 0

  lic_check=`/bin/systemctl is-active nuance-licmgr.service`
  lic_rc=$?
  watch_check=`/bin/systemctl is-active nuance-watcher.service`
  watch_rc=$?

  #mbk checking primary way...
  if [ ${lic_rc} -eq 0 ] && [ "${lic_check}" == "inactive" ]
  then
    echo "   SystemD states nuance-licmgr.service is stopped"
  else
    echo "   ERROR: SystemD states that nuance-licmgr.service is running, exiting!"
    exit 1
  fi
  if [ ${watch_rc} -eq 0 ] && [ "${watch_check}" == "inactive" ]
  then
    echo "   SystemD states nuance-watcher.service is stopped"
  else
    echo "   ERROR: SystemD states that nuance-watcher.service is running, exiting!"
    exit 5
  fi

  #mbk secondary checks below
  watchPID=$(ps -ef | grep -v grep | grep "watcher-daemon" | awk '{print $2}' | head -1)
  if [ -z "${watchPID}" ]
  then
    echo "    MAIN Watch Dog is not running"
  else
    echo "    ERROR: Found processes running for the Watch Dog Service, exiting"
    exit 6
  fi

  
  #Check License Manager
  licPID=$(ps -ef | grep -v grep | grep "lmgrd" | awk '{print $2}' | head -1)
  
  if [ -z "${licPID}" ] 
  then
    echo "   License Manager is not running"
  else
    echo "   License Manager with PID [${licPID}] is running and should not be, exiting!"
    exit 7
  fi
  
  exit 0
  
}

ssh_cmd()
{
  ssh_command="${1}"
  remote_host="${2}"
  if [ -z "${ssh_command}" ] || [ -z "${remote_host}" ]
  then
    log_msg "ERROR: A required parameter was not passed to ssh_cmd function, exiting!"
    exit 55
  fi
  
  ssh ${CURR_USER}@${remote_host} "${ssh_command}" | tee -a ${LOGFILE} 2>&1
  rc=${PIPESTATUS[0]}
  if [ ${rc} -eq 0 ]
  then
    log_msg "Success on remote SSH for ${remote_host}."
  else
    log_msg "ERROR: Server ${remote_host} SSH command returned exit code [${rc}]!"
	exit ${rc}
  fi
}
#########################################################################


#lets get the CMDB info
get-CMDB-Info

log_msg "Completed CMDB gathering..."

for checkServer in $(echo "${serverArray}")
do
  log_msg "Working on checking server ${checkServer}"
  #MBK for either running/stopped 
  if [ "${state}" == "running" ]
  then
    Command="$(typeset -f check_running); check_running"
    ssh_cmd "${Command}" "${checkServer}"
  else
    Command="$(typeset -f check_stopped); check_stopped"
    ssh_cmd "${Command}" "${checkServer}"
  fi
done


log_msg "#******************************************************************************************"
log_msg "Successfully Completed ${APPLNAME} for ${state} action on environment ${environment}"
log_msg "#******************************************************************************************"


END_DATE_TIME=$(date +%d-%b-%H:%M)

log_msg "Script ended at ${END_DATE_TIME}"

exit 0