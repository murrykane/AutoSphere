#!/bin/sh

value=`cat /etc/virtualimage.properties | grep WAS_PROFILE_ROOT | cut -d'=' -f2`
dmgrValue=`echo $value | cut -d'/' -f6`
echo $dmgrValue
instance=/opt/jenkins/AutoSphere/ant_tasks/sphere.xml

sed -i "s/wasdmgrprofilevalue/$dmgrValue/g" $instance
