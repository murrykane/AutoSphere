#! /bin/bash

wim_control() {
        echo "1st argument wim"
        agentCMD="wim-agent.sh"
        if [ $envFLAG -eq 1 ]; then
              out=$(/opt/IBM/WebSphere/apm/agent/bin/$agentCMD status)
              path="/opt/IBM/WebSphere"
        else
              out=$(/apps/WEBN*/apm/agent/bin/$agentCMD status)
              path="/apps/WEB*"
        fi
        instance=$out
        substring=$(echo $instance | awk '{ print $4 }');
        echo "Instance Name: $substring";

        if [ '$substring' ]; then
                {
                $path/apm/agent/bin/$agentCMD $action $substring;
                } || {
                echo "$agentCMD not found in this server!"
                exit
                }
        else
             echo "No instance found . ."
             exit
        fi
}

http_control() {
        echo "1st argument http"
        agentCMD="http_server-agent.sh"
        if [ $envFLAG -eq 1 ]; then
               path="/opt/IBM/WebSphere"
        else
               path="/apps/WEB*"
        fi
              {
              $path/apm/agent/bin/$agentCMD $action;
              } || {
              echo "$agentCMD not found in this server!"
              exit
              }
}

was_control() {
        echo "1st argument was"
        agentCMD="was-agent.sh"
             if [ $envFLAG -eq 1 ]; then
                   path="/opt/IBM/WebSphere"
             else
                   path="/apps/WEB*"

             fi
                  {
                   $path/apm/agent/bin/$agentCMD $action;
                  } || {
                   echo "$agentCMD not found in this server!"
                   exit
                  }
}

# ---------------------------------------------------------------

if [ $# -eq 2 ]; then
    name=$1
    action=$2
    # check environment
    if [ -f "/etc/virtualimage.properties" ];then
         echo "Environment: Rebuild";
         envFLAG=1
    else
         echo "Environment: Legacy";
         envFLAG=0
    fi 
        
    case $action in
         stop)
             echo "Action: stop"
         ;;
         start)
             echo "Action: start"
         ;;
         *)
             echo "Unrecognized entry [start or stop]"
             exit
         ;;
    esac

    case $name in
         wim)
                wim_control 
         ;;
         http)
                http_control 
         ;;
         was)
                was_control 
         ;;
         *)
             echo "Unsupported agentNAme [wim, http or was]"
             exit
         ;;
    esac
    presentDirectory=$(pwd)
    echo "done"
else
    echo "Usage:"
    echo "Required 2 arguments [agentName and action [stop or start]";

fi


