#!/bin/sh

. /etc/virtualimage.properties
homeDir=/opt/jenkins/AutoSphere/shell
javaDir=$WAS_INSTALL_ROOT/java/jre/lib/security/

echo $WAS_INSTALL_ROOT
cp $homeDir/lib/*.jar $javaDir

echo ${DMGR_HOST}
/usr/bin/expect  <<EOD
set timeout -1
spawn ssh -q -o StrictHostKeyChecking=no $PORTAL_ADMIN_USER@$DMGR_HOST
expect  "*assword: "
send "$PORTAL_PASSWORD\r"
expect "$ "
send " cp $homeDir/lib/*.jar $javaDir \r "
expect "$ "
send "exit\r"
EOD
