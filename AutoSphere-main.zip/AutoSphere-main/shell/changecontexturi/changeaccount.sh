#!/bin/sh

. /etc/virtualimage.properties

value=$1
instance="$2".xml
if [ $value = "on" ];then
echo "changing the xml admin account details"
echo $value
echo "$instance"
cp $instance "$instance".orig
sed -i "s/$ldapadminuserid/virtuser/g" $instance
sed -i "s/{xor}aQ0yZhxobDttGj5oazlrHg==/{xor}Lz4sLCgwLTs=/g" $instance
else 
echo " changing the xml back to point to $ldapadminuserid "
cp "$instance".orig $instance
rm "$instance".orig
fi
