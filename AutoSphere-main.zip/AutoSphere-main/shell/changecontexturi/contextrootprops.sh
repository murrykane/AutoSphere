#!/bin/sh
. /etc/virtualimage.properties
echo set context root properties in ConfigEngine

cd $WAS_PROFILE_ROOT/ConfigEngine

./ConfigEngine.sh -DparentProperties=/opt/jenkins/AutoSphere/shell/changecontexturi/contextrootprops.properties

