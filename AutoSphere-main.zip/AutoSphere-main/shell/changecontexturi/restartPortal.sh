#!/bin/sh
. /etc/virtualimage.properties

echo $DMGR_USERID $WAS_password
cd $WAS_PROFILE_ROOT/bin

if [ "$PRIMARY" = "true" ] ; then
./stopServer.sh WebSphere_Portal -username $DMGR_USERID -password $WAS_password
./startServer.sh WebSphere_Portal
else
./stopServer.sh WebSphere_Portal_$NODE_NAME -username $DMGR_USERID -password $WAS1_password
./startServer.sh WebSphere_Portal_$NODE_NAME
fi
