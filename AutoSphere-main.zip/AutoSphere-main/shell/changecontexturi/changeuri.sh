#!/bin/sh
. /etc/virtualimage.properties

if [[ !$PRIMARY ]] ; then
  if [[ $NODE_NAME  =~ .*_1 ]];
   then
     SECONDARY=false
   else
     SECONDARY=true
   fi
fi


if [ "$PRIMARY" = "true" ] ; then


echo Stopping Portal Server
cd $WAS_PROFILE_ROOT/bin

./stopServer.sh WebSphere_Portal -username $PORTAL_USER -password $WAS_password
echo Stopped Portal Server

# Add Custom Property for JVM IPV4
echo changing directory to ConfigEngine
cd ../ConfigEngine
echo Changed directory to ConfigEngine
echo Execute Modify Servlet Path
echo $WpsContextRoot $WpsDefaultHome $WpsPersonalizedHome $WsrpContextRoot
./ConfigEngine.sh modify-servlet-path -DWasPassword=$WAS_password -DPortalAdminPwd=$WAS_password -DWpsContextRoot=$WpsContextRoot  -DWpsDefaultHome=$WpsDefaultHome -DWpsPersonalizedHome=$WpsPersonalizedHome -DWsrpContextRoot=$WsrpContextRoot
echo Executed Modify Servlet Path
echo Execute Modify Servlet Path Portlets
echo $WpsContextRoot $WpsDefaultHome $WpsPersonalizedHome $WsrpContextRoot
./ConfigEngine.sh modify-servlet-path-portlets -DWasPassword=$WAS_password -DPortalAdminPwd=$WAS_password -DWpsContextRoot=$WpsContextRoot  -DWpsDefaultHome=$WpsDefaultHome -DWpsPersonalizedHome=$WpsPersonalizedHome -DWsrpContextRoot=$WsrpContextRoot
echo Executed  Modify Servlet Path Portlets
echo Execute create wcm Servlet Path
echo $WpsContextRoot $WpsDefaultHome $WpsPersonalizedHome $WsrpContextRoot
./ConfigEngine.sh create-wcm-servletpath-variables -DServerName=WebSphere_Portal -DWasPassword=$WAS_password -DWpsContextRoot=$WpsContextRoot  -DWpsDefaultHome=$WpsDefaultHome -DWpsPersonalizedHome=$WpsPersonalizedHome -DWsrpContextRoot=$WsrpContextRoot
echo Executed create wcm Servlet Path

echo Executing Register Nodetype commands

cd /opt/IBM/WebSphere/PortalServer/wcm/prereq.wcm/config/nodetypes

sed -i 's/action="register"/action="deregister"/g'  ibmcontentwcm.registernodetypes

cd $WAS_PROFILE_ROOT/ConfigEngine

./ConfigEngine.sh action-register-wcm-nodetypes -DWasPassword=$WAS_password  -DPortalAdminPwd=$WAS_password  -DWpsContextRoot=$WpsContextRoot  -DWpsDefaultHome=$WpsDefaultHome -DWpsPersonalizedHome=$WpsPersonalizedHome -DWsrpContextRoot=$WsrpContextRoot

cd /opt/IBM/WebSphere/PortalServer/wcm/prereq.wcm/config/nodetypes

sed -i 's/action="deregister"/action="register"/g'  ibmcontentwcm.registernodetypes

sed -i 's/wps/bsca\/bsc/g'  ibmcontentwcm.registernodetypes

cd $WAS_PROFILE_ROOT/ConfigEngine
./ConfigEngine.sh action-register-wcm-nodetypes -DWasPassword=$WAS_password  -DPortalAdminPwd=$WAS_password  -DWpsContextRoot=$WpsContextRoot  -DWpsDefaultHome=$WpsDefaultHome -DWpsPersonalizedHome=$WpsPersonalizedHome -DWsrpContextRoot=$WsrpContextRoot
echo Done executing register Nodetypes
#Register DMGR, Portaland nodeagent
$WAS_PROFILE_ROOT/bin/startServer.sh WebSphere_Portal

fi

if [[ "$PRIMARY" = "false" ]] && [[ "$SECONDARY" = "true" ]]; then
echo Stopping Portal Server on secondary Node
cd $WAS_PROFILE_ROOT/bin

./stopServer.sh WebSphere_Portal_$NODE_NAME -username $PORTAL_USER -password $WAS1_password
cd ../ConfigEngine
echo Executed create wcm Servlet Path
echo $WpsContextRoot $WpsDefaultHome $WpsPersonalizedHome $WsrpContextRoot
./ConfigEngine.sh create-wcm-servletpath-variables -DServerName=WebSphere_Portal_$NODE_NAME -DWasPassword=$WAS1_password -DWpsContextRoot=$WpsContextRoot  -DWpsDefaultHome=$WpsDefaultHome -DWpsPersonalizedHome=$WpsPersonalizedHome -DWsrpContextRoot=$WsrpContextRoot
echo Executed create wcm Servlet Path on secondary Node

$WAS_PROFILE_ROOT/bin/startServer.sh WebSphere_Portal_$NODE_NAME
fi

if [[ "$PRIMARY" = "false" ]] && [[ "$SECONDARY" = "false" ]]; then
echo Stopping Portal Server on Third Node
cd $WAS_PROFILE_ROOT/bin

./stopServer.sh WebSphere_Portal_$NODE_NAME -username $PORTAL_USER -password $WAS1_password
cd ../ConfigEngine
echo Executed create wcm Servlet Path
echo $WpsContextRoot $WpsDefaultHome $WpsPersonalizedHome $WsrpContextRoot
./ConfigEngine.sh create-wcm-servletpath-variables -DServerName=WebSphere_Portal_$NODE_NAME -DWasPassword=$WAS1_password -DWpsContextRoot=$WpsContextRoot  -DWpsDefaultHome=$WpsDefaultHome -DWpsPersonalizedHome=$WpsPersonalizedHome -DWsrpContextRoot=$WsrpContextRoot
echo Executed create wcm Servlet Path on secondary Node

$WAS_PROFILE_ROOT/bin/startServer.sh WebSphere_Portal_$NODE_NAME
fi
