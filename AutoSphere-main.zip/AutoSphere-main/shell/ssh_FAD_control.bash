#!/bin/bash
#
# Murry Kane
# Version 1.0
# ssh_FAD_control used to stop/start FAD IBM HTTP (Apache) web server services
#
#
# Modification History
# Who                 Date         Notes
#__________________________________________________________________________________________________
# Murry Kane          11/19/2018   Initial Version
#_________________________________________________________________________________________________

# source in the env setup script
if [ ! -z "${PROJ_PATH}" ]
then
  . ${PROJ_PATH}/shell/functions > /dev/null 2>&1
elif [ -s /opt/jenkins/AutoSphere/shell/functions ]
then
  . /opt/jenkins/AutoSphere/shell/functions > /dev/null 2>&1
elif [ -s /nfs/it-pam/scripts/functions ]
then
  . /nfs/it-pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/pam/scripts/functions ]
then
  . ~/pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/.mkane01/scripts/functions ]
then
  . ~/.mkane01/scripts/functions > /dev/null 2>&1
else
  echo "********************************************************************************"
  echo "*  ERROR: Can not define ENV as PROJ_PATH can't be found, exiting...."
  echo "********************************************************************************"
  exit 5
fi


APPLNAME="ssh_FAD_control"
eval LOGFILE=${NIGHTLY_LOG_DIR}/${APPLNAME}.${DATE_STAMP}.log
WASNAME="websphr"
ROOTUSER="root"
MBADMIN="mbadmin"
PAMADMIN="svcpam"
SREUSER="svcsre"
OPTIMUSER="svcoptim"
rc=0
shortSleep=2
mediumSleep=5
longSleep=10
checkScript="sudo /sbin/service websrvr_init status"
startScript="sudo /sbin/service websrvr_init start"
stopScript="sudo /sbin/service websrvr_init stop"

#set logging for Tidal/SDTOUT
set_logging Y

#########################################################################
# functions....

usage() { echo "Usage: $0 [-e <PROD|STAGE|WEBN34|WEBN33|WEBH72|WEBN35|WEBH71|WEBN52|WEBN51|WEBN208|etc...>] [-a <stop|start|status|restart|validatestop|validatestart]" 1>&2; exit 1; }

get-CMDB-Info()
{
  #https://blueshieldca.service-now.com/cmdb_rel_ci_list.do?sysparm_query=child.nameSTARTSWITHIBM%20HTTP%20Server%5Eparent.install_status%3D11%5Eparent.nameLIKEFind%20a%20Doctor%5Eparent.sys_class_name%3Dcmdb_ci_appl%5Echild.sys_class_name%3Dcmdb_ci_web_server%5Echild.install_status%3D11&sysparm_view=
  uri="${URL_INST}/api/now/table/cmdb_rel_ci?sysparm_query=child.nameSTARTSWITHIBM%20HTTP%20Server%5Eparent.install_status%3D11%5Eparent.nameSTARTSWITH${CMDBParentStr}Find%20a%20Doctor%5Eparent.sys_class_name%3Dcmdb_ci_appl%5Echild.sys_class_name%3Dcmdb_ci_web_server%5Echild.install_status%3D11&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=child&sysparm_limit=1000"
 
  log_msg "Using URL [${uri}]"
  querySNowApi "${uri}" "${snow_user}" "${snow_pass}" "${LOGFILE}"
  
  log_msg "CURL call returned: ${url_status}"
  
  if [ -z "${url_status}" ]
  then
    log_msg "Returned no rows for CMDB call, exiting!"
    exit 10
  fi

  status=$(tolower `echo "${url_status}" | awk -F':' '{print $4}' | awk -F',' '{print $1}' | awk -F'"' '{print $2}'`)
  error_code=$(echo "${url_status}" | awk -F':' '{print $5}' | awk -F',' '{print $1}' | awk -F'"' '{print $2}')
  log_msg "CURL return status is [${status}] with return code [${error_code}]"
  
  if [ "${error_code}" == "failure" ]
  then
    log_msg "Failure for CMDB call, please review the logs: exiting!"
    exit 12
  fi
  
  rows_returned=$(echo "${url_status}" | awk -F'"child":' '{print NF-1}')
  log_msg "Returned CI's from CDMB call is [${rows_returned}]"
  serverArray=''
  
  #check if returned rows is > 0
  
  if [ ${rows_returned} -gt 0 ]
  then
    log_msg "Result of CI's returned from CMDB is greater then 0"
  else
    log_msg "Result of CI's returned from CMDB is NOT greater then 0, exiting!"
    exit 13
  fi
  
  for (( i = 1; i <= ${rows_returned}; i++ ))
  do
    log_msg "Working on loop [${i}]"
    test=$(echo "${url_status}" | awk -F'{"result":' '{print $2}' | cut -d',' -f$i)
    log_msg "For loop [$i] found ${test}"
    server=$(echo "${test}" | cut -d'"' -f4 | cut -d@ -f2)
    log_msg "Server is ${server}"
    
    if [ -z "${server}" ]
    then
      log_msg "Something went wrong trying to parse the returned REST call for server name, exiting!"
      exit 14
    fi
    
    if [ -z "${serverArray}" ]
    then
      serverArray="${server}"
    else
      serverArray="${serverArray} ${server}"
    fi
  done
  
  log_msg "Server Array is [${serverArray}]"

}

get-cmdb-user()
{

  #lets get the username/passord ##################################################################
  #first source in the functions for SNOW
  if [ -s ${PAM_SHELL_DIR}/snow_functions ]
  then
    . ${PAM_SHELL_DIR}/snow_functions > /dev/null 2>&1
    #getURI Base
    getSNowInstance
    log_msg "Using URL Base [${URL_INST}]"
    if [ -z "${URL_INST}" ]
    then
      log_msg "Empty URL base for SNOW, exiting!"
      exit 6
    fi
    #now get the user/password
    getSNowCredential
    if [ -z "${snow_user}" ] || [ -z "${snow_pass}" ]
    then
      log_msg "We could not get the credentials for SNOW rest call, exiting!"
      exit 7
    fi
  else
    log_msg "SNOW functions could not be found [${PAM_SHELL_DIR}/snow_functions], exiting!"
    exit 4
  fi

  if [ -z "${snow_user}" ] || [ -z "${snow_pass}" ] 
  then
    log_msg "Could not identify user name and password, exiting!"
    exit 11
  fi

  log_msg "Found SNOW REST user string to be: [${snow_user}]"
  # done getting needed credentials ################################################################

}

ssh_cmd()
{
  ssh_command="${1}"
  remote_host="${2}"
  nohupCmd="${3}"
  combinedCmd=""
  rc=0
  
  if [ -z "${ssh_command}" ] || [ -z "${remote_host}" ]
  then
    log_msg "ERROR: A required parameter was not passed to ssh_cmd function, exiting!"
    exit 55
  fi

  if [ "${nohupCmd}" == "nohup" ]
  then
    combinedCmd="${nohupCmd} ${ssh_command} > /dev/null 2>&1 &"
    log_msg "Issuing the following command [${combinedCmd}] on server [${remote_host}]" 
    ssh ${remote_host} "${combinedCmd}"
    rc=$?
  else
    log_msg "Issuing the following command [${ssh_command}] on server [${remote_host}]" 
    response=$(ssh ${remote_host} "${ssh_command} 2>&1")
    rc=${PIPESTATUS[0]}
    combinedCmd="${ssh_command}"
  fi

  if [ ${rc} -eq 0 ]
  then
    log_msg "${response}"
  else
    log_msg "ERROR: Could NOT complete [${combinedCmd}] action for server [${remote_host}], exiting with RC = [${rc}]!"
    exit ${rc}
  fi
  return 0

}

ssh_cmd_status()
{
  ssh_command="${1}"
  remote_host="${2}"
  if [ -z "${ssh_command}" ] || [ -z "${remote_host}" ]
  then
    log_msg "ERROR: A required parameter was not passed to ssh_cmd function, exiting!"
    exit 55
  fi
  #log_msg "Issuing the following command [${ssh_command}] on server [${remote_host}]"
  ssh ${remote_host} "${ssh_command}" | tee -a ${LOGFILE} 2>&1
  rc=${PIPESTATUS[0]}
  if [ ${rc} -eq 0 ]
  then
    #log_msg "Successfully completed the SSH command for server [${remote_host}]"
    :
  else
    log_msg "INFO: Ignoring returned errors, use validatestart/validatestop to check return codes..."
    #exit ${rc}
  fi
  return 0

}

ssh_otherCmd()
{

  CMD="${1}"
  
  log_msg "----------------------------------------------------------------------------"
  for server in `echo ${serverArray}`
  do
    log_msg "Staring CMD functionality for server [${server}] with action [${CMD}]"
    if [ "${CMD}" == "validatestop" ]
    then
      ssh_cmd "${checkScript}" "${server}"
      #now check for response value
      state=$(echo "${response}" | cut -d'[' -f2 | cut -d']' -f1)
      if [ "${state}" != "NOT RUNNING" ]
      then
        log_msg "ERROR: The service (Currently [${state}]) is NOT in the correct state, exiting badly!"
        exit 25
      fi
    fi
    if [ "${CMD}" == "validatestart" ]
    then
      ssh_cmd "${checkScript}" "${server}"
      #now check for response value
      state=$(echo "${response}" | cut -d'[' -f2 | cut -d']' -f1)
      if [ "${state}" != "RUNNING" ]
      then
        log_msg "ERROR: The service (Currently [${state}]) is NOT in the correct state, exiting badly!"
        exit 26
      fi
    fi   
  done
  log_msg "----------------------------------------------------------------------------"
  return 0

}

start_servers()
{

  log_msg "----------------------------------------------------------------------------"
  log_msg "Starting START functionality for service [${startScript}]"
  for server in `echo ${serverArray}`
  do
    log_msg "Working on server: [${server}] for START Action on [${startScript}]"
    ssh_cmd "${startScript}" "${server}" "nohup"
  done
  log_msg "----------------------------------------------------------------------------"

  
  log_msg "Sleeping for [${longSleep}] seconds before continuing to allow all starts to complete..."
  sleep ${longSleep}
  
  return 0
  
}

stop_servers()
{

  log_msg "----------------------------------------------------------------------------"
  log_msg "Starting STOP functionality for service [${stopScript}]"
  for server in `echo ${serverArray}`
  do
    log_msg "Working on server: [${server}] for STOP Action on [${stopScript}]"
    ssh_cmd "${stopScript}" "${server}" "nohup"
  done
  log_msg "----------------------------------------------------------------------------"

  log_msg "Sleeping for [${longSleep}] seconds before continuing to allow all stops to complete..."
  sleep ${longSleep}
  
  return 0
  
}

check_servers()
{

  log_msg "----------------------------------------------------------------------------"
  log_msg "Starting STATUS functionality for service [${checkScript}]"
  for server in `echo ${serverArray}`
  do
    log_msg "Validating [${checkScript}] on Server... [${server}]"
    ssh_cmd_status "${checkScript}" "${server}"
  done
  log_msg "----------------------------------------------------------------------------"


}
#########################################################################

## MAIN ####
############
while getopts ":e:a:" o; do
    case "${o}" in
        e)
          env=$(toupper ${OPTARG})
          first3=${env:0:3}
          if [ ${env} == 'PROD' ] || [ ${env} == 'STAGE' ] || [ ${first3} == 'WEB' ]
          then
            #lets get the right lookup for CMDB 
            if [ ${env} == 'PROD' ]
            then
              CMDBParentStr=''
            elif [ ${env} == 'STAGE' ]
            then
              CMDBParentStr='WEBS01_'
            elif [ ${first3} == 'WEB' ]
            then
              CMDBParentStr="${env}_"
            else
              log_msg "The Value you supplied for environment is not KNOWN, exiting!"
              usage
            fi
          else
            #echo "e section"
            usage
          fi
          ;;
        a)
          action=$(tolower ${OPTARG})
          if [ ${action} == 'start' ] || [ ${action} == 'stop' ] || [ ${action} == 'status' ] || [ ${action} == 'restart' ] || [ ${action} == 'validatestop' ] || [ ${action} == 'validatestart' ] 
          then
            :
          else
            #echo "a section"
            usage
          fi
          ;;
        *)
            #echo "* section...."
            usage
            ;;
    esac
done
shift $((OPTIND-1))

#echo "env ${env} loc ${loc} action ${action}"
if [ -z "${env}" ] || [ -z "${action}" ]; then
    #echo "empty value...."
    usage
fi

if [ "${CURR_USER}" != "${WASNAME}" ] && [ "${SREUSER}" != "${CURR_USER}" ]
then
  log_msg "You must be ${WASNAME} or ${SREUSER} to execute this script, ABORTING!"
  chmod 666 ${LOGFILE} > /dev/null 2>&1
  exit 5
else
  log_msg "Running as user [${CURR_USER}]"
  log_msg "Environment = [${env}] and Action = [${action}]"
  chmod 666 ${LOGFILE} > /dev/null 2>&1
fi

#get CMDB User info
get-cmdb-user

#lets get the CMDB info
get-CMDB-Info

log_msg "Completed CMDB gathering..."

#actions.....
if [ ${action} == 'stop' ]
then
  stop_servers
elif [ ${action} == 'status' ]
then
  check_servers
elif [ ${action} == 'start' ]
then
  start_servers
elif [ ${action} == 'restart' ]
then
  stop_servers
  log_msg "Stop Completed, Sleeping for [${mediumSleep}] seconds before restart...."
  sleep ${mediumSleep}
  start_servers
elif [ ${action} == 'validatestop' ] || [ ${action} == 'validatestart' ] 
then
  ssh_otherCmd "${action}"
else
  usage
fi
rc=$?
if [ ${rc} -eq 0 ]
then
  log_msg "#*****************************************************"
  log_msg "Successfully Completed ${APPLNAME}"
  log_msg "#*****************************************************"
else
  log_msg "ERROR: Could NOT complete [${action}] action for servers [${serverArray}], exiting with RC = [${rc}]!"
  exit ${rc}
fi

exit 0
