#!/bin/bash
#
# Murry Kane
# Version 1.0
# MaintenanceStagingTable used to determine what applications are affected by a release weekend
#     - for instance is Linux Production Reboots being done
#     - is Oracle AIX patching being done
#     - is Oracle Linux patching being done 
#     - each of the above dictate if specific applications must be stopped or start after the relesae is done
#
# Modification History
# Who                 Date         Notes
#__________________________________________________________________________________________________
# Murry Kane          10/05/2020   Initial Version - This will be utility to either read from the staging table
#                                  or set something in the staging table after a job completes for an application start/stop
#__________________________________________________________________________________________________

# source in the env setup script
if [ ! -z "${PROJ_PATH}" ]
then
  . ${PROJ_PATH}/shell/functions > /dev/null 2>&1
elif [ -s /opt/jenkins/AutoSphere/shell/functions ]
then
  . /opt/jenkins/AutoSphere/shell/functions > /dev/null 2>&1
elif [ -s /nfs/it-pam/scripts/functions ]
then
  . /nfs/it-pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/pam/scripts/functions ]
then
  . ~/pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/.mkane01/scripts/functions ]
then
  . ~/.mkane01/scripts/functions > /dev/null 2>&1
else
  echo "********************************************************************************"
  echo "*  ERROR: Can not define ENV as PROJ_PATH can't be found, exiting...."
  echo "********************************************************************************"
  exit 5
fi

APPLNAME="MaintenanceStagingTable_control"
eval LOGFILE=${NIGHTLY_LOG_DIR}/${APPLNAME}.${DATETIME_STAMP}.log
WASNAME="websphr"
ROOTUSER="root"
SVCNAME="websphr"
SRENAME="svcsre"
rc=0
timeout=90
shortSleep=5
SLEEP_TIME=60
set_logging Y 
START_DATE_TIME=$(date +%d-%b-%H:%M) 

usage() { echo "Usage: $0 [-e <qa1|qa2|releasetest|opstest|breakfix|aip>] [-a <insert|update|read] [-t <STOPPORTAL|ORACLEAIX|LINUXREBOOT|AIPDB2|ORACLEAIPDB|ESBAIX|MEMBERPORTALUP|TESTCASESRUN>" 1>&2; exit 1; }

log_msg "Script started at ${START_DATE_TIME}"

while getopts ":e:a:t:" o; do
    case "${o}" in
        e)
          env=$(tolower ${OPTARG})
          if [ ${env} == 'aip' ] || [ ${env} == 'breakfix' ]  || [ ${env} == 'qa1' ] || [ ${env} == 'qa2' ] || [ ${env} == 'releasetest' ] || [ ${env} == 'breakfix' ] || [ ${env} == 'opstest' ]
          then
            :
          else
            usage
          fi
          ;;
        a)
          action=$(tolower ${OPTARG})
          if [ ${action} == 'insert' ] || [ ${action} == 'update' ] || [ ${action} == 'read' ]  
          then
            :
          else
            usage
          fi
          ;;
        t)
          type=$(toupper ${OPTARG})
          if [ ${type} == 'TESTCASESRUN' ] || [ ${type} == 'MEMBERPORTALUP' ] || [ ${type} == 'STOPPORTAL' ] || [ ${type} == 'ORACLEAIX' ] || [ ${type} == 'LINUXREBOOT' ] || [ ${type} == 'AIPDB2' ] || [ ${type} == 'ORACLEAIPDB' ] || [ ${type} == 'ESBAIX' ] || [ ${type} == 'TESTCASERUN' ]
          then  
            :
          else
            usage
          fi
          ;;
        *)
            usage
            ;;
    esac
done
shift $((OPTIND-1))

if [ -z "${env}" ] || [ -z "${action}" ]; then
    usage
fi

if [ "${CURR_USER}" != "${SVCNAME}" ]
then
  log_msg "You must be ${SVCNAME} to execute this script, ABORTING!"
  chmod 666 ${LOGFILE} 2>/dev/null
  exit 5
else
  log_msg "Running as user [${CURR_USER}]"
  log_msg "Environment = [${env}] and Action = [${action}]"
  chmod 666 ${LOGFILE} 2>/dev/null
fi

#if Production then set up cred's for production CURL otherwise NPE
if [ "${env}" == "aip" ]
then
  ESB="esbp01dp"
  ID="066a6eb2-5ab8-4f27-9c0f-489aee369516"
  TOKEN="I2xF6fU3wQ3cT1gW2mD2xJ5lE4lL8gG8cT7aN0tN3lP0lM7gQ0"
else
  ESB="esbhdp"
  ID="a83d1b0e-9159-42ef-b0b7-9987b59b084b"
  TOKEN="tS8pG1qM6uT8nM1nP4vD8dY6eY3sP5lU0fT3eW7aD0hK2tJ4jC"
fi


#########################################################################
# functions....
readTable()
{

  log_msg "Attempting request: Environment [${env}] Action [${action}] Type [${type}]"
  url_status=$(curl -k --request POST \
    --url https://${ESB}-api/private/${env}/api/bsc/gateway/readInfrProcessDowntime/v1 \
    --header 'content-type: application/json' \
    --header 'x-ibm-client-id: '${ID}'' \
    --header 'x-ibm-client-secret: '${TOKEN}'' \
    --data '{
      "requestHeader": {
          "consumer": {
              "name": "MEMBER",
              "id": "MEMBER",
              "businessUnit": "CHANNELS",
              "type": "INTERNAL",
              "clientVersion": "V1",
              "requestDateTime": "2020-01-01 01:36:05:331",
              "hostName": "nh00777.bsc.bscal.com",
              "businessTransactionType": "'${type}'",
              "contextId": "",
              "secondContextId": "",
              "thirdContextId": ""
          },
          "credentials": {
              "userName": "",
              "password": "",
              "token": "",
              "type": "jwt"
          },
          "transactionId": "c27eb29d-8c95-4e68-aa4d-6784c44c4863"
          }
  }' | tee -a ${LOGFILE} 2>&1) 
  rc=${PIPESTATUS[0]}
  
  log_msg ""
  if [ ${rc} -eq 0 ]
  then
    log_msg "No complete failure occurred for REST call"
  else
    log_msg "ERROR: Could NOT complete REST call action ${action} for environment ${env}, exiting with RC = ${rc}!"
    exit ${rc}
  fi
  
  log_msg "REST return is: ${url_status}"
  
  status=$(tolower `echo "${url_status}" | awk -F':' '{print $4}' | awk -F',' '{print $1}' | awk -F'"' '{print $2}'`)
  error_code=$(echo "${url_status}" | awk -F':' '{print $5}' | awk -F',' '{print $1}' | awk -F'"' '{print $2}')
  

  log_msg "REST return status is [${status}] with return code [${error_code}]"
  
  if [ "${status}" != "success" ] || [ "${error_code}" != "0" ]
  then
    log_msg "ERROR: REST call failed, exiting!" 
    exit 18
  else
    log_msg "Success, REST call completed succesfully"
  fi
  #REST return is: {"responseHeader":{"transactionNotification":{"status":"SUCCESS","statusCode":"0","responseDateTime":"2020-10-08 15:36:06:049","transactionId":"c27eb29d-8c95-4e68-aa4d-6784c44c4863","remarks":{"messages":[]}}},"responseBody":{"isFacetsDown":null,"isProcessComplete":"NO","isActive":"Y","attributes":[]}}
  responseBody=$(echo "${url_status}" | awk -F'"responseBody":' '{print $2}')
  isFacetsDown=$(echo "${responseBody}" | cut -d':' -f2 | cut -d',' -f1)
  isProcessComplete=$(echo "${responseBody}" | cut -d':' -f3 | cut -d',' -f1 | cut -d'"' -f2)
  isActive=$(echo "${responseBody}" | cut -d':' -f4 | cut -d',' -f1 | cut -d'"' -f2)
  log_msg "REST call stats: Completed [${isProcessComplete}] Active Flag is [${isActive}] Facets Down [${isFacetsDown}]"
  export RESTACTIONCOMPLETED=${isProcessComplete}
  export RESTSTATE=${isActive}
  export RESTFACETSDOWN=${isFacetsDown}

}

updateTable()
{
  
  log_msg "Attempting request: Environment [${env}] Action [${action}] Type [${type}]"
  url_status=$(curl -k --request POST \
    --url https://${ESB}-api/private/${env}/api/bsc/gateway/updateInfrProcessDowntime/v1 \
    --header 'content-type: application/json' \
    --header 'x-ibm-client-id: '${ID}'' \
    --header 'x-ibm-client-secret: '${TOKEN}'' \
    --data '{
      "requestHeader": {
          "consumer": {
              "name": "MEMBER",
              "id": "MEMBER",
              "businessUnit": "CHANNELS",
              "type": "INTERNAL",
              "clientVersion": "V1",
              "requestDateTime": "2020-01-01 01:36:05:331",
              "hostName": "nh00777.bsc.bscal.com",
              "businessTransactionType": "'${type}'",
              "contextId": "",
              "secondContextId": "",
              "thirdContextId": ""
          },
          "credentials": {
              "userName": "",
              "password": "",
              "token": "",
              "type": "jwt"
          },
          "transactionId": "c27eb29d-8c95-4e68-aa4d-6784c44c4863"
          }
  }' | tee -a ${LOGFILE} 2>&1) 
  rc=${PIPESTATUS[0]}
  
  log_msg ""
  if [ ${rc} -eq 0 ]
  then
    log_msg "No complete failure occurred for REST call"
  else
    log_msg "ERROR: Could NOT complete REST call action ${action} for environment ${env}, exiting with RC = ${rc}!"
    exit ${rc}
  fi
  
  log_msg "REST return is: ${url_status}"
  
  status=$(tolower `echo "${url_status}" | awk -F':' '{print $4}' | awk -F',' '{print $1}' | awk -F'"' '{print $2}'`)
  error_code=$(echo "${url_status}" | awk -F':' '{print $5}' | awk -F',' '{print $1}' | awk -F'"' '{print $2}')
  
  log_msg "REST return status is [${status}] with return code [${error_code}]"
  
  if [ "${status}" != "success" ] || [ "${error_code}" != "0" ] 
  then
    log_msg "ERROR: REST call failed, exiting!" 
    exit 19
  else
    log_msg "Success, REST call completed succesfully"
  fi
  #{"responseHeader":{"transactionNotification":{"status":"SUCCESS","statusCode":"0","responseDateTime":"2020-10-08 16:36:02:969","transactionId":"c27eb29d-8c95-4e68-aa4d-6784c44c4863","remarks":{"messages":[]}}},"responseBody":{"isFacetsDown":null,"isUpdateComplete":"YES","isActive":"N","attributes":[]}}

  responseBody=$(echo "${url_status}" | awk -F'"responseBody":' '{print $2}')
  isFacetsDown=$(echo "${responseBody}" | cut -d':' -f2 | cut -d',' -f1)
  isUpdateComplete=$(echo "${responseBody}" | cut -d':' -f3 | cut -d',' -f1 | cut -d'"' -f2)
  isActive=$(echo "${responseBody}" | cut -d':' -f4 | cut -d',' -f1 | cut -d'"' -f2)
  log_msg "REST call stats: Update Complete [${isUpdateComplete}] Active Flag is [${isActive}] Facets Down [${isFacetsDown}]"

}

insertTable()
{

  log_msg "Attempting request: Environment [${env}] Action [${action}] Type [${type}]"
  url_status=$(curl -k --request POST \
    --url https://${ESB}-api/private/${env}/api/bsc/gateway/insertInfrProcessDowntime/v1 \
    --header 'content-type: application/json' \
    --header 'x-ibm-client-id: '${ID}'' \
    --header 'x-ibm-client-secret: '${TOKEN}'' \
    --data '{
      "requestHeader": {
          "consumer": {
              "name": "MEMBER",
              "id": "MEMBER",
              "businessUnit": "CHANNELS",
              "type": "INTERNAL",
              "clientVersion": "V1",
              "requestDateTime": "2020-01-01 01:36:05:331",
              "hostName": "nh00777.bsc.bscal.com",
              "businessTransactionType": "'${type}'",
              "contextId": "",
              "secondContextId": "",
              "thirdContextId": ""
          },
          "credentials": {
              "userName": "",
              "password": "",
              "token": "",
              "type": "jwt"
          },
          "transactionId": "c27eb29d-8c95-4e68-aa4d-6784c44c4863"
          }
  }' | tee -a ${LOGFILE} 2>&1) 
  rc=${PIPESTATUS[0]}
  
  log_msg ""
  if [ ${rc} -eq 0 ]
  then
    log_msg "No complete failure occurred for REST call"
  else
    log_msg "ERROR: Could NOT complete REST call action ${action} for environment ${env}, exiting with RC = ${rc}!"
    exit ${rc}
  fi
  
  log_msg "REST return is: ${url_status}"
  
  status=$(tolower `echo "${url_status}" | awk -F':' '{print $4}' | awk -F',' '{print $1}' | awk -F'"' '{print $2}'`)
  error_code=$(echo "${url_status}" | awk -F':' '{print $5}' | awk -F',' '{print $1}' | awk -F'"' '{print $2}')
  
  log_msg "REST return status is [${status}] with return code [${error_code}]"
  
  if [ "${status}" != "success" ] || [ "${error_code}" != "0" ] 
  then
    log_msg "ERROR: REST call failed, exiting!" 
    exit 19
  else
    log_msg "Success, REST call completed succesfully"
  fi

  responseBody=$(echo "${url_status}" | awk -F'"responseBody":' '{print $2}')
  isFacetsDown=$(echo "${responseBody}" | cut -d':' -f2 | cut -d',' -f1)
  isInsertComplete=$(echo "${responseBody}" | cut -d':' -f3 | cut -d',' -f1 | cut -d'"' -f2)
  isActive=$(echo "${responseBody}" | cut -d':' -f4 | cut -d',' -f1 | cut -d'"' -f2)
  log_msg "REST call response: Insert Complete [${isInsertComplete}] Active Flag is [${isActive}] Facets Down [${isFacetsDown}]"

}

log_msg "Determing action to take"

if [ ${action} == 'insert' ]
then
  insertTable
elif [ ${action} == 'read' ]
then
  readTable
elif [ ${action} == 'update' ]
then
  updateTable
else
  usage
fi


log_msg "#*********************************************************************************"
log_msg "Successfully Completed ${APPLNAME} for ${action} action on environment ${env}"
log_msg "#*********************************************************************************"


END_DATE_TIME=$(date +%d-%b-%H:%M)

log_msg "Script ended at ${END_DATE_TIME}"

exit 0