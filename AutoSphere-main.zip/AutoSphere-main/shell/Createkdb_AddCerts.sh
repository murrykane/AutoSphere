#!/usr/bin/env bash

####################################################################################################
#1. Create certs folder in /opt/IBM/WebSphere/HTTPServer
#	a. mkdir /opt/IBM/WebSphere/HTTPServer/certs
#2. Create the cert with the name <conf file name eg: ws1-pimsh07>.bsc.bscal.com 
#	a. Copy F5 cert to /tmp on webserver
#	b. Copy webserver cert to /tmp on webserver
#3. Run this script to create kdb and to add certs to kdb
####################################################################################################


conf=${1?Error: Correct format: createkdb.sh <webserver conf file name w/o .conf extension> <F5 eg-pims-uat1.bsc.bscal.com>}
F5=${2?Error: Correct format: createkdb.sh <webserver conf file name w/o .conf extension> <F5 eg-pims-uat1.bsc.bscal.com>}

FILE=/tmp/$conf.bsc.bscal.com.pfx
if [ -f "$FILE" ]; then
    echo "$conf.bsc.bscal.com.pfx exist"
else
    echo "Error: Copy the cert $conf.bsc.bscal.com.pfx to /tmp"
    exit 1
fi

FILE=/tmp/$F5.cer
if [ -f "$FILE" ]; then
    echo "$F5.cer exist"
else
    echo "Error: Copy the cert $F5.cer to /tmp"
    exit 2
fi

#Create KDB
/opt/IBM/WebSphere/HTTPServer/bin/gskcmd -keydb -create -db /opt/IBM/WebSphere/HTTPServer/certs/$conf.kdb -pw Welcome1 -type cms -stash
echo "########################################"
echo "$conf.kdb KDB Created"
echo "########################################"

FILE=/opt/IBM/WebSphere/HTTPServer/certs/$conf.kdb
if [ -f "$FILE" ]; then
    echo "$conf.kdb exist"
else
    echo "Error: Create $conf.kdb"
    exit 3
fi

/opt/IBM/WebSphere/HTTPServer/bin/gskcmd -cert -import -db /tmp/$conf.bsc.bscal.com.pfx -pw Welcomeblueshield@1 -label $conf.bsc.bscal.com -type pkcs12 -target /opt/IBM/WebSphere/HTTPServer/certs/$conf.kdb -target_pw Welcome1 -target_type cms
echo "########################################"
echo "$conf.bsc.bscal.com Cert added to Webserver configuration"
echo "########################################"

/opt/IBM/WebSphere/HTTPServer/bin/gskcmd -cert -add -db /opt/IBM/WebSphere/HTTPServer/certs/$conf.kdb -file /tmp/$F5.cer -pw Welcome1 -label $F5
echo "########################################"
echo "$F5.cer cert added to webserver configuration"
echo "########################################"

echo "########################################"
echo "List of certificates in KeyDatabase"
echo "########################################"
/opt/IBM/WebSphere/HTTPServer/bin/gskcmd -cert -list all -db /opt/IBM/WebSphere/HTTPServer/certs/$conf.kdb -pw Welcome1

