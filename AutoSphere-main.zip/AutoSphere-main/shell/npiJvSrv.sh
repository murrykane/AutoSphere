#! /bin/bash
#
#=============================================================================================================
# Author: Jeffrey Apiado
# Role: start or stop JVM application
# Created: 02/16/2018
# Owner: IT-NPE-WEB Team
# CONSTANTS ***************************************************************************************************
npiScriptDirectory="/npi/InitiateSystems/Engine10.1.0/Brokers10.1.0/scripts"
npiMPINET="/npi/InitiateSystems/Engine10.1.0/identity_hub/inst/mpinet_identity_hub/conf/mpinet_identity_hub.sh"
declare -a arr=("BSCInbound" "BSCInboundSA")
##*************************************************************************************************************
javaApps_stop() {
        output=$($npiMPINET stop);
        echo $output;
        file="/tmp/jvmNpistop.properties"       
        for i in ${arr[@]}; do
            echo "Instance Name: $i"
            echo "Action: Stopping"
            echo $i > $file
            changeDir "stop" $file
        done
        # Kill remaining npiadm process if exist!
        ps -ef | sed -n '/npi\/InitiateSystems/p' | awk '{print $2}' | xargs kill > /dev/null 2>&1
}


javaApps_start() {
        output=$($npiMPINET start);
        echo $output;
        file="/tmp/jvmNpistart.properties"
        for i in ${arr[@]}; do
            echo "Instance Name: $i"
            echo "Action: Starting"
            echo $i > $file
            changeDir "start" $file
        done
}

changeDir() {
       cd $npiScriptDirectory    
       action=$1
       FILE=$2
       echo "[command: madconfig.sh $action_inbound_msgreader_instance < $FILE .................. MSGREADER]"
       msgreader=$(./madconfig.sh $action_inbound_msgreader_instance < $FILE)
       echo $msgreader
       echo "[command: madconfig.sh $action_inbound_msgbroker_instance < $FILE ....................MSGBROKER]"
       msgbroker=$(./madconfig.sh $action_inbound_msgbroker_instance < $FILE)
       echo $msgbroker
}

#===============================================================================================================
if [ $# -eq 1 ]; then
    cmd=$1
    case $cmd in
        stop)
             echo "[STOPPING.....]"
             javaApps_stop

        ;;
        start)
             echo "[STARTING.....]"
             javaApps_start
        ;;
        *)
            echo "Unsupported argument[stop ot start]"
            exit
     esac

else
   echo "Usage==============================================="
   echo "Syntax ./<script_name.sh> <argument:[stop or start]>"
   echo "===================================================="
fi

    
