#!/bin/bash
#
# Hung Ly
# Version 1.0
# ssh_springBatchJob_restart used to restart java processes 
#
#
# Modification History
# Who                 Date         Notes
#__________________________________________________________________________________________________
# Hung Ly          03/04/2022   Initial Version
#__________________________________________________________________________________________________

# source in the env setup script
if [ ! -z "${PROJ_PATH}" ]
then
  . ${PROJ_PATH}/shell/functions > /dev/null 2>&1
elif [ -s /opt/jenkins/AutoSphere/shell/functions ]
then
  . /opt/jenkins/AutoSphere/shell/functions > /dev/null 2>&1
elif [ -s /nfs/it-pam/scripts/functions ]
then
  . /nfs/it-pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/pam/scripts/functions ]
then
  . ~/pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/.mkane01/scripts/functions ]
then
  . ~/.mkane01/scripts/functions > /dev/null 2>&1
else
  echo "********************************************************************************"
  echo "*  ERROR: Can not define ENV as PROJ_PATH can't be found, exiting...."
  echo "********************************************************************************"
  exit 5
fi


APPLNAME="ssh_springBatchJob_restart"
eval LOGFILE=${NIGHTLY_LOG_DIR}/${APPLNAME}.${DATE_STAMP}.log
SREADMIN="svcsre"
rc=0
set_logging Y
serverName=$(hostname)

log_msg "Script is running on server [${serverName}]"


usage() { 
  echo "Usage: $0 [-s <hostname>] [-c <command>]" 1>&2
  exit 1
}

#########################################################################
# validation
while getopts ":s:c:" o; do
    case "${o}" in
        s)
          host=$(tolower ${OPTARG})
          if [ ${host} == 'uapp4100h' ] || [ ${host} == 'uapp4406p' ]
          then
            :
          else
            log_msg "Failed Hostname Verification"
            usage
          fi
          ;;
        c)
          command="${OPTARG}"
          if [[ "${command}" == "java -Xmx4048m -verbose:gc -jar"* ]] || [[ "${command}" == "/usr/bin/java -Xmx4048m -verbose:gc -jar"* ]]
          then
            :
          else
            log_msg "Failed Command Verification"
            usage
          fi
          ;;
        *)
          log_msg "Error:  Found Unexpected flag in command line!"
          usage
          ;;
    esac
done
shift "$((OPTIND-1))"

log_msg "Started command line variable verification"

if [ -z "${host}" ] || [ -z "${command}" ]; then
    usage
fi

log_msg "Completed command line variable verification"

if [ "${CURR_USER}" != "${SREADMIN}" ]
then
  log_msg "Running as user [${CURR_USER}]"
  log_msg "You must be ${SREADMIN} to execute this script, ABORTING!"
  #chmod 775 logfile
  chmod 666 ${LOGFILE} > /dev/null 2>&1
  exit 5
else
  log_msg "Running as user [${CURR_USER}]"
  log_msg "SSH to host: [${host}] and Command: [${command}]"
  #chmod 775 logfile
  chmod 666 ${LOGFILE} > /dev/null 2>&1
fi


#########################################################################
# functions....
validate_running()
{
  log_msg "Process Validation"
  remote_host="${1}"
  ssh_command="${2}"
  pId=$(ssh ${SREADMIN}@${remote_host} ps -ef | grep "${ssh_command}" |  grep -v 'root' | grep -v 'grep' | awk '{ printf $2 }')
  log_msg "Process ID is $pId.."
  if [[ -n "$pId" ]]
  then
    log_msg "..is running"
    return 0
  else
    log_msg "..is not running"
    return 1
  fi
}

ssh_cmd()
{  
  remote_host="${1}"
  ssh_command="${2}"
  combinedCmd=""
  rc=0
  acceptableRC=0
  
  if [ -z "${ssh_command}" ] || [ -z "${remote_host}" ]
  then
    log_msg "ERROR: A required parameter was not passed to ssh_cmd function, exiting!"
    exit 55
  fi
  
  log_msg "Issuing the following command [${ssh_command}] on server [${remote_host}]" 
  if [[ "${command}" == "java -Xmx4048m -verbose:gc -jar"* ]]
  then
	full_command="sudo -u svcspring /usr/bin/${ssh_command} &"
  else
    full_command="sudo -u svcspring ${ssh_command} &"
  fi
  timeout 60 ssh ${SREADMIN}@${remote_host} "${full_command}" | tee -a ${LOGFILE} 2>&1
  sshexit=${PIPESTATUS[0]}
  
  combinedCmd="ssh ${SREADMIN}@${remote_host} ${full_command}"
  
  validate_running ${remote_host} "${ssh_command}"
  rc=$?
  
  if [ ${rc} -eq ${acceptableRC} ]
  then
    log_msg "Successfully completed the SSH command for server [${remote_host}] with RC = [${rc}]"
  else
	rc=${sshexit}
    log_msg "ERROR: Expected return code [${acceptableRC}], received return code [${rc}]!"
    log_msg "ERROR: Could NOT complete command [${combinedCmd}] on server [${remote_host}], exiting with RC = [${rc}]!"
    exit ${rc}
  fi
  return 0

}

#########################################################################

##MAIN 
validate_running ${host} "${command}"
rc=$?
if [ ${rc} -eq 0 ]
then
  log_msg "#*****************************************************"
  log_msg "Completed ${APPLNAME}."
  log_msg "#*****************************************************"
  exit 0
fi  
 
ssh_cmd ${host} "${command}"

rc=$?
if [ ${rc} -eq 0 ]
then
  log_msg "#*****************************************************"
  log_msg "Successfully Completed ${APPLNAME}"
  log_msg "#*****************************************************"
else
  log_msg "ERROR: Could NOT complete command [${command}] on server [${host}], exiting with RC = [${rc}]!"
  exit ${rc}
fi

exit 0
