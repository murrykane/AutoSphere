#!/bin/bash
#
# Murry Kane
# Version 1.0
# websphere_action.sh - Used to SSH to a user prompted server with action (stop|start|restart) to call the websphere_init script with nohup 
#                       This will allow you to issue the websphere_init script on many servers quickly
#
# Modification History
# Who                 Date         Notes
#__________________________________________________________________________________________________
# Murry Kane          06/20/2017   Initial Version
# Murry Kane          11/02/2017   Added logic to allow restartforce and other options
#__________________________________________________________________________________________________

# source in the env setup script
if [ ! -z "${PROJ_PATH}" ]
then
  . ${PROJ_PATH}/shell/functions > /dev/null 2>&1
elif [ -s /opt/jenkins/AutoSphere/shell/functions ]
then
  . /opt/jenkins/AutoSphere/shell/functions > /dev/null 2>&1
elif [ -s /nfs/it-pam/scripts/functions ]
then
  . /nfs/it-pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/pam/scripts/functions ]
then
  . ~/pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/.mkane01/scripts/functions ]
then
  . ~/.mkane01/scripts/functions > /dev/null 2>&1
else
  echo "********************************************************************************"
  echo "*  ERROR: Can not define ENV as PROJ_PATH can't be found, exiting...."
  echo "********************************************************************************"
  exit 5
fi


APPLNAME="websphere_action.sh"
eval LOGFILE=${NIGHTLY_LOG_DIR}/${APPLNAME}.${DATE_STAMP}.log
WASNAME="websphr"
ROOTUSER="root"
rc=0


usage() { echo "Usage: $0" ; exit 1; }

ssh_cmd()
{
  hostname="${1}"
  action="${2}"
  if [ -z "${hostname}" ] || [ -z "${action}" ]
  then
    log_msg "ERROR: A required parameter was not passed to function, exiting!"
    exit 55
  fi
  ssh ${hostname} 'bash -c "( ( nohup sudo /sbin/service websphere_init '"${action}"' &>/dev/null ) & )"'
  rc=$?
  if [ ${rc} -eq 0 ]
  then
    log_msg "Successfully completed the SSH command for server [${hostname}] with action [${action}]"
  else
    log_msg "ERROR: Could NOT complete action for server [${hostname}], exiting with RC = [${rc}]!"
    exit ${rc}
  fi
  return 0

}

while true; do
  echo "Please Enter the Host to work on(empty to exit): "
  read hostname
  if [ -z "${hostname}" ]
  then
    log_msg "All done"
    break
  else
    while true; do
      read -p "Please enter an action to issue for WebSphere(start|stop|force|restart|forcerestart|status|removelock|addlock|addpid|removepid|lockstatus): " value
      value=`echo "${value}" | tr '[:upper:]' '[:lower:]'`
      case ${value} in
        start) ssh_cmd ${hostname} ${value}; break;;
        stop) ssh_cmd ${hostname} ${value}; break;;
        restart) ssh_cmd ${hostname} ${value};break;;
        force) ssh_cmd ${hostname} ${value};break;;
        forcerestart) ssh_cmd ${hostname} ${value};break;;
        status) ssh_cmd ${hostname} ${value};break;;
        removelock) ssh_cmd ${hostname} ${value};break;;
        addlock) ssh_cmd ${hostname} ${value};break;;
        addpid) ssh_cmd ${hostname} ${value};break;;
        removepid) ssh_cmd ${hostname} ${value};break;;
        lockstatus) ssh_cmd ${hostname} ${value};break;;
        *) echo "Please request [start|stop|force|restart|forcerestart|status|removelock|addlock|addpid|removepid|lockstatus] only!";;
      esac
    done
  fi
done
