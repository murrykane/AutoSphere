#!/bin/bash
#
# Murry Kane
# Version 1.0
# Validate_IVR-WebsphereClusters.bash used to validate a given state of the WebSphere clusters for IVR/VRU
#
# Modification History
# Who                 Date         Notes
#__________________________________________________________________________________________________
# Murry Kane          09/09/2020   Initial Version
#__________________________________________________________________________________________________
#

# source in the env setup script
if [ ! -z "${PROJ_PATH}" ]
then
  . ${PROJ_PATH}/shell/functions > /dev/null 2>&1
elif [ -s /opt/jenkins/AutoSphere/shell/functions ]
then
  . /opt/jenkins/AutoSphere/shell/functions > /dev/null 2>&1
elif [ -s /nfs/it-pam/scripts/functions ]
then
  . /nfs/it-pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/pam/scripts/functions ]
then
  . ~/pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/.mkane01/scripts/functions ]
then
  . ~/.mkane01/scripts/functions > /dev/null 2>&1
else
  echo "********************************************************************************"
  echo "*  ERROR: Can not define ENV as PROJ_PATH can't be found, exiting...."
  echo "********************************************************************************"
  exit 5
fi

APPLNAME="Validate_IVR-WebsphereClusters"
eval LOGFILE=${NIGHTLY_LOG_DIR}/${APPLNAME}.${DATETIME_STAMP}.log
WASNAME="websphr"
ROOTUSER="root"
SVCNAME="websphr"
SRENAME="svcsre"

rc=0
set_logging Y 
START_DATE_TIME=$(date +%d-%b-%H:%M)
#user_str='snow_user'
#pass_str='snow_pass'
#key_str='snow_encryptKey'

usage() { echo "Usage: $0 [-s <websphere.cluster.running|websphere.cluster.stopped|websphere.cluster.partial>] [-e <environment Examples: VRUN31|VRUH72|VRUH63|VRUH70|INTERACTIVE>" 1>&2; exit 1; }

log_msg "Script started at ${START_DATE_TIME}"

while getopts ":s:e:" o; do
    case "${o}" in
        s)
          state=$(tolower ${OPTARG})
          if [ ${state} == 'websphere.cluster.running' ] || [ ${state} == 'websphere.cluster.stopped' ] || [ ${state} == 'websphere.cluster.partial' ]  
          then
            :
          else
            usage
          fi
          ;;
        e)
          environment=$(toupper ${OPTARG})
          echo "Using environment [${environment}]"
          ;;
        *)
            usage
            ;;
    esac
done
shift $((OPTIND-1))

if [ -z "${state}" ] ; then
    usage
fi

if [ -z "${environment}" ] 
then
  usage
fi

if [ "${CURR_USER}" != "${SRENAME}" ] && [ "${CURR_USER}" != "${WASNAME}" ]
then
  log_msg "You must be ${SRENAME} or ${WASNAME} to execute this script, ABORTING!"
  chmod 666 ${LOGFILE} 2>/dev/null
  exit 5
else
  log_msg "Running as user [${CURR_USER}]"
  log_msg "State to check is [${state}] for environment [${environment}]"
  chmod 666 ${LOGFILE} 2>/dev/null
fi

#lets get the username/passord
#first source in the functions for SNOW
if [ -s ${PAM_SHELL_DIR}/snow_functions ]
then
  . ${PAM_SHELL_DIR}/snow_functions > /dev/null 2>&1
  #getURI Base
  getSNowInstance
  log_msg "Using URL Base [${URL_INST}]"
  if [ -z "${URL_INST}" ]
  then
    log_msg "Empty URL base for SNOW, exiting!"
    exit 6
  fi
  #now get the user/password
  getSNowCredential
  if [ -z "${snow_user}" ] || [ -z "${snow_pass}" ]
  then
    log_msg "We could not get the credentials for SNOW rest call, exiting!"
    exit 7
  fi
else
  log_msg "SNOW functions could not be found(${PAM_SHELL_DIR}/snow_functions), exiting!"
  exit 4
fi

if [ -z "${snow_user}" ] || [ -z "${snow_pass}" ] 
then
  log_msg "Could not identify user name and password, exiting!"
  exit 11
fi

log_msg "Found SNOW REST user string to be: [${snow_user}]"
# done getting needed credentials

#########################################################################
# functions....
get-CMDB-Info()
{
  # from system UI
  #https://blueshieldca2015.service-now.com/cmdb_rel_ci_list.do?sysparm_query=parent.nameLIKEIVR-VRU%5Echild.nameSTARTSWITHdmgr%5Eparent.operational_status%3D1%5Echild.operational_status%3D1%5Eparent.nameSTARTSWITHVRUS01%5Eparent.install_status%3D11%5Echild.install_status%3D11&sysparm_view=
  uri="${URL_INST}/api/now/table/cmdb_rel_ci?sysparm_query=parent.nameLIKEIVR-VRU%5Echild.nameSTARTSWITHdmgr%40%5Eparent.nameSTARTSWITH${environment}%5Eparent.operational_status%3D1%5Echild.operational_status%3D1%5Eparent.install_status%3D11%5Echild.install_status%3D11&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=child&sysparm_limit=1000"
 
  log_msg "Using URL [${uri}]"
  querySNowApi "${uri}" "${snow_user}" "${snow_pass}" "${LOGFILE}"
  
  log_msg "CURL call returned: ${url_status}"
  
  if [ -z "${url_status}" ]
  then
    log_msg "Returned no rows for CMDB call, exiting!"
    exit 10
  fi

  status=$(tolower `echo "${url_status}" | awk -F':' '{print $4}' | awk -F',' '{print $1}' | awk -F'"' '{print $2}'`)
  error_code=$(echo "${url_status}" | awk -F':' '{print $5}' | awk -F',' '{print $1}' | awk -F'"' '{print $2}')
  log_msg "CURL return status is [${status}] with return code [${error_code}]"
  
  if [ "${error_code}" == "failure" ]
  then
    log_msg "Failure for CMDB call, please review the logs: exiting!"
    exit 12
  fi
  
  rows_returned=$(echo "${url_status}" | awk -F'"child":' '{print NF-1}')
  log_msg "Returned CI's from CDMB call is [${rows_returned}]"
  serverArray=''
  
  #check if returned rows is > 0
  
  if [ ${rows_returned} -gt 0 ]
  then
    log_msg "Result of CI's returned from CMDB is greater then 0"
  else
    log_msg "Result of CI's returned from CMDB is NOT greater then 0, exiting!"
    exit 13
  fi
  
  for (( i = 1; i <= ${rows_returned}; i++ ))
  do
    log_msg "Working on loop [${i}]"
    test=$(echo "${url_status}" | awk -F'{"result":' '{print $2}' | cut -d',' -f$i)
    log_msg "For loop [$i] found ${test}"
    server=$(echo "${test}" | cut -d'"' -f4 | cut -d@ -f2)
    log_msg "Server is ${server}"
    
    if [ -z "${server}" ]
    then
      log_msg "Something went wrong trying to parse the returned REST call for server name, exiting!"
      exit 14
    fi
    
    if [ -z "${serverArray}" ]
    then
      serverArray="${server}"
    else
      serverArray="${serverArray} ${server}"
    fi
  done
  
  log_msg "Server Array is [${serverArray}]"

}


#lets get the CMDB info
get-CMDB-Info

log_msg "Completed CMDB gathering..."

for checkServer in $(echo "${serverArray}")
do
  log_msg "Working on checking server ${checkServer}"
  #lets check the cluster for each DMGR
  ssh ${WASNAME}@${checkServer} "/opt/jenkins/AutoSphere/python/validateAllClusters.py --s ${state} &> /dev/stdout" | tee -a ${LOGFILE} 2>&1
  rc=${PIPESTATUS[0]}
  
  log_msg ""
  if [ ${rc} -eq 0 ]
  then
    log_msg "Validation of [$state}] for server [${checkServer}] completed successfully"
  else
    log_msg "ERROR: Could NOT complete validation for cluster on [${checkServer}] for state [${state}], exiting!"
    exit ${rc}
  fi
  
done


log_msg "#*********************************************************************************"
log_msg "Successfully Completed ${APPLNAME} for ${action} action on environment ${environment}"
log_msg "#*********************************************************************************"


END_DATE_TIME=$(date +%d-%b-%H:%M)

log_msg "Script ended at ${END_DATE_TIME}"

exit 0