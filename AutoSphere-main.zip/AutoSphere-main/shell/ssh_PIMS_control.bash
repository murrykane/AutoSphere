#!/bin/bash
#
# Murry Kane
# Version 1.0
# ssh_PIMS_control used to stop/start and clear PIMS index cache for PIMS application on PROD/NPE 
#            -  see usage for more detail
#
# Modification History
# Who                 Date         Notes
#__________________________________________________________________________________________________
# Murry Kane          04/13/2021   Initial Version
# Murry Kane          08/17/2021   Updated CMDB query lookup now that the CMDB has been cleaned up
#_________________________________________________________________________________________________

# source in the env setup script
if [ ! -z "${PROJ_PATH}" ]
then
  . ${PROJ_PATH}/shell/functions > /dev/null 2>&1
elif [ -s /opt/jenkins/AutoSphere/shell/functions ]
then
  . /opt/jenkins/AutoSphere/shell/functions > /dev/null 2>&1
elif [ -s /nfs/it-pam/scripts/functions ]
then
  . /nfs/it-pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/pam/scripts/functions ]
then
  . ~/pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/.mkane01/scripts/functions ]
then
  . ~/.mkane01/scripts/functions > /dev/null 2>&1
else
  echo "********************************************************************************"
  echo "*  ERROR: Can not define ENV as PROJ_PATH can't be found, exiting...."
  echo "********************************************************************************"
  exit 5
fi


APPLNAME="ssh_PIMS_control"
eval LOGFILE=${NIGHTLY_LOG_DIR}/${APPLNAME}.${DATETIME_STAMP}.log
WASNAME="websphr"
rc=0
shortSleep=5
mediumSleep=30
longSleep=120
stopScript="${PYTHON_DIR}/stopAllClusters.py"
startScript="${PYTHON_DIR}/startCluster.py"


#########################################################################
# functions....
usage() 
{ 
echo "Usage: $0 [-e <PROD|STAGE|PIMSN01|PIMSN02|PIMSN03|PIMSN04|PIMSH02|PIMSH07|PIMSH09|PIMSH03|etc>] [-a <stop|start|clearcache|restart]" 1>&2
echo "                Examples"
echo "                   $0 -e prod -a clearcache"
echo "                   $0 -e stage -a start"
echo "                   $0 -e pimsn03 -a stop"
echo "                   $0 -e pimsn02 -a clearcache"
echo "                   $0 -e prod -a recycle"
echo ""
echo ""
echo " Actions:"
echo "  clearcache - This will remove the grail index cache for PIMS and for the application to rebuild the cache on startup, vendor recommends doing this before starting IBM Clusters"
echo "  start - This will start the IBM Clusters in a specific order PMC then ADC then AMC then MUTC"
echo "  stop - Will stop all IBM Clusters at the same time, then wait ${longSleep} seconds to allow time to complete the actual graceful shutdown"
echo "  recycle - For a recycle of the application it will issue: 'STOP' then 'CLEARCACHE' then 'START' in that order"
echo ""

exit 1;
}

get-CMDB-Info()
{
  # we need to arrays here, application servers and DMGR for the PIMS environment
  # https://blueshieldca.service-now.com/cmdb_rel_ci_list.do?sysparm_query=parent.nameSTARTSWITHPIMSS01_Provider%20Information%20Management%20System%5Eparent.sys_class_name%3Dcmdb_ci_appl%5Echild.sys_class_name%3Dcmdb_ci_app_server_websphere%5Eparent.install_status%3D11%5Echild.install_status%3D11%5Echild.nameSTARTSWITHdmgr&sysparm_view=
  uri="${URL_INST}/api/now/table/cmdb_rel_ci?sysparm_query=parent.nameSTARTSWITH${CMDBParentStr}%5Eparent.sys_class_name%3Dcmdb_ci_appl%5Echild.sys_class_name%3Dcmdb_ci_app_server_websphere%5Eparent.install_status%3D11%5Echild.install_status%3D11%5Echild.nameSTARTSWITHdmgr&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=child&sysparm_limit=1000"
 
  log_msg "Using URL [${uri}]"
  querySNowApi "${uri}" "${snow_user}" "${snow_pass}" "${LOGFILE}"
  
  log_msg "CURL call returned: ${url_status}"
  
  if [ -z "${url_status}" ]
  then
    log_msg "Returned no rows for CMDB call, exiting!"
    exit 10
  fi
  
  rows_returned=$(echo "${url_status}" | awk -F'"child":' '{print NF-1}')
  log_msg "Returned CI's from CDMB call is [${rows_returned}]"
  serverArray=''
  dmgrArray=''
  dmgrStripArray=''
  serversStripArray=''
  
  #check if returned rows is > 0
  
  if [ ${rows_returned} -gt 0 ]
  then
    log_msg "Result of CI's returned from CMDB is greater then 0"
  else
    log_msg "Result of CI's returned from CMDB is NOT greater then 0, exiting!"
    exit 13
  fi
  
  for (( i = 1; i <= ${rows_returned}; i++ ))
  do
    log_msg "Working on loop [${i}]"
    test=$(echo "${url_status}" | awk -F'{"result":' '{print $2}' | cut -d',' -f$i)
    log_msg "For loop [$i] found ${test}"
    server=$(tolower `echo "${test}" | cut -d'"' -f4 | cut -d@ -f2`)
    dmgr=$(tolower `echo "${test}" | cut -d'"' -f4 | cut -d@ -f1`)
    log_msg "Server is ${server} Possible DMGR is ${dmgr}"
    
    if [ -z "${server}" ]
    then
      log_msg "So
      ething went wrong trying to parse the returned REST call for server name, exiting!"
      exit 14
    fi
    
    if [ "${dmgr}" == "dmgr" ]
    then
      if [ -z "${dmgrArray}" ] 
      then
        dmgrArray="${server}"
      else
        dmgrArray="${dmgrArray} ${server}"
      fi
    fi
    
    if [ -z "${serverArray}" ]
    then
      serverArray="${server}"
    else
      serverArray="${serverArray} ${server}"
    fi
  done
  
  #lets remove duplicates...
  pimsArray=$(tr ' ' '\n' <<< "${serverArray}" | sort -u | tr '\n' ' ')
  pimsDmgrs=$(tr ' ' '\n' <<< "${dmgrArray}" | sort -u | tr '\n' ' ')
  
  log_msg "PIMS servers are: [${pimsArray}]"
  log_msg "PIMS DMGR servers are: [${pimsDmgrs}]"

}

clear_pims_cache()
{
  mount_point="/tmp/grails"
  # validate the mount point was found....
  if [ "${mount_point}" == "" ]
  then
      echo "Missing MOUNT POINT for grail files for PIMS, as it was not found!"
      exit 1
  else
      #echo "Found the following mount point [${mount_point}] to check for files to be removed."
      :
  fi

  # may want to include core.* files...
  find ${mount_point} -maxdepth 7 -type d \( -name "searchable-index" \) -print0 2>/dev/null |while IFS= read -r -d $'\0' file
  do
      echo "Working on file: ${file}" 
      # lets rm the files
      rm -R ${file} 
      rc=$?
      if [ ${rc} -ne 0 ]
      then
        echo "ERROR: Please review the log file, received the following return code on attempt: [${rc}]!"
      else  
        #echo "Success...."
        :
      fi   
  done

  echo "Completed Succesfully."
}

ssh_cmd()
{
  ssh_command="${1}"
  remote_host="${2}"
  if [ -z "${ssh_command}" ] || [ -z "${remote_host}" ]
  then
    log_msg "ERROR: A required parameter was not passed to ssh_cmd function, exiting!"
    exit 55
  fi
  
  ssh ${remote_host} "${ssh_command}" | tee -a ${LOGFILE} 2>&1
  rc=${PIPESTATUS[0]}
  if [ ${rc} -eq 0 ]
  then
    #log_msg "Success."
    :
  else
    log_msg "ERROR: SSH command returned exit code [${rc}]!"
    exit ${rc}
  fi
  return 0
}

start_servers()
{

  log_msg "----------------------------------------------------------------------------"
  log_msg "Starting START functionality for script [${startScript}]"
  for server in `echo ${pimsDmgrs}`
  do
    log_msg "Working on server: [${server}] for START Action with [${startScript}] for cluster [${ENVString}PMC]"
    ssh_cmd "${startScript} --clusterName=${ENVString}PMC" "${server}"
    log_msg "Completed --clusterName=${ENVString}PMC"
    log_msg "Working on server: [${server}] for START Action with [${startScript}] for cluster [${ENVString}ADC]"
    ssh_cmd "${startScript} --clusterName=${ENVString}ADC" "${server}"
    log_msg "Completed --clusterName=${ENVString}ADC"
    log_msg "Working on server: [${server}] for START Action with [${startScript}] for cluster [${ENVString}AMC]"
    ssh_cmd "${startScript} --clusterName=${ENVString}AMC" "${server}"    
    log_msg "Completed --clusterName=${ENVString}AMC"
    log_msg "Working on server: [${server}] for START Action with [${startScript}] for cluster [${ENVString}MUTC]"
    ssh_cmd "${startScript} --clusterName=${ENVString}MUTC" "${server}"    
    log_msg "Completed --clusterName=${ENVString}MUTC"  
  done
  log_msg "----------------------------------------------------------------------------"

  #log_msg "Sleeping for [${longSleep}] seconds before continuing to allow all starts to complete..."
  #sleep ${longSleep}
  
  return 0
  
}

stop_servers()
{

  log_msg "----------------------------------------------------------------------------"
  log_msg "Starting STOP functionality for script [${stopScript}]"
  for server in `echo ${pimsDmgrs}`
  do
    log_msg "Working on server: [${server}] for STOP Action with [${stopScript}]"
    ssh_cmd "${stopScript}" "${server}"
    #ssh_cmd "sudo -u ${SREUSER} ${stopScript}" "${server}" "nohup"
  done
  log_msg "----------------------------------------------------------------------------"

  log_msg "Sleeping for [${longSleep}] seconds before continuing to allow all stops to complete..."
  sleep ${longSleep}
  
  return 0
  
}

clear_cache()
{

  log_msg "----------------------------------------------------------------------------"
  log_msg "Starting CLEAR CACHE functionality"
  Command="$(typeset -f clear_pims_cache); clear_pims_cache"
  for server in `echo ${pimsArray}`
  do
    log_msg "Working on server: [${server}] for cache clear"
    ssh_cmd "${Command}" "${server}"
  done
  return 0
  
}


#end functions
#########################################################################

while getopts ":e:a:" o; do
    case "${o}" in
        e)
          env=$(tolower ${OPTARG})
          first4=$(echo ${env:0:4})
          if [ ${env} == 'prod' ] || [ ${env} == 'stage' ] || [ ${first4} == 'pims' ] 
          then
            #lets get the right lookup for CMDB 
            if [ ${env} == 'prod' ]
            then
              CMDBParentStr="Provider%20Information%20Management%20System"
              ENVString="PIMSP01"
            elif [ ${env} == 'stage' ]
            then
              CMDBParentStr="PIMSS01"
              ENVString="PIMSS01"
            elif [ ${first4} == 'pims' ]
            then
              CMDBParentStr=$(toupper ${env})
              ENVString=$(toupper ${env})
            else
              log_msg "The Value you supplied for environment is not KNOWN, exiting!"
              usage
            fi
          else
            #echo "e section"
            usage
          fi
          ;;
        a)
          action=$(tolower ${OPTARG})
          if [ ${action} == 'start' ] || [ ${action} == 'stop' ] || [ ${action} == 'clearcache' ] || [ ${action} == 'recycle' ]
          then
            :
          else
            #echo "a section"
            usage
          fi
          ;;
        *)
            #echo "* section...."
            usage
            ;;
    esac
done
shift $((OPTIND-1))

if [ -z "${env}" ] || [ -z "${action}" ]; then
    #echo "empty value...."
    usage
fi

if [ "${CURR_USER}" != "${WASNAME}" ]
then
  log_msg "You must be ${WASNAME} to execute this script, ABORTING!"
  chmod 666 ${LOGFILE} > /dev/null 2>&1
  exit 5
else
  log_msg "Running as user [${CURR_USER}]"
  log_msg "Environment = [${env}] and Action = [${action}]"
  chmod 666 ${LOGFILE} > /dev/null 2>&1
fi

#lets get the username/passord
#first source in the functions for SNOW
if [ -s ${PAM_SHELL_DIR}/snow_functions ]
then
  . ${PAM_SHELL_DIR}/snow_functions > /dev/null 2>&1
  #getURI Base and force to use prod SNow
  getSNowInstance prod
  log_msg "Using URL Base [${URL_INST}]"
  #now get the user/password force to use production SNow
  getSNowCredential prod
else
  log_msg "SNOW functions could not be found [${PAM_SHELL_DIR}/snow_functions], exiting!"
  exit 4
fi

if [ -z "${URL_INST}" ]
then
  log_msg "Empty URL base for SNOW, exiting!"
  exit 6
fi

if [ -z "${snow_user}" ] || [ -z "${snow_pass}" ]
then
  log_msg "We could not get the credentials for SNOW rest call, exiting!"
  exit 7
fi

  
log_msg "Found SNOW REST user string to be: [${snow_user}]"
# done getting needed credentials

#lets get the CMDB info
get-CMDB-Info
log_msg "Completed CMDB gathering..."

#actions.....
if [ ${action} == 'stop' ]
then
  stop_servers
  rc=$?
elif [ ${action} == 'start' ]
then
  start_servers
  rc=$?
elif [ ${action} == 'clearcache' ]
then
  clear_cache
  rc=$?
elif [ ${action} == 'recycle' ]
then
  #lets do all three....
  log_msg "As part of the Recycle, working on stop of the PIMS application"
  #$0 -e ${env} -a stop
  stop_servers
  log_msg "As part of the Recycle, working on clear cache of the PIMS application"
  #$0 -e ${env} -a clearcache
  clear_cache
  log_msg "As part of the Recycle, working on start of the PIMS application"
  #$0 -e ${env} -a start
  start_servers
  #just for last check below...
  rc=$?
else
  usage
fi

if [ ${rc} -eq 0 ]
then
  log_msg "#*****************************************************"
  log_msg "Successfully Completed ${APPLNAME}"
  log_msg "#*****************************************************"
else
  log_msg "ERROR: Could NOT complete [${action}] action for [${APPLNAME}], exiting with RC = [${rc}]!"
  exit ${rc}
fi

exit 0
