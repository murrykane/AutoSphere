#!/bin/sh 
#set timeout -1
#set file "/etc/virtualimage.properties"
#set fp [open "/etc/virtualimage.properties" r]
#fconfigure $fp -buffering line
#gets $fp data
#while {$data != ""} {
#puts $data
#gets $fp data
#}
#while {[gets $fp line] != -1} {
#puts "I just read $line"
#}
#close $fp
#close $f
#set DMGR_HOST nn00763
. /etc/virtualimage.properties

echo ${DMGR_USERID}
/usr/bin/expect  <<EOD
set timeout -1
spawn ssh -q -o StrictHostKeyChecking=no $DMGR_USERID@$DMGR_HOST
expect  "*assword: "
send "password\r"
expect "$ "
send "/opt/IBM/WebSphere/Profiles/Dmgr01/bin/stopManager.sh -username $DMGR_USERID  -password $WAS_password\r"
expect "$ "
send "/opt/IBM/WebSphere/Profiles/Dmgr01/bin/startManager.sh\r"
expect "$ "
send "exit\r"
EOD

