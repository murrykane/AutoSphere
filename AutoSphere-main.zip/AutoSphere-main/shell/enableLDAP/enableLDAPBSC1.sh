#!/bin/sh
######################################################################
# Name:    enableLDAPBSC1 - Enable LDAP for Web Portal for 
#                           Corporate LDAP.   This is LDAP 1 
#                           out of 2 that will be configured 
#                           for the federated repository for 
#                           Portal.   
# Rajesh Chelamalla
# Prerequsites:    Be sure to run the script in the 
#                  /opt/IBM/WebSphere/Profiles/wp_profile/ConfigEngine
#                  directory.   
#
#                  Helper ad property file wp_add_federated_ad_first.properties
#                  contains LDAP Corporate attributes and must be located 
#		   in the standard locatiion:
#                  /opt/IBM/WebSphere/Profiles/wp_profile/ConfigEngine/config/helpers
#
# Description:	This script will execute 8 steps needed to enable 
#		Corporate LDAP for Portal and switch WebSphere admin 
#		user to LDAP admin user.
#######################################################################

. /etc/virtualimage.properties
# commands for enabling LDAP1 for Portal
# execute this script from the /opt/IBM/WebSphere/Profiles/wp_profile/ConfigEngine
cd $WAS_PROFILE_ROOT/ConfigEngine
echo "***************************  START of enableLDAPBSC1 SCRIPT *******************"
echo "-> START 1 ********** Before the call to the validate ldap **********"
./ConfigEngine.sh validate-federated-ldap -DparentProperties=/opt/jenkins/AutoSphere/shell/enableLDAP/wp_add_federated_ad_first.properties -DWasPassword=$WAS_password 
echo "-> END 1 ********** After the call to validate-federated -ldap **********"

# now we have to create the LDAP 1 
echo "-> START 2 ************ Before the call to the validate ldap **********"
./ConfigEngine.sh wp-create-ldap -DparentProperties=/opt/jenkins/AutoSphere/shell/enableLDAP/wp_add_federated_ad_first.properties -DWasPassword=$WAS_password 
echo "-> END 2 ********** After the call to wp-create-ldap **********"

echo "-> START 3***** Before wp-update-entitytypes *****"
./ConfigEngine.sh wp-set-entitytypes -DparentProperties=/opt/jenkins/AutoSphere/shell/enableLDAP/wp_add_federated_ad_first.properties -DWasPassword=$WAS_password 
echo "-> END 3 ********** after the wp-update-entitytypes *********"

echo "-> START 4 ********* Before wp-create-realm *********"
./ConfigEngine.sh wp-create-realm -DparentProperties=/opt/jenkins/AutoSphere/shell/enableLDAP/wp_add_federated_ad_first.properties -DWasPassword=$WAS_password
echo "-> END 4 ********* After wp-create-realm ********"

echo "-> START 5 ********* Before wp-modify-realm-defaultparents *********"
./ConfigEngine.sh wp-modify-realm-defaultparents -DparentProperties=/opt/jenkins/AutoSphere/shell/enableLDAP/wp_add_federated_ad_first.properties -DWasPassword=$WAS_password -Drealm.personAccountParent=OU=Members,OU=Identity,OU=$ldapenvou,DC=devportal,DC=local -Drealm.groupParent=OU=Groups,OU=$ldapenvou,DC=devportal,DC=local -Drealm.orgContainerParent=OU=$ldapenvou,DC=devportal,DC=local 
echo "-> END 5 ********* After wp-modify-realm-defaultparents ********"

echo "-> START 6 ******** Before wp-default-realm **********"
./ConfigEngine.sh wp-default-realm -DparentProperties=/opt/jenkins/AutoSphere/shell/enableLDAP/wp_add_federated_ad_first.properties -DWasPassword=$WAS_password 
echo "-> END 6 ********* After wp-default-realm **********"


echo "-> START 7 ********** Before the wp-change-portal-admin-user **********"
./ConfigEngine.sh wp-change-portal-admin-user -Dskip.ldap.validation=true -DWasPassword=$WAS_password 
echo "-> END 7 ********** After the wp-change-portal-admin-user ***********"

echo "-> START 8 ******** Before the  change was admin user **********"
# change the WIMUserRegistry value and puma store.   Recycle DMGR, next
./ConfigEngine.sh wp-change-was-admin-user -Dskip.ldap.validation=true -DWasPassword=$WAS_password 
echo "-> END 8 ******** after change was admin user *********"


echo "******  Finished with enableLDAPBSC1 script.   LDAP 1 complete. *****"
echo "*********************************************************************"
echo "***************************  Finished WITH enableLDAPBSC1 SCRIPT *******************"
# now the bug fixes will have to be inplemented  
# 1 - change WIMUserRegistry realm name to 'Portal' in security.xml 
# 2 - add custom properties for WPPumaStoreService

