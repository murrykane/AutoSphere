echo "***Placed helper files in /opt/IBM/WebSphere/Profiles/wp_profile/ConfigEngine/config/helpers directory ***"


./enableLDAPBSC1.sh

./restartcluster1.sh

./fixes.sh

./restartcluster.sh

./enableLDAPBSC2.sh

./restartcluster.sh
