#!/bin/sh
######################################################################
# Name:    enableLDAPBSC2 - Enable LDAP2 for Web Portal for 
#                           Development forest  LDAP.   This is LDAP 2 
#                           out of 2 that will be configured 
#                           for the federated repository for 
#                           Portal.   
# Rajesh Chelamalla
# Prerequsites:    Be sure to run the script in the 
#                  /opt/IBM/WebSphere/Profiles/wp_profile/ConfigEngine
#                  directory.   
#######################################################################
. /etc/virtualimage.properties
#export ldapadminpwd=cLimbatr33-99
#export ldapenvou=TestQA1
# commands for enabling LDAP1 for Portal
# execute this script from the /opt/IBM/WebSphere/Profiles/wp_profile/ConfigEngine
cd $WAS_PROFILE_ROOT/ConfigEngine
echo "Before the call to the validate ldap2"
./ConfigEngine.sh validate-federated-ldap -DparentProperties=/opt/jenkins/AutoSphere/shell/enableLDAP/wp_add_federated_ad_second.properties -DWasPassword=$ldapadminpwd -Drealm.personAccountParent=OU=Members,OU=Identity,OU=$ldapenvou,DC=devportal,DC=local -Drealm.groupParent=OU=Groups,OU=$ldapenvou,DC=devportal,DC=local -Drealm.orgContainerParent=OU=$ldapenvou,DC=devportal,DC=local -Dfederated.ldap.baseDN=OU=$ldapenvou,DC=devportal,DC=local -Dfederated.ldap.et.group.searchBases=OU=$ldapenvou,DC=devportal,DC=local -Dfederated.ldap.et.personaccount.searchBases=OU=$ldapenvou,DC=devportal,DC=local
echo "After the call to validate-federated -ldap"

# now we have to create the LDAP 1 
echo "Before the call to the create ldap2"
./ConfigEngine.sh wp-create-ldap -DparentProperties=/opt/jenkins/AutoSphere/shell/enableLDAP/wp_add_federated_ad_second.properties -DWasPassword=$ldapadminpwd -Drealm.personAccountParent=OU=Members,OU=Identity,OU=$ldapenvou,DC=devportal,DC=local -Drealm.groupParent=OU=Groups,OU=$ldapenvou,DC=devportal,DC=local -Drealm.orgContainerParent=OU=$ldapenvou,DC=devportal,DC=local -Dfederated.ldap.baseDN=OU=$ldapenvou,DC=devportal,DC=local -Dfederated.ldap.et.group.searchBases=OU=$ldapenvou,DC=devportal,DC=local -Dfederated.ldap.et.personaccount.searchBases=OU=$ldapenvou,DC=devportal,DC=local
echo "After the call to wp-create-ldap"


echo "******  Finished with enableLDAPBSC2 script.   LDAP 2 complete. *****
echo "*********************************************************************"
echo " Make sure to restart the cell and sychronize the Portal node.


# Now cel will have to be restarted and Portal node sychronized 


