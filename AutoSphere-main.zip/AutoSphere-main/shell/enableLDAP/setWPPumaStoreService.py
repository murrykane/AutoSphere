import sys, time
global AdminConfig
# Identify the parent ID and assign it to the newrep variable.
 
newrep = AdminConfig.getid('/ResourceEnvironmentProvider:WP PumaStoreService/')
print newrep

name1 = ['name','store.puma_default.group.fbadefault.filter']
val1 = ['value','cn']

name2 = ['name','store.puma_default.user.fbadefault.filter']
val2 = ['value','cn']

rpAttrs1 = [ name1, val1 ]
rpAttrs2 = [ name2, val2 ] 

propSet = AdminConfig.showAttribute(newrep, 'propertySet')

# Create a J2EE resource property:
print AdminConfig.create('J2EEResourceProperty', propSet, rpAttrs1)
print AdminConfig.create('J2EEResourceProperty', propSet, rpAttrs2)

# Save the configuration changes:

AdminConfig.save()

sys.exit(1)

