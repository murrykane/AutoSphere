#!/bin/sh
. /etc/virtualimage.properties
cd /opt/IBM/WebSphere/Profiles/Dmgr01/config/cells/$CELL_NAME
sed -i -e '/xmi:id="WIMUserRegistry_1"/ s/defaultWIMFileBasedRealm/Portal/' security.xml
echo "Changed Realm Name"
