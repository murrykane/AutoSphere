#!/bin/sh
. /etc/virtualimage.properties
#export ldapadminuserid=svcbscwpadmin-npe
#export ldapadminpwd=cLimbatr33-99
cd $WAS_PROFILE_ROOT/ConfigEngine
./ConfigEngine.sh update-jcr-admin -DWasUserid=CN=svcbscwpadmin-npe,OU=BSC,OU=SERVICE,OU=ACCOUNTS,DC=dev,DC=bscal,DC=local -DWasPassword=cLimbatr33-99 -DPortalAdminId=CN=svcbscwpadmin-npe,OU=BSC,OU=SERVICE,OU=ACCOUNTS,DC=dev,DC=bscal,DC=local -DPortalAdminPwd=cLimbatr33-99 -DPortalAdminGroupId='CN=gs-portal-administrator-npe,OU=Security Groups,DC=dev,DC=bscal,DC=local'
cd $WAS_PROFILE_ROOT/bin
echo WebSphere_Portal_$NODE_NAME
echo ldapadminuserid is $ldapadminuserid
echo ldapadminpwd is $ldapadminpwd

#./stopServer.sh WebSphere_Portal_$NODE_NAME -username $ldapadminuserid -password $ldapadminpwd

#./stopNode.sh -username $ldapadminuserid -password $ldapadminpwd

./stopServer.sh WebSphere_Portal_$NODE_NAME -username $PORTAL_USER -password $WAS1_password

./stopNode.sh -username $PORTAL_USER -password $WAS1_password



./syncNode.sh $DMGR_HOST $DMGR_JMX_PORT -username $ldapadminuserid -password $ldapadminpwd

./startNode.sh

./startServer.sh WebSphere_Portal_$NODE_NAME





