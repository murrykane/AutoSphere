. /etc/virtualimage.properties
#export ldapadminuserid=svcbscwpadmin-npe
#export ldapadminpwd=cLimbatr33-99

echo ${DMGR_USERID}
/usr/bin/expect  <<EOD
set timeout -1
spawn ssh -q -o StrictHostKeyChecking=no $DMGR_USERID@$DMGR_HOST
expect  "*assword: "
send "password\r"
expect "$ "
send "/opt/IBM/WebSphere/Profiles/Dmgr01/bin/stopManager.sh -username $ldapadminuserid  -password $ldapadminpwd\r"
expect "$ "
send "/opt/IBM/WebSphere/Profiles/Dmgr01/bin/startManager.sh\r"
expect "$ "
send "exit\r"
EOD

cd $WAS_PROFILE_ROOT/bin

echo "****stop Portal server ***"

./stopServer.sh WebSphere_Portal -username $ldapadminuserid -password $ldapadminpwd
echo "****stop Node agent ***"

./stopNode.sh -username $ldapadminuserid  -password $ldapadminpwd

echo "**** Sync Node ****"

./syncNode.sh $DMGR_HOST $DMGR_JMX_PORT -username $ldapadminuserid  -password $ldapadminpwd
echo "**** start Node agent ***"

./startNode.sh

echo "****start Portal server ****"
./startServer.sh WebSphere_Portal
