#
#
# This script performs two activites.
#   a. Makes sure the Content Spot mapping for MP_AlphaTheme is in the cluster configuration
#   b. Makes sure that Sessions are enable for Anonymous users
#
# The script does this by making sure any old entries are removed first, then all the new ones are added.
#
#

print 'Deleting old content spot mappings'
mappings = AdminConfig.list('J2EEResourceProperty', 'MP_AlphaTheme*').splitlines()
for mapping in mappings :
    AdminConfig.remove(mapping)
    print 'Removed : ' +  mapping

print 'Deleting old Sessions setting.'
mappings = AdminConfig.list('J2EEResourceProperty', 'public.session*').splitlines()
for mapping in mappings :
    AdminConfig.remove(mapping)
    print 'Removed : ' +  mapping

print 'Saving configuration...'
print AdminConfig.save()
print 'Configuration saved.'

print 'Adding theme dynamic content spots...'
# Identify the parent ID and assign it to the newrep variable.
newrep = AdminConfig.getid('/ResourceEnvironmentProvider:WP DynamicContentSpotMappings/')
print newrep
 
# Produces:
# "WP DynamicContentSpotMappings(cells/basejumpCell/nodes/basejumpNode/servers/WebSphere_Portal|resources.xml#ResourceEnvironmentProvider_1335003123187)"
# Identify the required attributes
print AdminConfig.required('J2EEResourceProperty')
# Produces...
# Attribute                       Type
# name                            String
 
# Identify all possible attributes
print AdminConfig.attributes('J2EEResourceProperty')
# Produces..
#Attribute            Type
#name                String
#confidential            boolean
#description            String
#ignore                boolean
#name                String
#required            boolean
#supportsDynamicUpdates        boolean
#type                String
#value                String
 
# Set up the required attributes and assign it to the repAttrs variable:
 
name1 = ['name','MP_AlphaTheme_footer']
val1 = ['value', 'res:/bsca/bsc/mpo/MP_AlphaThemeDynamic/themes/html/dynamicSpots/footer.jsp']
 
name2 = ['name','MP_AlphaTheme_crumbTrail']
val2 = ['value', 'res:/bsca/bsc/mpo/MP_AlphaThemeDynamic/themes/html/dynamicSpots/crumbTrail.jsp?rootClass=wpthemeCrumbTrail&startLevel=2']
 
name3 = ['name','MP_AlphaTheme_topNav']
val3 = ['value', 'res:/bsca/bsc/mpo/MP_AlphaThemeDynamic/themes/html/dynamicSpots/navigation.jsp?rootClass=wpthemeHeaderNav&startLevel=0&primeRoot=true']
 
name4 = ['name','MP_AlphaTheme_primaryNav']
val4 = ['value', 'res:/bsca/bsc/mpo/MP_AlphaThemeDynamic/themes/html/dynamicSpots/navigation.jsp?rootClass=wpthemePrimaryNav%20wpthemeLeft&startLevel=1']
 
name5 = ['name','MP_AlphaTheme_secondaryNav']
val5 = ['value', 'res:/bsca/bsc/mpo/MP_AlphaThemeDynamic/themes/html/dynamicSpots/navigation.jsp?rootClass=wpthemeSecondaryNav&startLevel=2&levelsDisplayed=2']
 
name6 = ['name','MP_AlphaTheme_commonActions']
val6 = ['value', 'res:/bsca/bsc/mpo/MP_AlphaThemeDynamic/themes/html/dynamicSpots/commonActions.jsp']
 
name7 = ['name','MP_AlphaTheme_pageModeToggle']
val7 = ['value', 'res:/bsca/bsc/mpo/MP_AlphaThemeDynamic/themes/html/dynamicSpots/pageModeToggle.jsp,wp_toolbar']
 
name8 = ['name','MP_AlphaTheme_head']
val8 = ['value', 'res:/bsca/bsc/mpo/MP_AlphaThemeDynamic/themes/html/dynamicSpots/head.jsp']
 
name9 = ['name','MP_AlphaTheme_status']
val9 = ['value', 'res:/bsca/bsc/mpo/MP_AlphaThemeDynamic/themes/html/dynamicSpots/status.jsp, wp_status_bar']
 
name10 = ['name','MP_AlphaTheme_background_begin']
val10 = ['value', 'res:/bsca/bsc/mpo/MP_AlphaThemeDynamic/themes/html/dynamicSpots/background_begin.jsp']

name11 = ['name','MP_AlphaTheme_background_end']
val11 = ['value', 'res:/bsca/bsc/mpo/MP_AlphaThemeDynamic/themes/html/dynamicSpots/background_end.jsp']

name12 = ['name','MP_AlphaTheme_banner_nav']
val12 = ['value', 'res:/bsca/bsc/mpo/MP_AlphaThemeDynamic/themes/html/dynamicSpots/banner_nav.jsp']

name13 = ['name','MP_AlphaTheme_asa_head']
val13 = ['value', 'res:/bsca/bsc/mpo/MP_AlphaThemeDynamic/themes/html/dynamicSpots/asa_head.jsp']

name14 = ['name','MP_AlphaTheme_asa_body']
val14 = ['value', 'res:/bsca/bsc/mpo/MP_AlphaThemeDynamic/themes/html/dynamicSpots/asa_body.jsp']

name15 = ['name','MP_AlphaTheme_asa_bottom']
val15 = ['value', 'res:/bsca/bsc/mpo/MP_AlphaThemeDynamic/themes/html/dynamicSpots/asa_bottom.jsp']

name16 = ['name','MP_AlphaTheme_asa_portlet']
val16 = ['value', 'res:/bsca/bsc/mpo/MP_AlphaThemeDynamic/themes/html/dynamicSpots/asa_portlet.jsp']
 
 
rpAttrs1 = [ name1, val1 ]
rpAttrs2 = [ name2, val2 ]
rpAttrs3 = [ name3, val3 ]
rpAttrs4 = [ name4, val4 ]
rpAttrs5 = [ name5, val5 ]
rpAttrs6 = [ name6, val6 ]
rpAttrs7 = [ name7, val7 ]
rpAttrs8 = [ name8, val8 ]
rpAttrs9 = [ name9, val9 ]
rpAttrs10 = [ name10, val10 ]
rpAttrs11 = [ name11, val11 ]
rpAttrs12 = [ name12, val12 ]
rpAttrs13 = [ name13, val13 ]
rpAttrs14 = [ name14, val14 ]
rpAttrs15 = [ name15, val15 ]
rpAttrs16 = [ name16, val16 ]
 
# Get the J2EE resource property set:
 
propSet = AdminConfig.showAttribute(newrep, 'propertySet')
print propSet
 
# Produces:
# (cells/basejumpCell/nodes/basejumpNode/servers/WebSphere_Portal|resources.xml#J2EEResourcePropertySet_1335003123196)
 
# Create a J2EE resource property:
print AdminConfig.create('J2EEResourceProperty', propSet, rpAttrs1)
print AdminConfig.create('J2EEResourceProperty', propSet, rpAttrs2)
print AdminConfig.create('J2EEResourceProperty', propSet, rpAttrs3)
print AdminConfig.create('J2EEResourceProperty', propSet, rpAttrs4)
print AdminConfig.create('J2EEResourceProperty', propSet, rpAttrs5)
print AdminConfig.create('J2EEResourceProperty', propSet, rpAttrs6)
print AdminConfig.create('J2EEResourceProperty', propSet, rpAttrs7)
print AdminConfig.create('J2EEResourceProperty', propSet, rpAttrs8)
print AdminConfig.create('J2EEResourceProperty', propSet, rpAttrs9)
print AdminConfig.create('J2EEResourceProperty', propSet, rpAttrs10)
print AdminConfig.create('J2EEResourceProperty', propSet, rpAttrs11)
print AdminConfig.create('J2EEResourceProperty', propSet, rpAttrs12)
print AdminConfig.create('J2EEResourceProperty', propSet, rpAttrs13)
print AdminConfig.create('J2EEResourceProperty', propSet, rpAttrs14)
print AdminConfig.create('J2EEResourceProperty', propSet, rpAttrs15)
print AdminConfig.create('J2EEResourceProperty', propSet, rpAttrs16)


print 'Adding Anonymous Session configuration...'

newrep = AdminConfig.getid('/ResourceEnvironmentProvider:WP NavigatorService/')
#print newrep
propSet = AdminConfig.showAttribute(newrep, 'propertySet')
#print propSet
#print AdminConfig.showall(propSet);
#print AdminConfig.show(propSet)

attr1 = [ 'confidential' , 'false' ]
attr2 = [ 'description' ,  "This enables anonymous sessions for registration portlet" ]
attr3 = [ 'ignore' , 'false' ]
attr4 = [ 'name' , 'public.session' ]
attr5 = [ 'required' , 'false' ]
attr6 = [ 'supportsDynamicUpdates' , 'false' ]
attr7 = [ 'type' , 'java.lang.String' ]
attr8 = [ 'value' , 'true' ]

print AdminConfig.create('J2EEResourceProperty', propSet, [attr1,attr2,attr3,attr4,attr5,attr6,attr7,attr8])
print 'Anonymous Sessions configuration added.'

print 'Saving Configuration ...'
# Save the configuration changes:
AdminConfig.save()
print 'Configuration saved.'

sys.exit(1)
