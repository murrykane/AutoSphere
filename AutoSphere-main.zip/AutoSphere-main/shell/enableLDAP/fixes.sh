
w the bug fixes will have to be implemented for LDAP
# 1 - change WIMUserRegistry realm name to 'Portal' in security.xml
# 2 - add custom properties for WPPumaStoreService

# read property file to know dmgr server name
. /etc/virtualimage.properties
#export ldapadminuserid=svcbscwpadmin-npe
#export ldapadminpwd=cLimbatr33-99
#echo ${DMGR_USERID}
/usr/bin/expect  <<EOD
spawn scp /opt/jenkins/AutoSphere/shell/enableLDAP/changerealmName.sh $DMGR_USERID@$DMGR_HOST:/tmp
expect  "*assword: "
send "password\r"
expect "$ "
send "exit\r"
EOD
/usr/bin/expect  <<EOD
set timeout -1
spawn ssh -q -o StrictHostKeyChecking=no $DMGR_USERID@$DMGR_HOST
expect  "*assword: "
send "password\r"
expect "$ "
send "cd /tmp\r"
expect "$ "
send "./changerealmName.sh\r"
expect "$ "
send "exit\r"
EOD
