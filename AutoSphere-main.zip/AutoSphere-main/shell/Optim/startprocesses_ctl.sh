#!/bin/sh

#start Optim process
if [ -d "/opt/optim/IBM/InfoSphere/Optim/rt" ]
then
  echo " starting Optim process "
  . /opt/optim/IBM/InfoSphere/Optim/rt/rtsetenv

  # starting ODM process
  echo "The date to now is `date` "
  #sudo /bin/systemctl start rt4s.service
  sudo /bin/systemctl start irpcd.service
  rc=$?
  if [ ${rc} -eq 0 ]
  then
    :
    #log_msg "Successfully completed the SSH command for server [${remote_host}] with RC = [${rc}]"
  else
    echo "ERROR: Could NOT complete sudo command"
    exit ${rc}
  fi
  sleep 30s
  proc1=$(ps -ef|grep svcoptim)
  pr0svce1='pr0svce'
  nav_util1='/opt/optim/IBM/InfoSphere/Optim/rt/navroot/bin/nav_util'

  proc2=$(ps -ef|grep svcoptim | grep -v grep | grep ${nav_util1} | awk '{print $8}')
  proc3=$(ps -ef|grep svcoptim | grep -v grep | grep ${pr0svce1} | awk '{print $8}')

  #echo "proc1 is [${proc1}]"
  #echo "pr0svce1 is ${pr0svce1}"
  #echo "nav_util is ${nav_util1}"
  #echo "proc2 is ${proc2}"
  #echo "proc3 is ${proc3}"

  if [[ "${nav_util1}" == "${proc2}" ]]
  then
    if [[ "${proc3}" == "${pr0svce1}" ]]
    then
      echo "Optim services started successfully"
      exit 0
    fi
  else
   echo "Optim services are not running"
   exit 1
  fi

else
 echo "Optim is not installed on "`hostname`" server"
 exit 2
fi
