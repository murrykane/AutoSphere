#!/bin/sh

# Stopping Optim process
if [ -d "/opt/optim/IBM/InfoSphere/Optim/rt" ]
then
  echo "The date to now is `date` "
  echo "Stopping Optim services"
  . /opt/optim/IBM/InfoSphere/Optim/rt/rtsetenv
  sudo /bin/systemctl stop irpcd.service
  printf ' \n'
  sudo /bin/systemctl stop rt4s.service
  cd $PSTHOME
  proc1=$(ps -ef|grep svcoptim)
  #proc2= $(ps -ef|grep regss)
  #proc3= $(ps -ef|grep mwrpcss)

  watch='watchdog'
  regss='regss'
  mwrpcss='mwrpcss'

  if [[ "$proc1" == *"$watch"* || "$proc1" == *"$regss"* || "$proc1" == *"$mwrpcss"* ]]
  then
    mwcleanup -s
    mwadm stop
  fi

  pr0svce1='pr0svce'
  #irpcd_status=$(ps -ef|grep nav_util)
  nav_util1='nav_util'

  sleep 30s


  if [[ "$proc1" == *"$pr0svce1"* && "$proc1" == *"$nav_util1"* ]]
  then
   echo "Optim services are running"
   exit 1
  else
   echo "Optim services have been stopped successfully....zombie processes have been cleaned up"
   exit 0
  fi
else
  echo "Optim is not installed on "`hostname`" server"
  exit 2
fi
