#!/bin/bash
#
# Murry Kane
# Version 1.0
# checkprocesses_ctl2.sh used to check and validate the status of the Optim application
#
# Modification History
# Who                 Date         Notes
#__________________________________________________________________________________________________
# Murry Kane          08/17/2020   Initial Version
# Murry Kane          08/17/2020   Added check logic for primary and secondary
# Murry Kane          11/23/2020   Removed the nave_util1 check as its not always running....

if [ -d "/opt/optim/IBM/InfoSphere/Optim/rt" ]
then
  echo " Checking status of Optim and ODM process as on `date`"
  . /opt/optim/IBM/InfoSphere/Optim/rt/rtsetenv
  sudo /bin/systemctl status rt4s.service
  sudo /bin/systemctl status irpcd.service
  proc1=$(ps -ef|grep svcoptim)

  #murry kane - defaulting to running if not supplied
  if [ $# -eq 0 ]
  then
    echo "Defaulting to checking 'started' as it was not passed into script..."
    chkstatus="started"
  else
    chkstatus=$1
  fi

  #mbk primary check on service itself...
  rt4_check=`sudo /bin/systemctl is-active rt4s.service`
  rt4_rc=$?
  irp_check=`sudo /bin/systemctl is-active irpcd.service`
  irp_rc=$?

  pr0svce1='pr0svce'
  nav_util1='nav_util'

  if [[ "${chkstatus}" == "started" ]]
  then
    #mbk checking primary way...
    if [ ${rt4_rc} -eq 0 ] && [ "${rt4_check}" == "active" ]
    then
      echo "SystemD states rt4s.service is runnning"
    else
      echo "ERROR: SystemD states that rt4s.service is NOT running, exiting!"
      exit 1
    fi
    if [ ${irp_rc} -eq 0 ] && [ "${irp_check}" == "active" ]
    then
      echo "SystemD states irpcd.service is runnning"
    else
      echo "ERROR: SystemD states that irpcd.service is NOT running, exiting!"
      exit 1
    fi

    #mbk secondary checks below
    #if [[ "$proc1" == *"$pr0svce1"* && "$proc1" == *"$nav_util1"* ]]
    if [[ "$proc1" == *"$pr0svce1"* ]]
    then
      echo "Optim services are running"
      exit 0
    else
      echo "ERROR: Optim services are not running and they SHOULD BE, exiting!"
      exit 1
    fi
  else
    if [[ "$proc1" == *"$pr0svce1"* && "$proc1" == *"$nav_util1"* ]]
    then
      echo "ERROR: Optim services are running and they should NOT be, exiting!"
      exit 1
    else
      echo "Optim services are not running"
      exit 0
    fi
  fi
else
  echo "Optim is not installed on "`hostname`" server"
  exit 2
fi
