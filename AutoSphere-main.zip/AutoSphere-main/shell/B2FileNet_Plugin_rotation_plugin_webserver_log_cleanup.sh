#!/bin/bash 
# 
# Sunil
# Version 1.1
# Application: B2FileNet
# Rotate and cleanup historic plugin file 
# Clean historic apache logs
# 
# Modification History
# Who                 Date         Notes
#__________________________________________________
# Sunil            11/11/2019   Initial Version
#__________________________________________________
timestamp=`date "+%Y-%m-%d_%H:%M:%S"`
FileName=http_plugin.log
BackupFile=http_plugin.log.$timestamp
path01=/apps/fln*-ws*/plugin/logs/fln*-ws*
path02=/apps/fln*-wssecur*/plugin/logs/fln*-wssecur*
mv $path01/$FileName $path01/$BackupFile
touch $path01/$FileName
mv $path02/$FileName $path02/$BackupFile
touch $path02/$FileName
/usr/bin/find  /apps/fln*-ws*/plugin/logs/fln*-ws*/*log* -mtime +8 -exec rm -f {} \;
/usr/bin/find  /apps/fln*-wswssecur*/plugin/logs/fln*-wswssecur*/*log* -mtime +8 -exec rm -f {} \;
/usr/bin/find  /apps/fln*-ws*/logs/fln*-ws*/*access* -mtime +8 -exec rm -f {} \;
/usr/bin/find  /apps/fln*-ws*/logs/fln*-ws*/*error* -mtime +8 -exec rm -f {} \;
/usr/bin/find  /apps/fln*-wssecur*/logs/fln*-wssecur*/*access* -mtime +8 -exec rm -f {} \;
/usr/bin/find  /apps/fln*-wssecur*/logs/fln*-wssecur*/*error* -mtime +8 -exec rm -f {} \;