#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 05/10/2017 Murry Kane     Initial version
# 12/04/2017 Murry Kane     Wrote to work on Windows
# 03/18/2018 Murry Kane     Added logic to call new method to deterine if username/password needs
#                           to be sent to all IBM scripts based on IBM Security Enabled or not
#
#_________________________________________________________________________________________________
#
# AdminTask.modifySSLConfig('[-alias CellDefaultSSLSettings -scopeName (cell):WEBN208Cell -keyStoreName CellDefaultKeyStore -keyStoreScopeName (cell):WEBN208Cell -trustStoreName CellDefaultTrustStore -trustStoreScopeName (cell):WEBN208Cell -jsseProvider IBMJSSE2 -sslProtocol SSL_TLSv2 -clientAuthentication false -clientAuthenticationSupported false -securityLevel HIGH -enabledCiphers ]')
#
# AdminTask.modifySSLConfig('[-alias NodeDefaultSSLSettings -scopeName (cell):WEBN208Cell:(node):WEBN208ContentNode01 -keyStoreName WEBN208Keystore -keyStoreScopeName (cell):WEBN208Cell -trustStoreName CellDefaultTrustStore -trustStoreScopeName (cell):WEBN208Cell -jsseProvider IBMJSSE2 -sslProtocol SSL_TLSv2 -clientAuthentication false -clientAuthenticationSupported false -securityLevel HIGH -enabledCiphers ]')
# add property
# wsadmin>AdminTask.setAdminActiveSecuritySettings('[-customProperties ["com.ibm.websphere.security.test=false"]]')
# remove property
#wsadmin>AdminTask.setAdminActiveSecuritySettings('[-customProperties ["com.ibm.websphere.security.test="]]')

import shlex, subprocess, sys, platform, ConfigParser, os, log_message, getpass, getopt, ast, commands
from datetime import datetime
from constants import *
from init_websphere import *
import websphereClusterNodes_control


def usage():
  print "Usage: %s --Alias=<value> --KeyStore=<value> --CellDefaultStore=<value> --PersonalKeyStore=<value> --tls_value=<value> --customPropertyFlag=<value> --customPropertyName=<value> --customPropertyValue=<value> --NodeDefaultSSLSetting=<value>" % sys.argv[0]
  print 'Example: %s --Alias=CellDefaultSSLSettings --KeyStore=CellDefaultKeyStore --CellDefaultStore=CellDefaultTrustStore --PersonalKeyStore=WEBN208Keystore --tls_value=SSL_TLSv2 --customPropertyFlag=TRUE --customPropertyName=com.ibm.websphere.tls.disabledAlgorithms --customPropertyValue="SSLv3, RC4, DH keySize < 768, MD5withRSA, TLSv1" --NodeDefaultSSLSetting=NodeDefaultSSLSettings' % sys.argv[0]

if os.name != 'nt' and getpass.getuser() != 'websphr':
  print "You must run this as the effective user 'websphr', please try again as that user, exiting!"
  sys.exit(1)

def main():
  
  Alias = ''
  KeyStore = ''
  CellDefaultStore = ''
  PersonalKeyStore = ''
  tls_value = ''
  customPropertyFlag = ''
  customPropertyName = ''
  customPropertyValue = ''
  NodeDefaultSSLSetting = ''
  
  try:
    opts, args = getopt.getopt(sys.argv[1:], 'a:k:c:p:t:f:n:v:d:', ['Alias=', 'KeyStore=', 'CellDefaultStore=', 'PersonalKeyStore=', 'tls_value=', 'customPropertyFlag=', 'customPropertyName=', 'customPropertyValue=', 'NodeDefaultSSLSetting='])
  except getopt.GetoptError, err:
    print "exception in GETOPT with [%s]" % err
    usage()
    sys.exit(2)

  for opt, arg in opts:
    if opt in ( '-a', '--Alias'):
      Alias = arg
    elif opt in ('-k', '--KeyStore'):
      KeyStore = arg
    elif opt in ('-c', '--CellDefaultStore'):
      CellDefaultStore = arg
    elif opt in ('-p', '--PersonalKeyStore'):
      PersonalKeyStore = arg
    elif opt in ('-t', '--tls_value'):
      tls_value = arg
    elif opt in ('-f', '--customPropertyFlag'):
      customPropertyFlag = arg
    elif opt in ('-n', '--customPropertyName'):
      customPropertyName = arg
    elif opt in ('-v', '--customPropertyValue'):
      customPropertyValue = arg
    elif opt in ('-d', '--NodeDefaultSSLSetting'):
      NodeDefaultSSLSetting = arg
    else:
      usage
      sys.exit(3)
  
  #validate args passed in are defined...
  if not Alias:
    print "Alias NOT passed"
    usage()
    sys.exit(4)
  if not KeyStore:
    print "KeyStore NOT passed"
    usage()
    sys.exit(5)
  if not CellDefaultStore:
    print "CellDefaultStore NOT passed"
    usage()
    sys.exit(6)
  if not PersonalKeyStore:
    print "PersonalKeyStore NOT passed"
    usage()
    sys.exit(7)
  if not tls_value:
    print "tls_value NOT passed"
    usage()
  if customPropertyFlag.upper() == "TRUE":
    if not customPropertyName:
      print "CustomPropertyName is required with TRUE value for customPropertyFlag"
      usage()
    if not customPropertyValue:
      print "CustomPropertyValue is required with TRUE value for customPropertyFlag"
      usage()
  if not NodeDefaultSSLSetting:
    print "NodeDefaultSSLSetting NOT passed" 
    usage()
    
  pathname = os.path.dirname(sys.argv[0])        
  pathdir = os.path.abspath(pathname)
  localhost = platform.node().upper()
  currentscript = os.path.basename(os.path.splitext(__file__)[0])
  localhost = platform.node().upper()
  loglevel = 'DEBUG'
  date_fmt = datetime.now().strftime('%Y%m%d-%H%M')
  LOGFILE = '%s/%s_%s.log' % (LOG_DIR, currentscript, date_fmt)
  ignoreNodeList = ''
    
  log_msg = log_message.get_file_logger(currentscript, loglevel, LOGFILE, currentscript, True)
  log_msg.info("Starting program")
  log_msg.info("ingore node list is %s" % ignoreNodeList)
  ignoreNodeList = "/".join(ignoreNodeList)
  log_msg.debug("ignore list as string is: %s" % ignoreNodeList)
  if len(ignoreNodeList) == 0:
    ignoreNodeList = '/'
    log_msg.debug("ignore node modified due to empty, list as string is: %s" % ignoreNodeList)
  thenodelist = ''   
  
  # use manageprofiles.sh to get the WebSphere profiles on this server
  if getProfiles(profilesFile, log_msg):
    log_msg.info("Successfully got profiles for server")
  else:
    log_msg.error("ERROR: We could not get the profiles for this server, exiting!")
    sys.exit(14)
  
  #get the DMGR from the output above....
  xmlStr = ''
  aStr = ''
  temp = open(profilesFile,'r').readlines()
  for line in temp:   # there should only be 1 line....
    aStr = line.strip('\n\r[]') 
  log_msg.info("List of Profiles on server is [%s]" % aStr)
  if not aStr:
    #could not determine profiles on this system....
    log_msg.error("ERROR: We could not determine the WebSphere Profiles on this server, exiting!")
    sys.exit(15)
  
  #server may have one or more profiles, loop through them....
  profileList = aStr.split()
  for profile in profileList:
    if re.search('dmgr', profile, re.IGNORECASE):
      log_msg.info("Profile [%s] is a DMGR" % profile)
      startStr = " ".join(re.findall("[a-zA-Z]+", aStr)).split()[0]
      startNum = " ".join(re.findall("[0-9]+", aStr)).split()[0]
      xmlStr = '%s%s' % (startStr, startNum)
      if len(xmlStr) < 5:
        log_msg.warn("The XML Search String [%s] is very small, which may lead to bad results!" % xmlStr)
      
  if not xmlStr:    
    log_msg.error("We could not determine if this server is a DMGR, exiting!")
    sys.exit(15)
    
  log_msg.info("XML String to find files with is [%s]" % xmlStr)
  xmlString = "%s*.xml" % xmlStr
  jythonscript = '%s/%s.py' % (JYTHON_DIR, currentscript)
  
  XMLFile, username, encrypted_password, password, wsadminpath = getXMLFile(xmlString, log_msg) 
  wsadminfile = os.path.join(wsadminpath + os.sep, 'bin' + os.sep, 'wsadmin' + ext_name).replace("\\", "/")
  
  # lets validate all variables are defined
  #------------------------------------------
  if os.path.isfile(wsadminfile):
    log_msg.debug("Found the WSAdmin.sh with: [%s]" % wsadminfile)
  else:
    log_msg.error("Unable to find the WSAdmin script with: [%s], exiting!" % wsadminfile)
    sys.exit(10)    
  if os.path.isfile(jythonscript):
    log_msg.debug("Found the python script with: [%s]" % jythonscript)
  else:
    log_msg.error("Unable to find the jython script with: [%s], exiting!" % jythonscript)
    sys.exit(10)
  if os.path.isfile(XMLFile):
    log_msg.debug("Found the XML Property File with: [%s]" % XMLFile)
  else:
    log_msg.error("Unable to find the XML Property File with: [%s], exiting!" % XMLFile)
    sys.exit(10)
  if username:
    log_msg.debug("Found the user name to use with WSAdmin script with: [%s]" % username)
  else:
    log_msg.error("Unable to find the user name for WSAdmin script with: [%s], exiting!" % username)
    sys.exit(10)
  if encrypted_password:
    log_msg.debug("Obtained the encrypted password for WSAdmin script with: [%s]" % encrypted_password)
  else:
    log_msg.error("Unable to find the encrypted password for WSAdmin script with: [%s], exiting!" % encrypted_password)
    sys.exit(10)
  if password:
    log_msg.debug("Obtained the password for WSAdmin script with: [%s]" % 'XXXXXXXXXX')
  else:
    log_msg.error("Unable to find the password for WSAdmin script with: [%s], exiting!" % password)
    sys.exit(10) 
  ################################################################################################
  
  ################################################################################################
  # lets check if IBM security is set on this environment.....
  #
  IBMSecuritySet = False
  IBMSecuritySet = securityEnabledCheck(log_msg, wsadminpath)
  if IBMSecuritySet:
    if serverStatusWithNoPass(serverStatusOutFile, log_msg, wsadminpath):
      log_msg.debug("Successfully created the server status output file")
    else:
      log_msg.error("Could not determine status of the DMGR, exiting!")
      sys.exit(99) 
  else:      
    #make sure we are on a running DMGR to proceed....
    if serverStatusWithPass(serverStatusOutFile, username, password, log_msg, wsadminpath):
      log_msg.debug("Successfully created the server status output file")
    else:
      log_msg.error("Could not determine status of the DMGR, exiting!")
      sys.exit(99)
      
  #lets read the serverStatus output now....
  dFlag = False
  sfile = file(serverStatusOutFile)
  for line in sfile:
    if 'The Deployment Manager' in line:
      log_msg.debug("Found the following line in the ServerStatus output: [%s]" % line.strip())
      dFlag = True
      #get the last value to check if its 'STARTED'
      if line.rsplit(None, 1)[-1] == 'STARTED':
        log_msg.info("DMGR is running on this server, continue with script.....")
      else:
        log_msg.error("DMGR is NOT running, we can not continue with this script, please start the DMGR and run again!")
        sys.exit(45)
  # make sure its a DMGR
  if not dFlag:
    log_msg.error("This is not a DMGR server, and we can not run on this server, exiting!")
    sys.exit(55)

  result = []  

  log_msg.debug("Alias %s" % Alias)
  log_msg.debug("KeyStore %s" % KeyStore)
  log_msg.debug("CellDefaultStore %s" % CellDefaultStore)
  log_msg.debug("PersonalKeyStore %s" % PersonalKeyStore )
  log_msg.debug("TLS Value %s" % tls_value)
  log_msg.debug("customPropertyFlag %s" % customPropertyFlag)
  log_msg.debug("customPropertyName %s" % customPropertyName)
  log_msg.debug("customPropertyValue %s" % customPropertyValue)
  log_msg.debug("NodeDefaultSSLSetting %s" % NodeDefaultSSLSetting)

  if IBMSecuritySet:
    logging_cmd = '%s -lang jython -conntype NONE -javaoption "-Dpython.path=%s" -f %s %s %s %s %s %s %s %s \'"%s"\' %s' % ( wsadminfile, PYTHONPATH, jythonscript, Alias, KeyStore, CellDefaultStore, PersonalKeyStore, tls_value, customPropertyFlag, customPropertyName, customPropertyValue, NodeDefaultSSLSetting)
    cmd = '%s -lang jython -conntype SOAP -user %s -password %s -javaoption "-Dpython.path=%s" -f %s %s %s %s %s %s %s %s \'"%s"\' %s' % ( wsadminfile, username, password, PYTHONPATH, jythonscript, Alias, KeyStore, CellDefaultStore, PersonalKeyStore, tls_value, customPropertyFlag, customPropertyName, customPropertyValue, NodeDefaultSSLSetting)  
  else:
    logging_cmd = '%s -lang jython -conntype NONE -user %s -password %s -javaoption "-Dpython.path=%s" -f %s %s %s %s %s %s %s %s \'"%s"\' %s' % ( wsadminfile, username, 'XXXXXXXXX', PYTHONPATH, jythonscript, Alias, KeyStore, CellDefaultStore, PersonalKeyStore, tls_value, customPropertyFlag, customPropertyName, customPropertyValue, NodeDefaultSSLSetting)
    cmd = '%s -lang jython -conntype SOAP -user %s -password %s -javaoption "-Dpython.path=%s" -f %s %s %s %s %s %s %s %s \'"%s"\' %s' % ( wsadminfile, username, password, PYTHONPATH, jythonscript, Alias, KeyStore, CellDefaultStore, PersonalKeyStore, tls_value, customPropertyFlag, customPropertyName, customPropertyValue, NodeDefaultSSLSetting)
  log_msg.info("Issueing: [%s]" % logging_cmd)
  
  if os.name != 'nt':
    args = shlex.split(cmd)
  else:
    args = cmd
    #log_msg.debug("Windows special with ARGS: [%s]" % args)
  process = subprocess.Popen(args,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
  
  # Poll process for new output until finished
  while True:
    nextline = process.stdout.readline().rstrip()
    if nextline == '' and process.poll() is not None:
      break
    if nextline and (not nextline.isspace()):
      log_msg.info(nextline)
      if 'Nodes to update are: ' in nextline:
        key, value = nextline.split('Nodes to update are: ')
        result = eval(value.strip())
      sys.stdout.flush()
    
  output, error = process.communicate()
  exit_code = process.wait()

  if exit_code > 0:
    #print "ERROR: [%s], exiting" % error
    if output:
      log_msg.error("Received STDOUT: %s" % output)
    if error:
      #lets see if its just the 'ulimit:' open files error received all the time
      for line in error.split(os.linesep):
        if line.find('ulimit:') > 0:
          log_msg.debug("Ignoring the ULIMIT: error from stderr...")
        else:
          log_msg.error(line)
    log_msg.error("ERROR: Exiting program!")
    sys.exit(exit_code)
  else:
    if output:
      log_msg.info("Received STDOUT: %s" % output)
    log_msg.info("Success on executing [%s]" % jythonscript)
 
  if os.name == 'nt':
    log_msg.info("_____________________________________________________________________________________________________") 
    log_msg.error("Windows logic HAS NOT BEEN COMPLETED, skipping logic to update web servers and node agents in this cluster!!!!!")
    log_msg.info("_____________________________________________________________________________________________________") 
  else:
    ###################################################################################
    # need to modify the file on the local DMGR server....
    in_file="%s/properties/ssl.client.props" % wsadminpath
    sav_file="%s/properties/ssl.client.props.%s" % (wsadminpath, date_fmt)
    out_file="%s/properties/ssl.client.props.sav" % wsadminpath
    log_msg.debug("SSL File [%s] SAV File [%s] TMP File [%s]" % (in_file, sav_file, out_file))
    cmd = 'cp %s %s' % (in_file, sav_file)
    rc,output = commands.getstatusoutput('%s' % (cmd))
    if rc > 0:
      log_msg.error("Backup of the original SSL file [%s] could not be completed with error: [%s], exiting!" % (in_file, output))
      sys.exit(33) 
    cmd = 'sed "s/^com.ibm.ssl.protocol=.*/com.ibm.ssl.protocol=%s/g" %s > %s' % (tls_value, in_file, out_file)
    rc,output = commands.getstatusoutput('%s' % (cmd))
    if rc > 0:
      log_msg.error("Modify of SSL file [%s] could not be completed with error: [%s], exiting!" % (in_file, output))
      sys.exit(34) 
    cmd = 'mv %s %s' % ( out_file, in_file)
    rc, output = commands.getstatusoutput('%s' % (cmd))
    if rc > 0:
      log_msg.error("Replace of the original SSL file [%s] could not be completed with error: [%s], exiting!" % (in_file, output))
      sys.exit(33)         
    log_msg.info("Completed backup and modification of SSL file [%s]" % in_file)
    ###################################################################################
    
    #need to stop/start the manager now
    stop_mgr_cmd = "%s/bin/stopManager.sh -username %s -password \'%s\'" % (wsadminpath, username, password)
    stop_mgr_cmd_log = "%s/bin/stopManager.sh -username %s -password \'%s\'" % (wsadminpath, username, 'XXXXXXXXX')
    start_mgr_cmd = "%s/bin/startManager.sh" % (wsadminpath)
    
    #stop it
    log_msg.info("Issueing: [%s]" % stop_mgr_cmd_log)
    args = shlex.split(stop_mgr_cmd)
    output = run_command(args, log_msg)
    log_msg.info("Output received: [%s]" % output)
    #start it...
    log_msg.info("Issueing: [%s]" % start_mgr_cmd)
    args = shlex.split(start_mgr_cmd)
    output = run_command(args, log_msg)
    log_msg.info("Output received: [%s]" % output)
    ####################################
    
    if result.count > 0: 
      #first lets stop the nodeagents on all servers....
      log_msg.info("Calling script to stop nodes in cluster")
      websphereClusterNodes_control.main('stop')
      for nodename, hostname, binPath, port, dmgrHost in result:
        log_msg.info("_____________________________________________________________________________________________________")
        log_msg.info("NodeName %s HostName %s Path %s Port %s DMGR Host %s" % (nodename, hostname, binPath, port, dmgrHost))
        ssherror, sshCmd, sshargs, sshprocess, sshoutput, nodenameHost = ('','','','','','')
        try:
          # lets determine if its local host or not
          nodenameHost = os.popen('nslookup %s' % hostname ).read().split("Name:")[1].split("\t")[1].split(".")[0].upper()     
        except:
          nodenameHost = os.popen('nslookup %s' % hostname ).read().split("canonical name = ")[1].split(".")[0].upper()
          
        if nodenameHost == localhost:
          log_msg.info("Already completed on local host %s" % localhost)
        else:
          in_file="%s/properties/ssl.client.props" % binPath
          sav_file="%s/properties/ssl.client.props.%s" % (binPath, date_fmt)
          out_file="%s/properties/ssl.client.props.sav" % binPath
          log_msg.debug("SSL File [%s] SAV File [%s] TMP File [%s]" % (in_file, sav_file, out_file))
          cmd = 'cp %s %s' % (in_file, sav_file)
          rc,output = commands.getstatusoutput('ssh %s %s' % (hostname, cmd))
          if rc > 0:
            log_msg.error("Backup of the original SSL file [%s] could not be completed with error: [%s], exiting!" % (in_file, output))
            #sys.exit(33) 
          cmd = 'sed "s/^com.ibm.ssl.protocol=.*/com.ibm.ssl.protocol=%s/g" %s \> %s' % (tls_value, in_file, out_file)
          rc,output = commands.getstatusoutput('ssh %s %s' % (hostname, cmd))
          if rc > 0:
            log_msg.error("Modify of SSL file [%s] could not be completed with error: [%s], exiting!" % (in_file, output))
            #sys.exit(34) 
          cmd = 'mv %s %s' % ( out_file, in_file)
          rc, output = commands.getstatusoutput('ssh %s %s' % (hostname,cmd))
          if rc > 0:
            log_msg.error("Replace of the original SSL file [%s] could not be completed with error: [%s], exiting!" % (in_file, output))
            #sys.exit(35)         
          log_msg.info("Completed backup and modification of SSL file [%s]" % in_file)
              
        if nodenameHost == localhost:
          log_msg.info("Ignoring local host %s for syncNode.sh command" % localhost)
        else:
          sshCmd = 'ssh %s nohup %s/bin/syncNode.sh %s %s -stopservers -restart -username %s -password \'%s\' >> %s/logs/syncNode.log 2>&1 & disown' % (hostname, binPath, dmgrHost, port, username, password, binPath)  
          sshCmd_logging = 'ssh %s nohup %s/bin/syncNode.sh %s %s -username %s -password \'%s\' >> %s/logs/syncNode.log 2>&1 & disown' % (hostname, binPath, dmgrHost, port, username, 'XXXXXXXX', binPath)  
          log_msg.debug("Issueing the following: [%s]" % sshCmd_logging)
          sshexit_code = 0
          sshargs = shlex.split(sshCmd)
          sshprocess = subprocess.Popen(sshargs,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
          sshoutput, ssherror = sshprocess.communicate()
          sshexit_code = sshprocess.wait()
          if sshexit_code > 0:
            if sshoutput:
              log_msg.error("ERROR OUTPUT: \n[%s]" % sshoutput)
              log_msg.error("ERROR: SSH command received rc: %s error message:(IGNORE ulimit line)\n[%s]" % (sshexit_code, ssherror))
              #sys.exit(sshexit_code)
          if sshoutput:
            log_msg.info("Output from SSH on %s is:\n[%s]" % (hostname, sshoutput))
          else:
            log_msg.info("Susccesfully submitted command for %s" % hostname)
    else:
      log_msg.info("No nodes to do for the syncNode!")
    
    if result.count > 0:
      log_msg.info("_____________________________________________________________________________________________________") 
  #endif....
    
  log_msg.info("Completed program successfully")
    
if __name__ == "__main__":
  main()

