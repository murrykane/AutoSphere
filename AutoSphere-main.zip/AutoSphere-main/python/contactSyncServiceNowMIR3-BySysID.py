#!/usr/bin/env python
'''
Murry Kane 
Version 1.0

 Updates
 Date       By             Reason
_________________________________________________________________________________________________
 03/11/2020 Murry Kane     Initial version
 05/19/2021 Murry Kane     found bug with strip_accents can strip down to None and causes issues later
                           - needed to change job title in compareContactRecords for None and set to ''
 08/26/2021 Murry Kane     Need to add ZIP code to all users loaded into MIR (this will just end up being employees only)
 09/15/2021 Murry Kane     Found bug in ZIP logic above if next user had no zip it would use the last one found for another 
                           contact, causing many more updates then needed

_________________________________________________________________________________________________
 Description
 This script will export all contacts from ServiceNow via rest call, it will process each record 
 and gather specific fields for syncing with MIR3 notificaiton system. 
 
List of fields:

MIR3 Field    Service Now Extract list of fields
              calendar_integration
yes country   country   
              last_position_update
              user_password
              last_login_time
yes floor     u_floor_cube
              source
yes (active)  sys_updated_on
              u_applicant_id
yes building  building
              u_work_term_number
              web_service_access_only
              notification
              enable_multifactor_authn
              sys_updated_by
              sso_source
              sys_created_on
              agent_status
              sys_domain
              u_badge_num
              state
              vip
              sys_created_by
yes custom    u_job_title
              longitude
yes zip       zip
yes home_phonehome_phone
              time_format
              u_management_level
              u_employment_status
              last_login
              default_perspective
              geolocation_tracked
              u_acct_start
yes active    active
              time_sheet_policy
yes custom    u_bsc_source
yes custom    cost_center
yes business  phone
yes Custom    name
Yes Custom    u_emp_type
yes employeeidemployee_number
              password_needs_reset
              gender
yes city      city
              failed_attempts
yes username  user_name
              latitude
              roles
yes job_title title
              sys_class_name
              u_user_account_control
yes custom    sys_id
              internal_integration_user
              ldap_server
yes home mobile/home sms mobile_phone
yes street    street
yes company   company
yes custom    department
yes first namefirst_name
yes work emailemail
              introduction
yes language  preferred_language
              u_candidate_id
yes custom    manager
              u_is_manager
              locked_out
              auditor
              sys_mod_count
yes last name last_name
              photo
              u_self_approve
              avatar
yes middle name middle_name
              sys_tags
              time_zone
              u_last_ldap_refresh
              schedule
              on_schedule
              u_acct_end
              date_format
yes custom    location
              u_transaction_date
yes custom    u_business_unit

Notes:

Special handling will be done for contact 'active = false' by using 'last_updated_on' date that is over 30 days before we will set the contact inactive
in MIR3 this to to avoid possible flapping (switching user from contractor to employee etc) or accidental inactive/active 

'''

import shlex, subprocess, sys, platform, os, log_message, getpass, getopt, ast, requests, json, base64, re, traceback, unicodedata
from datetime import datetime, timedelta
from SREConstants import *
from SREConfigParser import *
from SRESecurity import *
import xml.etree.ElementTree as ET

def strip_accents(string, accents=('COMBINING ACUTE ACCENT', 'COMBINING GRAVE ACCENT', 'COMBINING TILDE')):
  accents = set(map(unicodedata.lookup, accents))
  chars = [c for c in unicodedata.normalize('NFD', string) if c not in accents]
  normalized_chars = unicodedata.normalize('NFC', ''.join(chars))
  #lets fix en dash
  str1_chars = re.sub(u"\u2013", "-", normalized_chars)
  str2_chars = re.sub(u"\xa0", " ", str1_chars)
  #mbk adding logic to set to empty if None is present after stripping...
  if not str2_chars:
    str2_chars = ''
    #print('Having to set [{}] to empty as it is None after stripping....'.format(string))
    
  return str2_chars

def checkNoneLowerCase(string, log_msg):

  returnStr = ''
  
  if string:
    returnStr = string.lower().strip()
  
  log_msg.debug("Passed [{}] returning with value: [{}]".format(string,returnStr))
  
  return returnStr
  
   
def usage():
  print("Usage: %s --environment=<PROD><DEV><QA><2015><TRAINING> (optional)--loglevel=<INFO><DEBUG><WARN><ERROR><FATAL> (optional)--help" % sys.argv[0])
  print("Usage: %s (optional)--e <PROD><DEV><QA><2015><TRAINING> (optional)--l <INFO><DEBUG><WARN><ERROR><FATAL> (optional)--h" % sys.argv[0])
  print("-------------------------------------------------------------------------------------------------------------------------------")

def getMIR3ContactTotals(log_msg, mir3_response):

  mir3ContactCnt = 0
  mir3_ns = ''  #mbk assign it to default before getting from elementTree
  foundIt = False
  
  root = ET.fromstring(mir3_response.content)
  for child in root.iter('*'):
    #log_msg.debug("Child Tag [{}] Child Attribute [{}] Child Text [{}]".format(child.tag, child.attrib, child.text))
    
    if len(re.findall('}response$', child.tag, flags=re.IGNORECASE)) > 0:
      mir3_ns = child.tag.split('}')[0] + '}'
      log_msg.debug("Response Found for getting namespace using the following: [{}]".format(mir3_ns))
    
    if len(re.findall('{}matchcount$'.format(mir3_ns), child.tag, flags=re.IGNORECASE)) > 0:
      log_msg.debug("Count of records found in MIR3 is: [{}]".format(child.text))
      mir3ContactCnt = child.text
      foundIt = True
    
    if mir3_ns is not None and foundIt:
      log_msg.debug("Found needed values for parsing elementTree...")
      break
  return mir3ContactCnt
  
def getMIR3ContactData(log_msg, mir3_response):

  mir3ContactCnt = 0
  contactTuple = {}
  mir3_ns = ''  #mbk assign it to default before getting from elementTree
  
  root = ET.fromstring(mir3_response.content)
  for child in root.iter('*'):
    #log_msg.debug("Child Tag [{}] Child Attribute [{}] Child Text [{}]".format(child.tag, child.attrib, child.text))
    
    if len(re.findall('}response$', child.tag, flags=re.IGNORECASE)) > 0:
      mir3_ns = child.tag.split('}')[0] + '}'
      log_msg.debug("Response Found for getting namespace using the following: [{}]".format(mir3_ns))
    
    if len(re.findall('{}matchcount$'.format(mir3_ns), child.tag, flags=re.IGNORECASE)) > 0:
      log_msg.debug("Count of records found in MIR3 is: [{}]".format(child.text))
      #contactTuple["mir3_matchcount"] = child.text
      #only care on what is returned so commented this out...
      #mir3ContactCnt = int(child.text)
      
    if len(re.findall('{}returncount$'.format(mir3_ns), child.tag, flags=re.IGNORECASE)) > 0:
      log_msg.debug("Count of matched records found in MIR3 is: [{}]".format(child.text))
      #contactTuple["mir3_returncount"] = child.text
      mir3ContactCnt = int(child.text)
    
    #if mir3_ns is not None and 'mir3_returncount' in contactTuple and 'mir3_matchcount' in contactTuple:
    if mir3_ns is not None and mir3ContactCnt > 0:
      log_msg.debug("Found needed values for parsing elementTree...")
      break
    
  for recipent in root.iter('{}recipientDetail'.format(mir3_ns)):
    #reset all variables for this loops 500+ times based on config setting
    mir3_jobcode = ''
    mir3_managerlevel = ''
    mir3_department = ''
    mir3_businessunit = ''
    mir3_datasource = ''
    mir3_middlename = ''
    mir3_supervisorid = ''
    mir3_snow_sysid = ''
    mir3_snow_userid = ''  
    mir3_workemail = ''
    mir3_personalemail = ''
    mir3_workphone = ''
    mir3_homephone = ''
    mir3_mobile = ''
    mir3_sms = ''
    mir3_homeemail = ''
    mir3_passwordhash = ''  
    mir3_homezip = ''
    mir3_addressType = ''
    mir3_addressZip = ''
    #####################################################################
    
    log_msg.debug("Tag for this item is {}".format(recipent.tag))
    mir3_useruuid = recipent.find('{}userUUID'.format(mir3_ns)).text 
    mir3_pin = recipent.find('{}pin'.format(mir3_ns)).text
    mir3_telephonyid = recipent.find('{}telephonyId'.format(mir3_ns)).text
    mir3_firstname = recipent.find('{}firstName'.format(mir3_ns)).text
    mir3_lastname = recipent.find('{}lastName'.format(mir3_ns)).text
    mir3_locale = recipent.find('{}locale'.format(mir3_ns)).text
    mir3_division = recipent.find('{}division'.format(mir3_ns)).text

    if recipent.find('{}password'.format(mir3_ns)) is None:
      mir3_passwordhash = ''
    else:
      mir3_passwordhash = recipent.find('{}password'.format(mir3_ns)).text
      
    if recipent.find('{}employeeId'.format(mir3_ns)) is None:
      mir3_employeeid = ''
    else:
      mir3_employeeid = recipent.find('{}employeeId'.format(mir3_ns)).text.lower()
      
    if recipent.find('{}company'.format(mir3_ns)) is None:
      mir3_company = ''
    else:
      mir3_company = recipent.find('{}company'.format(mir3_ns)).text
        
    if recipent.find('{}username'.format(mir3_ns)) is None:
      mir3_username = ''
    else:
      mir3_username = recipent.find('{}username'.format(mir3_ns)).text
       
    if recipent.find('{}jobTitle'.format(mir3_ns)) is None:
      mir3_jobtitle = ''
    else:
      mir3_jobtitle = recipent.find('{}jobTitle'.format(mir3_ns)).text

    if recipent.find('{}role'.format(mir3_ns)) is None:
      mir3_role = ''
    else:
      mir3_role = recipent.find('{}role'.format(mir3_ns)).text

    #for addresses...
    for addresses in recipent.iter('{}addresses'.format(mir3_ns)):
      #log_msg.debug("In Address lookups")
      mir3_homezip = ''
      mir3_addressType = ''
      mir3_addressZip = ''
      
      for address in addresses.iter('{}address'.format(mir3_ns)):
        mir3_addressType = address.find('{}addressTypeName'.format(mir3_ns)).text
        #mir3_addressZip = address.find('{}zip'.format(mir3_ns)).text  if not found then .text gives error....
        if address.find('{}zip'.format(mir3_ns)) is None:
          mir3_addressZip = ''
        else:
          mir3_addressZip = address.find('{}zip'.format(mir3_ns)).text
          
        log_msg.debug("Address Type [{}] has ZIP [{}]".format(mir3_addressType, mir3_addressZip))
        #log_msg.debug("Address Type [{}] has type [{}]".format(mir3_addressType, type(mir3_addressType)))
        if (mir3_addressType == "home"):
          if len(mir3_addressZip) > 0:
            log_msg.debug("Found ZIP for HOME Address setting to [{}]".format(mir3_addressZip))
            mir3_homezip = mir3_addressZip
    
    #now get devices...
    for devices in recipent.iter('{}devices'.format(mir3_ns)):
      #log_msg.debug("Tag for this item is {}".format(devices.tag))
      mir3_workemail = ''
      mir3_personalemail = ''
      mir3_workphone = ''
      mir3_homephone = ''
      mir3_mobile = ''
      mir3_sms = ''
      mir3_homeemail = ''  
      
      for device in devices.iter('{}device'.format(mir3_ns)):
        #log_msg.debug("Tag for eachdevice is {}".format(device.tag))
        mir3_devicetype = device.find('{}deviceType'.format(mir3_ns)).text 
        mir3_deviceaddr = device.find('{}address'.format(mir3_ns)).text
        log_msg.debug("Name [{}] with address [{}]".format(mir3_devicetype, mir3_deviceaddr))
        
        if len(re.findall('work email', mir3_devicetype, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found work email....")
          mir3_workemail = mir3_deviceaddr
        if len(re.findall('personal email', mir3_devicetype, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found personal email....")
          mir3_personalemail = mir3_deviceaddr
        if len(re.findall('work phone', mir3_devicetype, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found work phone....")
          mir3_workphone = mir3_deviceaddr
        if len(re.findall('home phone', mir3_devicetype, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found home phone....")
          mir3_homephone = mir3_deviceaddr
        if len(re.findall('home mobile', mir3_devicetype, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found home mobile....")
          mir3_mobile = mir3_deviceaddr
        if len(re.findall('work mobile', mir3_devicetype, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found work mobile....")
          mir3_mobile = mir3_deviceaddr
        if len(re.findall('home sms', mir3_devicetype, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found home sms....")
          mir3_sms = mir3_deviceaddr
        if len(re.findall('work sms', mir3_devicetype, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found work sms....")
          mir3_sms = mir3_deviceaddr
        if len(re.findall('home email', mir3_devicetype, flags=re.IGNORECASE)) > 0:
          log_msg.info("Found home email....")
          mir3_homeemail = mir3_deviceaddr          
 
    #now get custom attributes
    for customfields in recipent.iter('{}customFields'.format(mir3_ns)):
      #log_msg.debug("Tag for this item is {}".format(devices.tag))
      mir3_jobcode = ''
      mir3_managerlevel = ''
      mir3_department = ''
      mir3_businessunit = ''
      mir3_datasource = ''
      mir3_middlename = ''
      mir3_supervisorid = ''
      mir3_snow_sysid = ''
      mir3_snow_userid = ''  
  
      for customfield in customfields.iter('{}customField'.format(mir3_ns)):
        #log_msg.debug("Tag for eachdevice is {}".format(customfield.tag))
        mir3_name = customfield.find('{}name'.format(mir3_ns)).text 
        mir3_value = customfield.find('{}value'.format(mir3_ns)).text
        log_msg.debug("Name [{}] with address [{}]".format(mir3_name, mir3_value))
        
        if len(re.findall('job code', mir3_name, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found job code....")
          mir3_jobcode = mir3_value
        if len(re.findall('manager level', mir3_name, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found manager level....")
          mir3_managerlevel = mir3_value
        if len(re.findall('department id', mir3_name, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found department id....")
          mir3_department = mir3_value
        if len(re.findall('business unit', mir3_name, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found business unit....")
          mir3_businessunit = mir3_value
        if len(re.findall('data source', mir3_name, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found data source....")
          mir3_datasource = mir3_value
        if len(re.findall('middle name', mir3_name, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found middle name....")
          mir3_middlename = mir3_value
        if len(re.findall('supervisor id', mir3_name, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found supervisor id....")
          mir3_supervisorid = mir3_value
        if len(re.findall('snow_sysid', mir3_name, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found ServiceNow sysid....")
          mir3_snow_sysid = mir3_value
        if len(re.findall('snow_userid', mir3_name, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found ServiceNow userid....")
          mir3_snow_userid = mir3_value.lower()          
        
    if len(mir3_employeeid) < 1:
      log_msg.warning("INVALID EmployeeID for ServiceNow sysid [{}] and MIR3 Contact UUID [{}]".format(mir3_snow_sysid, mir3_useruuid))
      log_msg.info("Invalid Contact Details: UUID is {} pin {} telephony {} firstname {} lastname {} locale {} employee ID {} company {} division {}".format(mir3_useruuid,mir3_pin,mir3_telephonyid,mir3_firstname,mir3_lastname,mir3_locale,mir3_employeeid,mir3_company,mir3_division))
    else:
      log_msg.debug("UUID is {} pin {} telephony {} firstname {} lastname {} locale {} employee ID {} company {} division {} username {} workemail {} personal email {} work phone {} home phone {} mobile {} sms {} home email {} mir3_jobcode {} mir3_managerlevel {} mir3_department {} mir3_department {} mir3_businessunit {} mir3_datasource {} mir3_middlename {} job_title {} supervisor id {} snow_sysid {} snow_userid {} mir3_passwordhash {} mir3_homezip {}".format(mir3_useruuid,mir3_pin,mir3_telephonyid,mir3_firstname,mir3_lastname,mir3_locale, mir3_employeeid,mir3_company,mir3_division, mir3_username, mir3_workemail, mir3_personalemail, mir3_workphone, mir3_homephone, mir3_mobile, mir3_sms, mir3_homeemail,mir3_jobcode, mir3_managerlevel, mir3_department, mir3_businessunit, mir3_datasource, mir3_middlename, mir3_jobtitle, mir3_role, mir3_supervisorid, mir3_snow_sysid, mir3_snow_userid, mir3_passwordhash, mir3_homezip ))
      contactTuple[mir3_employeeid] = { 'mir3_pin' : mir3_pin, 'mir3_telephonyid' : mir3_telephonyid, 'mir3_firstname' : mir3_firstname, 'mir3_lastname' : mir3_lastname, 'mir3_locale' : mir3_locale, 'mir3_useruuid' : mir3_useruuid, 'mir3_company' : mir3_company, 'mir3_division' : mir3_division, 'mir3_username' : mir3_username, 'mir3_workemail' : mir3_workemail, 'mir3_personalemail' : mir3_personalemail, 'mir3_workphone' : mir3_workphone, 'mir3_homephone' : mir3_homephone, 'mir3_mobile' : mir3_mobile, 'mir3_sms' : mir3_sms, 'mir3_homeemail' : mir3_homeemail, 'mir3_jobcode' : mir3_jobcode, 'mir3_managerlevel' :  mir3_managerlevel, 'mir3_department' : mir3_department, 'mir3_businessunit' : mir3_businessunit, 'mir3_datasource' : mir3_datasource, 'mir3_middlename' : mir3_middlename, 'mir3_jobtitle' : mir3_jobtitle, 'mir3_role' : mir3_role, 'mir3_supervisorid' : mir3_supervisorid, 'mir3_snow_sysid' : mir3_snow_sysid, 'mir3_snow_userid' : mir3_snow_userid, 'mir3_employeeid' : mir3_employeeid, 'mir3_passwordhash' : mir3_passwordhash, 'mir3_homezip' : mir3_homezip }

    
  #return values needed for logic on insert...  
  return mir3ContactCnt, contactTuple
  
def getSNowContactData(log_msg, contact):

  contactTuple = {}
  #log_msg.debug('Working on contact [{}]'.format(contact))
  for key, val in contact.items():
  
    #log_msg.debug('Key for contact is {}'.format(key))
    if(key.lower() == "sys_id"):
      if val is None:
        sn_sys_id = ''
      else:
        sn_sys_id = strip_accents(val)
      log_msg.debug('   sys_id is: {}'.format(sn_sys_id))
      contactTuple["sn_sys_id"] = sn_sys_id
      
    if(key.lower() == "country"):
      if val is None:
        sn_country = ''
      else:
        sn_country = strip_accents(val)
      log_msg.debug('   country is: {}'.format(sn_country))
      contactTuple["sn_country"] = sn_country
      
    if(key.lower() == "u_floor_cube"):
      if val is None:
        sn_foor = ''
      else:
        sn_floor = strip_accents(val)
      log_msg.debug('   floor is: {}'.format(sn_floor))
      contactTuple["sn_floor"] = sn_floor
      
    if(key.lower() == "sys_updated_on"):
      if val is None:
        sn_sys_updated_on = ''
      else:
        sn_sys_updated_on = strip_accents(val)
      log_msg.debug('   last updated on: {}'.format(sn_sys_updated_on))
      contactTuple["sn_sys_updated_on"] = sn_sys_updated_on
      
    if(key.lower() == "building"):
      if val is None:
        sn_building = ''
      else:
        sn_building = strip_accents(val)
      log_msg.debug('   building is: {}'.format(sn_building))
      contactTuple["sn_building"] = sn_building
      
    if(key.lower() == "u_job_title"):
      if val is None:
        sn_job_title = ''
      else:
        sn_job_title = strip_accents(val)
      log_msg.debug('   job title is: {}'.format(sn_job_title))
      contactTuple["sn_job_title"] = sn_job_title
      
    if(key.lower() == "zip"):
      if val is None:
        sn_zip = ''
      else:
        sn_zip = strip_accents(val)
      log_msg.debug('   zip is: {}'.format(sn_zip))
      contactTuple["sn_zip"] = sn_zip
      
    if(key.lower() == "home_phone"):
      if val is None:
        sn_home_phone = ''
      else:
        sn_home_phone = strip_accents(val)
      log_msg.debug('   home phone is: {}'.format(sn_home_phone))
      contactTuple["sn_home_phone"] = sn_home_phone
      
    if(key.lower() == "active"):
      if val is None:
        sn_active = ''
      else:
        sn_active = strip_accents(val)
      log_msg.debug('   active is: {}'.format(sn_active))
      contactTuple["sn_active"] = sn_active
      
    if(key.lower() == "u_bsc_source"):
      if val is None:
        sn_u_bsc_source = ''
      else:
        sn_u_bsc_source = strip_accents(val)
      log_msg.debug('   BSC Source is: {}'.format(sn_u_bsc_source))
      contactTuple["sn_u_bsc_source"] = sn_u_bsc_source
      
    if(key.lower() == "cost_center"):
      if val is None:
        sn_cost_center = ''
      else:
        sn_cost_center = strip_accents(val)
      log_msg.debug('   cost center is: {}'.format(sn_cost_center))
      contactTuple["sn_cost_center"] = sn_cost_center
      
    if(key.lower() == "phone"):
      if val is None:
        sn_bus_phone = ''
      else:
        sn_bus_phone = strip_accents(val)
      log_msg.debug('   Business phone is: {}'.format(sn_bus_phone))
      contactTuple["sn_bus_phone"] = sn_bus_phone
      
    if(key.lower() == "name"):
      if val is None:
        sn_full_name = ''
      else:
        sn_full_name = strip_accents(val)
      log_msg.debug('   full name is: {}'.format(sn_full_name))
      contactTuple["sn_full_name"] = sn_full_name
      
    if(key.lower() == "u_emp_type"):
      if val is None:
        sn_u_emp_type = ''
      else:
        sn_u_emp_type = strip_accents(val)
      log_msg.debug('   employee type is: {}'.format(sn_u_emp_type))
      contactTuple["sn_u_emp_type"] = sn_u_emp_type
      
    if(key.lower() == "employee_number"):
      if val is None:
        sn_employee_number = ''
      else:
        sn_employee_number = strip_accents(val)
      log_msg.debug('   employee number is: {}'.format(sn_employee_number))
      contactTuple["sn_employee_number"] = sn_employee_number
      
    if(key.lower() == "city"):
      if val is None:
        sn_city = ''
      else:
        sn_city = strip_accents(val)
      log_msg.debug('   city is: {}'.format(sn_city))
      contactTuple["sn_city"] = sn_city
      
    if(key.lower() == "user_name"):
      if val is None:
        sn_username = ''
      else:
        sn_username = strip_accents(val).lower()
      log_msg.debug('   username is: {}'.format(sn_username))
      contactTuple["sn_username"] = sn_username
      
    if(key.lower() == "title"):
      if val is None:
        sn_title = ''
      else:
        sn_title = strip_accents(val)
      log_msg.debug('   title is: {}'.format(sn_title))
      contactTuple["sn_title"] = sn_title
      
    if(key.lower() == "mobile_phone"):
      if val is None:
        sn_mobile_phone = ''
        sn_sms_number = ''
      else:
        sn_mobile_phone = strip_accents(val)
        sn_sms_number = strip_accents(val)
      log_msg.debug('   mobile phone is: {}'.format(sn_mobile_phone))
      log_msg.debug('   SMS number is: {}'.format(sn_sms_number))
      contactTuple["sn_mobile_phone"] = sn_mobile_phone
      contactTuple["sn_sms_number"] = sn_sms_number
      
    if(key.lower() == "street"):
      if val is None:
        sn_street = ''
      else:
        sn_street = strip_accents(val)
      log_msg.debug('   street is: {}'.format(sn_street))
      contactTuple["sn_street"] = sn_street
      
    if(key.lower() == "company"):
      if val is None:
        sn_company = ''
      else:
        sn_company = strip_accents(val)
      log_msg.debug('   company is: {}'.format(sn_company))
      contactTuple["sn_company"] = sn_company
      
    if(key.lower() == "department"):
      if val is None:
        sn_department = ''
      else:
        sn_department = strip_accents(val)
      log_msg.debug('   department is: {}'.format(sn_department))
      contactTuple["sn_department"] = sn_department
      
    if(key.lower() == "first_name"):
      if val is None:
        sn_first_name = ''
      else:
        sn_first_name = strip_accents(val)
      log_msg.debug('   first name is: {}'.format(sn_first_name))
      contactTuple["sn_first_name"] = sn_first_name
      
    if(key.lower() == "email"):
      if val is None:
        sn_work_email = ''
      else:
        sn_work_email = strip_accents(val)
      log_msg.debug('   work email is: {}'.format(sn_work_email))
      contactTuple["sn_work_email"] = sn_work_email

    if(key.lower() == "u_personal_email"):
      if val is None:
        sn_personal_email = ''
      else:
        sn_personal_email = strip_accents(val)
      log_msg.debug('   personal email is: {}'.format(sn_personal_email))
      contactTuple["sn_personal_email"] = sn_personal_email
      
    if(key.lower() == "preferred_language"):
      if val is None:
        sn_language = ''
      else:
        sn_language = strip_accents(val)
      log_msg.debug('   language is: {}'.format(sn_language))
      contactTuple["sn_language"] = sn_language
      
    if(key.lower() == "manager"):
      if val is None:
        sn_manager = ''
      else:
        sn_manager = strip_accents(val)
      log_msg.debug('   manager is: {}'.format(sn_manager))
      contactTuple["sn_manager"] = sn_manager
      
    if(key.lower() == "last_name"):
      if val is None:
        sn_last_name = ''
      else:
        sn_last_name = strip_accents(val)
      log_msg.debug('   last name is: {}'.format(sn_last_name))
      contactTuple["sn_last_name"] = sn_last_name
      
    if(key.lower() == "middle_name"):
      if val is None:
        sn_middle_name = ''
      else:
        sn_middle_name = strip_accents(val)
      log_msg.debug('   middle name is: {}'.format(sn_middle_name))
      contactTuple["sn_middle_name"] = sn_middle_name
      
    if(key.lower() == "location"):
      if val is None:
        sn_location = ''
      else:
        sn_location = strip_accents(val)
      log_msg.debug('   location is: {}'.format(sn_location))
      contactTuple["sn_location"] = sn_location
      
    if(key.lower() == "u_business_unit"):
      if val is None:
        sn_u_business_unit = ''
      else:
        sn_u_business_unit = strip_accents(val)
      log_msg.debug('   business unit is: {}'.format(sn_u_business_unit))
      contactTuple["sn_u_business_unit"] = sn_u_business_unit

    if(key.lower() == "u_management_level"):
      if val is None:
        sn_u_management_level = ''
      else:
        sn_u_management_level = strip_accents(val)
      log_msg.debug('   management level: {}'.format(sn_u_management_level))
      contactTuple["sn_u_management_level"] = sn_u_management_level
      
      
  return contactTuple

def insertMIR3Contact(log_msg, mir3_url, sn_contactAttrs, mir3_username, mir3_password, mir3_api_version, mir3_default_role, datasync):

  #MIR3 variables
  mir3_auth_str = '%s:%s' % (mir3_username, mir3_password)
  mir3_b64_auth_str = base64.b64encode(mir3_auth_str.encode("utf-8"))

  payload_start = """<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://www.mir3.com/ws\"> \r\n
   <soapenv:Header/>\r\n
   <soapenv:Body>\r\n
      <ws:addNewRecipients>\r\n
         <ws:apiVersion>{mir3_api_version}</ws:apiVersion>\r\n
         <ws:authorization>\r\n
            <ws:username><![CDATA[{username}]]></ws:username>\r\n
            <ws:password><![CDATA[{password}]]></ws:password>\r\n
         </ws:authorization>\r\n
         <ws:ignoreInvalidDevices>true</ws:ignoreInvalidDevices>\r\n
         <ws:recipientDetail>
               <ws:firstName><![CDATA[{firstname}]]></ws:firstName>\r\n
               <ws:lastName><![CDATA[{lastname}]]></ws:lastName>\r\n
               <ws:jobTitle><![CDATA[{jobtitle}]]></ws:jobTitle>\r\n
               <ws:company><![CDATA[{company}]]></ws:company>\r\n"""

                  
  payload_start_cont = """\r\n
                 <ws:role><![CDATA[{role}]]></ws:role>\r\n
               <ws:devices>\r\n """
               
  payload_end = """</ws:customFields>\r\n
               <ws:employeeId><![CDATA[{employeeid}]]></ws:employeeId>\r\n
         </ws:recipientDetail>\r\n
        </ws:addNewRecipients>\r\n
      </soapenv:Body>\r\n
    </soapenv:Envelope> """    

  payload_home_mobile = """ \r\n
                    <ws:device>\r\n
                     <ws:deviceType>Home Mobile</ws:deviceType>\r\n
                     <ws:address><![CDATA[{mobile}]]></ws:address>\r\n
                     <ws:description>Home Mobile</ws:description>\r\n
                     <ws:private>false</ws:private>\r\n
                     <ws:disabled>false</ws:disabled>\r\n
                     <ws:defaultPriority>1</ws:defaultPriority>\r\n
                  </ws:device>\r\n """
                  
  payload_work_email = """ \r\n
                    <ws:device>\r\n
                     <ws:deviceType>Work Email</ws:deviceType>\r\n
                     <ws:address><![CDATA[{workemail}]]></ws:address>\r\n
                     <ws:description>Work Email</ws:description>\r\n
                     <ws:private>false</ws:private>\r\n
                     <ws:disabled>false</ws:disabled>\r\n
                     <ws:sendReports2>GRAPHICAL</ws:sendReports2>\r\n
                     <ws:defaultPriority>1</ws:defaultPriority>\r\n
                  </ws:device>\r\n """
                  
  payload_personal_email = """ \r\n
                  <ws:device>\r\n
                     <ws:deviceType>Personal Email</ws:deviceType>\r\n
                     <ws:address><![CDATA[{personalemail}]]></ws:address>\r\n
                     <ws:description>Personal Email</ws:description>\r\n
                     <ws:private>false</ws:private>\r\n
                     <ws:disabled>false</ws:disabled>\r\n
                     <ws:sendReports2>GRAPHICAL</ws:sendReports2>\r\n
                     <ws:defaultPriority>1</ws:defaultPriority>\r\n
                  </ws:device>\r\n"""
  
  payload_work_phone = """ \r\n
                  <ws:device>\r\n
                     <ws:deviceType>Work Phone</ws:deviceType>\r\n
                     <ws:address><![CDATA[{workphone}]]></ws:address>\r\n
                     <ws:description>Work Phone</ws:description>\r\n
                     <ws:private>false</ws:private>\r\n
                     <ws:disabled>false</ws:disabled>\r\n
                     <ws:defaultPriority>1</ws:defaultPriority>\r\n
                  </ws:device>\r\n"""

  payload_home_phone = """ \r\n
                  <ws:device>\r\n
                     <ws:deviceType>Home Phone</ws:deviceType>\r\n
                     <ws:address><![CDATA[{homephone}]]></ws:address>\r\n
                     <ws:description>Home Phone</ws:description>\r\n
                     <ws:private>false</ws:private>\r\n
                     <ws:disabled>false</ws:disabled>\r\n
                     <ws:defaultPriority>1</ws:defaultPriority>\r\n
                  </ws:device>\r\n"""
  
  payload_sms = """ \r\n
                    <ws:device>\r\n
                     <ws:deviceType>Home SMS</ws:deviceType>\r\n
                     <ws:address><![CDATA[{sms}]]></ws:address>\r\n
                     <ws:description>Home SMS</ws:description>\r\n
                     <ws:private>false</ws:private>\r\n
                     <ws:disabled>false</ws:disabled>\r\n
                     <ws:defaultPriority>1</ws:defaultPriority>\r\n
                  </ws:device>\r\n"""
  
  payload_bus_unit = """\r\n
                    <ws:customField>\r\n
                     <ws:name>Business Unit</ws:name>\r\n
                     <ws:value><![CDATA[{businessunit}]]></ws:value>\r\n
                  </ws:customField>\r\n """
  payload_job_code = """\r\n
                  <ws:customField>\r\n
                     <ws:name>Job Code</ws:name>\r\n
                     <ws:value><![CDATA[{jobcode}]]></ws:value>\r\n
                  </ws:customField>\r\n"""
  payload_dept = """\r\n
                  <ws:customField>\r\n
                     <ws:name>Department ID</ws:name>\r\n
                     <ws:value><![CDATA[{departmentid}]]></ws:value>\r\n
                  </ws:customField>\r\n"""
  payload_manager_level = """\r\n                
                  <ws:customField>\r\n
                     <ws:name>Manager Level</ws:name>\r\n
                     <ws:value><![CDATA[{managerlevel}]]></ws:value>\r\n
                  </ws:customField>\r\n"""
  payload_datasource = """\r\n
                  <ws:customField>\r\n
                     <ws:name>Data Source</ws:name>\r\n
                     <ws:value><![CDATA[{datasource}]]></ws:value>\r\n
                  </ws:customField>\r\n"""
  payload_middlename = """\r\n                
                  <ws:customField>\r\n
                     <ws:name>Middle Name</ws:name>\r\n
                     <ws:value><![CDATA[{middlename}]]></ws:value>\r\n
                  </ws:customField>\r\n"""
  payload_supervisor = """\r\n
                  <ws:customField>\r\n
                     <ws:name>Supervisor ID</ws:name>\r\n
                     <ws:value><![CDATA[{manager}]]></ws:value>\r\n
                  </ws:customField>\r\n"""
  payload_snow_sysid = """\r\n
                  <ws:customField>\r\n
                     <ws:name>snow_sysid</ws:name>\r\n
                     <ws:value><![CDATA[{snow_sysid}]]></ws:value>\r\n
                  </ws:customField>\r\n"""
  payload_snow_userid = """\r\n
                  <ws:customField>\r\n
                     <ws:name>snow_userid</ws:name>\r\n
                     <ws:value><![CDATA[{snow_userid}]]></ws:value>\r\n
                  </ws:customField>\r\n"""

  payload_home_address = """\r\n
               <ws:addresses>\r\n
                  <ws:address>\r\n
                     <ws:addressTypeName>home</ws:addressTypeName>\r\n
                      <ws:zip><![CDATA[{snow_zip}]]></ws:zip>\r\n
                  </ws:address>\r\n
               </ws:addresses>\r\n"""

  #lots of checks for empty values and it not empty append to payload string
  payload_append = payload_start
  
  if len(sn_contactAttrs['sn_zip']) > 0:
    payload_append = payload_append + payload_home_address
    
  payload_append = payload_append + payload_start_cont
  
  if len(sn_contactAttrs['sn_mobile_phone']) > 0:
    payload_append = payload_append + payload_home_mobile 
  
  if len(sn_contactAttrs['sn_work_email']) > 0:
    payload_append = payload_append + payload_work_email
  
  if len(sn_contactAttrs['sn_personal_email']) > 0:
    payload_append = payload_append + payload_personal_email

  if len(sn_contactAttrs['sn_bus_phone']) > 0:
    payload_append = payload_append + payload_work_phone

  if len(sn_contactAttrs['sn_home_phone']) > 0:
    payload_append = payload_append + payload_home_phone
    
  if len(sn_contactAttrs['sn_mobile_phone']) > 0:
    payload_append = payload_append + payload_sms
  
  #append xml tags between devices and customfields
  payload_append = payload_append +  """</ws:devices>\r\n
               <ws:customFields>\r\n"""
               
  if len(sn_contactAttrs['sn_u_business_unit']) > 0:
    payload_append = payload_append + payload_bus_unit
    
  if len(sn_contactAttrs['sn_u_emp_type']) > 0:
    payload_append = payload_append + payload_job_code
    
  if len(sn_contactAttrs['sn_department']) > 0:
    payload_append = payload_append + payload_dept
    
  if len(sn_contactAttrs['sn_u_management_level']) > 0:
    payload_append = payload_append + payload_manager_level
    
  #all will get data source
  payload_append = payload_append + payload_datasource
    
  if len(sn_contactAttrs['sn_middle_name']) > 0:
    payload_append = payload_append + payload_middlename
    
  if len(sn_contactAttrs['sn_manager']) > 0:
    payload_append = payload_append + payload_supervisor
    
  if len(sn_contactAttrs['sn_sys_id']) > 0:
    payload_append = payload_append + payload_snow_sysid
    
  if len(sn_contactAttrs['sn_username']) > 0:
    payload_append = payload_append + payload_snow_userid
  
  #append trailer records
  payload_append = payload_append + payload_end

                  
  #default to MIR3 default role....
  mir3_role = mir3_default_role
  
  #update to the needed values....
  mir3_payload_upd = payload_append.format(mir3_api_version=mir3_api_version, username=mir3_username, password=mir3_password, employeeid=sn_contactAttrs['sn_username'], firstname=sn_contactAttrs['sn_first_name'], lastname=sn_contactAttrs['sn_last_name'], jobtitle=sn_contactAttrs['sn_job_title'], company=sn_contactAttrs['sn_company'], role=mir3_role, mobile=sn_contactAttrs['sn_mobile_phone'], workemail=sn_contactAttrs['sn_work_email'], workphone=sn_contactAttrs['sn_bus_phone'], personalemail=sn_contactAttrs['sn_personal_email'], homephone=sn_contactAttrs['sn_home_phone'], sms=sn_contactAttrs['sn_mobile_phone'], businessunit=sn_contactAttrs['sn_u_business_unit'], jobcode=sn_contactAttrs['sn_u_emp_type'], departmentid=sn_contactAttrs['sn_department'], managerlevel=sn_contactAttrs['sn_u_management_level'], datasource=datasync, middlename=sn_contactAttrs['sn_middle_name'], manager=sn_contactAttrs['sn_manager'], snow_sysid=sn_contactAttrs['sn_sys_id'], snow_userid=sn_contactAttrs['sn_username'], snow_zip=sn_contactAttrs['sn_zip'])
  mir3_payload_log = payload_append.format(mir3_api_version=mir3_api_version, username='XXXXXXXXXX', password='XXXXXXXXXX', employeeid=sn_contactAttrs['sn_username'], firstname=sn_contactAttrs['sn_first_name'], lastname=sn_contactAttrs['sn_last_name'], jobtitle=sn_contactAttrs['sn_job_title'], company=sn_contactAttrs['sn_company'], role=mir3_role, mobile=sn_contactAttrs['sn_mobile_phone'], workemail=sn_contactAttrs['sn_work_email'], workphone=sn_contactAttrs['sn_bus_phone'], personalemail=sn_contactAttrs['sn_personal_email'], homephone=sn_contactAttrs['sn_home_phone'], sms=sn_contactAttrs['sn_mobile_phone'], businessunit=sn_contactAttrs['sn_u_business_unit'], jobcode=sn_contactAttrs['sn_u_emp_type'], departmentid=sn_contactAttrs['sn_department'], managerlevel=sn_contactAttrs['sn_u_management_level'], datasource=datasync, middlename=sn_contactAttrs['sn_middle_name'], manager=sn_contactAttrs['sn_manager'], snow_sysid=sn_contactAttrs['sn_sys_id'], snow_userid=sn_contactAttrs['sn_username'], snow_zip=sn_contactAttrs['sn_zip'])

  log_msg.debug("Updated payload: [{}]".format(mir3_payload_log))

  mir3_headers = {
    'Authorization': 'Basic {}'.format(mir3_b64_auth_str),
    'Content-Type': 'application/xml'
  }

  mir3_response = requests.request("POST", mir3_url, headers=mir3_headers, data = mir3_payload_upd, verify=True)

  if mir3_response.status_code != 200: 
    log_msg.info("Failure with attempted payload: [{}]".format(mir3_payload_log))
    log_msg.error("MIR3 Status [{}] Headers [{}] Error Response: [{}]".format(mir3_response.status_code, mir3_response.headers, mir3_response.text))
    exit(21)

  #lets validate we got 'success' = 'true' from the response....
  log_msg.debug("headers [{}] text [{}]".format(mir3_response.headers, mir3_response.text))
  successValue = re.search("<success>.*</success>", mir3_response.text, flags=re.IGNORECASE)
  responseCode = successValue.group(0).split('>')[1].split('</')[0]
  if len(responseCode) > 0:
    log_msg.debug("Success boolean from MIR3 response is [{}]".format(responseCode))
    if responseCode.lower() == 'false':
      log_msg.info("Failure with attempted payload: [{}]".format(mir3_payload_log))
      log_msg.error("Failed to insert contact [{}], exiting from program!".format(sn_contactAttrs['sn_username']))
      log_msg.error("Received: [{}]".format(mir3_response.text))
      exit(25)
    else:
      log_msg.debug("Received: [{}] from insert call into MIR3 for contact [{}]".format(responseCode, sn_contactAttrs['sn_username']))
  else:
    log_msg.warning("Could not find <success> in the response from MIR3, for contact [{}]".format(sn_contactAttrs['sn_username']))
    log_msg.warning("Received: [{}]".format(mir3_response.text))
 
  #check for non-critical errors....
  errorStr = re.search("<errorcode>.*</errorcode>", mir3_response.text, flags=re.IGNORECASE)
  if errorStr is not None:
    errorNum = errorStr.group(0).split('>')[1].split('</')[0]
    if len(errorNum) > 0:
      log_msg.warning("Received none-critical error message: [{}] for contact [{}]".format(errorNum, sn_contactAttrs['sn_username']))
      errorMsgStr = re.search("<errormessage>.*</errormessage>", mir3_response.text, flags=re.IGNORECASE)
      errorMsg = errorMsgStr.group(0).split('>')[1].split('</')[0]
      log_msg.warning("Non-Critical Message received: [{}] for contact [{}]".format(errorMsg, sn_contactAttrs['sn_username']))
    else:
      log_msg.debug("No non-critical error received for contact [{}]".format(sn_contactAttrs['sn_username']))
    
  log_msg.info("Successfully inserted contact [{}]".format(sn_contactAttrs['sn_username']))
 
def compareContactRecords(log_msg, sn_contactAttrs, mir3_contactAttrs):
  # returning with 0 means no update needed, 1 means update needed...
  returnValue = 0
  
  if 'sn_first_name' in sn_contactAttrs and 'mir3_firstname' in mir3_contactAttrs:
    value1 = checkNoneLowerCase(sn_contactAttrs['sn_first_name'], log_msg)
    value2 = checkNoneLowerCase(mir3_contactAttrs['mir3_firstname'], log_msg)
    #if sn_contactAttrs['sn_first_name'].lower().strip() != mir3_contactAttrs['mir3_firstname'].lower().strip():
    if value1 != value2:
      log_msg.info("Need to update First Name: Current Value [{}] Setting to [{}] for Contact [{}]".format(mir3_contactAttrs['mir3_firstname'], sn_contactAttrs['sn_first_name'], sn_contactAttrs['sn_username'] ))
      returnValue = 1
      
  if 'sn_last_name' in sn_contactAttrs and 'mir3_lastname' in mir3_contactAttrs:  
    value1 = checkNoneLowerCase(sn_contactAttrs['sn_last_name'], log_msg)
    value2 = checkNoneLowerCase(mir3_contactAttrs['mir3_lastname'], log_msg)
    #if sn_contactAttrs['sn_last_name'].lower().strip() != mir3_contactAttrs['mir3_lastname'].lower().strip():
    if value1 != value2:
      log_msg.info("Need to update Last Name: Current Value [{}] Setting to [{}] for Contact [{}]".format(mir3_contactAttrs['mir3_lastname'], sn_contactAttrs['sn_last_name'], sn_contactAttrs['sn_username']))
      returnValue = 1
  
  if 'sn_username' in sn_contactAttrs and 'mir3_employeeid' in mir3_contactAttrs:  
    value1 = checkNoneLowerCase(sn_contactAttrs['sn_username'], log_msg)
    value2 = checkNoneLowerCase(mir3_contactAttrs['mir3_employeeid'], log_msg)
    #if sn_contactAttrs['sn_username'].lower().strip() != mir3_contactAttrs['mir3_employeeid'].lower().strip():
    if value1 != value2:
      log_msg.info("Need to update employee id: Current Value [{}] Setting to [{}] for Contact [{}]".format(mir3_contactAttrs['mir3_employeeid'], sn_contactAttrs['sn_username'], sn_contactAttrs['sn_username']))
      returnValue = 1
      
  if 'sn_company' in sn_contactAttrs and 'mir3_company' in mir3_contactAttrs:
    value1 = checkNoneLowerCase(sn_contactAttrs['sn_company'], log_msg)
    value2 = checkNoneLowerCase(mir3_contactAttrs['mir3_company'], log_msg)
    #if sn_contactAttrs['sn_company'].lower().strip() != mir3_contactAttrs['mir3_company'].lower().strip():
    if value1 != value2:
      log_msg.info("Need to update company: Current Value [{}] Setting to [{}] for Contact [{}]".format(mir3_contactAttrs['mir3_company'], sn_contactAttrs['sn_company'], sn_contactAttrs['sn_username']))
      returnValue = 1
    
  if 'sn_bus_phone' in sn_contactAttrs and 'mir3_workphone' in mir3_contactAttrs:
    value1 = checkNoneLowerCase(sn_contactAttrs['sn_bus_phone'], log_msg)
    value2 = checkNoneLowerCase(mir3_contactAttrs['mir3_workphone'], log_msg)
    #if sn_contactAttrs['sn_bus_phone'].lower().strip() != mir3_contactAttrs['mir3_workphone'].lower().strip():
    if value1 != value2:
      log_msg.info("Need to update work phone: Current Value [{}] Setting to [{}] for Contact [{}]".format(mir3_contactAttrs['mir3_workphone'], sn_contactAttrs['sn_bus_phone'], sn_contactAttrs['sn_username']))
      returnValue = 1
    
  if 'sn_work_email' in sn_contactAttrs and 'mir3_workemail' in mir3_contactAttrs:
    value1 = checkNoneLowerCase(sn_contactAttrs['sn_work_email'], log_msg)
    value2 = checkNoneLowerCase(mir3_contactAttrs['mir3_workemail'], log_msg)
    #if sn_contactAttrs['sn_work_email'].lower().strip() != mir3_contactAttrs['mir3_workemail'].lower().strip():
    if value1 != value2:
      log_msg.info("Need to update work email: Current Value [{}] Setting to [{}] for Contact [{}]".format(mir3_contactAttrs['mir3_workemail'], sn_contactAttrs['sn_work_email'], sn_contactAttrs['sn_username']))
      returnValue = 1

  if 'sn_personal_email' in sn_contactAttrs and 'mir3_personalemail' in mir3_contactAttrs:
    value1 = checkNoneLowerCase(sn_contactAttrs['sn_personal_email'], log_msg)
    value2 = checkNoneLowerCase(mir3_contactAttrs['mir3_personalemail'], log_msg)
    #if sn_contactAttrs['sn_personal_email'].lower().strip() != mir3_contactAttrs['mir3_personalemail'].lower().strip():
    if value1 != value2:
      log_msg.info("Need to update personal email: Current Value [{}] Setting to [{}] for Contact [{}]".format(mir3_contactAttrs['mir3_personalemail'], sn_contactAttrs['sn_personal_email'], sn_contactAttrs['sn_username']))
      returnValue = 1
      
  if 'sn_mobile_phone' in sn_contactAttrs and 'mir3_mobile' in mir3_contactAttrs:
    value1 = checkNoneLowerCase(sn_contactAttrs['sn_mobile_phone'], log_msg)
    value2 = checkNoneLowerCase(mir3_contactAttrs['mir3_mobile'], log_msg)
    #if sn_contactAttrs['sn_mobile_phone'].lower().strip() != mir3_contactAttrs['mir3_mobile'].lower().strip():
    if value1 != value2:
      log_msg.info("Need to update mobile phone: Current Value [{}] Setting to [{}] for Contact [{}]".format(mir3_contactAttrs['mir3_mobile'], sn_contactAttrs['sn_mobile_phone'], sn_contactAttrs['sn_username']))
      returnValue = 1
    
  if 'sn_sms_number' in sn_contactAttrs and 'mir3_sms' in mir3_contactAttrs:
    value1 = checkNoneLowerCase(sn_contactAttrs['sn_sms_number'], log_msg)
    value2 = checkNoneLowerCase(mir3_contactAttrs['mir3_sms'], log_msg)
    #if sn_contactAttrs['sn_sms_number'].lower().strip() != mir3_contactAttrs['mir3_sms'].lower().strip():
    if value1 != value2:
      log_msg.info("Need to update SMS Number: Current Value [{}] Setting to [{}] for Contact [{}]".format(mir3_contactAttrs['mir3_sms'], sn_contactAttrs['sn_sms_number'], sn_contactAttrs['sn_username']))
      returnValue = 1
      
  if 'sn_home_phone' in sn_contactAttrs and 'mir3_homephone' in mir3_contactAttrs:
    value1 = checkNoneLowerCase(sn_contactAttrs['sn_home_phone'], log_msg)
    value2 = checkNoneLowerCase(mir3_contactAttrs['mir3_homephone'], log_msg)
    #if sn_contactAttrs['sn_home_phone'].lower().strip() != mir3_contactAttrs['mir3_homephone'].lower().strip():
    if value1 != value2:
      log_msg.info("Need to update HOME Phone: Current Value [{}] Setting to [{}] for Contact [{}]".format(mir3_contactAttrs['mir3_homephone'], sn_contactAttrs['sn_home_phone'], sn_contactAttrs['sn_username']))
      returnValue = 1
      
  if 'sn_u_emp_type' in sn_contactAttrs and 'mir3_jobcode' in mir3_contactAttrs:
    value1 = checkNoneLowerCase(sn_contactAttrs['sn_u_emp_type'], log_msg)
    value2 = checkNoneLowerCase(mir3_contactAttrs['mir3_jobcode'], log_msg)
    #if sn_contactAttrs['sn_u_emp_type'].lower().strip() != mir3_contactAttrs['mir3_jobcode'].lower().strip():
    if value1 != value2:
      log_msg.info("Need to update Job Code: Current Value [{}] Setting to [{}] for Contact [{}]".format(mir3_contactAttrs['mir3_jobcode'], sn_contactAttrs['sn_u_emp_type'], sn_contactAttrs['sn_username']))
      returnValue = 1
  
  if 'sn_department' in sn_contactAttrs and 'mir3_department' in mir3_contactAttrs:
    value1 = checkNoneLowerCase(sn_contactAttrs['sn_department'], log_msg)
    value2 = checkNoneLowerCase(mir3_contactAttrs['mir3_department'], log_msg)
    #if sn_contactAttrs['sn_department'].lower().strip() != mir3_contactAttrs['mir3_department'].lower().strip():
    if value1 != value2:
      log_msg.info("Need to update CostCenter/Department: Current Value [{}] Setting to [{}] for Contact [{}]".format(mir3_contactAttrs['mir3_department'],sn_contactAttrs['sn_department'], sn_contactAttrs['sn_username']))
      returnValue = 1
    
  if 'sn_middle_name' in sn_contactAttrs and 'mir3_middlename' in mir3_contactAttrs:
    value1 = checkNoneLowerCase(sn_contactAttrs['sn_middle_name'], log_msg)
    value2 = checkNoneLowerCase(mir3_contactAttrs['mir3_middlename'], log_msg)
    #if sn_contactAttrs['sn_middle_name'].lower().strip() != mir3_contactAttrs['mir3_middlename'].lower().strip():
    if value1 != value2:
      log_msg.info("Need to update middle name: Current Value [{}] Setting to [{}] for Contact [{}]".format(mir3_contactAttrs['mir3_middlename'], sn_contactAttrs['sn_middle_name'], sn_contactAttrs['sn_username']))
      returnValue = 1
    
  if 'sn_u_business_unit' in sn_contactAttrs and 'mir3_businessunit' in mir3_contactAttrs:
    value1 = checkNoneLowerCase(sn_contactAttrs['sn_u_business_unit'], log_msg)
    value2 = checkNoneLowerCase(mir3_contactAttrs['mir3_businessunit'], log_msg)
    #if sn_contactAttrs['sn_u_business_unit'].lower().strip() != mir3_contactAttrs['mir3_businessunit'].lower().strip():
    if value1 != value2:
      log_msg.info("Need to update business unit: Current Value [{}] Setting to [{}] for Contact [{}]".format(mir3_contactAttrs['mir3_businessunit'], sn_contactAttrs['sn_u_business_unit'], sn_contactAttrs['sn_username']))
      returnValue = 1

  if 'sn_job_title' in sn_contactAttrs and 'mir3_jobtitle' in mir3_contactAttrs:
    value1 = checkNoneLowerCase(sn_contactAttrs['sn_job_title'], log_msg)
    value2 = checkNoneLowerCase(mir3_contactAttrs['mir3_jobtitle'], log_msg)    
    #if sn_contactAttrs['sn_job_title'].lower().strip() != mir3_contactAttrs['mir3_jobtitle'].lower().strip():
    if value1 !=value2:
      log_msg.info("Need to update job title: Current Value [{}] Setting to [{}] for Contact [{}]".format(mir3_contactAttrs['mir3_jobtitle'], sn_contactAttrs['sn_job_title'], sn_contactAttrs['sn_username']))
      returnValue = 1

  if 'sn_u_management_level' in sn_contactAttrs and 'mir3_managerlevel' in mir3_contactAttrs:
    value1 = checkNoneLowerCase(sn_contactAttrs['sn_u_management_level'], log_msg)
    value2 = checkNoneLowerCase(mir3_contactAttrs['mir3_managerlevel'], log_msg)
    #if sn_contactAttrs['sn_u_management_level'].lower().strip() != mir3_contactAttrs['mir3_managerlevel'].lower().strip():
    if value1 != value2:
      log_msg.info("Need to update Management Level: Current Value [{}] Setting to [{}] for Contact [{}]".format(mir3_contactAttrs['mir3_managerlevel'], sn_contactAttrs['sn_u_management_level'], sn_contactAttrs['sn_username']))
      returnValue = 1
      
  if 'sn_manager' in sn_contactAttrs and 'mir3_supervisorid' in mir3_contactAttrs:
    value1 = checkNoneLowerCase(sn_contactAttrs['sn_manager'], log_msg)
    value2 = checkNoneLowerCase(mir3_contactAttrs['mir3_supervisorid'], log_msg)
    #if sn_contactAttrs['sn_manager'].lower().strip() != mir3_contactAttrs['mir3_supervisorid'].lower().strip():
    if value1 != value2:
      log_msg.info("Need to update manager: Current Value [{}] Setting to [{}] for Contact [{}]".format(mir3_contactAttrs['mir3_supervisorid'], sn_contactAttrs['sn_manager'], sn_contactAttrs['sn_username']))
      returnValue = 1  

  if 'sn_username' in sn_contactAttrs and 'mir3_snow_userid' in mir3_contactAttrs:
    value1 = checkNoneLowerCase(sn_contactAttrs['sn_username'], log_msg)
    value2 = checkNoneLowerCase(mir3_contactAttrs['mir3_snow_userid'], log_msg)
    #if sn_contactAttrs['sn_username'].lower().strip() != mir3_contactAttrs['mir3_snow_userid'].lower().strip():
    if value1 != value2:
      log_msg.info("Need to update ServiceNow userid: Current Value [{}] Setting to [{}] for Contact [{}]".format(mir3_contactAttrs['mir3_snow_userid'], sn_contactAttrs['sn_username'], sn_contactAttrs['sn_username']))
      returnValue = 1
      
  if 'sn_sys_id' in sn_contactAttrs and 'mir3_snow_sysid' in mir3_contactAttrs:
    value1 = checkNoneLowerCase(sn_contactAttrs['sn_sys_id'], log_msg)
    value2 = checkNoneLowerCase(mir3_contactAttrs['mir3_snow_sysid'], log_msg)
    #if sn_contactAttrs['sn_sys_id'].lower().strip() != mir3_contactAttrs['mir3_snow_sysid'].lower().strip():
    if value1 != value2:
      log_msg.info("Need to update ServiceNow sysid: Current Value [{}] Setting to [{}] for Contact [{}]".format(mir3_contactAttrs['mir3_snow_sysid'], sn_contactAttrs['sn_sys_id'], sn_contactAttrs['sn_username']))
      returnValue = 1
  
  #check zip 
  if 'sn_zip' in sn_contactAttrs and 'mir3_homezip' in mir3_contactAttrs:
    value1 = checkNoneLowerCase(sn_contactAttrs['sn_zip'], log_msg)
    value2 = checkNoneLowerCase(mir3_contactAttrs['mir3_homezip'], log_msg)
    #if sn_contactAttrs['sn_sys_id'].lower().strip() != mir3_contactAttrs['mir3_snow_sysid'].lower().strip():
    if value1 != value2:
      log_msg.info("Need to update zip: Current Value [{}] Setting to [{}] for Contact [{}]".format(mir3_contactAttrs['mir3_homezip'], sn_contactAttrs['sn_zip'], sn_contactAttrs['sn_username']))
      returnValue = 1
      
  return returnValue

def callMIR3(log_msg, mir3_url, mir3_cntMaxCnt, mir3_username, mir3_password, mir3_api_version, mir3_getContacts):

  #MIR3 variables
  mir3_auth_str = '%s:%s' % (mir3_username, mir3_password)
  mir3_b64_auth_str = base64.b64encode(mir3_auth_str.encode("utf-8"))
  cntPaginationCnt = 1
  mir3ContactData = {}
  mir3ContactIter = {}

  mir3_payloadGetTotal = mir3_getContacts.format(mir3_api_version, mir3_username, mir3_password, 1, 1)
  mir3_payloadGetTotalLog = mir3_getContacts.format(mir3_api_version, 'XXXXXXXXXX', 'XXXXXXXXXX', 1, 1)
  
  log_msg.debug("MIR3 Payload is: [{}]".format(mir3_payloadGetTotalLog))
  
  mir3_headers = {
    'Authorization': 'Basic {}'.format(mir3_b64_auth_str),
    'Content-Type': 'application/xml'
  }

  mir3_response = requests.request("POST", mir3_url, headers=mir3_headers, data = mir3_payloadGetTotal, verify=True)

  if mir3_response.status_code != 200: 
    log_msg.error("MIR3 Status [{}] Headers [{}] Error Response: [{}]".format(mir3_response.status_code, mir3_response.headers, mir3_response.text))
    exit(19)
  
  #return mir3_response      
  mir3ContactTotals = int(getMIR3ContactTotals(log_msg, mir3_response))
  log_msg.debug("Totals for MIR3 is [{}]".format(mir3ContactTotals))


  #now call MIR3 in loop to get all contacts into hashmap
  while cntPaginationCnt <= mir3ContactTotals:
  
    returnedContactCnt = 0
    mir3_payload = mir3_getContacts.format(mir3_api_version, mir3_username, mir3_password, cntPaginationCnt, mir3_cntMaxCnt)
    mir3_response = requests.request("POST", mir3_url, headers=mir3_headers, data = mir3_payload, verify=True)

    if mir3_response.status_code != 200: 
      log_msg.error("MIR3 Status [{}] Headers [{}] Error Response: [{}]".format(mir3_response.status_code, mir3_response.headers, mir3_response.text))
      exit(20)    
    
    returnedContactCnt, mir3ContactIter = getMIR3ContactData(log_msg, mir3_response)
    
    #append to full hashmap
    mir3ContactData = dict(list(mir3ContactData.items()) + list(mir3ContactIter.items()))
    #mir3ContactData += mir3ContactIter
    log_msg.debug("Added [{}] more MIR3 contacts to hashmap Total Count now [{}]".format(returnedContactCnt, len(mir3ContactData)))
    
    #to setup starting point for next loop....
    cntPaginationCnt += returnedContactCnt
    log_msg.debug("New Pagination counter is [{}]".format(cntPaginationCnt))
    

  #return hashmap 
  log_msg.debug("All done getting MIR3 contacts, size of hashmap is [{}]".format(len(mir3ContactData)))
  return mir3ContactData
  
def updateMIR3Contact(log_msg, mir3_url, sn_contactAttrs, mir3_contactAttrs, mir3_username, mir3_password, mir3_api_version, mir3_default_role, datasync):

  #MIR3 variables
  mir3_auth_str = '%s:%s' % (mir3_username, mir3_password)
  mir3_b64_auth_str = base64.b64encode(mir3_auth_str.encode("utf-8"))
  
  #payload into 3 sections....
  payload_start = """<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://www.mir3.com/ws\"> \r\n
   <soapenv:Header/>\r\n
   <soapenv:Body>\r\n
      <ws:updateRecipients>\r\n
         <ws:apiVersion>{mir3_api_version}</ws:apiVersion>\r\n
         <ws:authorization>\r\n
            <ws:username><![CDATA[{username}]]></ws:username>\r\n
            <ws:password><![CDATA[{password}]]></ws:password>\r\n
         </ws:authorization>\r\n
         <ws:persistData>true</ws:persistData>
         <ws:ignoreInvalidDevices>true</ws:ignoreInvalidDevices>\r\n
         <ws:createIfNotFound>false</ws:createIfNotFound>\r\n
         <ws:updateOneRecipient>\r\n
            <ws:recipient>\r\n
               <ws:userUUID><![CDATA[{uuid}]]></ws:userUUID>\r\n
               <!--<ws:employeeId><![CDATA[{employeeid}]]></ws:employeeId>-->\r\n
            </ws:recipient>\r\n
            <ws:recipientDetail>\r\n
              <ws:userUUID><![CDATA[{uuid}]]></ws:userUUID>\r\n 
              <ws:pin><![CDATA[{pin}]]></ws:pin>\r\n
               <ws:telephonyId><![CDATA[{telephonyid}]]></ws:telephonyId>\r\n
               <ws:firstName><![CDATA[{firstname}]]></ws:firstName>\r\n
               <ws:lastName><![CDATA[{lastname}]]></ws:lastName>\r\n
               <ws:jobTitle><![CDATA[{jobtitle}]]></ws:jobTitle>\r\n
               <ws:company><![CDATA[{company}]]></ws:company>\r\n
               <!--<ws:division>?</ws:division>-->\r\n """
   
  payload_passwordhash = """ \r\n
           <ws:username><![CDATA[{employeeid}]]></ws:username>\r\n 
           <ws:password><![CDATA[{passwordhash}]]></ws:password>\r\n """
           #<passwordExpired>true</passwordExpired>\r\n"""
  
  payload_startcont = """\r\n
              <ws:role><![CDATA[{role}]]></ws:role>\r\n 
              <ws:devices>\r\n """
               
  payload_end = """ \r\n
              </ws:customFields>\r\n
              <ws:employeeId><![CDATA[{employeeid}]]></ws:employeeId>\r\n
            </ws:recipientDetail>\r\n
         </ws:updateOneRecipient>\r\n
      </ws:updateRecipients>\r\n
    </soapenv:Body>\r\n
    </soapenv:Envelope>\r\n """
    
  payload_home_mobile = """ \r\n
                    <ws:device>\r\n
                     <ws:deviceType>Home Mobile</ws:deviceType>\r\n
                     <ws:address><![CDATA[{mobile}]]></ws:address>\r\n
                     <ws:description>Home Mobile</ws:description>\r\n
                     <ws:private>false</ws:private>\r\n
                     <ws:disabled>false</ws:disabled>\r\n
                     <ws:defaultPriority>1</ws:defaultPriority>\r\n
                  </ws:device>\r\n """
                  
  payload_work_email = """ \r\n
                    <ws:device>\r\n
                     <ws:deviceType>Work Email</ws:deviceType>\r\n
                     <ws:address><![CDATA[{workemail}]]></ws:address>\r\n
                     <ws:description>Work Email</ws:description>\r\n
                     <ws:private>false</ws:private>\r\n
                     <ws:disabled>false</ws:disabled>\r\n
                     <ws:sendReports2>GRAPHICAL</ws:sendReports2>\r\n
                     <ws:defaultPriority>1</ws:defaultPriority>\r\n
                  </ws:device>\r\n """
                  
  payload_personal_email = """ \r\n
                  <ws:device>\r\n
                     <ws:deviceType>Personal Email</ws:deviceType>\r\n
                     <ws:address><![CDATA[{personalemail}]]></ws:address>\r\n
                     <ws:description>Personal Email</ws:description>\r\n
                     <ws:private>false</ws:private>\r\n
                     <ws:disabled>false</ws:disabled>\r\n
                     <ws:sendReports2>GRAPHICAL</ws:sendReports2>\r\n
                     <ws:defaultPriority>1</ws:defaultPriority>\r\n
                  </ws:device>\r\n"""
  
  payload_work_phone = """ \r\n
                  <ws:device>\r\n
                     <ws:deviceType>Work Phone</ws:deviceType>\r\n
                     <ws:address><![CDATA[{workphone}]]></ws:address>\r\n
                     <ws:description>Work Phone</ws:description>\r\n
                     <ws:private>false</ws:private>\r\n
                     <ws:disabled>false</ws:disabled>\r\n
                     <ws:defaultPriority>1</ws:defaultPriority>\r\n
                  </ws:device>\r\n"""

  payload_home_phone = """ \r\n
                  <ws:device>\r\n
                     <ws:deviceType>Home Phone</ws:deviceType>\r\n
                     <ws:address><![CDATA[{homephone}]]></ws:address>\r\n
                     <ws:description>Home Phone</ws:description>\r\n
                     <ws:private>false</ws:private>\r\n
                     <ws:disabled>false</ws:disabled>\r\n
                     <ws:defaultPriority>1</ws:defaultPriority>\r\n
                  </ws:device>\r\n"""
  
  payload_sms = """ \r\n
                    <ws:device>\r\n
                     <ws:deviceType>Home SMS</ws:deviceType>\r\n
                     <ws:address><![CDATA[{sms}]]></ws:address>\r\n
                     <ws:description>Home SMS</ws:description>\r\n
                     <ws:private>false</ws:private>\r\n
                     <ws:disabled>false</ws:disabled>\r\n
                     <ws:defaultPriority>1</ws:defaultPriority>\r\n
                  </ws:device>\r\n"""
  
  payload_bus_unit = """\r\n
                    <ws:customField>\r\n
                     <ws:name>Business Unit</ws:name>\r\n
                     <ws:value><![CDATA[{businessunit}]]></ws:value>\r\n
                  </ws:customField>\r\n """
  payload_job_code = """\r\n
                  <ws:customField>\r\n
                     <ws:name>Job Code</ws:name>\r\n
                     <ws:value><![CDATA[{jobcode}]]></ws:value>\r\n
                  </ws:customField>\r\n"""
  payload_dept = """\r\n
                  <ws:customField>\r\n
                     <ws:name>Department ID</ws:name>\r\n
                     <ws:value><![CDATA[{departmentid}]]></ws:value>\r\n
                  </ws:customField>\r\n"""
  payload_manager_level = """\r\n                
                  <ws:customField>\r\n
                     <ws:name>Manager Level</ws:name>\r\n
                     <ws:value><![CDATA[{managerlevel}]]></ws:value>\r\n
                  </ws:customField>\r\n"""
  payload_datasource = """\r\n
                  <ws:customField>\r\n
                     <ws:name>Data Source</ws:name>\r\n
                     <ws:value><![CDATA[{datasource}]]></ws:value>\r\n
                  </ws:customField>\r\n"""
  payload_middlename = """\r\n                
                  <ws:customField>\r\n
                     <ws:name>Middle Name</ws:name>\r\n
                     <ws:value><![CDATA[{middlename}]]></ws:value>\r\n
                  </ws:customField>\r\n"""
  payload_supervisor = """\r\n
                  <ws:customField>\r\n
                     <ws:name>Supervisor ID</ws:name>\r\n
                     <ws:value><![CDATA[{manager}]]></ws:value>\r\n
                  </ws:customField>\r\n"""
  payload_snow_sysid = """\r\n
                  <ws:customField>\r\n
                     <ws:name>snow_sysid</ws:name>\r\n
                     <ws:value><![CDATA[{snow_sysid}]]></ws:value>\r\n
                  </ws:customField>\r\n"""
  payload_snow_userid = """\r\n
                  <ws:customField>\r\n
                     <ws:name>snow_userid</ws:name>\r\n
                     <ws:value><![CDATA[{snow_userid}]]></ws:value>\r\n
                  </ws:customField>\r\n"""
                  
  
  payload_home_address = """\r\n
               <ws:addresses>\r\n
                  <ws:address>\r\n
                     <ws:addressTypeName>home</ws:addressTypeName>\r\n
                      <ws:zip><![CDATA[{snow_zip}]]></ws:zip>\r\n
                  </ws:address>\r\n
               </ws:addresses>\r\n"""
 
  
  #check if role is defined to contact
  mir3_role = ''
  if 'mir3_role' in mir3_contactAttrs:
    mir3_role = mir3_contactAttrs['mir3_role']
  else:
    mir3_role = mir3_default_role
  
  #workphone = '(831) 444-8686'
  log_msg.debug("Using MIR3 role [{}]".format(mir3_role))
  
  
  #lots of checks for empty values and it not empty append to payload string
  payload_append = payload_start
  
  if len(mir3_contactAttrs['mir3_passwordhash']) > 0:
    log_msg.debug("Appending password hashmap for contact [{}]".format(sn_contactAttrs['sn_username']))
    payload_append = payload_append + payload_passwordhash
  
  #MBK add address here...
  if len(sn_contactAttrs['sn_zip']) > 0:
    payload_append = payload_append + payload_home_address
  
  
  payload_append = payload_append + payload_startcont
  
  if len(sn_contactAttrs['sn_mobile_phone']) > 0:
    payload_append = payload_append + payload_home_mobile 
  
  if len(sn_contactAttrs['sn_work_email']) > 0:
    payload_append = payload_append + payload_work_email
  
  if len(sn_contactAttrs['sn_personal_email']) > 0:
    payload_append = payload_append + payload_personal_email

  if len(sn_contactAttrs['sn_bus_phone']) > 0:
    payload_append = payload_append + payload_work_phone

  if len(sn_contactAttrs['sn_home_phone']) > 0:
    payload_append = payload_append + payload_home_phone
    
  if len(sn_contactAttrs['sn_mobile_phone']) > 0:
    payload_append = payload_append + payload_sms
  
  #append xml tags between devices and customfields
  payload_append = payload_append +  """</ws:devices>\r\n
               <ws:customFields>\r\n"""
               
  if len(sn_contactAttrs['sn_u_business_unit']) > 0:
    payload_append = payload_append + payload_bus_unit
    
  if len(sn_contactAttrs['sn_u_emp_type']) > 0:
    payload_append = payload_append + payload_job_code
    
  if len(sn_contactAttrs['sn_department']) > 0:
    payload_append = payload_append + payload_dept
    
  if len(sn_contactAttrs['sn_u_management_level']) > 0:
    payload_append = payload_append + payload_manager_level
    
  #all will get data source
  payload_append = payload_append + payload_datasource
    
  if len(sn_contactAttrs['sn_middle_name']) > 0:
    payload_append = payload_append + payload_middlename
    
  if len(sn_contactAttrs['sn_manager']) > 0:
    payload_append = payload_append + payload_supervisor
    
  if len(sn_contactAttrs['sn_sys_id']) > 0:
    payload_append = payload_append + payload_snow_sysid
    
  if len(sn_contactAttrs['sn_username']) > 0:
    payload_append = payload_append + payload_snow_userid
  
  #append trailer records
  payload_append = payload_append + payload_end
  
  #update to the needed values....
  mir3_payload_upd = payload_append.format(mir3_api_version=mir3_api_version, username=mir3_username, password=mir3_password, uuid=mir3_contactAttrs['mir3_useruuid'], employeeid=sn_contactAttrs['sn_username'], pin=mir3_contactAttrs['mir3_pin'], telephonyid=mir3_contactAttrs['mir3_telephonyid'], firstname=sn_contactAttrs['sn_first_name'], lastname=sn_contactAttrs['sn_last_name'], jobtitle=sn_contactAttrs['sn_job_title'], company=sn_contactAttrs['sn_company'], role=mir3_role, mobile=sn_contactAttrs['sn_mobile_phone'], workemail=sn_contactAttrs['sn_work_email'], personalemail=sn_contactAttrs['sn_personal_email'], workphone=sn_contactAttrs['sn_bus_phone'], homephone=sn_contactAttrs['sn_home_phone'], sms=sn_contactAttrs['sn_mobile_phone'], businessunit=sn_contactAttrs['sn_u_business_unit'], jobcode=sn_contactAttrs['sn_u_emp_type'], departmentid=sn_contactAttrs['sn_department'], managerlevel=sn_contactAttrs['sn_u_management_level'], datasource=datasync, middlename=sn_contactAttrs['sn_middle_name'], manager=sn_contactAttrs['sn_manager'], snow_sysid=sn_contactAttrs['sn_sys_id'], snow_userid=sn_contactAttrs['sn_username'], passwordhash=mir3_contactAttrs['mir3_passwordhash'], snow_zip=sn_contactAttrs['sn_zip'] )
  mir3_payload_log = payload_append.format(mir3_api_version=mir3_api_version, username='XXXXXXXXXXX', password='XXXXXXXXXXX', uuid=mir3_contactAttrs['mir3_useruuid'], employeeid=sn_contactAttrs['sn_username'], pin=mir3_contactAttrs['mir3_pin'], telephonyid=mir3_contactAttrs['mir3_telephonyid'], firstname=sn_contactAttrs['sn_first_name'], lastname=sn_contactAttrs['sn_last_name'], jobtitle=sn_contactAttrs['sn_job_title'], company=sn_contactAttrs['sn_company'], role=mir3_role, mobile=sn_contactAttrs['sn_mobile_phone'], workemail=sn_contactAttrs['sn_work_email'], personalemail=sn_contactAttrs['sn_personal_email'], workphone=sn_contactAttrs['sn_bus_phone'], homephone=sn_contactAttrs['sn_home_phone'], sms=sn_contactAttrs['sn_mobile_phone'], businessunit=sn_contactAttrs['sn_u_business_unit'], jobcode=sn_contactAttrs['sn_u_emp_type'], departmentid=sn_contactAttrs['sn_department'], managerlevel=sn_contactAttrs['sn_u_management_level'], datasource=datasync, middlename=sn_contactAttrs['sn_middle_name'], manager=sn_contactAttrs['sn_manager'], snow_sysid=sn_contactAttrs['sn_sys_id'], snow_userid=sn_contactAttrs['sn_username'], passwordhash=mir3_contactAttrs['mir3_passwordhash'], snow_zip=sn_contactAttrs['sn_zip'] )

  log_msg.debug("Updated payload: [{}]".format(mir3_payload_log))

  mir3_headers = {
    'Authorization': 'Basic {}'.format(mir3_b64_auth_str),
    'Content-Type': 'application/xml'
  }

  mir3_response = requests.request("POST", mir3_url, headers=mir3_headers, data = mir3_payload_upd, verify=True)
  #mir3_response = requests.request("POST", mir3_url, headers=mir3_headers, data = payload, verify=False)

  if mir3_response.status_code != 200: 
    log_msg.error("MIR3 Status [{}] Headers [{}] Error Response: [{}]".format(mir3_response.status_code, mir3_response.headers, mir3_response.text))
    exit(26)

  #lets validate we got 'success' = 'true' from the response....
  log_msg.debug("headers [{}] text [{}]".format(mir3_response.headers, mir3_response.text))
  successValue = re.search("<success>.*</success>", mir3_response.text, flags=re.IGNORECASE)
  responseCode = successValue.group(0).split('>')[1].split('</')[0]
  if len(responseCode) > 0:
    log_msg.debug("Success boolean from MIR3 response is [{}]".format(responseCode))
    if responseCode.lower() == 'false':
      log_msg.error("Failed to update contact [{}], exiting from program!".format(sn_contactAttrs['sn_username']))
      log_msg.error("Received: [{}]".format(mir3_response.text))
      exit(27)
    else:
      log_msg.debug("Received: [{}] from update call into MIR3 for contact [{}]".format(responseCode, sn_contactAttrs['sn_username']))
  else:
    log_msg.warning("Could not find <success> in the response from MIR3, for contact [{}]".format(sn_contactAttrs['sn_username']))
    log_msg.warning("Received: [{}]".format(mir3_response.text))
    
  #check for non-critical errors....
  errorStr = re.search("<errorcode>.*</errorcode>", mir3_response.text, flags=re.IGNORECASE)
  if errorStr is not None:
    errorNum = errorStr.group(0).split('>')[1].split('</')[0]
    if len(errorNum) > 0:
      log_msg.warning("Received none-critical error message: [{}] for contact [{}]".format(errorNum, sn_contactAttrs['sn_username']))
      errorMsgStr = re.search("<errormessage>.*</errormessage>", mir3_response.text, flags=re.IGNORECASE)
      errorMsg = errorMsgStr.group(0).split('>')[1].split('</')[0]
      log_msg.warning("Non-Critical Message received: [{}] for contact [{}]".format(errorMsg, sn_contactAttrs['sn_username']))
    else:
      log_msg.debug("No non-critical error received for contact [{}]".format(sn_contactAttrs['sn_username']))
        
  log_msg.info("Successfully updated contact [{}]".format(sn_contactAttrs['sn_username']))
 
def removeMIR3Contact(log_msg, mir3_url, sn_contactAttrs, mir3_contactAttrs, mir3_username, mir3_password, mir3_api_version):

  #MIR3 variables
  mir3_auth_str = '%s:%s' % (mir3_username, mir3_password)
  mir3_b64_auth_str = base64.b64encode(mir3_auth_str.encode("utf-8"))
  
  payload = """<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://www.mir3.com/ws\">  \r\n
   <soapenv:Header/> \r\n
   <soapenv:Body> \r\n
      <ws:deleteRecipients> \r\n
         <ws:apiVersion>{mir3_api_version}</ws:apiVersion> \r\n
         <ws:authorization> \r\n
            <ws:username><![CDATA[{username}]]></ws:username> \r\n
            <ws:password><![CDATA[{password}]]></ws:password> \r\n
         </ws:authorization> \r\n
         <ws:recipient> \r\n
            <ws:userUUID><![CDATA[{uuid}]]></ws:userUUID> \r\n
         </ws:recipient> \r\n
      </ws:deleteRecipients> \r\n
   </soapenv:Body> \r\n
  </soapenv:Envelope>"""
  
  mir3_payload_upd = payload.format(mir3_api_version=mir3_api_version, username=mir3_username, password=mir3_password, uuid=mir3_contactAttrs['mir3_useruuid'] )
  mir3_payload_log = payload.format(mir3_api_version=mir3_api_version, username='XXXXXXXXXXX', password='XXXXXXXXXXX', uuid=mir3_contactAttrs['mir3_useruuid'] )
  
  log_msg.debug("Updated payload: [{}]".format(mir3_payload_log))

  mir3_headers = {
    'Authorization': 'Basic {}'.format(mir3_b64_auth_str),
    'Content-Type': 'application/xml'
  }

  mir3_response = requests.request("POST", mir3_url, headers=mir3_headers, data = mir3_payload_upd, verify=True)

  if mir3_response.status_code != 200: 
    log_msg.error("MIR3 Status [{}] Headers [{}] Error Response: [{}]".format(mir3_response.status_code, mir3_response.headers, mir3_response.text))
    exit(28)
  
  #lets validate we got 'success' = 'true' from the response....
  log_msg.debug("headers [{}] text [{}]".format(mir3_response.headers, mir3_response.text.encode('utf-8')))
  successValue = re.search("<success>.*</success>", mir3_response.text, flags=re.IGNORECASE)
  responseCode = successValue.group(0).split('>')[1].split('</')[0]
  if len(responseCode) > 0:
    log_msg.debug("Success boolean from MIR3 response is [{}]".format(responseCode))
    if responseCode.lower() == 'false':
      log_msg.error("Failed to remove contact [{}], exiting from program!".format(sn_contactAttrs['sn_username']))
      exit(29)
    else:
      log_msg.debug("Received: [{}] from delete call into MIR3 for contact [{}]".format(responseCode, sn_contactAttrs['sn_username']))
  else:
    log_msg.warning("Could not find <success> in the response from MIR3, for contact [{}]".format(sn_contactAttrs['sn_username']))

  #check for non-critical errors....
  errorStr = re.search("<errorcode>.*</errorcode>", mir3_response.text, flags=re.IGNORECASE)
  if errorStr is not None:
    errorNum = errorStr.group(0).split('>')[1].split('</')[0]
    if len(errorNum) > 0:
      log_msg.warning("Received none-critical error message: [{}] for contact [{}]".format(errorNum, sn_contactAttrs['sn_username']))
      errorMsgStr = re.search("<errormessage>.*</errormessage>", mir3_response.text, flags=re.IGNORECASE)
      errorMsg = errorMsgStr.group(0).split('>')[1].split('</')[0]
      log_msg.warning("Non-Critical Message received: [{}] for contact [{}]".format(errorMsg, sn_contactAttrs['sn_username']))
    else:
      log_msg.debug("No non-critical error received for contact [{}]".format(sn_contactAttrs['sn_username']))
    
  log_msg.info("Successfully removed contact [{}]".format(sn_contactAttrs['sn_username']))

def initSetup(args):

  try:
    #opts, args = getopt.getopt(sys.argv[1:], 'hl:e:', ['help', 'loglevel=', 'environment='])
    opts, args = getopt.getopt(args[1:], 'hl:e:', ['help', 'loglevel=', 'environment='])
  except getopt.GetoptError as err:
    print("exception in GETOPT with [%s]" % err)
    usage()
    sys.exit(2)
  
  # defaults.....
  loglevel = 'INFO'
  environment = 'QA'
  
  validloglevel = [ 'DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL' ]
  
  for opt, arg in opts:
    if opt in ('--l', '--loglevel'):
      loglevel = arg.upper()
    elif opt in ('--e', '--environment'):
      environment = arg.upper()
    elif opt in ('--h', '--help'):
      usage()
      sys.exit(0)
    else:
      assert False, "unhandled option"

  pathname = os.path.dirname(sys.argv[0])        
  pathdir = os.path.abspath(pathname)
  currentscript = os.path.basename(os.path.splitext(__file__)[0])
  date_fmt = datetime.now().strftime('%Y%m%d-%H%M')
  LOGFILE = '%s/%s_%s.log' % (LOG_DIR, currentscript, date_fmt)

  if validloglevel.count(loglevel) < 1:
    usage()
    sys.exit(5)
    
  
  log_msg = log_message.get_file_logger(currentscript, loglevel, LOGFILE, currentscript, True)
  log_msg.info("Starting program running with LOG4J as [%s]" % loglevel)

  try:
  
    #get config file information....
    cfgfile, config, sections = getConfigSections(log_msg, currentscript)
    if sections is None:
      log_msg.fatal("NO configuration file found, exiting!")
      sys.exit(3)
    else:
      log_msg.debug("Sections in configuration file [{}]".format(sections))
    
    if environment not in sections:
      log_msg.fatal("Provided Section [{}] does not exist in configuration file [{}], exiting!".format(environment,cfgfile))
      sys.exit(8)
      
    #get variables....    
    sn_maxResultCnt = config.getint('DEFAULT', 'sn_maxResultCnt', fallback=None)
    skipContactTypes = config.get('DEFAULT', 'skipContactTypes', fallback=None)
    mir3_cntMaxCnt = config.getint('DEFAULT', 'mir3_cntMaxCnt', fallback=None)
    encryptKey = config.get(environment, 'encryptKey', fallback=None)
    sn_instance = config.get(environment, 'sn_instance', fallback=None)
    mir3_url = config.get(environment, 'mir3_url', fallback=None)
    mir3_username_encrypt = config.get(environment, 'mir3_username', fallback=None)
    sn_username_encrypt = config.get(environment, 'sn_username', fallback=None)
    sn_password_encrypt = config.get(environment, 'sn_password', fallback=None)
    mir3_password_encrypt = config.get(environment,'mir3_password', fallback=None)
    mir3_api_version = config.get('DEFAULT', 'mir3_api_version', fallback=None)
    mir3_default_role = config.get('DEFAULT', 'mir3_default_role', fallback=None)
    datasync = config.get('DEFAULT', 'datasync', fallback=None)
    sn_getContacts = config.get('DEFAULT', 'sn_getContacts', fallback=None)
    mir3_getContacts = config.get('DEFAULT', 'mir3_getContacts', fallback=None)
    sn_waitDeleteDays = config.getint('DEFAULT', 'sn_waitDeleteDays', fallback=None)
  
    if mir3_getContacts is None:
      log_msg.error("We must have the query to get Contacts in MIR3, please set in property file, exiting!")
      sys.exit(3)
      
    if sn_waitDeleteDays is None:
      log_msg.error("We must have the number of days inactive to delete a MIR3 contact, please set in property file, exiting!")
      sys.exit(3)
      
    if sn_getContacts is None:
      log_msg.error("We must have a query lookup for Contacts in ServiceNow, exiting!")
      sys.exit(3)
      
    if datasync is None:
      log_msg.error("We must have a data sync value to add to MIR3, exiting!")
      sys.exit(3)
      
    if sn_instance is None:
      log_msg.error("We must have a ServiceNow instance to query against, exiting!")
      sys.exit(3)

    if mir3_default_role is None:
      log_msg.error("We must have a MIR3 default role, exiting!")
      sys.exit(3)
      
    if mir3_api_version is None:
      log_msg.error("We must have a MIR3 API Version, exiting!")
      sys.exit(3)

    if encryptKey is None:
      log_msg.error("We must have a must have an encrypting key, exiting!")
      sys.exit(3)
    
    if mir3_cntMaxCnt is None:
      log_msg.error("We must have a MIR3 Max Return count of contacts, exiting!")
      sys.exit(3)
    
    if sn_maxResultCnt is None:
      log_msg.error("We must have a ServiceNow Max Return count of contacts, exiting!")
      sys.exit(3)

    if skipContactTypes is None:
      log_msg.error("We must have a contact type skip values(service accounts for instance), exiting!")
      sys.exit(3)
 
    if mir3_url is None:
      log_msg.error("We must have a URL for MIR3, exiting!")
      sys.exit(3)

    if mir3_username_encrypt is None:
      log_msg.error("We must have a MIR3 username, exiting!")
      sys.exit(3)

    if mir3_password_encrypt is None:
      log_msg.error("We must have a MIR3 password, exiting!")
      sys.exit(3)

    if sn_username_encrypt is None:
      log_msg.error("We must have a ServiceNow username, exiting!")
      sys.exit(3)

    if sn_password_encrypt is None:
      log_msg.error("We must have a ServiceNow password, exiting!")
      sys.exit(3)
      
    log_msg.debug("sn_maxResultCnt is {} Environment {} ServiceNow Instance {} skipcontacttypes {}".format(sn_maxResultCnt, environment, sn_instance, skipContactTypes))
    log_msg.debug("encrypt key {} mir3_cntmaxcnt {} mir3_url {} mir3_username_encrypted {} mir3_password_encrypted {} sn_username_encrypted {} sn_password_encrypt {}".format(encryptKey, mir3_cntMaxCnt, mir3_url, mir3_username_encrypt, mir3_password_encrypt, sn_username_encrypt, sn_password_encrypt))
    
    
    #use security functions to get username/password
    sn_username = decryptStringWithKey(log_msg, sn_username_encrypt, encryptKey)
    log_msg.debug("ServiceNow username [{}]".format(sn_username))
    sn_password = decryptStringWithKey(log_msg, sn_password_encrypt, encryptKey)
    log_msg.debug("ServiceNow password [{}]".format('XXXXXXXXXX'))
    mir3_username = decryptStringWithKey(log_msg, mir3_username_encrypt, encryptKey)
    log_msg.debug("MIR3 username [{}]".format(mir3_username))
    mir3_password = decryptStringWithKey(log_msg, mir3_password_encrypt, encryptKey)
    log_msg.debug("MIR3 password [{}]".format('XXXXXXXXXX'))
    log_msg.debug("MIR Contact lookup is [{}]".format(mir3_getContacts))
    

  except OSError as err:
    log_msg.error("OS error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except ValueError as err:
    log_msg.error("VALUE error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except KeyboardInterrupt:
    log_msg.error('You cancelled the operation.')
    log_msg.error(traceback.format_exc())
    raise
  except IOError as err:
    log_msg.error("IOError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except EOFError as err:
    log_msg.error("EOFError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except KeyError as err:
    log_msg.error("KeyError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except Exception as err:
    log_msg.error("Unexpected error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
    
  
  return log_msg, sn_maxResultCnt, skipContactTypes, mir3_cntMaxCnt, encryptKey, sn_instance, mir3_url, mir3_api_version, datasync, sn_username, sn_password, mir3_username, mir3_password, sn_getContacts, mir3_default_role, sn_waitDeleteDays, mir3_getContacts
 
 
def main():
    
  #counters
  updateContactCnt = 0
  insertContactCnt = 0
  removeContactCnt = 0
  skipContactCnt = 0
  sn_recordCnt = 0
  sn_paginationCnt = 0
  noactionContactCnt = 0
  
  #setup the script
  log_msg, sn_maxResultCnt, skipContactTypes, mir3_cntMaxCnt, encryptKey, sn_instance, mir3_url, mir3_api_version, datasync, sn_username, sn_password, mir3_username, mir3_password, sn_getContacts, mir3_default_role, sn_waitDeleteDays, mir3_getContacts = initSetup(sys.argv)
   
  try:
    
    
    #call MIR3  MBK Need a Work around for this....
    mir3_results = callMIR3(log_msg, mir3_url, mir3_cntMaxCnt, mir3_username, mir3_password, mir3_api_version, mir3_getContacts)
    '''
    #MBK No longer need this for testing....
    cntjson = json.dumps(mir3_results)
    f = open('D:/temp\cntsysid.json', 'w')
    f.write(cntjson)
    f.close()
    
    
    #since I have created the json file above.... just read in the file for speed of testing
    with open('D:/temp\cntsysid.json') as f:
      mir3_results = json.load(f)
    '''

    # we will just get the first record, to get the total count of records....
    log_msg.debug("Instance is {} ".format(sn_instance))
    log_msg.debug("Query for SNOW contacts is {}".format(sn_getContacts))
    
    url = sn_getContacts.format(sn_instance, 1,1)
    resp = requests.get(url, auth=(sn_username, sn_password)) 
    log_msg.debug("HTTP REST call received: %s" % resp.status_code)
    
    if resp.status_code != 200:
      # This means something went wrong.
      log_msg.error("ServiceNow Status [{}] Headers [{}] Error Response: [{}]".format(resp.status_code, resp.headers, resp.text))
      sys.exit(14)
    
    #log the headers
    log_msg.debug("Headers are: [{}]".format(resp.headers))
    totalCnt = int(resp.headers['X-Total-Count'])
    
    log_msg.info("Total Count of records to process in ServiceNow is [{}]".format(totalCnt))
    
    #hard-coding total records for testing...
    #totalCnt = 101
    
    #While loop to get all contacts from ServiceNow
    while sn_paginationCnt <= totalCnt:   

      resp = None
      json_objs = None
      contacts = None
      key = None
      
      log_msg.info("Pagination is now [{}]".format(sn_paginationCnt))
      url = sn_getContacts.format(sn_instance, sn_maxResultCnt, sn_paginationCnt) 
      log_msg.debug("Making REST call: [{}]".format(url))
      resp = requests.get(url, auth=(sn_username, sn_password)) 
      log_msg.debug("HTTP REST call received: %s" % resp.status_code)
      
      if resp.status_code != 200:
        # This means something went wrong.
        log_msg.error("ServiceNow Status [{}] Headers [{}] Error Response: [{}]".format(resp.status_code, resp.headers, resp.text))
        sys.exit(15)
       
      json_objs=resp.json()
      for keyvalue in json_objs.items():
        key, contacts = keyvalue[0], keyvalue[1]
      
      #contacts will now be all rows returned

      for contact in contacts:
        #counter....
        sn_recordCnt += 1
        
        if sn_recordCnt > totalCnt:
          log_msg.info("Reached are last record....")
          sn_recordCnt = sn_recordCnt -1
          break
        
        log_msg.debug('Working on contact [{}]'.format(contact))
        #process the record 
        sn_contactAttrs = getSNowContactData(log_msg, contact)
        log_msg.debug('Contact Data is [{}]'.format(sn_contactAttrs))
        skipFlag = False

        #lets check for unicode characters not allowed....
        try:
          #json.dumps(test1)
          #json.dumps(contact).encode('ascii')
          for value in sn_contactAttrs.values():
            #log_msg.debug("Value is [{}]".format(value))
            value.encode('ascii')
          
        except UnicodeEncodeError as err:
          log_msg.warning("Exception in contact data NONE ASCII with data value [{}] Entire record: [{}] with error [{}]".format(value, contact, err))
          skipFlag = True          
        
        #perform all skip record checks#############################################################################
        if sn_contactAttrs.get('sn_username') is None or sn_contactAttrs.get('sn_username') == '':
          log_msg.warning("Contact has no username populated, skipping this record: [{}]".format(sn_contactAttrs))
          skipFlag = True
        
        if not skipFlag and (sn_contactAttrs.get('sn_u_emp_type') is None or sn_contactAttrs.get('sn_u_emp_type') == ''):
          log_msg.warning("Contact has no employee type defined, skipping this record: [{}]".format(sn_contactAttrs['sn_username']))
          skipFlag = True
        
        if not skipFlag and (sn_contactAttrs.get('sn_sys_updated_on') is None or sn_contactAttrs.get('sn_sys_updated_on') == ''):
          log_msg.warning("Contact has no last updated populated, skipping this record: [{}]".format(sn_contactAttrs['sn_username']))
          skipFlag = True
          
        if not skipFlag and (sn_contactAttrs.get('sn_active') is None or sn_contactAttrs.get('sn_active') == ''):
          log_msg.warning("Contact does not have active/inactive populated, skipping this record: [{}]".format(sn_contactAttrs['sn_username']))
          skipFlag = True
        
        if not skipFlag and sn_contactAttrs['sn_u_emp_type'].lower() in skipContactTypes:
          log_msg.debug("Contact type is a SKIP type [{}], skipping this record: [{}]".format(sn_contactAttrs['sn_u_emp_type'], sn_contactAttrs))
          skipFlag = True
        #end skip checks#############################################################################################
        
        if not skipFlag:  
          log_msg.debug("Contact Type is NOT a SKIP type [{}] for record [{}]".format(sn_contactAttrs['sn_u_emp_type'], sn_contactAttrs))
          #get the last updated on for check later on remove from MIR3
          datetime_object = datetime.strptime(sn_contactAttrs['sn_sys_updated_on'], '%m-%d-%Y %I:%M:%S %p')
          
          #check for insert of contact 
          if sn_contactAttrs['sn_username'] not in mir3_results and sn_contactAttrs['sn_active'].lower() == "true":
            log_msg.debug("Attempting insert for contact: [{}]".format(sn_contactAttrs['sn_username']))
            insertMIR3Contact(log_msg, mir3_url, sn_contactAttrs, mir3_username, mir3_password, mir3_api_version, mir3_default_role, datasync)
            insertContactCnt += 1
          #check for inactive contact that isn't in MIR3 to add to skipping contact....
          elif sn_contactAttrs['sn_username'] not in mir3_results and sn_contactAttrs['sn_active'].lower() == "false":
            log_msg.debug("Inactive contact [{}] not found in MIR3, adding to skip count".format(sn_contactAttrs['sn_username']))
            skipContactCnt += 1
          #check for waiting to delete of contact
          elif sn_contactAttrs['sn_username'] in mir3_results and sn_contactAttrs['sn_active'].lower() == "false" and datetime_object > datetime.today() - timedelta(days=sn_waitDeleteDays):  
            log_msg.info("Waiting to delete contact [{}] in MIR3 as contact was last updated on [{}] pending {} day grace period".format(sn_contactAttrs['sn_username'], datetime_object, sn_waitDeleteDays))
            noactionContactCnt += 1
          #check to delete of contact
          elif sn_contactAttrs['sn_username'] in mir3_results and sn_contactAttrs['sn_active'].lower() == "false" and datetime_object < datetime.today() - timedelta(days=sn_waitDeleteDays): 
            log_msg.debug("Attempting delete of contact [{}] in MIR3 as contact was last updated [{}]".format(sn_contactAttrs['sn_username'], datetime_object))
            removeMIR3Contact(log_msg, mir3_url, sn_contactAttrs, mir3_results[sn_contactAttrs['sn_username']], mir3_username, mir3_password, mir3_api_version)
            removeContactCnt += 1   
          #check for update of contact            
          elif sn_contactAttrs['sn_username'] in mir3_results and compareContactRecords(log_msg, sn_contactAttrs, mir3_results[sn_contactAttrs['sn_username']]) > 0:
            log_msg.debug("Attempting update of contact [{}]".format(sn_contactAttrs['sn_username'])) 
            updateMIR3Contact(log_msg, mir3_url, sn_contactAttrs, mir3_results[sn_contactAttrs['sn_username']], mir3_username, mir3_password, mir3_api_version, mir3_default_role, datasync)
            updateContactCnt += 1
          #check for no action on contact
          elif sn_contactAttrs['sn_username'] in mir3_results and compareContactRecords(log_msg, sn_contactAttrs, mir3_results[sn_contactAttrs['sn_username']]) < 1:
            log_msg.debug("No action needed (INS/UPD/DLT) needed for contact [{}]".format(sn_contactAttrs['sn_username']))
            noactionContactCnt += 1
          #we should never get here....
          else:
            log_msg.warning("OPPS..... Should not get here for contact [{}]".format(sn_contactAttrs['sn_username']))   
        #this is a skip of the given contact             
        else:
          skipContactCnt += 1
          
      #last thing is to increment counter
      sn_paginationCnt += sn_maxResultCnt
      
  
  except OSError as err:
    log_msg.error("OS error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except ValueError as err:
    log_msg.error("VALUE error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except KeyboardInterrupt:
    log_msg.error('You cancelled the operation.')
    log_msg.error(traceback.format_exc())
    raise
  except IOError as err:
    log_msg.error("IOError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except EOFError as err:
    log_msg.error("EOFError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except KeyError as err:
    log_msg.error("KeyError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except Exception as err:
    log_msg.error("Unexpected error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  finally:
    log_msg.info("---------------------------------------------------------------------------------------------------------")
    log_msg.info("Counts: Inserts [{}] Updates [{}] Deletes [{}] Skips [{}] No Action [{}] Total Processed [{}]".format(insertContactCnt, updateContactCnt, removeContactCnt, skipContactCnt, noactionContactCnt, sn_recordCnt))
    log_msg.info("---------------------------------------------------------------------------------------------------------")

  
  log_msg.info("Completed program successfully")
  sys.exit(0)
   
if __name__ == "__main__":
  main()
