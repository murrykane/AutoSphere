#!/usr/bin/env python
'''
Murry Kane 
Version 1.0

 Updates
 Date       By             Reason
_________________________________________________________________________________________________
 12/28/2021 Murry Kane     Initial version

_________________________________________________________________________________________________
 Description
 This script will recurse each directory in the 4 share's for VDI profiles and identify any profile over
 1 gig in size for an email warning user to clean up his files, after 30 days of warning automatic deletion
 of the directory will be done

'''

import shlex, subprocess, sys, platform, os, log_message, getpass, getopt, ast, requests, json, base64, re, traceback, unicodedata, shutil, stat, time, yaml, zipfile, smtplib, textwrap
from datetime import datetime, timedelta, date
from backupFile import *
from SREConstants import *
from pathlib import Path
from SREConfigParser import *
from SRESecurity import *
from email.message import EmailMessage
#from email.mime.text import MIMEText
from email.utils import make_msgid

global removedDirsCnt
global removedTreeCnt
global removedFileCnt
global failedRemoveCnt
global offenderProfiles
global vdiDirsToNotify
global cntDirsOverMax
global existingProfileCnt
     
def usage():
  print("Usage: %s (optional)--loglevel=<INFO><DEBUG><WARN><ERROR><FATAL> (optional)--help (optional)--emailAndPurge (optional)--colo=<LAS><SAC>" % sys.argv[0])
  print("Usage: %s (optional)--l <INFO><DEBUG><WARN><ERROR><FATAL> (optional)--h (optional)--e (optional)--c <sac><las>" % sys.argv[0])
  print("-------------------------------------------------------------------------------------------------------------------------------")

def removePath2(top, log_msg, retryCnt):
  """ param <path> could either be relative or absolute. 
      log_msg is the pointer to the log file 
      retry count is used to attempt to clean the same directory that many times due to unforseen errors"""
  
  global removedTreeCnt  
  global removedDirsCnt
  global removedFileCnt
  global failedRemoveCnt
  filename = ''
  
  returnVal = False
  
  try:
  
    log_msg.debug("Working on removepath2 for directory [{}]".format(top))
    
    for root, dirs, files in os.walk(top, topdown=False):
      log_msg.debug("Root is [{}]".format(root))
      log_msg.debug("dirs is [{}]".format(dirs))
      log_msg.debug("files is [{}]".format(files))
      
      for name in files:
        filename = os.path.join(root, name)
        log_msg.debug("Working on file [{}]".format(filename))
        os.chmod(filename, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO | stat.S_IWUSR)
        os.remove(filename)
        removedFileCnt += 1
      for name in dirs:
        filename = os.path.join(root, name)
        log_msg.debug("Working on dir [{}]".format(filename))
        os.chmod(filename, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO | stat.S_IWUSR)
        os.rmdir(filename)
        #MBK do we care about nested directories?
        removedDirsCnt += 1 
        
    os.chmod(top, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO | stat.S_IWUSR)  
    os.rmdir(top)
    removedTreeCnt += 1
    returnVal = True
    return returnVal
    
  except Exception as e:
    log_msg.warning("Tree Path [{}] for file/dir [{}] could not be removed! message: {}".format(top, filename, e))
    if(retryCnt >= 3):
      log_msg.error("Retry didn't work on this directory [{}], exiting and adding to fail counter....".format(top))
      failedRemoveCnt += 1
      return returnVal
    else:
      retryCnt += 1
      #short sleep
      time.sleep(3)
      #this will perform the loop of retries for the delete of the terminated employee
      removePath2(top, log_msg, retryCnt)
 
def get_dir_size(log_msg, root, vdi_maxdirsize):
  size = 0
 
  for path, dirs, files in os.walk(root):
    for f in files:
      try:
        size +=  os.path.getsize( os.path.join( path, f ) )
        if(size > vdi_maxdirsize):
          #lets break to speed up run time
          log_msg.debug("MAX Size reached for directory {}, exiting for loop to get size...".format(root))
          break
      except OSError:
        log_msg.warning("A File must have been deleted while trying to get the size of it, skipping and continuing...")
        continue
      else:
        continue
    else:
      continue
    break
    
  return size       
        
def removeFoundDirs(log_msg, dir):

  success = False
  global failedRemoveCnt
  
  log_msg.info("Working on removal of VDI Directory: {}".format(dir))
  if(os.path.isdir(r'{}'.format(dir))):
    log_msg.debug("Directory there, deleting.....")
    success = removePath2(r'{}'.format(dir), log_msg, 0)
  else:
    log_msg.info("Didn't find the directory to delete, skipping {}".format(dir))
    #success = True #mbk for now MBK
    failedRemoveCnt += 1
  return success
    
def buildOffenderReport(log_msg, reportProfiles, skipSearchProfiles):
  
  global offenderProfiles
  global existingProfileCnt
  global vdiDirsToNotify
  
  offenderProfiles = {}
  theList = {}
  theKeys = {}
  
  today = date.today()

  #list of profiles
  if(reportProfiles is None):
    log_msg.debug("The report of offending profiles from last time is empty")
  else:
    theList = reportProfiles["Profiles"]
    theKeys = {k for d in theList for k in d.keys()}
  
  if(len(vdiDirsToNotify) > 0):
    log_msg.info("Looking for offending profiles over MAX size limit...")
    for item in vdiDirsToNotify:
      #first see if the directory is in the exiting report
      log_msg.debug("Working on {} with type {}".format(item, type(item)))
      if item in theKeys:
        log_msg.debug("Found this profile {} from past runs".format(item))
        #need to get date and count of emails from report and +1 to counter and then add to array
        for s in range(len(theList)):
          log_msg.debug("thelist[s] is {} type is {}".format(theList[s], type(theList[s])))
          for key,value in theList[s].items():
            log_msg.debug("Key {} value {}".format(key,value))
            if os.path.normpath(item) == os.path.normpath(key):
              log_msg.debug("found data {}".format(value))
              theDate = value['foundDate']
              emailCount = value['emailsSent'] + 1
              log_msg.info("Previously existing Profile {} found Date: {} Emails Sent count is: {}".format(item, theDate, emailCount))
              offenderProfiles[item] = { 'foundDate' : theDate, 'emailsSent' : emailCount }
              existingProfileCnt += 1
            else:
              log_msg.debug("Search in old report for Profile {} not matched for this profile {}".format(item,key))
      else:
        #add record to final array
        log_msg.info("New offending Profile found {} found Date: {} Email Count being set to: {}".format(item,today,1))
        offenderProfiles[item] = { 'foundDate' : str(today), 'emailsSent' : 1 } 
  else:
    #This means we either didn't look for profiles this time, or all profiles have been cleaned up from last run
    log_msg.info("Working on adding back in last time offenders back into the report")
    if skipSearchProfiles and reportProfiles is not None:
      #this means we dont know if the user cleaned up their profile and we need to add back into the offenders report
      for item in theKeys:
        log_msg.debug("Found this profile {} from past runs".format(item))
        #need to get date and count of emails from report and +1 to counter and then add to array
        for s in range(len(theList)):
          log_msg.debug("thelist[s] is {} type is {}".format(theList[s], type(theList[s])))
          for key,value in theList[s].items():
            log_msg.debug("Key {} value {}".format(key,value))
            if os.path.normpath(item) == os.path.normpath(key):
              log_msg.debug("found matching data {}".format(value))
              theDate = value['foundDate']
              emailCount = value['emailsSent'] + 1
              log_msg.debug("Adding Profile {} found Date: {} Emails Sent count is: {} back into the offenders report".format(item, theDate, emailCount))
              offenderProfiles[item] = { 'foundDate' : theDate, 'emailsSent' : emailCount }
              existingProfileCnt += 1
            else:
              log_msg.debug("skipping record {}".format(key))

    elif not skipSearchProfiles and reportProfiles is not None:
      #this means the entries if any should not be in the offenders report
      for record in theKeys:
        log_msg.info("Profile {} will not be added into offenders list from past runs as it no longer exceeds MAX size allowed".format(record))
  
  log_msg.debug(offenderProfiles)
  
def removeWriteNewFile(log_msg, vdi_report):

  global offenderProfiles
  
  file_exists = os.path.exists(vdi_report)
  if(file_exists):
    log_msg.debug("Removing existing report")
    os.remove(vdi_report)
  else:
    log_msg.info("No need to remove existing report, its not found [{}]!".format(vdi_report))
  
  if(len(offenderProfiles) > 0): 
    #now create new file
    with open(vdi_report, 'w') as file:
      documents = yaml.dump({'Profiles' : [offenderProfiles]}, file) 
  else:
    log_msg.info("No report needed on this run, skipping report creation")
 
def getReport(log_msg, vdi_report, backuploc):

  file_exists = os.path.exists(vdi_report)
  if(file_exists):
    with open(vdi_report) as file:  
      reportProfiles = yaml.safe_load(file)
    #MBK lets make a backup of the report keeping 20 versions
    backupFileWithLimit(vdi_report, backuploc, 20)
  else:
    reportProfiles = None
    log_msg.info("We could not find the report [{}]".format(vdi_report))
  
  return reportProfiles
  
def findVDIDirs(log_msg, vdi_dirs, vdi_maxdirsize):

  global vdiDirsToNotify
  global cntDirsOverMax
  
  vdiDirsToNotify = []
  
  for vdiDir in vdi_dirs:
    log_msg.info("Working on VDI profile directory: {}".format(vdiDir))
    vdiList = os.listdir(vdiDir)
    log_msg.debug("Listing of VDI Profiles is: {}".format(vdiList))
    #now iterate through 
    for dir in vdiList:
      dirsize = get_dir_size(log_msg, os.path.join(vdiDir,dir), vdi_maxdirsize)
      if(dirsize > vdi_maxdirsize):
        log_msg.info("Directory [{}] is larger then the maximum size[{}] with: [{}], adding to notification array".format(os.path.join(vdiDir,dir), vdi_maxdirsize, dirsize))
        vdiDirsToNotify.append(os.path.join(vdiDir,dir))
        cntDirsOverMax += 1
      else:
        log_msg.debug("Directory [{}] is smaller then the maximum size[{}] with: [{}], skipping this directory".format(os.path.join(vdiDir,dir), vdi_maxdirsize, dirsize))
  
def emailUsers(log_msg, email_subject, email_sender, email_body, email_bcc_list, email_gateway ):

  global offenderProfiles
  msg = EmailMessage()
  asparagus_cid = make_msgid()
  msg.add_alternative("""\
    <html>
      <head></head>
      <body>
        {email_body}
      </body>
    </html>
    """.format(asparagus_cid=asparagus_cid[1:-1], email_body=email_body), subtype='html')   
  
  users = [] 
  for user in offenderProfiles:
    log_msg.debug("User with VDI profile over maximum size is going to get a nasty email: {}".format(user))
    basename = os.path.basename(user)
    
    if( '_' in basename):
      result = basename.index('_')
    else:
      result = 0
      
    if(result > 0):
      users.append('{}@blueshieldca.com'.format(basename[0:result]))
    else:
      users.append('{}@blueshieldca.com'.format(basename))
  
  msg['Subject'] = email_subject 
  msg['From'] = email_sender  
  msg['To'] = users
  msg['Cc'] = email_sender
  if email_bcc_list is not None:
    msg['Bcc'] = email_bcc_list

  log_msg.debug("Users getting email for over the profile limit are: {}".format(users))
  log_msg.info("Offending profiles email message is: {}".format(msg.as_string()))
  
  try:
    if(len(users) > 0):
      #MBK Add back the actual email...
      smtpObj = smtplib.SMTP(email_gateway)       
      smtpObj.send_message(msg)
      log_msg.info("Successfully sent email to offending users")
    else:
      log_msg.info("No users to send the email to on this run, skipping email")
  except SMTPException:
   log_msg.error("Error: Unable to send email to offending Users!")
   #mbk we error out here....?
   sys.exit(44)
 
def initSetup(args):

  try:
    opts, args = getopt.getopt(args[1:], 'hl:pc', ['help', 'loglevel=','emailAndPurge', 'colo='])
  except getopt.GetoptError as err:
    print("exception in GETOPT with [%s]" % err)
    usage()
    sys.exit(2)
  
  # defaults.....
  loglevel = 'INFO'
  skipSearchProfiles = False
  coloRun = 'ALL'
  
  validloglevel = [ 'DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL' ]
  validColos = [ 'ALL', 'SAC', 'LAS' ]
  
  for opt, arg in opts:
    if opt in ('--l', '--loglevel'):
      loglevel = arg.upper()
    elif opt in ('--h', '--help'):
      usage()
      sys.exit(0)
    elif opt in ('--p', '--emailAndPurge'):
      skipSearchProfiles = True
    elif opt in ('--c', '--colo'):
      coloRun = arg.upper()
    else:
      assert False, "unhandled option"

  pathname = os.path.dirname(sys.argv[0])        
  pathdir = os.path.abspath(pathname)
  currentscript = os.path.basename(os.path.splitext(__file__)[0])
  date_fmt = datetime.now().strftime('%Y%m%d-%H%M')
  LOGFILE = '%s/%s_%s.log' % (LOG_DIR, currentscript, date_fmt)

  if validloglevel.count(loglevel) < 1:
    usage()
    sys.exit(5)
  
  if validColos.count(coloRun) < 1:
    usage()
    sys.exit(7)
  
  log_msg = log_message.get_file_logger(currentscript, loglevel, LOGFILE, currentscript, True)
  log_msg.info("Starting program running with LOG4J as [%s]" % loglevel)

  try:
  
    #get config file information....
    cfgfile, config, sections = getConfigSections(log_msg, currentscript)
    if sections is None:
      log_msg.fatal("NO configuration file found, exiting!")
      sys.exit(3)
    else:
      log_msg.debug("Sections in configuration file [{}]".format(sections))
      
    #get variables....  
    if(coloRun == 'ALL'):
      vdi_dirs = config.get('DEFAULT', 'vdi_dirs', fallback=None)
    elif(coloRun == 'LAS'):
      vdi_dirs = config.get('LAS', 'vdi_dirs', fallback=None)
    elif(coloRun == 'SAC'):
      vdi_dirs = config.get('SAC', 'vdi_dirs', fallback=None)
      
    vdi_maxdirsize = config.getint('DEFAULT', 'vdi_maxdirsize', fallback=None)
    vdi_report = config.get('DEFAULT', 'vdi_report', fallback=None)
    email_subject = config.get('DEFAULT', 'email_subject', fallback=None)
    email_sender = config.get('DEFAULT', 'email_sender', fallback=None)
    email_body = config.get('DEFAULT', 'email_body', fallback=None)
    vdi_minDaysToDelete = config.getint('DEFAULT', 'vdi_minDaysToDelete', fallback=None)
    vdi_emailcountmax = config.getint('DEFAULT', 'vdi_emailcountmax', fallback=None)
    email_bcc_list = config.get('DEFAULT', 'email_bcc_list', fallback=None)
    email_gateway = config.get('DEFAULT', 'email_gateway', fallback=None)
    
    if vdi_dirs is None:
      log_msg.error("We must have a VDI locations for cleanup (share mounts), exiting!")
      sys.exit(3)
    else:
      vdi_dirs = ast.literal_eval(vdi_dirs)

    if vdi_maxdirsize is None:
      log_msg.error("We must have a VDI MAX Size for notification and cleanup, exiting!")
      sys.exit(4)

    if vdi_report is None:
      log_msg.error("We didn't get the report for past VDI profiles that are large from the property file, exiting!")
      sys.exit(5)
    else:
      #lets normalize path..
      vdi_report = os.path.normpath(vdi_report)
      
    if email_subject is None:
      log_msg.error("We didn't get the email_subject for sending emails from configuration file, exiting!")
      sys.exit(6)
    if email_sender is None:
      log_msg.error("We didn't get the email_sender for sending emails from configuration file, exiting!")
      sys.exit(7)
    if email_body is None:
      log_msg.error("We didn't get the email_body for sending emails from the property file, exiting!")
      sys.exit(8)
    if vdi_minDaysToDelete is None:
      log_msg.error("We didn't get the vdi_minDaysToDelete from the property file, exiting!")
      sys.exit(9)     
    if vdi_emailcountmax is None:
      log_msg.error("We must have the maximum number of emails to a user before deleting their profile, exiting!")
      sys.exit(10)
    if email_gateway is None:
      log_msg.error("We must have the email gateway defined, to send the email to user, exiting!")
      sys.exit(11)
      
      
    log_msg.info("VDI MAX Directory size is {}".format(vdi_maxdirsize))
    log_msg.info("VDI MIN Days before delete is {}".format(vdi_minDaysToDelete))
    log_msg.info("VDI Report is located at {}".format(vdi_report))
    log_msg.info("VDI Search Directories are: {}".format(vdi_dirs))
    log_msg.info("VDI Minimum number of emails to send to user is {}".format(vdi_emailcountmax))
    log_msg.info("Email Subject is: {}".format(email_subject))
    log_msg.info("Email Sender is: {}".format(email_sender))
    if email_bcc_list is not None:
      log_msg.info("Email BCC list is: {}".format(email_bcc_list))
	
  except OSError as err:
    log_msg.error("OS error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except ValueError as err:
    log_msg.error("VALUE error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except KeyboardInterrupt:
    log_msg.error('You cancelled the operation.')
    log_msg.error(traceback.format_exc())
    raise
  except IOError as err:
    log_msg.error("IOError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except EOFError as err:
    log_msg.error("EOFError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except KeyError as err:
    log_msg.error("KeyError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except Exception as err:
    log_msg.error("Unexpected error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  
  return log_msg, vdi_maxdirsize, vdi_dirs, skipSearchProfiles, vdi_report, email_subject, email_sender, email_body, vdi_minDaysToDelete, vdi_emailcountmax, email_bcc_list, email_gateway
 
def determineDeleteProfiles(log_msg, vdi_minDaysToDelete, vdi_emailcountmax):
  global offenderProfiles
  global finalProfiles
  
  finalProfiles = {}
  
  today = date.today()
  success = False
  
  log_msg.debug("Today is {}".format(today)) 
  log_msg.debug(offenderProfiles)
  
  for key in offenderProfiles.copy():   #mbk make a copy of the array to not break the iteration....
    success = False
    log_msg.debug("Working on key: {} value {}".format(key, offenderProfiles[key]))
    #datetime_object = datetime.strptime('Jun 1 2005  1:33PM', '%b %d %Y %I:%M%p')
    dateVal = datetime.strptime(offenderProfiles[key]['foundDate'], '%Y-%m-%d').date()
    emailCnt = offenderProfiles[key]['emailsSent']
    log_msg.debug("Date found to be: {} of type {}".format(dateVal, type(dateVal)))
    dateDiff = abs(today-dateVal).days
    log_msg.debug("Diff of days is {} Email Count sent {}".format(dateDiff,emailCnt))
    
    if(dateDiff > vdi_minDaysToDelete and emailCnt >= vdi_emailcountmax):
      log_msg.debug("Time to delete this profile {}".format(key))
      #mbk actual delete of this profile....
      success = removeFoundDirs(log_msg, key)
    else:
      log_msg.debug("No need to delete this profile {}".format(key))
    
    if(success):
      del offenderProfiles[key]
      log_msg.info("Removing Profile from final report as the profile {} was successfully deleted".format(key))
    else:
      log_msg.debug("Profile [{}] remaining in final report as future processing will action upon it".format(key))
         
def main():
    
  #counters
  global removedTreeCnt
  global removedDirsCnt
  global removedFileCnt
  global failedRemoveCnt
  global cntDirsOverMax
  global vdiDirsToNotify
  global offenderProfiles
  global existingProfileCnt
  
  removedDirsCnt = 0
  removedFileCnt = 0
  failedRemoveCnt = 0
  removedTreeCnt = 0
  existingProfileCnt = 0
  
  skipContactCnt = 0
  sn_recordCnt = 0
  sn_paginationCnt = 0
  cntDirsOverMax = 0
  vdiDirsToNotify = []
  offenderProfiles = {}
  
  #setup the script
  log_msg, vdi_maxdirsize, vdi_dirs, skipSearchProfiles, vdi_report, email_subject, email_sender, email_body, vdi_minDaysToDelete, vdi_emailcountmax, email_bcc_list, email_gateway = initSetup(sys.argv)
   
  try:
    
    #lets work on the clean up now...
    if not skipSearchProfiles:
      findVDIDirs(log_msg, vdi_dirs, vdi_maxdirsize)
    else:
      log_msg.info("Skipping search for large VDI profiles and moving on to email from existing report")
      #MBK for now lets add some dummy records
      #vdiDirsToNotify.append(os.path.normpath("\\\\bsc\\it\\vdi_profile_sac\\rsilva72_bpo"))
      #vdiDirsToNotify.append(os.path.normpath("\\\\bsc\\it\\vdi_profile_sac\\jolive04_bpo"))
      #vdiDirsToNotify.append(os.path.normpath("\\\\bsc\\it\\vdi_profile_sac\\kgunaw01_bsc"))
      #vdiDirsToNotify.append(os.path.normpath("\\\\bsc\\it\\vdi_profile_sac\\amoham10_bsc"))
      
    #now read in the past report and backup file
    reportProfiles = getReport(log_msg, vdi_report, BACKUP_DIR)
    if(reportProfiles):
      log_msg.debug("Profiles from last time are: {}".format(reportProfiles))
    
    #build new array from old/current
    buildOffenderReport(log_msg, reportProfiles, skipSearchProfiles)
    
    #now email offending users
    emailUsers(log_msg, email_subject, email_sender, email_body, email_bcc_list, email_gateway )
    
    #delete offenders
    determineDeleteProfiles(log_msg, vdi_minDaysToDelete, vdi_emailcountmax)
    log_msg.debug("Remaining profiles for next time are {}".format(offenderProfiles))
    
    #now write the new report
    removeWriteNewFile(log_msg, vdi_report)
        
  except OSError as err:
    log_msg.error("OS error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except ValueError as err:
    log_msg.error("VALUE error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except KeyboardInterrupt:
    log_msg.error('You cancelled the operation.')
    log_msg.error(traceback.format_exc())
    raise
  except IOError as err:
    log_msg.error("IOError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except EOFError as err:
    log_msg.error("EOFError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except KeyError as err:
    log_msg.error("KeyError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except Exception as err:
    log_msg.error("Unexpected error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  finally:
    #add up to get skip count
    log_msg.info("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")
    log_msg.info("Counts: Profiles found on this run over limit [{}] Existing Count [{}] Final Count of Profiles over limit [{}] Failed Profiles Removed [{}] Profiles Removed [{}] Directories Removed [{}] Files Removed [{}]".format(cntDirsOverMax, existingProfileCnt, len(offenderProfiles), failedRemoveCnt, removedTreeCnt, removedDirsCnt, removedFileCnt))
    log_msg.info("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")

  if(failedRemoveCnt > 0):
    log_msg.error("Failure to remove all needed VDI profiles, exiting badly!")
    sys.exit(failedRemoveCnt)
  else:
    log_msg.info("Completed program successfully")
    sys.exit(0)
   
if __name__ == "__main__":
  main()
