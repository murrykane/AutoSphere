#!/usr/bin/env python
'''
Murry Kane 
Version 1.0

 Updates
 Date       By             Reason
_________________________________________________________________________________________________
 03/11/2020 Murry Kane     Initial version

_________________________________________________________________________________________________
 Description
 This script will export all contacts from ServiceNow via rest call, it will process each record 
 and gather specific fields for syncing with MIR3 notificaiton system. 
 
List of fields:

MIR3 Field    Service Now Extract list of fields
              calendar_integration
yes country   country   
              last_position_update
              user_password
              last_login_time
yes floor     u_floor_cube
              source
yes (active)  sys_updated_on
              u_applicant_id
yes building  building
              u_work_term_number
              web_service_access_only
              notification
              enable_multifactor_authn
              sys_updated_by
              sso_source
              sys_created_on
              agent_status
              sys_domain
              u_badge_num
              state
              vip
              sys_created_by
yes custom    u_job_title
              longitude
yes zip       zip
yes home_phonehome_phone
              time_format
              u_management_level
              u_employment_status
              last_login
              default_perspective
              geolocation_tracked
              u_acct_start
yes active    active
              time_sheet_policy
yes custom    u_bsc_source
yes custom    cost_center
yes business  phone
yes Custom    name
Yes Custom    u_emp_type
yes employeeidemployee_number
              password_needs_reset
              gender
yes city      city
              failed_attempts
yes username  user_name
              latitude
              roles
yes job_title title
              sys_class_name
              u_user_account_control
yes custom    sys_id
              internal_integration_user
              ldap_server
yes home mobile/home sms mobile_phone
yes street    street
yes company   company
yes custom    department
yes first namefirst_name
yes work emailemail
              introduction
yes language  preferred_language
              u_candidate_id
yes custom    manager
              u_is_manager
              locked_out
              auditor
              sys_mod_count
yes last name last_name
              photo
              u_self_approve
              avatar
yes middle name middle_name
              sys_tags
              time_zone
              u_last_ldap_refresh
              schedule
              on_schedule
              u_acct_end
              date_format
yes custom    location
              u_transaction_date
yes custom    u_business_unit

Notes:

Special handling will be done for contact 'active = false' by using 'last_updated_on' date that is over 30 days before we will set the contact inactive
in MIR3 this to to avoid possible flapping (switching user from contractor to employee etc) or accidental inactive/active 

'''

import shlex, subprocess, sys, platform, os, log_message, getpass, getopt, ast, requests, json, base64, re, traceback
from datetime import datetime, timedelta
from SREConstants import *
import xml.etree.ElementTree as ET

def usage():
  print("Usage: %s (optional)--loglevel=<INFO><DEBUG><WARN><ERROR><FATAL> (optional)--help" % sys.argv[0])
  print("-------------------------------------------------------------------------------------------------------------------------------")

def getMIR3ContactData(log_msg, mir3_response):

  mir3ContactCnt = 0
  contactTuple = {}
  mir3_ns = 'http://www.mir3.com/ws'  #mbk assign it to default before getting from elementTree
  
  root = ET.fromstring(mir3_response.content)
  for child in root.iter('*'):
    log_msg.debug("Child Tag [{}] Child Attribute [{}] Child Text [{}]".format(child.tag, child.attrib, child.text))
    
    if len(re.findall('}response$', child.tag, flags=re.IGNORECASE)) > 0:
      mir3_ns = child.tag.split('}')[0] + '}'
      log_msg.debug("Response Found for getting namespace using the following: [{}]".format(mir3_ns))
    
    if len(re.findall('{}matchcount$'.format(mir3_ns), child.tag, flags=re.IGNORECASE)) > 0:
      log_msg.debug("Count of records found in MIR3 is: [{}]".format(child.text))
      contactTuple["mir3_matchcount"] = child.text
      #only care on what is returned so commented this out...
      #mir3ContactCnt = int(child.text)
      
    if len(re.findall('{}returncount$'.format(mir3_ns), child.tag, flags=re.IGNORECASE)) > 0:
      log_msg.debug("Count of matched records found in MIR3 is: [{}]".format(child.text))
      contactTuple["mir3_returncount"] = child.text
      mir3ContactCnt = int(child.text)
      
    if len(re.findall('{}useruuid$'.format(mir3_ns), child.tag, flags=re.IGNORECASE)) > 0:
      log_msg.debug("User UUID found in MIR3 is: [{}]".format(child.text))
      contactTuple["mir3_useruuid"] = child.text
      
    if len(re.findall('{}username$'.format(mir3_ns), child.tag, flags=re.IGNORECASE)) > 0:
      log_msg.debug("Username found in MIR3 is: [{}]".format(child.text))
      contactTuple["mir3_username"] = child.text
      
    if len(re.findall('{}pin$'.format(mir3_ns), child.tag, flags=re.IGNORECASE)) > 0:
      log_msg.debug("PIN found in MIR3 is: [{}]".format(child.text))
      contactTuple["mir3_pin"] = child.text
      
    if len(re.findall('{}telephonyid$'.format(mir3_ns), child.tag, flags=re.IGNORECASE)) > 0:
      log_msg.debug("Telephone found in MIR3 is: [{}]".format(child.text))
      contactTuple["mir3_telephone"] = child.text   

    if len(re.findall('{}firstname$'.format(mir3_ns), child.tag, flags=re.IGNORECASE)) > 0:
      log_msg.debug("First Name found in MIR3 is: [{}]".format(child.text))
      contactTuple["mir3_firstname"] = child.text  
      
    if len(re.findall('{}lastname$'.format(mir3_ns), child.tag, flags=re.IGNORECASE)) > 0:
      log_msg.debug("Last Name found in MIR3 is: [{}]".format(child.text))
      contactTuple["mir3_lastname"] = child.text   

    if len(re.findall('{}locale$'.format(mir3_ns), child.tag, flags=re.IGNORECASE)) > 0:
      log_msg.debug("Locale found in MIR3 is: [{}]".format(child.text))
      contactTuple["mir3_locale"] = child.text   

    if len(re.findall('{}employeeid$'.format(mir3_ns), child.tag, flags=re.IGNORECASE)) > 0:
      log_msg.debug("Employee ID found in MIR3 is: [{}]".format(child.text))
      contactTuple["mir3_employeeid"] = child.text   

    if len(re.findall('{}company$'.format(mir3_ns), child.tag, flags=re.IGNORECASE)) > 0:
      log_msg.debug("Company found in MIR3 is: [{}]".format(child.text))
      contactTuple["mir3_company"] = child.text   

    if len(re.findall('{}division$'.format(mir3_ns), child.tag, flags=re.IGNORECASE)) > 0:
      log_msg.debug("Division found in MIR3 is: [{}]".format(child.text))
      contactTuple["mir3_division"] = child.text   
    '''   need work here.....
    if child.tag.lower().find('addresstypename') > 0:
      log_msg.debug("An Address found in MIR3 is: [{}]".format(child.text))
      #contactTuple[""] = child.text   
      if child.text.lower().find('home') > 0:
        log_msg.debug("Home Address found in MIR3 is: [{}]".format
    
    >>> for device in root.iter('{http://www.mir3.com/ws}device'):
    ...   print(device.tag)
    ...   type = device.find('{http://www.mir3.com/ws}deviceType').text
    ...   print(type)
    ...
    {http://www.mir3.com/ws}device
    Personal Email
    {http://www.mir3.com/ws}device
    Work Phone
    {http://www.mir3.com/ws}device
    Home Mobile
    {http://www.mir3.com/ws}device
    Home SMS
    {http://www.mir3.com/ws}device
    Work Email
    '''
  #now get the lower level Items like device
  for device in root.iter('{}device'.format(mir3_ns)):
    #log_msg.debug("Tag for device is {}".format(device.tag))
    type = device.find('{}deviceType'.format(mir3_ns)).text
    address = device.find('{}address'.format(mir3_ns)).text
    description = device.find('{}description'.format(mir3_ns)).text
    private = device.find('{}private'.format(mir3_ns)).text
    disabled = device.find('{}disabled'.format(mir3_ns)).text
    #sendreport2 = device.find('{}sendReports2'.format(mir3_ns)).text
    defaultpriority = device.find('{}defaultPriority'.format(mir3_ns)).text
    source = device.find('{}source'.format(mir3_ns)).text
    #log_msg.debug("Device label is {} address {} description {} private {} disabled {} sendreport2 {} defaultpriority {} source {}".format(type, address, description, private, disabled, sendreport2, defaultpriority, source))
    log_msg.debug("Device label is {} address {} description {} private {} disabled {} defaultpriority {} source {}".format(type, address, description, private, disabled, defaultpriority, source))

    contactTuple[type] = address

  for custom in root.iter('{}customField'.format(mir3_ns)):
    name = custom.find('{}name'.format(mir3_ns)).text
    value = custom.find('{}value'.format(mir3_ns)).text
    log_msg.debug("Custom Attribute [{}] value [{}]".format(name, value))

    contactTuple[name] = value
  
  #return values needed for logic on insert...  
  return mir3ContactCnt, contactTuple
  
def getSNowContactData(log_msg, contact):

  contactTuple = {}
  #log_msg.debug('Working on contact [{}]'.format(contact))
  for key, val in contact.items():
  
    #log_msg.debug('Key for contact is {}'.format(key))
    if(key.lower() == "sys_id"):
      if val is None:
        sn_sys_id = ''
      else:
        sn_sys_id = val
      log_msg.debug('   sys_id is: {}'.format(sn_sys_id))
      contactTuple["sn_sys_id"] = sn_sys_id
      
    if(key.lower() == "country"):
      if val is None:
        sn_country = ''
      else:
        sn_country = val
      log_msg.debug('   country is: {}'.format(sn_country))
      contactTuple["sn_country"] = sn_country
      
    if(key.lower() == "u_floor_cube"):
      if val is None:
        sn_foor = ''
      else:
        sn_floor = val
      log_msg.debug('   floor is: {}'.format(sn_floor))
      contactTuple["sn_floor"] = sn_floor
      
    if(key.lower() == "sys_updated_on"):
      if val is None:
        sn_sys_updated_on = ''
      else:
        sn_sys_updated_on = val
      log_msg.debug('   last updated on: {}'.format(sn_sys_updated_on))
      contactTuple["sn_sys_updated_on"] = sn_sys_updated_on
      
    if(key.lower() == "building"):
      if val is None:
        sn_building = ''
      else:
        sn_building = val
      log_msg.debug('   building is: {}'.format(sn_building))
      contactTuple["sn_building"] = sn_building
      
    if(key.lower() == "u_job_title"):
      if val is None:
        sn_job_title = ''
      else:
        sn_job_title = val
      log_msg.debug('   job title is: {}'.format(sn_job_title))
      contactTuple["sn_job_title"] = sn_job_title
      
    if(key.lower() == "zip"):
      if val is None:
        sn_zip = ''
      else:
        sn_zip = val
      log_msg.debug('   zip is: {}'.format(sn_zip))
      contactTuple["sn_zip"] = sn_zip
      
    if(key.lower() == "home_phone"):
      if val is None:
        sn_home_phone = ''
      else:
        sn_home_phone = val
      log_msg.debug('   home phone is: {}'.format(sn_home_phone))
      contactTuple["sn_home_phone"] = sn_home_phone
      
    if(key.lower() == "active"):
      if val is None:
        sn_active = ''
      else:
        sn_active = val
      log_msg.debug('   active is: {}'.format(sn_active))
      contactTuple["sn_active"] = sn_active
      
    if(key.lower() == "u_bsc_source"):
      if val is None:
        sn_u_bsc_source = ''
      else:
        sn_u_bsc_source = val
      log_msg.debug('   BSC Source is: {}'.format(sn_u_bsc_source))
      contactTuple["sn_u_bsc_source"] = sn_u_bsc_source
      
    if(key.lower() == "cost_center"):
      if val is None:
        sn_cost_center = ''
      else:
        sn_cost_center = val
      log_msg.debug('   cost center is: {}'.format(sn_cost_center))
      contactTuple["sn_cost_center"] = sn_cost_center
      
    if(key.lower() == "phone"):
      if val is None:
        sn_bus_phone = ''
      else:
        sn_bus_phone = val
      log_msg.debug('   Business phone is: {}'.format(sn_bus_phone))
      contactTuple["sn_bus_phone"] = sn_bus_phone
      
    if(key.lower() == "name"):
      if val is None:
        sn_full_name = ''
      else:
        sn_full_name = val
      log_msg.debug('   full name is: {}'.format(sn_full_name))
      contactTuple["sn_full_name"] = sn_full_name
      
    if(key.lower() == "u_emp_type"):
      if val is None:
        sn_u_emp_type = ''
      else:
        sn_u_emp_type = val
      log_msg.debug('   employee type is: {}'.format(sn_u_emp_type))
      contactTuple["sn_u_emp_type"] = sn_u_emp_type
      
    if(key.lower() == "employee_number"):
      if val is None:
        sn_employee_number = ''
      else:
        sn_employee_number = val
      log_msg.debug('   employee number is: {}'.format(sn_employee_number))
      contactTuple["sn_employee_number"] = sn_employee_number
      
    if(key.lower() == "city"):
      if val is None:
        sn_city = ''
      else:
        sn_city = val
      log_msg.debug('   city is: {}'.format(sn_city))
      contactTuple["sn_city"] = sn_city
      
    if(key.lower() == "user_name"):
      if val is None:
        sn_username = ''
      else:
        sn_username = val
      log_msg.debug('   username is: {}'.format(sn_username))
      contactTuple["sn_username"] = sn_username
      
    if(key.lower() == "title"):
      if val is None:
        sn_title = ''
      else:
        sn_title = val
      log_msg.debug('   title is: {}'.format(sn_title))
      contactTuple["sn_title"] = sn_title
      
    if(key.lower() == "mobile_phone"):
      if val is None:
        sn_mobile_phone = ''
        sn_sms_number = ''
      else:
        sn_mobile_phone = val
        sn_sms_number = val
      log_msg.debug('   mobile phone is: {}'.format(sn_mobile_phone))
      log_msg.debug('   SMS number is: {}'.format(sn_sms_number))
      contactTuple["sn_mobile_phone"] = sn_mobile_phone
      contactTuple["sn_sms_number"] = sn_sms_number
      
    if(key.lower() == "street"):
      if val is None:
        sn_street = ''
      else:
        sn_street = val
      log_msg.debug('   street is: {}'.format(sn_street))
      contactTuple["sn_street"] = sn_street
      
    if(key.lower() == "company"):
      if val is None:
        sn_company = ''
      else:
        sn_company = val
      log_msg.debug('   company is: {}'.format(sn_company))
      contactTuple["sn_company"] = sn_company
      
    if(key.lower() == "department"):
      if val is None:
        sn_department = ''
      else:
        sn_department = val
      log_msg.debug('   department is: {}'.format(sn_department))
      contactTuple["sn_department"] = sn_department
      
    if(key.lower() == "first_name"):
      if val is None:
        sn_first_name = ''
      else:
        sn_first_name = val
      log_msg.debug('   first name is: {}'.format(sn_first_name))
      contactTuple["sn_first_name"] = sn_first_name
      
    if(key.lower() == "email"):
      if val is None:
        sn_work_email = ''
      else:
        sn_work_email = val
      log_msg.debug('   work email is: {}'.format(sn_work_email))
      contactTuple["sn_work_email"] = sn_work_email
      
    if(key.lower() == "preferred_language"):
      if val is None:
        sn_language = ''
      else:
        sn_language = val
      log_msg.debug('   language is: {}'.format(sn_language))
      contactTuple["sn_language"] = sn_language
      
    if(key.lower() == "manager"):
      if val is None:
        sn_manager = ''
      else:
        sn_manager = val
      log_msg.debug('   manager is: {}'.format(sn_manager))
      contactTuple["sn_manager"] = sn_manager
      
    if(key.lower() == "last_name"):
      if val is None:
        sn_last_name = ''
      else:
        sn_last_name = val
      log_msg.debug('   last name is: {}'.format(sn_last_name))
      contactTuple["sn_last_name"] = sn_last_name
      
    if(key.lower() == "middle_name"):
      if val is None:
        sn_middle_name = ''
      else:
        sn_middle_name = val
      log_msg.debug('   middle name is: {}'.format(sn_middle_name))
      contactTuple["sn_middle_name"] = sn_middle_name
      
    if(key.lower() == "location"):
      if val is None:
        sn_location = ''
      else:
        sn_location = val
      log_msg.debug('   location is: {}'.format(sn_location))
      contactTuple["sn_location"] = sn_location
      
    if(key.lower() == "u_business_unit"):
      if val is None:
        sn_u_business_unit = ''
      else:
        sn_u_business_unit = val
      log_msg.debug('   business unit is: {}'.format(sn_u_business_unit))
      contactTuple["sn_u_business_unit"] = sn_u_business_unit
      
  return contactTuple

def insertContactToMIR3(log_msg, sn_contactAttrs):
  #check that the record is not inactive first....
  if sn_contactAttrs(['sn_active']).lower() == "true":
    log_msg.debug("The contact is active....")
  else:
    log_msg.debug("{} is inactive skipping insert....".format(sn_contactAttrs(['sn_username'])))
    return 1

def compareContactRecords(log_msg, sn_contactAttrs, mir3_contactAttrs):
  # returning with 0 means no update needed, 1 means update needed...
  returnValue = 0
  
  if 'sn_first_name' in sn_contactAttrs and 'mir3_firstname' in mir3_contactAttrs:
    if sn_contactAttrs['sn_first_name'].lower() != mir3_contactAttrs['mir3_firstname'].lower():
      log_msg.debug("Need to update first name")
      returnValue = 1
      
  if 'sn_last_name' in sn_contactAttrs and 'mir3_lastname' in mir3_contactAttrs:  
    if sn_contactAttrs['sn_last_name'].lower() != mir3_contactAttrs['mir3_lastname'].lower():
      log_msg.debug("Need to update last name")
      returnValue = 1
  
  if 'sn_employee_number' in sn_contactAttrs and 'mir3_employeeid' in mir3_contactAttrs:  
    if sn_contactAttrs['sn_employee_number'].lower() != mir3_contactAttrs['mir3_employeeid'].lower():
      log_msg.debug("Need to update employee id")
      returnValue = 1
  
  if 'sn_company' in sn_contactAttrs and 'mir3_company' in mir3_contactAttrs:  
    if sn_contactAttrs['sn_company'].lower() != mir3_contactAttrs['mir3_company'].lower():
      log_msg.debug("Need to update company")
      returnValue = 1
    
  if 'sn_bus_phone' in sn_contactAttrs and 'Work Phone' in mir3_contactAttrs:
    if sn_contactAttrs['sn_bus_phone'].lower() != mir3_contactAttrs['Work Phone'].lower():
      log_msg.debug("Need to update work phone")
      returnValue = 1
    
  if 'sn_work_email' in sn_contactAttrs and 'Work Email' in mir3_contactAttrs:
    if sn_contactAttrs['sn_work_email'].lower() != mir3_contactAttrs['Work Email'].lower():
      log_msg.debug("Need to update work email")
      returnValue = 1
  
  if 'sn_mobile_phone' in sn_contactAttrs and 'Home Mobile' in mir3_contactAttrs:
    if sn_contactAttrs['sn_mobile_phone'].lower() != mir3_contactAttrs['Home Mobile'].lower():
      log_msg.debug("Need to update mobile phone")
      returnValue = 1

  if 'sn_mobile_phone' in sn_contactAttrs and 'Work Mobile' in mir3_contactAttrs:
    if sn_contactAttrs['sn_mobile_phone'].lower() != mir3_contactAttrs['Work Mobile'].lower():
      log_msg.debug("Need to update mobile phone")
      returnValue = 1
    
  if 'sn_sms_number' in sn_contactAttrs and 'Home SMS' in mir3_contactAttrs:
    if sn_contactAttrs['sn_sms_number'].lower() != mir3_contactAttrs['Home SMS'].lower():
      log_msg.debug("Need to update SMS Number")
      returnValue = 1
      
  if 'sn_sms_number' in sn_contactAttrs and 'Work SMS' in mir3_contactAttrs:
    if sn_contactAttrs['sn_sms_number'].lower() != mir3_contactAttrs['Work SMS'].lower():
      log_msg.debug("Need to update SMS Number")
      returnValue = 1
      
  #if sn_contactAttrs['???'].lower() != mir3_contactAttrs['Job Code'].lower():
  #  log_msg.debug("Need to update last name")
  #  returnValue = 1
    
  if 'sn_cost_center' in sn_contactAttrs and 'Department ID' in mir3_contactAttrs:
    if sn_contactAttrs['sn_cost_center'].lower() != mir3_contactAttrs['Department ID'].lower():
      log_msg.debug("Need to update CostCenter/Department")
      returnValue = 1
    
  if 'sn_middle_name' in sn_contactAttrs and 'Middle Name' in mir3_contactAttrs:
    if sn_contactAttrs['sn_middle_name'].lower() != mir3_contactAttrs['Middle Name'].lower():
      log_msg.debug("Need to update middle name")
      returnValue = 1
    
  if 'sn_u_business_unit' in sn_contactAttrs and 'Business Unit' in mir3_contactAttrs:
    if sn_contactAttrs['sn_u_business_unit'].lower() != mir3_contactAttrs['Business Unit'].lower():
      log_msg.debug("Need to update business unit")
      returnValue = 1
       
  return returnValue

  
def main():

  try:
    opts, args = getopt.getopt(sys.argv[1:], 'hl:', ['help', 'loglevel='])
  except getopt.GetoptError as err:
    print("exception in GETOPT with [%s]" % err)
    usage()
    sys.exit(2)
  
  # defaults.....
  loglevel = 'INFO'
  validloglevel = [ 'DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL' ]
  
  for opt, arg in opts:
    if opt in ('--l', '--loglevel'):
      loglevel = arg.upper()
    elif opt in ('--h', '--help'):
      usage()
      sys.exit(0)
    else:
      assert False, "unhandled option"

  pathname = os.path.dirname(sys.argv[0])        
  pathdir = os.path.abspath(pathname)
  currentscript = os.path.basename(os.path.splitext(__file__)[0])
  date_fmt = datetime.now().strftime('%Y%m%d-%H%M')
  LOGFILE = '%s/%s_%s.log' % (LOG_DIR, currentscript, date_fmt)

  #MIR3 variables
  mir3_url = "https://inwebservices.mir3.com/services/mir3"
  mir3_username = 'mkane01'
  mir3_password = 'Blue123$'
  mir3_auth_str = '%s:%s' % (mir3_username, mir3_password)
  mir3_b64_auth_str = base64.b64encode(mir3_auth_str.encode("utf-8"))
  
  #counters
  updateContactCnt = 0
  insertContactCnt = 0
  removeContactCnt = 0
  skipContactCnt = 0
  
  #skip_contact_type
  skipContactTypes = { 'service account' }
  
  if validloglevel.count(loglevel) < 1:
    usage()
    sys.exit(5)
  
  log_msg = log_message.get_file_logger(currentscript, loglevel, LOGFILE, currentscript, True)
  log_msg.info("Starting program running with LOG4J as [%s]" % loglevel)

  try:
    url = 'https://blueshieldca2015.service-now.com/api/now/table/sys_user?sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_limit=10000'
    #url = 'https://blueshieldca2015.service-now.com/api/now/table/sys_user?sysparm_query=user_name%3Degonza01&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_limit=1'
    resp = requests.get(url, auth=('mkane01', 'Skippy10!'))   #MBK fix this!
    log_msg.debug("HTTP REST call received: %s" % resp.status_code)
    
    if resp.status_code != 200:
      # This means something went wrong.
      #log_msg.error('ERROR: HTTP REST GET /sys_user/ failed with return code {}'.format(resp.status_code))
      log_msg.error('ERROR: ServiceNow Status:', mir3_response.status_code, 'Headers:', mir3_response.headers, 'Error Response:', mir3_response.text.encode('utf8'))
      sys.exit(14)
    
    json_objs=resp.json()
    for keyvalue in json_objs.items():
      key, contacts = keyvalue[0], keyvalue[1]
    
    #contacts will now be all rows returned

    for contact in contacts:
      #print(contact)
      log_msg.debug('Working on contact [{}]'.format(contact))
      #process the record 
      sn_contactAttrs = getSNowContactData(log_msg, contact)
      log_msg.debug('Contact Data is [{}]'.format(sn_contactAttrs))
    
      log_msg.info('Contact looking up in MIR3 is [{}]'.format(sn_contactAttrs['sn_username']))

      #mir3_payload = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://www.mir3.com/ws\">\n    <soapenv:Header/>\n    <soapenv:Body>\n        <ws:searchRecipients>\n            <ws:apiVersion>4.7</ws:apiVersion>\n            <ws:authorization>\n                <ws:username>mkane01</ws:username>\n                <ws:password>Blue123$</ws:password>\n            </ws:authorization>\n            <ws:includeDetail>true</ws:includeDetail>\n            <ws:query>\n                <ws:not>\n            </ws:not>\n            </ws:query>\n        </ws:searchRecipients>\n    </soapenv:Body>\n</soapenv:Envelope>"
      mir3_payload = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://www.mir3.com/ws\">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <ws:searchRecipients>\r\n         <ws:apiVersion>4.7</ws:apiVersion>\r\n         <!--Optional:-->\r\n         <ws:authorization>\r\n            <ws:username>{}</ws:username>\r\n            <ws:password>{}</ws:password>\r\n         </ws:authorization>\r\n         <ws:maxResults>2</ws:maxResults>\r\n         <ws:includeDetail>true</ws:includeDetail>\r\n         <ws:query>\r\n            <ws:or>\r\n               <ws:username>{}</ws:username>\r\n               <ws:customField>\r\n               \t<ws:name>snow_sysid</ws:name>\r\n               \t<ws:value>{}</ws:value>\r\n               </ws:customField>\r\n            </ws:or>\r\n         </ws:query>\r\n      </ws:searchRecipients>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>".format(mir3_username, mir3_password, sn_contactAttrs['sn_username'], sn_contactAttrs['sn_sys_id'])
      log_msg.debug("MIR3 Payload is: [{}]".format(mir3_payload))
      
      mir3_headers = {
        'Authorization': 'Basic {}'.format(mir3_b64_auth_str),
        'Content-Type': 'application/xml'
      }

      mir3_response = requests.request("POST", mir3_url, headers=mir3_headers, data = mir3_payload, verify=False)

      if mir3_response.status_code != 200: 
        log_msg.error('ERROR: MIR3 Status:', mir3_response.status_code, 'Headers:', mir3_response.headers, 'Error Response:', mir3_response.text.encode('utf8'))
        exit(19)
      
      xmlString = mir3_response.text.encode('utf8')
      log_msg.debug("Returned from MIR3 Soap call: [{}]".format(xmlString))
      #lets parse the record
      mir3ContactCnt = 0
      mir3ContactCnt, mir3_contactAttrs = getMIR3ContactData(log_msg, mir3_response)

      log_msg.debug("Count of returned contacts [{}] with data: [{}]".format(mir3ContactCnt,mir3_contactAttrs))
      
      if mir3ContactCnt > 1:
        log_msg.error("ERROR: We should never get more than 1 record returned from MIR3! Contact: [{}]".format(sn_contactAttrs['sn_username']))
        sys.exit(22)
      
      #logic for skip record/insert contact/update contact/remove contact
      if sn_contactAttrs['sn_u_emp_type'].lower() in skipContactTypes:
        log_msg.debug("Contact [{}] is a SKIP type, skipping this contact".format(sn_contactAttrs['sn_username']))
        skipContactCnt += 1
      elif sn_contactAttrs['sn_active'].lower() == "false" and mir3ContactCnt > 0:
        log_msg.debug("Contact check for deletion in MIR3....")
        datetime_object = datetime.strptime(sn_contactAttrs['sn_sys_updated_on'], '%m-%d-%Y %I:%M:%S %p')
        if datetime_object < datetime.today() - timedelta(days=14):
          log_msg.info("Performing delete of contact {} in MIR3".format(mir3_contactAttrs['mir3_username']))
          removeContactCnt += 1
          #make call here.... MBK
        else:
          log_msg.info("Need to wait longer for the delete as [{}] hasn't met the 14 day grace period....".format(datetime_object))
      elif sn_contactAttrs['sn_active'].lower() == "false" and mir3ContactCnt == 0:
        log_msg.info("Contact [{}] is not in MIR3 and is inactive in ServiceNow, no action needed....".format(sn_contactAttrs['sn_username']))
      elif sn_contactAttrs['sn_active'].lower() == "true" and mir3ContactCnt == 0:
        log_msg.info("Contact insert into MIR3 needed for contact [{}]".format(sn_contactAttrs['sn_username']))
        #make call here for MIR3 insert MBK
        insertContactCnt += 1
      elif sn_contactAttrs['sn_active'].lower() == "true" and mir3ContactCnt == 1:
        #check for update....
        log_msg.info("record exists in MIR3, checking for update....")
        if compareContactRecords(log_msg, sn_contactAttrs, mir3_contactAttrs) > 0:
          updateContactCnt += 1
          log_msg.info("Updating contact [{}]".format(sn_contactAttrs['sn_username']))
      else:
        log_msg.info("Contact [{}] - We should never get here!!!!!!".format(sn_contactAttrs['sn_username']))
      
      log_msg.debug("Complete with contact: [{}]".format(sn_contactAttrs['sn_username']))
  
  except OSError as err:
    log_msg.error("OS error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except ValueError as err:
    log_msg.error("VALUE error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except KeyboardInterrupt:
    log_msg.error('You cancelled the operation.')
    log_msg.error(traceback.format_exc())
    raise
  except IOError as err:
    log_msg.error("IOError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except EOFError as err:
    log_msg.error("EOFError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except KeyError as err:
    log_msg.error("KeyError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except Exception as err:
    log_msg.error("Unexpected error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  finally:
    log_msg.info("---------------------------------------------------------------------------")
    log_msg.info("Counts: Inserts [{}] Updates [{}] Deletes [{}] Skips [{}]".format(insertContactCnt, updateContactCnt, removeContactCnt, skipContactCnt))
    log_msg.info("---------------------------------------------------------------------------")

  
  log_msg.info("Completed program successfully")
  sys.exit(0)
   
if __name__ == "__main__":
  main()
           



