#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 05/08/2017 Murry Kane     Initial version
# 12/04/2017 Murry Kane     Made changes to get it to work on Windows
# 01/11/2018 Murry Kane     changed function iswindows to account for wsadmin os.name = 'java'
#_________________________________________________________________________________________________
#

import os
from re import search
True = 1
False = 0

def iswindows():
  tt = os.name
  if tt == 'nt':
    #print "its NT"
    return True
  elif tt == 'java':
    # need to find out via java 
    #print "its JAVA"
    import java
    ss = java.lang.System.getProperty( "os.name" )
    #return "win" in tt.lower()
    if ss.lower().find('win') >= 0:
      return True
    else:
      return False
  else:
    #print "its something else ... linux"
    return False
  return False
  

def find_file(name, path):
  for root, dirs, files in os.walk(path):
    if name in files:
      return os.path.join(root, name)
            
if iswindows() is True:
  PROJ_PATH = 'D:/apps/jenkins/AutoSphere'
  WAS_HOME = 'D:/IBM/WebSphere/AppServer'
  SVN_HOME = 'D:/apps/jenkins'
  serverStatusOutFile = 'C:/temp/serverStatusOutput.out'
  profilesFile = 'C:/temp/profileList.out'
  ext_name = '.bat'
  if os.name == 'java':
    print 'Skipping getting PYTHONPATH since we have a bug with os.name returning "java" from within wsadmin.....'
  else:
    PYTHONPATH = os.environ['PYTHONPATH'].replace("\\", "/") 
else:
  PROJ_PATH = '/opt/jenkins/AutoSphere'
  WAS_HOME = '/opt/WebSphere/AppServer'
  SVN_HOME = '/opt/jenkins'
  serverStatusOutFile = '/tmp/serverStatusOutput.out'
  profilesFile = '/tmp/profileList.out'
  ext_name = '.sh'
  PYTHONPATH = os.environ['PYTHONPATH']
  
PYTHON_DIR = '%s/python' % PROJ_PATH
JYTHON_DIR = '%s/jython' % PROJ_PATH
SHELL_DIR = '%s/shell' % PROJ_PATH
INIT_DIR = '%s/bin/init' % PROJ_PATH
LOG_DIR = '%s/logs' % PROJ_PATH
XML_DIR = '%s/xml' % PROJ_PATH
SVN_COMMON = '%s/AutoCommon' % SVN_HOME
SVN_SPHERE = '%s/AutoSphere' % SVN_HOME
SVN_XML = '%s/xml' % SVN_SPHERE
PUREAPP_VI_PROP = '/etc/virtualimage.properties'
PUREAPP_STR_XML = 'BSCVM_ENVIRONMENT'

if not os.path.exists(WAS_HOME):
  WAS_HOME = '/opt/IBM/WebSphere/AppServer'
  if not os.path.exists(WAS_HOME):
    print "Could not determine WAS_HOME"

if iswindows() is True:
  #JAVA_BIN = "%s/bin/java" % (os.environ['JAVA_HOME'].replace("\\", "/"))
  #JAVA_BIN = '%s/8.0/bin/java' % JAVA_HOME
  if os.name == 'java':
    print 'Skipping getting JAVA_BIN since we have a bug with os.name returning "java" from within wsadmin.....'
  else:
    keys = os.environ.keys()
    JAVA_BIN = ''
    for key in keys:
      if search("JAVA_HOME", key):
        JAVA_BIN = "%s/bin/java" % (os.environ['JAVA_HOME'].replace("\\", '/'))
    if not (JAVA_BIN):
      #lets find one.....
      JAVA_BIN = find_file('java.exe', WAS_HOME).replace("\\", '/')
    #print "JAVA_BIN is [%s]" % JAVA_BIN
else:
  JAVA_HOME = '%s/java' % WAS_HOME
  JAVA_BIN = '%s/bin/java' % JAVA_HOME
