#
# This script will Delete SIB configurations
#
# Name          : SDLC_JMS_Deletion_Script.py
# Created       : November 29, 2018
# Author        : Sriram & Team.
# Perpous       : Delete JMS realated resources of BSC SIBus
#

#importing extenal libraries that are needed
import sys

global AdminTask
global AdminConfig
global AdminControl

########################################## Delete JMS Queues - Start ##########################################
print "deleting JMS Queues..."

#LegacyReqQ Queue
LReqQ=AdminConfig.getid("/J2CAdminObject:LegacyReqQ/")
AdminTask.deleteSIBJMSQueue(LReqQ)
print "LegacyReqQ queue deleted."

#LegacyResQ Queue
LResQ=AdminConfig.getid("/J2CAdminObject:LegacyResQ/")
AdminTask.deleteSIBJMSQueue(LResQ)
print "LegacyResQ queue deleted."

#ServicesRequestQ Queue
SReqQ=AdminConfig.getid("/J2CAdminObject:ServicesRequestQ/")
AdminTask.deleteSIBJMSQueue(SReqQ)
print "ServicesRequestQ queue deleted."


#ServicesResponseQ Queue
SResQ=AdminConfig.getid("/J2CAdminObject:ServicesResponseQ/")
AdminTask.deleteSIBJMSQueue(SResQ)
print "ServicesResponseQ queue deleted."

#AuditRequestQ Queue
AReqQ=AdminConfig.getid("/J2CAdminObject:AuditRequestQ/")
AdminTask.deleteSIBJMSQueue(AReqQ)
print "AuditRequestQ queue deleted."


AdminConfig.save()
print "saving configuration"
print "JMS Queues Deleted."

########################################## Delete JMS Queues - End ##########################################

########################################## Delete Activation specifications - Start ################################
print "Deleting J2Activation specifications..."

#LegacyLoginActivationSpec
LegacyActSpec=AdminConfig.getid("/J2CActivationSpec:LegacyLoginActivationSpec/")
AdminTask.deleteSIBJMSActivationSpec(LegacyActSpec)
print "LegacyLoginActivationSpec deleted."

#ServicesActivationSpec
ServicesActSpec=AdminConfig.getid("/J2CActivationSpec:ServicesActivationSpec/")
AdminTask.deleteSIBJMSActivationSpec(ServicesActSpec)
print "ServicesActivationSpec deleted."

#AuditActivationSpec
AuditActSpec=AdminConfig.getid("/J2CActivationSpec:AuditActivationSpec/")
AdminTask.deleteSIBJMSActivationSpec(AuditActSpec)
print "AuditActivationSpec deleted."

AdminConfig.save()
print "saving configuration"

########################################## Delete Activation specifications - End ################################

########################################## Delete Queue Connection Factories - Start  ##########################################

print "Deleting Queue connection factories..."
#AuditQCF
Audit = AdminConfig.getid("/J2CConnectionFactory:AuditQCF/")
AdminTask.deleteSIBJMSConnectionFactory(Audit)
print "Queue connection factory AuditQCF deleted."

#LegacyLoginQCF
LegacyQCF=AdminConfig.getid("/J2CConnectionFactory:LegacyLoginQCF/")
AdminTask.deleteSIBJMSConnectionFactory(LegacyQCF)
print "Queue connection factory LegacyLoginQCF deleted."

#ServicesQCF
Services=AdminConfig.getid("/J2CConnectionFactory:ServicesQCF/")
AdminTask.deleteSIBJMSConnectionFactory(Services)
print "Queue connection factory ServicesQCF deleted."

print "Queue connection factories deleted."
AdminConfig.save()
print "saving configuration"

########################################## Delete Queue Connection Factories - End  ##########################################

########################################## Delete SIBDB Data source - Start ################################

print "Getting SIBDB Data Source ID"

ds = AdminConfig.getid('/DataSource:SIBDB/')

print "Deleting SIBDB Data Source..."

#AdminTask.deleteDataSource ('(cells/PRTCell/clusters/PortalCluster|resources.xml#DataSource_1513023766071)')

AdminTask.deleteDatasource(ds)

print "SIBDB Data Source deleted"

AdminConfig.save()
print "saving configuration"

########################################## Delete SIBDB Data source - End ################################

########################################## Delete SIBUS BSCSIBus - Start  ##########################################
print "Deleting SIBUS BSCSIBus..."
AdminTask.deleteSIBus('[-bus BSCSIBus ]')
print "SIBUS BSCSIBus deleted."
AdminConfig.save()
print "saving configuration"
########################################## Delete SIBUS BSCSIBus - End  ##########################################
