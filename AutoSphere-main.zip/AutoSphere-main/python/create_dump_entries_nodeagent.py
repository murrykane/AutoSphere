import sys

global AdminTask
global AdminConfig
global AdminControl

print "*******************Creating Environment Entries for all nodeagents********************"

print

print "creating the Environment Entries (javacore,heap dumps and system dumps) for uapp9048h"

srvid = AdminConfig.getid('/Cell:PRTCell/Node:PRTH72PortalNode01/Server:nodeagent/')
pdef = AdminConfig.list('JavaProcessDef', srvid)


AdminConfig.create('Property', (pdef), '[[validationExpression ""] [name "IBM_JAVACOREDIR"] [description ""] [value "/home/websphr/Dumps/nodeagent_uapp9048h"] [required "false"]]')

AdminConfig.create('Property', (pdef), '[[validationExpression ""] [name "IBM_HEAPDUMPDIR"] [description ""] [value "/home/websphr/Dumps/nodeagent_uapp9048h"] [required "false"]]')

AdminConfig.create('Property', (pdef), '[[validationExpression ""] [name "IBM_COREDIR"] [description ""] [value "/home/websphr/Dumps/nodeagent_uapp9048h"] [required "false"]]')

AdminConfig.save()

print

print "created Environment Entries for uapp9048h"

print

print "creating the Environment Entries (javacore,heap dumps and system dumps) for uapp9047h"

srvid = AdminConfig.getid('/Cell:PRTCell/Node:PRTH72PortalNode02/Server:nodeagent/')
pdef = AdminConfig.list('JavaProcessDef', srvid)


AdminConfig.create('Property', (pdef), '[[validationExpression ""] [name "IBM_JAVACOREDIR"] [description ""] [value "/home/websphr/Dumps/nodeagent_uapp9047h"] [required "false"]]')

AdminConfig.create('Property', (pdef), '[[validationExpression ""] [name "IBM_HEAPDUMPDIR"] [description ""] [value "/home/websphr/Dumps/nodeagent_uapp9047h"] [required "false"]]')

AdminConfig.create('Property', (pdef), '[[validationExpression ""] [name "IBM_COREDIR"] [description ""] [value "/home/websphr/Dumps/nodeagent_uapp9047h"] [required "false"]]')

AdminConfig.save()

print

print "created Environment Entries for uapp9047h"

print

print "*******************Environment Entries created for all nodeagents********************"
