#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 02/25/2021 Murry Kane     Initial version - used for SNow functions
#_________________________________________________________________________________________________
#

import os, requests, sys, traceback

def addSnowAttachment(log_msg, table_name, sys_id, file_name, phys_file, type, snow_instance, snow_user, snow_pass):
  '''
  This will add an attachment to a object in ServiceNow

  Parms required
    1) log_msg (The pointer to the logging file)
    2) Table Name  (The Service Now Table that you will add an attachment too)
    3) Sys ID (The record you want to add the attachment too in the table)
    4) File Name (What you want to see for the attachement on the Snow Record (typically the file name))
    5) Physical File (Path and name of the file)
    5) Document Type ( Word/PDF/xls/ etc should be in value like 'document/doc'
    6) SNow Instance (The 2015/dev/qa/prod instance of ServiceNow IE blueshieldca2015
    7) SNow username (The username to send to the REST call for SNow
    8) SNow password (The password to send to the REST call for SNow
    
  You should expect a 201 response for success
  '''
  try:
    returnStr = ''
    # Set the request parameters
    url = 'https://{}.service-now.com/api/now/attachment/file?table_name={}&table_sys_id={}&file_name={}'.format(snow_instance, table_name, sys_id, file_name)

    # Set proper headers
    headers = {"Content-Type":"{}".format(type),"Accept":"application/json"}

    # read the data in from the file
    data = open(phys_file, 'rb').read()
    
    # Do the HTTP request
    response = requests.post(url, auth=(snow_user, snow_pass), headers=headers, data=data)

    # Check for HTTP codes other than 200
    if response.status_code != 201: 
      #log_msg.error('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:',response.json())
      print('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:',response.json())
      #returnStr=response.json() //empty will denote issues with adding the attachment
      returnStr = None
    else:
      # Decode the JSON response into a dictionary and use the data
      returnStr=response.json() 
      #print("Success")
      
  except Exception as err:
    #log_msg.error("Unexpected error: {0}".format(err))
    #log_msg.error(traceback.format_exc())
    print("Unexpeced error: {0}".format(err))
    print(traceback.format_exc())
    returnStr = None
    raise
  finally: 
    #print(returnStr)
    #log_msg.info(returnStr) 
    return returnStr
