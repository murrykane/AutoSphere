#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 03/12/2020 Murry Kane     Initial version - copied from constants.py and removed java/was
#_________________________________________________________________________________________________
#

import os

def iswindows():
  tt = os.name
  if tt == 'nt':
    #print "its NT"
    return True
  elif tt == 'java':
    # need to find out via java 
    #print "its JAVA"
    import java
    ss = java.lang.System.getProperty( "os.name" )
    #return "win" in tt.lower()
    if ss.lower().find('win') >= 0:
      return True
    else:
      return False
  else:
    #print "its something else ... linux"
    return False
  return False
              
if iswindows() is True:
  #lets see if its defined as an environment variable first before hard-coding it
  SVN_HOME = os.getenv('SVN_HOME')
  if not bool(SVN_HOME):
    SVN_HOME = 'D:/apps/jenkins'
  #lets see if its defined as an environment variable first before hard-coding it
  APPS_HOME = os.getenv('APPS_HOME')
  if not bool(APPS_HOME): 
    APPS_HOME = 'D:/apps'
		
  REPORTS_DIR = 'D:/reports'
  BACKUP_DIR = 'D:/Backups'
  ext_name = '.bat'
  if os.name == 'java':
    print('Skipping getting PYTHONPATH since we have a bug with os.name returning "java" from within wsadmin.....')
  else:
    PYTHONPATH = os.environ['PYTHONPATH'].replace("\\", "/") 
else:
  SVN_HOME = '/opt/jenkins'
  APPS_HOME = '/opt/jenkins'
  ext_name = '.sh'
  PYTHONPATH = os.environ['PYTHONPATH']

PROJ_PATH = '{}/AutoSphere'.format(SVN_HOME) 
PYTHON_DIR = '%s/python' % PROJ_PATH
JYTHON_DIR = '%s/jython' % PROJ_PATH
SHELL_DIR = '%s/shell' % PROJ_PATH
INIT_DIR = '%s/bin/init' % PROJ_PATH
LOG_DIR = '%s/logs' % APPS_HOME
XML_DIR = '%s/xml' % PROJ_PATH
SVN_COMMON = '%s/AutoCommon' % SVN_HOME
SVN_SPHERE = '%s/AutoSphere' % SVN_HOME
SVN_XML = '%s/xml' % SVN_SPHERE
CFG_PATH = '{}/cfg'.format(PROJ_PATH)


