
'''
Vitaliy Fanin
Version 1.0

 Updates
 Date       By                  Reason
_________________________________________________________________________________________________
 04/09/2021 Vitaliy Fanin       Initial version - JIRA Story IOS-321

_________________________________________________________________________________________________
 Description
 This script will unzip the CFST 820 File, extract 2 files for other destinations and re-zip all the 
 files once more. 
'''

import sys, getopt, zipfile, os, os.path, log_message, traceback, subprocess, glob
from datetime import datetime
import shutil
from SREConstants import *
from SREConfigParser import *
from SRESecurity import *

def validateWorkingPath(log_msg, FILE_PATH, FILE_NAME):
    try:
        path, dirs, files = next(os.walk(FILE_PATH))
    except Exception as e:
        log_msg.fatal("Fatal error while validating working path. {}".format(e))
        sys.exit(3)

    file_exists = os.path.exists(os.path.join(FILE_PATH, FILE_NAME))
    file_count = len(files)
    dir_count = len(dirs)
    if not file_exists:
        log_msg.fatal("Exiting, expected file {} not found. The working directory {} is expected to have the {} file in it.  Please place the Zip file for processing." \
            .format(FILE_NAME, FILE_PATH, FILE_NAME))
        sys.exit(4)
    elif file_count != 1:
        log_msg.fatal("Exiting, file count is {}. The working directory {} should only have one ZIP file within. Please review and restart.".format(file_count, FILE_PATH))
        sys.exit(5)
    elif dir_count != 0:
        log_msg.fatal("Exiting, additional directories found within {}. There should be no directories at start of processing.".format(FILE_PATH))
        sys.exit(6)
    elif not os.path.isfile(os.path.join(FILE_PATH, FILE_NAME)):
        log_msg.fatal("Exiting, expected file {} is not a file. Please review.".format(FILE_NAME))
        sys.exit(7)
    if not zipfile.is_zipfile(os.path.join(FILE_PATH, FILE_NAME)):
        log_msg.fatal("Exiting, expected file {} is not a valid ZIP file.".format(FILE_NAME))
        sys.exit(8)
    log_msg.info("Working Directory Validated Successfully...")
    
def usage():
    print("Usage: %s --password=<encrypted_password> --loglevel=<INFO><DEBUG><WARN><ERROR><FATAL> (optional)--help" % sys.argv[0])
    print("Usage: %s --p <encrypted_password> --l <INFO><DEBUG><WARN><ERROR><FATAL> (optional)--h" % sys.argv[0])
    print("-------------------------------------------------------------------------------------------------------------------------------")

def unzipFile_7Zip(log_msg, FILE_PATH, FILE_NAME, UNZIPPED_FILE_PATH, password):
    cmd = ['7z', 'x', os.path.join(FILE_PATH, FILE_NAME), '-o'+UNZIPPED_FILE_PATH, '-p'+password]
    sp = subprocess.Popen(cmd, stderr=subprocess.STDOUT, stdout=subprocess.PIPE)
    out, err = sp.communicate()
    if sp.returncode > 0:
        log_msg.fatal("Error while unzipping file {} with 7-zip.".format(FILE_NAME))
        sys.exit(10)
    if err != None:
        log_msg.error("Non-Fatal error while unzipping file {} with 7-zip.\n {}".format(FILE_NAME, err))
    log_msg.info(out.decode("utf-8") )

    log_msg.info("  File unzipped with 7-zip...")

def findAndCopyFile(log_msg, FILE_MASK, FILE_PATH, UNZIPPED_FILE_PATH):
    fileToCopy = glob.glob(os.path.join(UNZIPPED_FILE_PATH, FILE_MASK))
    if len(fileToCopy) != 1:
        log_msg.fatal("Error! Unable to find a single file matching mask {}.".format(FILE_MASK))
        sys.exit(11)
    fileToCopy = os.path.basename(fileToCopy[0])
    
    fileToCopy_src = os.path.join(UNZIPPED_FILE_PATH, fileToCopy)
    fileToCopy_dst = os.path.join(FILE_PATH, fileToCopy)

    shutil.copy2(fileToCopy_src, fileToCopy_dst)

def copyFiles(log_msg, FILE_PATH, UNZIPPED_FILE_PATH):
    PDF_FILE_MASK = '*Cap & Retro Letter*.pdf'
    TXT_FILE_MASK = 'CFST_820LAC*.txt'
    BC_FILE_MASK = '*Prop56_Hyde*.xls*'
    GEMT_FILE_MASK = '*GEMT*.xls*'
    
    findAndCopyFile(log_msg, PDF_FILE_MASK, FILE_PATH, UNZIPPED_FILE_PATH)
    findAndCopyFile(log_msg, TXT_FILE_MASK, FILE_PATH, UNZIPPED_FILE_PATH)
    findAndCopyFile(log_msg, BC_FILE_MASK, FILE_PATH, UNZIPPED_FILE_PATH)
    findAndCopyFile(log_msg, GEMT_FILE_MASK, FILE_PATH, UNZIPPED_FILE_PATH)
    
    log_msg.info("  Files Copied Successfully...")

def zipAllFiles(log_msg, UNZIPPED_FILE_PATH, FILE_PATH):
    date_fmt = datetime.now().strftime('%m%d%y')
    ZIP_FILE_NAME = "CFST_" + date_fmt + ".zip"

    cmd = ['7z', 'a', '-tzip', os.path.join(FILE_PATH, ZIP_FILE_NAME), UNZIPPED_FILE_PATH + '/*']
    
    sp = subprocess.Popen(cmd, stderr=subprocess.STDOUT, stdout=subprocess.PIPE)
    out, err = sp.communicate()
    if sp.returncode > 0:
        log_msg.fatal("Error while zipping file {}.".format(ZIP_FILE_NAME))
        sys.exit(13)
    if err != None:
        log_msg.error("Non-Fatal error while zipping file {}.".format(ZIP_FILE_NAME))
    log_msg.info(out.decode("utf-8"))

    log_msg.info("  All Files Zipped successfully...")

def cleanUpWorkingDirectory(log_msg, UNZIPPED_FILE_PATH, ZIP_FILE):
    try:
        shutil.rmtree(UNZIPPED_FILE_PATH)
        os.remove(ZIP_FILE)
    except Exception as e:
        log_msg.fatal("Error while cleaning up working directory {}. {}" .format(UNZIPPED_FILE_PATH, e))
        sys.exit(14)
    log_msg.info("  Cleaned up working directory successfully...")

def main():
    FILE_PATH = r"D:\LACare_820_Processing"
    UNZIPPED_FILE_PATH = os.path.join(FILE_PATH, 'CFST')
    ZIP_FILE_NAME = "CFST.zip"
    PASSWORD = ""
    log_msg = ""  
    log_msg, PASSWORD = initSetup(sys.argv)

    log_msg.info("Starting CFST File Processing...")

    log_msg.info("Validating working directory...")
    validateWorkingPath(log_msg, FILE_PATH, ZIP_FILE_NAME)

    log_msg.info("Unzipping ZIP File using 7zip...")
    unzipFile_7Zip(log_msg, FILE_PATH, ZIP_FILE_NAME, UNZIPPED_FILE_PATH, password=PASSWORD)

    log_msg.info("Copying Files...")
    copyFiles(log_msg, FILE_PATH, UNZIPPED_FILE_PATH)

    log_msg.info("Creating new ZIP for all Files...")
    zipAllFiles(log_msg, UNZIPPED_FILE_PATH, FILE_PATH)

    log_msg.info("Cleaning up working directory...")
    cleanUpWorkingDirectory(log_msg, UNZIPPED_FILE_PATH, ZIP_FILE=os.path.join(FILE_PATH, ZIP_FILE_NAME))

    log_msg.info("Program completed successfully!")

def initSetup(args):

    encryptKey = "7LbYdIxza71cWMho8Ru6kg3ZaBjxJFIuqWGDuhyfTDM="

    try:
        opts, args = getopt.getopt(args[1:], 'hp:l:', ['help', 'password=', 'loglevel='])
    except getopt.GetoptError as err:
        print("exception in GETOPT with [%s]" % err)
        usage()
        sys.exit(2)
  
    # defaults.....
    loglevel = 'INFO'
  
    validloglevel = [ 'DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL' ]
  
    for opt, arg in opts:
        if opt in ('--p', '--password'):
            encPassword = arg
        elif opt in ('--l', '--loglevel'):
            loglevel = arg.upper()
        elif opt in ('--h', '--help'):
            usage()
            sys.exit(0)
        else:
            assert False, "unhandled option"

    currentscript = os.path.basename(os.path.splitext(__file__)[0])
    date_fmt = datetime.now().strftime('%Y%m%d-%H%M')
    LOGFILE = '%s/%s_%s.log' % (LOG_DIR, currentscript, date_fmt)    
    
    if validloglevel.count(loglevel) < 1:
        usage()
        sys.exit(5)

    log_msg = log_message.get_file_logger(currentscript, loglevel, LOGFILE, currentscript, True)
    log_msg.info("Starting program running with LOG4J as [%s]" % loglevel)
    log_msg.info("Arguments for program {}".format(opts))

    try:
     
        #validate variables....    
        if encPassword is None:
            log_msg.error("Encrypted Password not found, exiting!")
            sys.exit(3)

        if encryptKey is None:
            log_msg.error("We must have an encrypting key, exiting!")
            sys.exit(3)
      
        log_msg.debug("encrypt key {}\n encrypted password: {}\n"\
            .format(encryptKey, encPassword))
    
        #use security functions to get username/password
        zipPass = decryptStringWithKey(log_msg, encPassword, encryptKey)
        log_msg.debug("Zip File password [{}]".format('XXXXXXXXXX'))

    except OSError as err:
        log_msg.error("OS error: {0}".format(err))
        log_msg.error(traceback.format_exc())
        raise
    except ValueError as err:
        log_msg.error("VALUE error: {0}".format(err))
        log_msg.error(traceback.format_exc())
        raise
    except KeyboardInterrupt:
        log_msg.error('You cancelled the operation.')
        log_msg.error(traceback.format_exc())
        raise
    except IOError as err:
        log_msg.error("IOError error: {0}".format(err))
        log_msg.error(traceback.format_exc())
        raise
    except EOFError as err:
        log_msg.error("EOFError error: {0}".format(err))
        log_msg.error(traceback.format_exc())
        raise
    except KeyError as err:
        log_msg.error("KeyError error: {0}".format(err))
        log_msg.error(traceback.format_exc())
        raise
    except Exception as err:
        log_msg.error("Unexpected error: {0}".format(err))
        log_msg.error(traceback.format_exc())
        raise
    
    return log_msg, zipPass

main()