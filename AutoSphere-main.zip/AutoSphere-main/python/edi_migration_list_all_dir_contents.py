# !/usr/bin/python
# Vitaliy Fanin
# Version 2.0

# This script has been created to get a listing of the directories inside a starting directory.  This will include all 
# directories, even if they are empty. The output is written to a text file.  The directory scan and listing takes the 
# longest, so only doing it once, if possible. The next script will be designed to read the output text file and use 
# robocopy to copy those directories.

import os
import time
import sys
import re
from datetime import datetime

def use_os_walk(dir):
   subfolders= []

   for root, dirs, files in os.walk(dir, topdown=False):
      for name in dirs:
         print(os.path.join(root, name))
         subfolders.append(os.path.join(root, name))

   return subfolders

def run_fast_scandir(dir):    # dir: str
    
    subfolders= []

    for f in os.scandir(dir):
        if f.is_dir():
            print(f.path)
            subfolders.append(f.path)

    for dir in list(subfolders):
        sf = run_fast_scandir(dir)
        subfolders.extend(sf)
    
    return subfolders

os.system('cls')

startTime = time.time()
share = r"\\ainf513p\editm" # using raw string to avoid Python using the double slashes as escape characters

#rootFolders = ["edienl", "edibound", "ediclm", "ediinq", "editm", "SOR", "TM8", "TransmissionFiles"]
#rootFolders = ["edienl", "ediclm", "SOR"]
rootFolders = [r"editm\TM8_8\GBD-Repository\TransmissionFiles\active\2020\03"]

for dir in rootFolders:
    #dir = "edibound"
    
    if dir.find('\\') ==-1:
        name = dir
    else:
        re_string = r"^(.+?)\\.*"
        try:
            name = re.search(re_string, dir).group(1)
        except Exception:
            print("Could not determine proper log file name. Exiting...")
            sys.exit()

    print("Path: " + os.path.join(share, dir))

    subfolders = use_os_walk(os.path.join(share, dir))
    print ('The script took {0} seconds!'.format(time.time() - startTime))

    filepath = "D:\Temp\prod\{}_os_walk_listing_{}.txt".format(name,datetime.now().strftime("%Y-%m-%d"))

    with open(filepath, 'a+') as f:
        for item in subfolders:
            f.write("%s\n" % item)

    f.close()

    print("File {} has been created with the directory listing.".format(filepath))
    print("{} directories found.".format(len(subfolders)))

"""

os.system('cls')
f = open("C:/Temp/os_scandir_listing_01232019.txt", "w+")

startTime = time.time()
subfolders = run_fast_scandir(r"\\dev.bscal.local\apps\edis01\edibound")
print ('The script took {0} seconds!'.format(time.time() - startTime))

with open('C:/Temp/os_scandir_listing_01232019.txt', 'w') as f:
    for item in subfolders:
        f.write("%s\n" % item)

f.close()
"""
