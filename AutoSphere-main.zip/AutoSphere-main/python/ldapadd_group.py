import sys

global AdminTask
global AdminConfig
global AdminControl

AdminApp.edit('bsc-mdm-ear', '[ -MapRolesToUsers [[ mdm_scoreme_dev AppDeploymentOption.No AppDeploymentOption.No "" "CN=mdm_scoreme_dev,OU=Applications,OU=Resources,OU=Role Based Access,DC=dev,DC=bscal,DC=local" AppDeploymentOption.No "" "group:dir-dev.dev.bscal.local:636/CN=mdm_scoreme_dev,OU=Applications,OU=Resources,OU=Role Based Access,DC=dev,DC=bscal,DC=local" ][ mdm_scoreme_prod AppDeploymentOption.No AppDeploymentOption.No "" "CN=mdm_scoreme_dev,OU=Applications,OU=Resources,OU=Role Based Access,DC=dev,DC=bscal,DC=local" AppDeploymentOption.No "" "group:dir-dev.dev.bscal.local:636/CN=mdm_scoreme_dev,OU=Applications,OU=Resources,OU=Role Based Access,DC=dev,DC=bscal,DC=local" ]]]' )

AdminConfig.save()
