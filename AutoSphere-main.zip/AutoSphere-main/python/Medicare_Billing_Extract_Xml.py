# -*- coding: utf-8 -*-
"""
Created on Thu Dec 17 11:32:26 2020

@author: kparro01
"""

import os
import sys
import time
from datetime import datetime
import pandas as pd
import re
from lxml import etree

def exitHandler(exitCode,functionName):
    print('An error occured in {}. Exiting with code {}'.format(functionName,exitCode))
    sys.exit(exitCode)

def getXmlFile(dir_xml,identifier='.mbill.'):
    try:
        print('Searching for XML file in [{}]'.format(dir_xml))
        files = os.listdir(dir_xml)
        files = [f for f in files if identifier in f and f.endswith('.xml')]
        
        if len(files) == 1:
            file = files[0]
            print('Found the following XML file [{}]'.format(file))
            return dir_xml + file
        elif len(files) > 1:
            print('ERROR: Unable to find unique XML file:\n{}'.format(files))
            return None
        else:
            print('ERROR: Unable to find XML file')
            return None
    except:
        print('Unexpected error:', sys.exc_info())
        return None

def fast_iter(context, func, *args, **kwargs):
    """
    https://stackoverflow.com/questions/7171140/using-python-iterparse-for-large-xml-files
    
    CITATION:
        http://lxml.de/parsing.html#modifying-the-tree
        Based on Liza Daly's fast_iter
        http://www.ibm.com/developerworks/xml/library/x-hiperfparse/
        See also http://effbot.org/zone/element-iterparse.htm
        
    Customized by Kyle Parrott to return data list
    """
    
    data = []
    
    for event, elem in context:
        stmt_data = func(elem, *args, **kwargs)
        
        if stmt_data is None:
            return None
        
        data.append(stmt_data)
        
        # It's safe to call clear() here because no descendants will be
        # accessed
        elem.clear()
        # Also eliminate now-empty references from the root node to elem
        for ancestor in elem.xpath('ancestor-or-self::*'):
            while ancestor.getprevious() is not None:
                del ancestor.getparent()[0]
    del context
    
    return data

def process_element(elem):
    try:
        stmt_data = {}

        # INVOICE, MEMBER_NUMBER, GROUP_NUMBER
        subgroup_item_heading = elem.xpath('stmt_detail/bill/group_subgroup/grsg_item/heading')
        subgroup_item_data = elem.xpath('stmt_detail/bill/group_subgroup/grsg_item/data')

        if subgroup_item_heading[0].text == 'Group Number:':
            stmt_data['GROUP_NUMBER'] = subgroup_item_data[0].text
        else:
            stmt_data['GROUP_NUMBER'] = ''

        if subgroup_item_heading[1].text == 'Member Number:':
            stmt_data['MEMBER_NUMBER'] = subgroup_item_data[1].text
        else:
            stmt_data['MEMBER_NUMBER'] = ''

        if subgroup_item_heading[2].text == 'Invoice Number:':
            stmt_data['INVOICE'] = subgroup_item_data[2].text
        else:
            stmt_data['INVOICE'] = ''

        # MEMBER_NAME
        member_name_heading = elem.xpath('stmt_detail/bill/general/remit_block/remit_info/heading')
        member_name_data = elem.xpath('stmt_detail/bill/general/remit_block/remit_info/data')
        if member_name_heading[0].text == 'Member Name:':
            stmt_data['MEMBER_NAME'] = member_name_data[0].text
        else:
            stmt_data['MEMBER_NAME'] = ''

        # TOTAL_AMOUNT_DUE
        total_amount_due_heading = elem.xpath('stmt_detail/bill/general/remit_block/total_due/heading')
        total_amount_due_data = elem.xpath('stmt_detail/bill/general/remit_block/total_due/data')
        if total_amount_due_heading[0].text == 'Total Due - please pay this amount':
            stmt_data['TOTAL_AMOUNT_DUE'] = total_amount_due_data[0].text
        else:
            stmt_data['TOTAL_AMOUNT_DUE'] = ''

        # SUPPRESS_PRINT
        suppress_print_data = elem.xpath('stmt_detail/dst_factory_controls/suppress_print')
        if suppress_print_data[0] is not None:
            stmt_data['SUPPRESS_PRINT'] = suppress_print_data[0].text
        else:
            stmt_data['SUPPRESS_PRINT'] = ''

        # INSERT
        insert_data = elem.xpath('stmt_detail/dst_factory_controls/inserts')
        if insert_data[0] is not None:
            stmt_data['INSERT'] = insert_data[0].text
        else:
            stmt_data['INSERT'] = ''

        # SUB_PERCENTAGE,SUB_YR, SUB_AMT
        sub_percentage_sub_yr_text_1 = elem.xpath('stmt_detail/bill/bill_details/detail[@heading="Miscellaneous Credits and Debits"]/section/data_line/text1')
        sub_percentage_sub_yr_text_2 = elem.xpath('stmt_detail/bill/bill_details/detail[@heading="Miscellaneous Credits and Debits"]/section/data_line/text2')

        if len(sub_percentage_sub_yr_text_1) > 0:
            stmt_data['SUB_PERCENTAGE,SUB_YR'] = sub_percentage_sub_yr_text_1[0].text
        else:
            stmt_data['SUB_PERCENTAGE,SUB_YR'] = ''
        if len(sub_percentage_sub_yr_text_2) > 0:
            stmt_data['SUB_AMT'] = sub_percentage_sub_yr_text_2[0].text
        else:
            stmt_data['SUB_AMT'] = ''

        # BILL_DETAIL1, BILL_DETAIL1_VALUE, BILL_DETAIL2, BILL_DETAIL2_VALUE, BILL_DETAIL3, BILL_DETAIL3_VALUE
        bill_detail_section = elem.xpath('stmt_detail/bill/bill_details/detail[@heading="Billing Details"]/section/*')

        if len(bill_detail_section) > 0:
            bill_detail_section_text1 = bill_detail_section[0].xpath('./text1')
            bill_detail_section_text2 = bill_detail_section[0].xpath('./text2')
            if len(bill_detail_section_text1) > 0:
                stmt_data['BILL_DETAIL1'] = bill_detail_section_text1[0].text
            else:
                stmt_data['BILL_DETAIL1'] = ''
            if len(bill_detail_section_text2) > 0:
                stmt_data['BILL_DETAIL1_VALUE'] = bill_detail_section_text2[0].text
            else:
                stmt_data['BILL_DETAIL1_VALUE'] = ''
        else:
            stmt_data['BILL_DETAIL1'] = ''
            stmt_data['BILL_DETAIL1_VALUE'] = ''

        if len(bill_detail_section) > 1:
            bill_detail_section_text1 = bill_detail_section[1].xpath('./text1')
            bill_detail_section_text2 = bill_detail_section[1].xpath('./text2')
            if len(bill_detail_section_text1) > 0:
                stmt_data['BILL_DETAIL2'] = bill_detail_section_text1[0].text
            else:
                stmt_data['BILL_DETAIL2'] = ''
            if len(bill_detail_section_text2) > 0:
                stmt_data['BILL_DETAIL2_VALUE'] = bill_detail_section_text2[0].text
            else:
                stmt_data['BILL_DETAIL2_VALUE'] = ''
        else:
            stmt_data['BILL_DETAIL2'] = ''
            stmt_data['BILL_DETAIL2_VALUE'] = ''

        if len(bill_detail_section) > 2:
            bill_detail_section_text1 = bill_detail_section[2].xpath('./text1')
            bill_detail_section_text2 = bill_detail_section[2].xpath('./text2')
            if len(bill_detail_section_text1) > 0:
                stmt_data['BILL_DETAIL3'] = bill_detail_section_text1[0].text
            else:
                stmt_data['BILL_DETAIL3'] = ''
            if len(bill_detail_section_text2) > 0:
                stmt_data['BILL_DETAIL3_VALUE'] = bill_detail_section_text2[0].text
            else:
                stmt_data['BILL_DETAIL3_VALUE'] = ''
        else:
            stmt_data['BILL_DETAIL3'] = ''
            stmt_data['BILL_DETAIL3_VALUE'] = ''
        
        # TERM_DATE
        term_date_letter_block = elem.xpath('stmt_detail/bill/general/letter_block/body/text')
        if len(term_date_letter_block) > 0:
            term_date_text = term_date_letter_block[0].text
            term_date_search = re.search('terminated effective (\d+/\d+/\d+)[.]',term_date_text,re.IGNORECASE)
            if term_date_search:
                stmt_data['TERM_DATE'] = term_date_search.group(1)
            else:
                stmt_data['TERM_DATE'] = ''
        else:
            stmt_data['TERM_DATE'] = ''
        
        # MEMBER_BILL_DATE
        member_bill_date_heading = elem.xpath('stmt_detail/bill/summary/bill_summary/summary_item[@id="1"]/heading')
        member_bill_date_data = elem.xpath('stmt_detail/bill/summary/bill_summary/summary_item[@id="1"]/data')
        if member_bill_date_heading[0].text == 'Bill Date:':
            stmt_data['MEMBER_BILL_DATE'] = member_bill_date_data[0].text
        else:
            stmt_data['MEMBER_BILL_DATE'] = ''

        # MEMBER_BILL_PERIOD
        member_bill_period_heading = elem.xpath('stmt_detail/bill/summary/bill_summary/summary_item[@id="2"]/heading')
        member_bill_period_data = elem.xpath('stmt_detail/bill/summary/bill_summary/summary_item[@id="2"]/data')
        if member_bill_period_heading[0].text == 'Billing Period:':
            stmt_data['MEMBER_BILL_PERIOD'] = member_bill_period_data[0].text
        else:
            stmt_data['MEMBER_BILL_PERIOD'] = ''

        # MEMBER_DUE_DATE
        member_due_date_heading = elem.xpath('stmt_detail/bill/summary/bill_summary/summary_item[@id="3"]/heading')
        member_due_date_data = elem.xpath('stmt_detail/bill/summary/bill_summary/summary_item[@id="3"]/data')
        if member_due_date_heading[0].text == 'Due Date:':
            stmt_data['MEMBER_DUE_DATE'] = member_due_date_data[0].text
        else:
            stmt_data['MEMBER_DUE_DATE'] = ''

        # CONTACT PHONE
        contact_phone_data = elem.xpath('stmt_detail/bill/general/customer_service/customer_service_item[@id="1"]/customer_contact/contact_indicative')
        if len(contact_phone_data) > 0:
            stmt_data['CONTACT PHONE'] = contact_phone_data[0].text
        else:
            stmt_data['CONTACT PHONE'] = ''    

        return stmt_data
    except:
        print('Statement data prior to error: {}'.format(stmt_data))
        print('Unexpected error:', sys.exc_info())
        return None

def extractBillingData(file):
    try:
        print('Extracting billing data...')
        context = etree.iterparse(file, tag='stmt')
        data = fast_iter(context,process_element)
        
        if len(data) > 0:
            return data
        else:
            return None
    except:
        print('Unexpected error:', sys.exc_info())
        return None

def createDataFrame(data):
    try:
        print('Creating Data Frame...')
        df = pd.DataFrame(data, columns = ['INVOICE',
                                           'MEMBER_NAME',
                                           'MEMBER_NUMBER',
                                           'GROUP_NUMBER',
                                           'TOTAL_AMOUNT_DUE',
                                           'SUPPRESS_PRINT',
                                           'INSERT',
                                           'SUB_PERCENTAGE,SUB_YR',
                                           'SUB_AMT',
                                           'BILL_DETAIL1',
                                           'BILL_DETAIL1_VALUE',
                                           'BILL_DETAIL2',
                                           'BILL_DETAIL2_VALUE',
                                           'BILL_DETAIL3',
                                           'BILL_DETAIL3_VALUE',
                                           'TERM_DATE',
                                           'MEMBER_BILL_DATE',
                                           'MEMBER_BILL_PERIOD',
                                           'MEMBER_DUE_DATE',
                                           'CONTACT PHONE'])
        
        rows = len(df.index)
        if rows > 0:
            print('Created Data Frame with {} rows'.format(rows))
            return df
        else:
            print('ERROR: Unable to create data frame')
            return None
    except:
        print('Unexpected error:', sys.exc_info())
        return None

def addSummaryLineToDataFrame(df):
    try:
        print('Adding Summary Line to Data Frame')
        total_count = len(df.index)
        value_counts_suppress_print = df.SUPPRESS_PRINT.value_counts()
        total_suppressed = value_counts_suppress_print.loc['Y']
        total_print = value_counts_suppress_print.loc['N']
        
        total_count_str = 'Total Count: {}'.format(total_count)
        total_suppressed_str = 'Total Suppressed: {}'.format(total_suppressed)
        total_print_str = 'Total Print: {}'.format(total_print)
        
        print(total_count_str)
        print(total_suppressed_str)
        print(total_print_str)

        summary_line = {'INVOICE' : total_count_str,
                        'MEMBER_NAME' : total_suppressed_str,
                        'MEMBER_NUMBER' : total_print_str}

        df = df.append(summary_line, ignore_index=True)
        
        return df
    except:
        print('Unexpected error:', sys.exc_info())
        return None

def main():
    try:
        start = time.time()
        dir_xml = '//ainf514p/FACP02-core/Facets/RIS/Temp/MA_Bills/Review/'
        dir_excel = dir_xml
        
        # --------------------------------- Get XML File Name --------------------------------- #
        file = getXmlFile(dir_xml)
        if file is None:
            exitHandler(10,'getXmlFile')
        
        # ------------------------------- Extract Billing Data -------------------------------- #
        data = extractBillingData(file)
        if data is None:
            exitHandler(15,'extractBillingData')
        
        # --------------------------------- Create Data Frame --------------------------------- #
        df = createDataFrame(data)
        if df is None:
            exitHandler(20,'createDataFrame')
        
        # ----------------------------- Add Summary to Data Frame ----------------------------- #
        df = addSummaryLineToDataFrame(df)
        if df is None:
            exitHandler(25,'addSummaryLineToDataFrame')
        
        # -------------------------------- Save to Excel File --------------------------------- #
        date_str = datetime.now().strftime("%Y%m%d")
        excel_file = 'MedAdvBillsRpt_{}.xlsx'.format(date_str)
        print('Saving Data Frame as [{}] in [{}]'.format(excel_file,dir_excel))
        
        with pd.ExcelWriter(dir_excel + excel_file) as writer:
            df.to_excel(writer, index=False)
        
        # ------------------------------- Print Execution Time -------------------------------- #
        end = time.time()
        print('Completed successfully in {} seconds'.format(round(end - start,2)))
        sys.exit(0)
            
    except SystemExit:
        raise # Re-raise the system exit
    except:
        print('Unexpected error:', sys.exc_info())
        exitHandler(99,'main')


main()