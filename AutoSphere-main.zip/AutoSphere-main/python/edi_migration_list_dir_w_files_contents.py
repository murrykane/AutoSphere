# !/usr/bin/python
# Vitaliy Fanin
# Version 2.0

# This script has been created to get a listing of the directories inside a starting directory which have files inside of it.  The output
# is written to a text file.  The directory scan and listing takes the longest, so only doing it once, if possible.
# The next script will be designed to read the output text file and use robocopy to copy those directories.

import os
import time
from datetime import datetime

def use_os_walk(dir):
   subfolders= []

   for root, dirs, files in os.walk(dir, topdown=False):
               
       #if len(files) > 0:
       if files:
           print(root)
           subfolders.append(root) 
       """for name in dirs:
           print(os.path.join(root, name))
           subfolders.append(os.path.join(root, name))"""

   return subfolders

os.system('cls')

startTime = time.time()
share = r"\\dev.bscal.local\apps\edih03" # using raw string to avoid Python using the double slashes as escape characters
dir = "edibound"
print("Path: " + os.path.join(share, dir))

subfolders = use_os_walk(os.path.join(share, dir))
print ('The script took {0:.2f} seconds!'.format(time.time() - startTime))

filepath = "C:\Temp\{}_os_walk_listing_{}_V2.txt".format(dir, datetime.now().strftime("%Y-%m-%d"))

with open(filepath, 'w') as f:
    for item in subfolders:
        f.write("%s\n" % item)

f.close()

print("File {} has been created with the directory listing.".format(filepath))
print("{} directories found.".format(len(subfolders)))

"""

os.system('cls')
f = open("C:/Temp/os_scandir_listing_01232019.txt", "w+")

startTime = time.time()
subfolders = run_fast_scandir(r"\\dev.bscal.local\apps\edis01\edibound")
print ('The script took {0} seconds!'.format(time.time() - startTime))

with open('C:/Temp/os_scandir_listing_01232019.txt', 'w') as f:
    for item in subfolders:
        f.write("%s\n" % item)

f.close()
"""
