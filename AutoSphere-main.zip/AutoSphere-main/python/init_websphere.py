#!/usr/bin/python
#Murry Kane 
#Version 1.0
#exit
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 05/08/2017 Murry Kane     Initial version
# 07/31/2017 Murry Kane     Had to update getProfiles to avoid empty lines being written to the output file
# 12/04/2017 Murry Kane     Added code to work on Windows environments
#______________________________________________________________________________________________
#
import shlex, subprocess, sys, platform, ConfigParser, os, log_message, getpass, re, fnmatch
from datetime import datetime
from constants import *
from threading import Timer
import xml.etree.ElementTree as ET
longTimeout=90

if os.name == 'nt':
  out_file = 'c:/temp/serverStatus.out'
  ext_name = '.bat'
else:
  out_file = '/tmp/serverStatus.out'
  ext_name = '.sh'
  
timeout = 20

def usage():
  print "Usage: " + sys.argv[0]

if os.name != 'nt':
  if getpass.getuser() != 'websphr':
    print "You must run this as the effective user 'websphr', please try again as that user, exiting!"
    sys.exit(1)
#else:
#  print "Not unix......"
  
def run_command(cmd, log_msg):
  """Execute `cmd` in a subprocess and gets its output both STDERR and STDOUT
  Return subprocess exit code on natural completion of the subprocess.
  Raise an exception otherwise."""
    
  process = subprocess.Popen(cmd,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
  output, error = process.communicate()
  exit_code = process.wait()

  if exit_code > 0:
    if output:
      log_msg.error("Received STDOUT: %s" % output)
    if error:
      #lets see if its just the 'ulimit:' open files error received all the time
      for line in error.split(os.linesep):
        if line.find('ulimit:') > 0:
          log_msg.debug("Ignoring the ULIMIT: error from stderr...")
        else:
          log_msg.error(line)
    log_msg.error("ERROR: Exiting program!")
    #sys.exit(exit_code)
  else:
    if output:
      log_msg.info("OUTPUT Received, hiding due to password in output....")
  return output
  

def run_command_with_timeout(cmd, timeout_sec, log_msg):
    """Execute `cmd` in a subprocess and enforce timeout `timeout_sec` seconds.
 
    Return subprocess exit code on natural completion of the subprocess.
    Raise an exception if timeout expires before subprocess completes."""
    proc = subprocess.Popen(cmd)
    timer = Timer(timeout_sec, proc.kill)
    timer.start()
    #output,error = proc.communicate()
    #log_msg.info("output is [%s] with error out [%s]" % (output, error))
    if timer.is_alive():
        # Process completed naturally - cancel timer and return exit code
        timer.cancel()
        return proc.returncode
        #lets return the output(password)
        #return output
    # Process killed by timer - raise exception
    else:
      #raise SubprocessTimeoutError('Process #%d killed after %f seconds' % (proc.pid, timeout_sec))
      return 15
  
def serverStatusQuery(searchStr, position, log_msg):
  """ This will call the WebSphere serverStatus 'ext_name' command and use 
  Timeout in case the command requires a user name and password to complete
  and if that occurs it will kill it and try and get the correct Profile for
  the current server. """
  
  xmlString = ''
  cmd = '%s/bin/serverStatus%s -all' % (WAS_HOME, ext_name)
  log_msg.info("Issueing: [%s]" % cmd)
  args = shlex.split(cmd)
  process = subprocess.Popen(args,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
  timer = Timer(timeout, process.kill)
  
  try:
    log_msg.info("Starting timer....")
    timer.start()
    while True:
      nextline = process.stdout.readline().rstrip()
      if nextline == '' and process.poll() is not None:
        break
      if nextline and (not nextline.isspace()):
        #log_msg.info('not empty line....')
        log_msg.info(nextline)
        if searchStr in nextline:
          key, value = nextline.split(searchStr)
          profile = value.rsplit(' ')[position]
          log_msg.info("Key is %s Value is %s Profile is [%s]" % (key, value, profile))
      sys.stdout.flush()
  except:
    log_msg.error("Exception caught! exiting!")
    sys.exit(11)

  output,error = process.communicate()
  if timer.is_alive():
    # Process completed naturally - cancel timer and return exit code
    timer.cancel()
    log_msg.info("serverStatus%s completed on its own...." % ext_name)
  else:
    log_msg.error("Could not complete the serverStatus%s in a timely maner wait time was exceeded..." % ext_name)
  
  exit_code = process.returncode
  log_msg.info("Exit code is %s" % exit_code)
  
  if exit_code > 0:
    if output:
      log_msg.error("Received STDOUT: %s" % output)
    if error:
      #lets see if its just the 'ulimit:' open files error received all the time
      for line in error.split(os.linesep):
        if line.find('ulimit:') > 0:
          log_msg.debug("Ignoring the ULIMIT: error from stderr...")
        else:
          log_msg.error(line)
    log_msg.error("ERROR: Exiting program!")
    sys.exit(exit_code)
  else:
    if output:
      log_msg.info("Received STDOUT: %s" % output)
    if profile:
      log_msg.info("Found the needed profile with [%s]" % profile)
      startStr = " ".join(re.findall("[a-zA-Z]+", profile)).split()[0]
      startNum = " ".join(re.findall("[0-9]+", profile)).split()[0]
      xmlString = '%s%s' % (startStr, startNum)
    else:
      log_msg.error("Could not find the WebSphere Profile!, exiting!")
      return ''
    log_msg.info("Success on executing [%s]" % 'serverStatus%s' % ext_name)
  
  log_msg.info("Returning with Profile start string [%s]" % xmlString)
  return xmlString

def getWebspherePass(encrypted_password, log_msg):
  """ This will call the BSC custom decrypt program to provide the real password """
  password = ''
  cmd = '%s -cp %s/lib/ws_runtime.jar com.ibm.ws.security.util.PasswordDecoder "%s"' % (JAVA_BIN, SVN_COMMON, encrypted_password)
  log_msg.info("Issueing: [%s]" % cmd)
  args = shlex.split(cmd)
  password = run_command(args, log_msg)
  #log_msg.info("Found the following output: [%s]" % password)
  if password:
    log_msg.info("We were able to get the password for WebSphere")
    password = password.split("decoded password == ",1)[1].split('"')[1]
  else:
    log_msg.error("We could NOT get the needed password for WebSphere, returning!")
  
  #log_msg.info("Password is [%s]" % password)
  return password
    
def getXMLFile(searchStr, log_msg):
  """ This will call the WebSphere serverStatus(ext_name) command and use 
  Timeout in case the command requires a user name and password to complete
  and if that occurs it will kill it and try and get the correct Profile for
  the current server. """
  
  xmlFile = ''
  newStr=searchStr.split('*.xml')[0] 
  endStr=searchStr.split('*')[1]

  foundOne = False
  excludes = ['webserver', 'template', 'reetemplates', 'templates', 'archive' ] 
  #excludes = [ 'junkaabaf' ]
  
  log_msg.info("Checking if this is a PUREAPP Server or not...")
  if os.path.exists(PUREAPP_VI_PROP):
    with open(PUREAPP_VI_PROP) as search:
      for line in search:
        if re.search('^%s' % PUREAPP_STR_XML, line):
          log_msg.debug("This is a PUREAPP server and string was found in file [%s] of value [%s]" % (PUREAPP_VI_PROP, PUREAPP_STR_XML))  
          searchStrNew = line.strip('\n\r[]').split('=')[1]
          log_msg.debug("Found search string with [%s]" % searchStrNew)
          inc_new = [searchStrNew]
          for root, dirs, files in os.walk(SVN_XML, topdown=True):
            dirs[:] = [d for d in dirs if d not in excludes] 
            for dir in dirs:
              for pat in inc_new:
                if foundOne:
                  break
                else:
                  for filename in os.listdir('%s/%s' % (root,dir)):
                    #print "filename is %s" % filename
                    if re.search(r'^%s.*%s' % (searchStrNew, endStr), filename, re.IGNORECASE):
                      xmlFile = '%s/%s/%s' % (root,dir,filename)
                      foundOne = True      
                      #print "found one....."
                      break 
  else:
    log_msg.info("This is not a PUREAPP server type, checking SVN XML directory...")  
    for root, dirs, files in os.walk(SVN_XML, topdown=True):
      dirs[:] = [d for d in dirs if d not in excludes] 
      for dir in dirs:
        #log_msg.debug("Working on finding files in DIR [%s]" % dir)
        if foundOne:
          break
        else:
          for filename in os.listdir('%s/%s' % (root,dir)):
            if re.search(r'^%s.*%s' % (newStr,endStr), filename, re.IGNORECASE):
              xmlFile = '%s/%s/%s' % (root,dir,filename)
              #print "found one... with %s" % xmlFile
              foundOne = True      
              break  
                  
  if xmlFile:
    log_msg.info("XML File found with: [%s]" % xmlFile) 
  else:
    log_msg.error("XML File could not be found!, returning with ERROR!")
    return
      
  # now lets get the values from the XML file!
  tree = ET.parse(xmlFile)
  root = tree.getroot()

  for ainstall in root.findall('installation'):
    for aadmin in ainstall.findall('admin'):
      username = (aadmin.get('username'))
      encrypted_password = (aadmin.get('password'))
  
  if username:
    log_msg.info("Found WebSphere user name to be: [%s]" % username)
  else:
    log_msg.error("Could not find the WebSphere user name to use, returning!")
    return
  
  if encrypted_password:
    log_msg.info("Found the following encrypted password for WebSphere: [%s]" % encrypted_password)
  else:
    log_msg.error("Could not find the WebSphere encrypted password, returning!")
    return
  
  # now lets get the DMGR path....
  for xdmgr in root.findall('dmgr'):
    for xprofile in xdmgr.findall('profile'):
      dmgr_path = (xprofile.get('home'))
  
  if dmgr_path:
    log_msg.info("Found the DMGR path with [%s]" % dmgr_path)
    if os.name == 'nt':
      dmgr_path = dmgr_path.replace("\\", "/")
      log_msg.info("Updated for windows the path to be [%s]" % dmgr_path)
  else:
    log_msg.error("Could not find the path for DMGR in the XMLFile, returning!")
    return
  
  # lets get the real password now....
  password = getWebspherePass(encrypted_password, log_msg)
  if password:
    log_msg.info("We got a password....")
  else:
    log_msg.error("We failed to get the password for WebSphere, returning!")
    return
  return (xmlFile, username, encrypted_password, password, dmgr_path)

def serverStatusWithPass(out_file, username, password, log_msg, BIN_HOME):
  """ This will call the WebSphere serverStatus(ext_name) command and use 
  Timeout in case the command requests user interaction (new certificate, etc)
  and if that occurs it will kill it and try and get the correct Profile for
  the current server. """
  #if os.name == 'nt':
  #  cmd_logging = "%s/bin/serverStatus%s -all -username '%s' -password '%s'" % (BIN_HOME, ext_name, username, 'XXXXXXXXX')
  #  cmd = "%s/bin/serverStatus%s -all -username '%s' -password '%s'" % (BIN_HOME, ext_name, username, password)
  #else:
  #  cmd_logging = "%s/bin/serverStatus%s -all -username '%s' -password '%s'" % (BIN_HOME, ext_name, username, 'XXXXXXXXX')
  #  cmd = "%s/bin/serverStatus%s -all -username '%s' -password '%s'" % (BIN_HOME, ext_name, username, password)
  serverStatusBin = os.path.join(BIN_HOME + os.sep, 'bin' + os.sep, 'serverStatus' + ext_name).replace("\\", "/")
  log_msg.info("Server Status found with: [%s]" % serverStatusBin)
  if not os.path.isfile(serverStatusBin):
    log_msg.error("ERROR: We could not find the serverStatus executable with[%s], exiting method!" % serverStatusBin)
    return False
  cmd_logging = "%s -all -username '%s' -password '%s'" % (serverStatusBin, username, 'XXXXXXXXXX')
  cmd = "%s -all -username '%s' -password '%s'" % (serverStatusBin, username, password)
  #cmd = "D:/IBM/WebSphere/Profiles/FACH70BDmgr/bin/serverStatus.bat -all -username '%s' -password '%s'" % (username, password)
  log_msg.info("Issueing: [%s]" % cmd_logging)
  args = shlex.split(cmd)
  #log_msg.info("after shlex...args [%s]" % args)
  process = subprocess.Popen(args,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
  #log_msg.info("after Popen...")
  timer = Timer(longTimeout, process.kill)
  #log_msg.info("after timer...")
  # first lets remove the out_file if it exists
  if os.path.isfile(out_file):
    log_msg.debug("The out file [%s] exists from previous runs, removing it..." % out_file)
    os.remove(out_file)
  #open a file for write
  statusOutput = open(out_file, 'w')
    
  try:
    log_msg.info("Starting timer....")
    timer.start()
    while True:
      nextline = process.stdout.readline().rstrip()
      if nextline == '' and process.poll() is not None:
        statusOutput.close()
        break
      if nextline and (not nextline.isspace()):
        log_msg.info(nextline)
        #write output to file.....
        statusOutput.write('%s\n' % nextline)
        sys.stdout.flush()
      #else:
      #  log_msg.info('empty line!')        
  except:
    log_msg.error("Exception caught! exiting!")
    statusOutput.close()
    return False

  output,error = process.communicate()
  if timer.is_alive():
    # Process completed naturally - cancel timer and return exit code
    timer.cancel()
    log_msg.info("serverStatus%s completed on its own...." % ext_name)
  else:
    log_msg.error("Could not complete the serverStatus%s in a timely maner wait time was exceeded..." % ext_name)
  
  exit_code = process.returncode
  log_msg.info("Exit code is %s" % exit_code)
  statusOutput.close()
  
  if exit_code > 0:
    if output:
      log_msg.error("Received STDOUT: %s" % output)
    if error:
      #lets see if its just the 'ulimit:' open files error received all the time
      for line in error.split(os.linesep):
        if line.find('ulimit:') > 0:
          log_msg.debug("Ignoring the ULIMIT: error from stderr...")
        else:
          log_msg.error(line)
    log_msg.error("ERROR: Exiting program!")
    #sys.exit(exit_code)
    return False
  else:
    if output:
      log_msg.info("Received STDOUT: %s" % output)
    log_msg.info("Success on executing [%s]" % 'serverStatus%s' % ext_name)
  
  log_msg.info("Success on creating out file [%s]" % out_file)
  return True

def serverStatusWithNoPass(out_file, log_msg, BIN_HOME):
  """ This will call the WebSphere serverStatus(ext_name) command and use 
  Timeout in case the command requests user interaction (new certificate, etc)
  and if that occurs it will kill it and try and get the correct Profile for
  the current server. """

  serverStatusBin = os.path.join(BIN_HOME + os.sep, 'bin' + os.sep, 'serverStatus' + ext_name).replace("\\", "/")
  log_msg.info("Server Status found with: [%s]" % serverStatusBin)
  if not os.path.isfile(serverStatusBin):
    log_msg.error("ERROR: We could not find the serverStatus executable with[%s], exiting method!" % serverStatusBin)
    return False
  cmd_logging = "%s -all" % (serverStatusBin)
  cmd = "%s -all" % (serverStatusBin)

  log_msg.info("Issueing: [%s]" % cmd_logging)
  args = shlex.split(cmd)
  process = subprocess.Popen(args,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
  timer = Timer(longTimeout, process.kill)
  if os.path.isfile(out_file):
    log_msg.debug("The out file [%s] exists from previous runs, removing it..." % out_file)
    os.remove(out_file)
  #open a file for write
  statusOutput = open(out_file, 'w')
    
  try:
    log_msg.info("Starting timer....")
    timer.start()
    while True:
      nextline = process.stdout.readline().rstrip()
      if nextline == '' and process.poll() is not None:
        statusOutput.close()
        break
      if nextline and (not nextline.isspace()):
        log_msg.info(nextline)
        statusOutput.write('%s\n' % nextline)
        sys.stdout.flush()
      
  except:
    log_msg.error("Exception caught! exiting!")
    statusOutput.close()
    return False

  output,error = process.communicate()
  if timer.is_alive():
    # Process completed naturally - cancel timer and return exit code
    timer.cancel()
    log_msg.info("serverStatus%s completed on its own...." % ext_name)
  else:
    log_msg.error("Could not complete the serverStatus%s in a timely maner wait time was exceeded..." % ext_name)
  
  exit_code = process.returncode
  log_msg.info("Exit code is %s" % exit_code)
  statusOutput.close()
  
  if exit_code > 0:
    if output:
      log_msg.error("Received STDOUT: %s" % output)
    if error:
      #lets see if its just the 'ulimit:' open files error received all the time
      for line in error.split(os.linesep):
        if line.find('ulimit:') > 0:
          log_msg.debug("Ignoring the ULIMIT: error from stderr...")
        else:
          log_msg.error(line)
    log_msg.error("ERROR: Exiting program!")
    return False
  else:
    if output:
      log_msg.info("Received STDOUT: %s" % output)
    log_msg.info("Success on executing [%s]" % 'serverStatus%s' % ext_name)
  
  log_msg.info("Success on creating out file [%s]" % out_file)
  return True  

def securityEnabledCheck(log_msg, BIN_HOME):
  """
  Setting of IBM Security for encrypted password in a property file, the logic is as follows:
    com.ibm.SOAP.securityEnabled=true in ../WebSphere/AppServer/profiles/../properties/soap.client.props file
  
  if the above is 'true' then we do not need to pass username and password to stop node/app servers 
  We will either return 0 or 1 where 0 is TRUE(security enabled) and 1 is FALSE (security disabled)
  """
  
  returnValue = False
  serverSoapClientFile = os.path.join(BIN_HOME + os.sep, 'properties' + os.sep, 'soap.client.props').replace("\\", "/")
  if not os.path.isfile(serverSoapClientFile):
    log_msg.error("ERROR: We could not find the serverStatus executable with[%s], exiting method!" % serverSoapClientFile)
    return False
  log_msg.info("Found security file [%s], checking if IBM security is enabled..." % serverSoapClientFile)
  #see if the string is in there
  #findIt = open(serverSoapClientFile, 'r').read().upper().find('com.ibm.SOAP.securityEnabled'.upper())
  theLine = None
  with open(serverSoapClientFile, 'r') as f:
    for line in f:
      if 'com.ibm.soap.securityenabled'.upper() in line.upper():
        theLine = line.strip()
        log_msg.info("Found the security setting in file [%s] with line [%s]" % (serverSoapClientFile, theLine))
        break
  
  if theLine is None:
    log_msg.info("IBM Security is not set on this environment, returning with false.")
    return False
  SecuritySettingFlag = theLine.split('=')[1].upper()
  log_msg.info("IBM Security value is [%s]" % SecuritySettingFlag)
  if SecuritySettingFlag == 'TRUE':
    log_msg.info("IBM Security is ENABLED on this environment, we will not need to pass Username/Password with IBM commands")
    return True
  
  log_msg.info("IBM Security is NOT enabled on this environment, we will need to pass Username/Password with IBM commands")  
  return returnValue

def getProfiles(out_file, log_msg):
  """ This will call the WebSphere manageprofiles(ext_name) command and use 
  Timeout in case the command requests user interaction 
  and if that occurs it will kill it and try and get the correct Profile for
  the current server. """
  
  cmd = '%s/bin/manageprofiles%s -listProfiles' % (WAS_HOME, ext_name)
  log_msg.info("Issueing: [%s]" % cmd)
  args = shlex.split(cmd)
  process = subprocess.Popen(args,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
  timer = Timer(longTimeout, process.kill)

  # first lets remove the out_file if it exists
  if os.path.isfile(out_file):
    log_msg.debug("The out file [%s] exists from previous runs, removing it..." % out_file)
    os.remove(out_file)
  #open a file for write
  statusOutput = open(out_file, 'w')
    
  try:
    log_msg.info("Starting timer....")
    timer.start()
    while True:
      nextline = process.stdout.readline().rstrip()
      if nextline == '' and process.poll() is not None:
        statusOutput.close()
        break
      if nextline and (not nextline.isspace()):
        #log_msg.info('not empty line....')
        log_msg.info(nextline)
        #write output to file.....
        statusOutput.write('%s\n' % nextline)
        sys.stdout.flush()
      #else:
      #  log_msg.info('empty line!')
  except:
    log_msg.error("Exception caught! exiting!")
    return False

  output,error = process.communicate()
  if timer.is_alive():
    # Process completed naturally - cancel timer and return exit code
    timer.cancel()
    log_msg.info("manageprofiles%s completed on its own...." % ext_name)
  else:
    log_msg.error("Could not complete the manageprofiles%s in a timely maner wait time was exceeded..." % ext_name)
  
  exit_code = process.returncode
  log_msg.info("Exit code is %s" % exit_code)
  
  if exit_code > 0:
    if output:
      log_msg.error("Received STDOUT: %s" % output)
    if error:
      #lets see if its just the 'ulimit:' open files error received all the time
      for line in error.split(os.linesep):
        if line.find('ulimit:') > 0:
          log_msg.debug("Ignoring the ULIMIT: error from stderr...")
        else:
          log_msg.error(line)
    log_msg.error("ERROR: Exiting program!")
    return False
  else:
    if output:
      log_msg.info("Received STDOUT: %s" % output)
    log_msg.info("Success on executing [%s%s]" % ('manageprofiles', ext_name))
  
  log_msg.info("Success on creating out file [%s]" % out_file)
  return True

def getProfileRoot(profile, log_msg):
  """ This will call the WebSphere manageprofiles(ext_name) command and use 
  Timeout in case the command requests user interaction and we will request
  the -getPath option for binary to get the full path of the given profile passed in
  if a timeout occurs it will kill it and try and get the correct Profile path for
  the current server. """
  
  cmd = '%s/bin/manageprofiles%s -profileName %s -getPath' % (WAS_HOME, ext_name, profile)
  log_msg.info("Issueing: [%s]" % cmd)
  args = shlex.split(cmd)
  process = subprocess.Popen(args,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
  timer = Timer(longTimeout, process.kill)
  profilePath = ''
  
  try:
    log_msg.info("Starting timer....")
    timer.start()
    while True:
      nextline = process.stdout.readline().rstrip()
      if nextline == '' and process.poll() is not None:
        break
      if nextline and (not nextline.isspace()):
        #log_msg.info('not empty line....')
        log_msg.info(nextline)
        #get the result...
        profilePath = nextline
        sys.stdout.flush()
      #else:
      #  log_msg.info('empty line!')
  except Exception:
    log_msg.error("Exception caught [%s]! exiting!" % Exception)
    return

  output,error = process.communicate()
  if timer.is_alive():
    # Process completed naturally - cancel timer and return exit code
    timer.cancel()
    log_msg.info("manageprofiles%s completed on its own...." % ext_name)
  else:
    log_msg.error("Could not complete the manageprofiles%s in a timely maner wait time was exceeded..." % ext_name)
  
  exit_code = process.returncode
  log_msg.info("Exit code is %s" % exit_code)
  
  if exit_code > 0:
    if output:
      log_msg.error("Received STDOUT: %s" % output)
    if error:
      #lets see if its just the 'ulimit:' open files error received all the time
      for line in error.split(os.linesep):
        if line.find('ulimit:') > 0:
          log_msg.debug("Ignoring the ULIMIT: error from stderr...")
        else:
          log_msg.error(line)
    log_msg.error("ERROR: Exiting program!")
    return
  else:
    if output:
      log_msg.info("Received STDOUT: %s" % output)
    log_msg.info("Success on executing [%s]" % 'manageprofiles%s' % ext_name)
  
  log_msg.info("Success on getting path [%s] for profile [%s]" % (profilePath, profile))
  return profilePath
  