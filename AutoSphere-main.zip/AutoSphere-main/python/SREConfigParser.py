#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 03/24/2020 Murry Kane     Initial version - used for configuration files
#_________________________________________________________________________________________________
#

import os, pathlib, configparser
from SREConstants import *

def getConfigFile(log_msg, currentscript):
  #lets try and find the config file
  returnVal = None
  file='{}/{}.ini'.format(CFG_PATH, currentscript)
  log_msg.debug("Configuration file we are looking for is: {}".format(file))
  cfgfile = pathlib.Path(file)
  if cfgfile.exists():
    log_msg.debug("Using configuration file [{}]".format(file))
    returnVal = file
  else:
    log_msg.info("No configuration file found")
  
  return returnVal
  
def getConfigSections(log_msg, currentscript):

  configFile = getConfigFile(log_msg, currentscript)
  if configFile is None:
    return None, None, None
  
  config = configparser.ConfigParser()
  config.read(configFile)
  sections = config.sections()
  
  log_msg.debug("Configuration sections are {}".format(sections))
  
  return configFile,config,sections 


