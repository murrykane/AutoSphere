# =========================================================================================================================
# Created by: Jeffrey Apiado
# Owned by: IT NPE WEB Team
# Role: Class for parsing XML in AutoSphere/xml directory
#        no intention to replace Xparser java class, use this
#        to extend parsing capability. 
# *********************************************************
# Modified:
#   Version1.0               July 17, 2019          Jeffrey         Initial draft
#   Version1.1               September 20, 2021     Jeffrey         Make script determine reEntries tag if presence or not
# =========================================================================================================================


import xml.etree.ElementTree as ET

class parse:
     def __init__(self, xmlfile):
          self.root = ET.parse(xmlfile).getroot()

     def getRep_count_all(self):
          getrep_all = []
          for cp in self.root.findall("./server/resources/reProviders"):
                for rep in cp:
                   for xxx in rep:
                       getrep_all.append(rep.tag)
          if getrep_all:
              return (len(getrep_all), getrep_all)
          else:
              return (None, None)
                        
     def getRep_count_withEntry(self):
          getrep_with_entries = []
          for cp in self.root.findall("./server/resources/reProviders"):
                for rep in cp:
                   for xxx in rep:
                       if xxx.tag == 'reEntries':
                           getrep_with_entries.append(rep.tag)        
          if getrep_with_entries:
              return (len(getrep_with_entries), getrep_with_entries)
          else:
              return (None, None)

     def getRep_count_withoutEntry(self):
         entrybox = []
         for np in self.root.findall("./server/resources/reProviders"):
                for rep in np:
                   for yyy in rep:
                        if yyy.tag == 'customProperties':
                           entrybox.append(rep.tag)
         if entrybox:
              return (len(entrybox), entrybox)
         else:
              return (None, None)
         

     def getRep_entry_count(self, repnumber):
         (count, array)  = self.getRep_count_withEntry()
         if repnumber in array:
            holder = []
            for r in self.root.findall("./server/resources/reProviders/%s/reEntries" % repnumber):
                 for renum in r:
                     holder.append(renum.tag) 
            return (len(holder), holder)
         else:
            return (None, None)
            
     def getREP_count():
        _rep = []
        for cp in root.findall("./server/resources/reProviders"):
            for rep in cp:
              _rep.append(rep.tag)
              
        if _rep:
          return (len(holder), holder)
        else:
          return (0, None)
          
                
     def getR_entries(self, rpath, tag):
        hold = []
        if tag == 'reEntries':
          for rrr in self.root.findall('%s/*' % rpath):
             varA = "%s/%s/customProperties/*" % (rpath, rrr.tag)
             print '--> extendpath: %s' % varA
             for ccc in self.root.findall(varA):
                  print '==> APPEND to LIST: %s' % ccc.attrib
                  hold.append(ccc.attrib)
        elif tag == 'customProperties':
           varB = "%s/customProperties/*" % rpath
           for cuu in self.root.findall(varB):
              hold.append(cuu.attrib)
        return hold         
          
                             
     def getCustom_property(self, repnumber):
         data = []
         entryn = self.root.find("./server/resources/reProviders/%s/reEntries" % repnumber)
         if entryn is not None:
            print '--> reEntries found'
            vpath = './server/resources/reProviders/%s/reEntries' % repnumber
            print '--> elemPath: %s' % vpath
            xtag = 'reEntries'
            data = self.getR_entries(vpath, xtag)
         else:   
            custn = "./server/resources/reProviders/%s" % repnumber
            ctag = 'customProperties'
            data = self.getR_entries(custn, ctag)
         print '--> returning: ',data
         return (len(data),data)

     # **********************************************************************************************************************************
     # method: evalHash
     # parameter: data (a malformed dictionary) - ex: {"name: logout.explicit.filterchain", "value: com.bsc.common.logout.BSCExplicitLogout"} 
     # syntax: instance.evalHash(someDictionary)
     # output: a well formed dictionary with a key associated to its value -  ex: {"logout.explicit.filterchain": "com.bsc.common.logout.BSCExplicitLogout"}
     # ***********************************************************************************************************************************
     def evalHash(self, data):
          _dict = {}
          _name = data['name']
          _value = data['value']
          _dict[_name] = _value
          return _dict
     
     # ****************************************************************************
     # method: getAttribute
     # parameter: xpath (xml element tree - ex: ./server/resources/reProviders)
     #            attr (attribute name of a tag in xpath - ex: configure)
     # syntax:   instance.getAttribute('./server/resources/reProviders','configure')
     # output: if True return a value of key name - configure (ex: true)
     #         or return None
     # *****************************************************************************
     def getAttribute(self, xpath, attr):
         _attr = self.root.find(xpath).attrib.get(attr)
         if _attr:
              return _attr
         else:
              return None

# ======================== FOR TEST BELOW ============================
# DO NOT EDIT ------------->
#if __name__ == '__main__':
#     inst = parse('C:\\Users\\TEMP\\prtn31commonDocument.xml')
#     count, data = inst.getCustom_property('rep4')
#     for line in data:
#          print xx        

