#!/usr/bin/python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 05/08/2017 Murry Kane     Initial version
#
#_________________________________________________________________________________________________
#
import logging

LOGDIR_DEFAULT = '/opt/jenkins/AutoSphere/python/logs'
FORMAT = '%(asctime)s - %(levelname)s - %(module)s - %(message)s'

def setup_console_logger(name):
  formatter = logging.Formatter(fmt='%(asctime)s - %(levelname)s - %(module)s - %(message)s')

  handler = logging.StreamHandler()
  handler.setFormatter(formatter)

  logger = logging.getLogger(name)
  logger.setLevel(logging.DEBUG)
  logger.addHandler(handler)
  return logger
  
#def get_file_logger(name=None, level=None, logfile=None, format=None, dDate=None):
def get_file_logger(name=None, level=None, logfile=None, funcName=None, consoleHandler=None):
  defName = "__app__"
  defLevel = 'DEBUG'
  defDate = 'datefmt=%Y-%m-%d %H:%M:%S'
  defFmt = '%(levelname)s: %(asctime)s %(funcName)s(%(lineno)d) -- %(message)s'
  defLog = 'apps.log'
  levels = {'CRITICAL' : logging.CRITICAL,
    'ERROR' : logging.ERROR,
    'WARNING' : logging.WARNING,
    'INFO' : logging.INFO,
    'DEBUG' : logging.DEBUG
  }
  
  formatter = logging.Formatter('%(levelname)s: %(asctime)s %(module)s(%(lineno)d) -- %(message)s',
                              datefmt='%Y-%m-%d %H:%M:%S')
  
  if name:
    logger = logging.getLogger(name)
  else:
    logger = logging.getLogger(defName)
  
  if logfile:
    fh = logging.FileHandler(logfile)
  else:
    fh = logging.FileHandler(defLog)
    
  fh.setFormatter(formatter)
  logger.addHandler(fh)
  
  if consoleHandler:
    consoleHandler = logging.StreamHandler()
    consoleHandler.setFormatter(formatter)
    logger.addHandler(consoleHandler)
    
  if level:
    level = logging.getLevelName(level)
    logger.setLevel(level)
  else:
    level = logging.getLevelName(defLevel)
    logger.setLevel(level)
  return logger

def get_logger(name=None):
    default = "__app__"
    formatter = logging.Formatter('%(levelname)s: %(asctime)s %(funcName)s(%(lineno)d) -- %(message)s',
                              datefmt='%Y-%m-%d %H:%M:%S')
    log_map = {"__app__": "app.log", "__basic_log__": "file1.log", "__advance_log__": "file2.log"}
    if name:
      logger = logging.getLogger(name)
      fh = logging.FileHandler(log_map[name])
    else:
      logger = logging.getLogger(default)
      fh = logging.FileHandler(log_map[default])
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    logger.setLevel(logging.DEBUG)
    return logger
    
