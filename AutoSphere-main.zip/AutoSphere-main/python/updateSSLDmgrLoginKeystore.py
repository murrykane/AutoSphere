#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 09/01/2017 Murry Kane     Initial version
#                           This program will update the DMGR login keystore to a Verisign
#                           certificate that will need to be updated periodically 
# 12/04/2017 Murry Kane     Wrote to work on Windows
# 03/18/2018 Murry Kane     Added logic to call new method to deterine if username/password needs
#                           to be sent to all IBM scripts based on IBM Security Enabled or not
#
#_________________________________________________________________________________________________
#

import shlex, subprocess, sys, platform, ConfigParser, os, log_message, getpass, getopt, ast, json, commands, time, socket
from datetime import datetime
from constants import *
from init_websphere import *
from os import environ

def windowsLogic(IHSresultSet, WASresultSet, log_msg, localhost, StepAction, wsadminpath, date_fmt):

  log_msg.info("Starting Windows logic for backup and replace of Keystores....") 
  if len(IHSresultSet) > 0 and StepAction != 'CSR':
    log_msg.info("Working on IHS serves to backup the IHS Plugin file on each Web Server with PowerShell")
    for nodename, hostname, binPath, port, dmgrHost, certPath, pluginFile in IHSresultSet:
      log_msg.info("_____________________________________________________________________________________________________")
      log_msg.info("IHS - NodeName %s HostName %s Path %s Port %s DMGR Host %s CertPath %s Plugin File %s Working on SCP..." % (nodename, hostname, binPath, port, dmgrHost, certPath, pluginFile))
      cellName = certPath.split('/')[2]
      nodeName = certPath.split('/')[4]
      serverName = certPath.split('/')[6]
      hostip = socket.gethostbyname_ex(hostname)[2][0]
      log_msg.info("Socket lookup by Name [%s] resolved to [%s]" % (hostname, hostip))
      nodenameHost = os.popen('nslookup %s' % hostip ).read().split("Name:")[1].strip().split(".")[0].upper()
    
      log_msg.info("CellName %s nodeName %s ServerName %s derived from CertPath %s" % (cellName, nodeName, serverName, certPath))
      fullCertPath = str(certPath.replace("\\", "/").replace("${CONFIG_ROOT}", "%s/config" % wsadminpath))
      fullPluginPath = str(pluginFile.replace("\\", "/").replace("${CONFIG_ROOT}", "%s/config" % wsadminpath))
      log_msg.info("Full certificate path is %s with Web Server Plugin file %s" % (fullCertPath, fullPluginPath))
      certPathRoot, certFile = fullCertPath.split(":")
      pluginPathRoot, pluginFile = fullPluginPath.split(":")
      log_msg.info("Root for Cert [%s] Path is [%s] Root for Plugin [%s] Path is [%s]" % (certPathRoot, certFile, pluginPathRoot, pluginFile))
      #nodenameHost = os.popen('nslookup %s' % hostname ).read().split("Name:")[1].strip().split(".")[0].upper()
      log_msg.info("NodeName is %s with local host name %s" % (nodenameHost, localhost))        
      pluginCopyFile = '//%s%s$%s' % (localhost, pluginPathRoot, pluginFile)
      pluginBackupFile = '//%s%s$%s.%s' % (localhost, pluginPathRoot, pluginFile, date_fmt)
      log_msg.info("Copy file [%s] Backup file [%s]" % (pluginCopyFile, pluginBackupFile))
      #now lets make the backup...
      cmd = ["powershell.exe","Copy-Item", "-Path", "%s" % pluginCopyFile, "-Destination", "%s" % pluginBackupFile, "-Force", "-PassThru", "-Verbose"]
      log_msg.debug("Issueing the following: [%s]" % cmd)
      sshexit_code = 0
      sshargs = cmd
      sshprocess = subprocess.Popen(sshargs,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
      sshoutput, ssherror = sshprocess.communicate()
      sshexit_code = sshprocess.wait()
      if sshexit_code > 0:
        if sshoutput:
          log_msg.error("ERROR OUTPUT: \n[%s]" % sshoutput)
          log_msg.error("ERROR: the command received rc: %s error message:(IGNORE ulimit line)\n[%s]" % (sshexit_code, ssherror))
          sys.exit(sshexit_code)
      if sshoutput:
        log_msg.info("Output from CMD on %s is:\n[%s]" % (hostname, sshoutput))
      else:
        #log_msg.info("Susccesfully submitted command for %s" % nodenameHost)     
        log_msg.info("Susccesfully submitted command for %s" % hostname)  
      
      #now copy the local file to remote server..... 
      if nodenameHost == localhost and 'DMGR' in nodename.upper():
        log_msg.info("Ignoring local host %s as its already been completed on the DMGR" % localhost)
      else:      
        pluginCopyFile = '//%s%s$%s' % (nodenameHost, pluginPathRoot, pluginFile)
        localpluginFile = '//%s%s$%s' % (localhost, pluginPathRoot, pluginFile)
        log_msg.info("Local file [%s] remote file [%s]" % (localpluginFile, pluginCopyFile))
        #now lets make the backup...
        cmd = ["powershell.exe","Copy-Item", "-Path", "%s" % localpluginFile, "-Destination", "%s" % pluginCopyFile, "-Force", "-PassThru", "-Verbose"]
        log_msg.debug("Issueing the following: [%s]" % cmd)
        sshexit_code = 0
        sshargs = cmd
        sshprocess = subprocess.Popen(sshargs,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
        sshoutput, ssherror = sshprocess.communicate()
        sshexit_code = sshprocess.wait()
        if sshexit_code > 0:
          if sshoutput:
            log_msg.error("ERROR OUTPUT: \n[%s]" % sshoutput)
            log_msg.error("ERROR: the command received rc: %s error message:(IGNORE ulimit line)\n[%s]" % (sshexit_code, ssherror))
            sys.exit(sshexit_code)
        if sshoutput:
          log_msg.info("Output from CMD on %s is:\n[%s]" % (hostname, sshoutput))
        else:
          #log_msg.info("Susccesfully submitted command for %s" % nodenameHost) 
          log_msg.info("Susccesfully submitted command for %s" % hostname)  
          
  #####
  # now lets do application servers
  #####
  if len(WASresultSet) > 0 and StepAction != 'CSR':
    log_msg.info("Working on Application serves to backup the Keystore's for just the DMGR")
    for nodename, hostname, binPath, port, dmgrHost, keyPath, trustPath in WASresultSet: 
      log_msg.info("_____________________________________________________________________________________________________")    
      log_msg.info("NodeName %s HostName %s Path %s Port %s DMGR Host %s KeyPath %s TrustPath %s" % (nodename, hostname, binPath, port, dmgrHost, keyPath, trustPath))
      # lets get some info from certPath
      hostip = socket.gethostbyname_ex(hostname)[2][0]
      log_msg.info("Socket lookup by Name [%s] resolved to [%s]" % (hostname, hostip))
      nodenameHost = os.popen('nslookup %s' % hostip ).read().split("Name:")[1].strip().split(".")[0].upper()
      #nodenameHost = os.popen('nslookup %s' % hostname ).read().split("Name:")[1].strip().split(".")[0].upper()
      log_msg.info("Cluster HostName(cname) is [%s] with NSLOOKUP host name [%s] running on host [%s]" % (hostname, nodenameHost, localhost))  
      
      fullCertKeyPath = str(keyPath.replace("\\", "/").replace("${CONFIG_ROOT}", "%s/config" % wsadminpath))
      fullCertTrustPath = str(trustPath.replace("\\", "/").replace("${CONFIG_ROOT}", "%s/config" % wsadminpath))
      log_msg.info("Full certificate path for CellDefaultKeyStore is [%s] and CellDefaultTrustStore is [%s]" % (fullCertKeyPath, fullCertTrustPath))
      #MBK before the scp we need to backup the file on the local DMGR
      # 
      sav_file="%s.%s" % (fullCertKeyPath, date_fmt)
      log_msg.debug("Copy File [%s] SAV File [%s]" % (fullCertKeyPath, sav_file))
      #cmd = 'cp %s %s' % (fullCertKeyPath, sav_file)
      cmd = ["powershell.exe","Copy-Item", "-Path", r'%s' % fullCertKeyPath, "-Destination", r'%s' % sav_file, "-Force", "-PassThru", "-Verbose"]
      log_msg.info("Issuing: %s" % (cmd))
      sshexit_code = 0
      sshargs = cmd
      sshprocess = subprocess.Popen(sshargs,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
      sshoutput, ssherror = sshprocess.communicate()
      sshexit_code = sshprocess.wait()
      if sshexit_code > 0:
        if sshoutput:
          log_msg.error("ERROR OUTPUT: \n[%s]" % sshoutput)
          log_msg.error("ERROR: the command received rc: %s error message:(IGNORE ulimit line)\n[%s]" % (sshexit_code, ssherror))
          sys.exit(sshexit_code)
      if sshoutput:
        log_msg.info("Output from CMD on %s is:\n[%s]" % (hostname, sshoutput))
      else:
        #log_msg.info("Susccesfully submitted command for %s" % nodenameHost) 
        log_msg.info("Susccesfully submitted command for %s" % hostname)  
     
      sav_file="%s.%s" % (fullCertTrustPath, date_fmt)
      log_msg.debug("Copy File [%s] SAV File [%s]" % (fullCertTrustPath, sav_file))
      #cmd = 'cp %s %s' % (fullCertTrustPath, sav_file)
      cmd = ["powershell.exe","Copy-Item", "-Path", "%s" % fullCertTrustPath, "-Destination", "%s" % sav_file, "-Force", "-PassThru", "-Verbose"]
      log_msg.info("Issuing: %s" % (cmd))

      sshexit_code = 0
      sshargs = cmd
      sshprocess = subprocess.Popen(sshargs,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
      sshoutput, ssherror = sshprocess.communicate()
      sshexit_code = sshprocess.wait()
      if sshexit_code > 0:
        if sshoutput:
          log_msg.error("ERROR OUTPUT: \n[%s]" % sshoutput)
          log_msg.error("ERROR: the command received rc: %s error message:(IGNORE ulimit line)\n[%s]" % (sshexit_code, ssherror))
          sys.exit(sshexit_code)
      if sshoutput:
        log_msg.info("Output from CMD on %s is:\n[%s]" % (hostname, sshoutput))
      else:
        #log_msg.info("Susccesfully submitted command for %s" % nodenameHost) 
        log_msg.info("Susccesfully submitted command for %s" % hostname)  
      ###################################################################
      # we only need to do the above for loop 1 time, thus need to break....          
      break
      
  # now copy file to each application server
  if len(WASresultSet) > 0 and StepAction != 'CSR':
    log_msg.info("Working on Application serves to backup the Keystore's and SCP to each Application Node")
    for nodename, hostname, binPath, port, dmgrHost, keyPath, trustPath in WASresultSet: 
      log_msg.info("NodeName %s HostName %s Path %s Port %s DMGR Host %s KeyPath %s TrustPath %s" % (nodename, hostname, binPath, port, dmgrHost, keyPath, trustPath)) 
      hostip = socket.gethostbyname_ex(hostname)[2][0]
      log_msg.info("Socket lookup by Name [%s] resolved to [%s]" % (hostname, hostip))
      nodenameHost = os.popen('nslookup %s' % hostip ).read().split("Name:")[1].strip().split(".")[0].upper()      
      #nodenameHost = os.popen('nslookup %s' % hostname ).read().split("Name:")[1].strip().split(".")[0].upper()
      #log_msg.info("NodeName is %s with local host name %s" % (nodenameHost, localhost))  
      log_msg.info("Cluster HostName(cname) is [%s] with NSLOOKUP host name [%s] running on host [%s]" % (hostname, nodenameHost, localhost))  
      if nodenameHost == localhost and 'DMGR' in nodename.upper():
        log_msg.info("Ignoring local host %s as its already been completed on the DMGR" % localhost)
      else:       
        fullCertKeyPath = str(keyPath.replace("${CONFIG_ROOT}", "%s/config" % binPath).replace("\\", "/"))
        fullCertTrustPath = str(trustPath.replace("${CONFIG_ROOT}", "%s/config" % binPath).replace("\\", "/"))
        localfullCertKeyPath = str(keyPath.replace("${CONFIG_ROOT}", "%s/config" % wsadminpath).replace("\\", "/"))
        localfullCertTrustPath = str(trustPath.replace("${CONFIG_ROOT}", "%s/config" % wsadminpath).replace("\\", "/"))
        log_msg.info("Full certificate path for Destination (CellDefaultKeyStore is [%s] and CellDefaultTrustStore is [%s]) Local (CellDefaultKeyStore is [%s] and CellDefaultTrustStore is [%s])" % (fullCertKeyPath, fullCertTrustPath, localfullCertKeyPath, localfullCertTrustPath))
        #need to backup file on remote server then copy current file to remote server for key and trust .p12's
        keyPathRoot, keyFile = fullCertKeyPath.split(":")
        trustPathRoot, trustFile = fullCertTrustPath.split(":")
        localkeyPathRoot, localkeyFile = localfullCertKeyPath.split(":")
        localtrustPathRoot, localtrustFile = localfullCertTrustPath.split(":")
        log_msg.info("Destination (Root for Key [%s] Path is [%s] Root for Trust [%s] Path is [%s]) Local (Root for Key [%s] Path is [%s] Root for Trust [%s] Path is [%s])" % (keyPathRoot, keyFile, trustPathRoot, trustFile, localkeyPathRoot, localkeyFile, localtrustPathRoot, localtrustFile))
        #nodenameHost = os.popen('nslookup %s' % hostname ).read().split("Name:")[1].strip().split(".")[0].upper()
        #log_msg.info("NodeName is %s with local host name %s" % (nodenameHost, localhost)) 
        #keyCopyFile = '\\%s\%s%s' % (nodenameHost, keyPathRoot, keyFile)
        #keyBackupFile = '\\%s\%s%s.%s' % (nodenameHost, keyPathRoot, keyFile, date_fmt)        
        keyCopyFile = '//%s/%s$%s' % (nodenameHost, keyPathRoot, keyFile)
        keyBackupFile = '//%s/%s$%s.%s' % (nodenameHost, keyPathRoot, keyFile, date_fmt)
        log_msg.info("Copy file [%s] Backup file [%s]" % (keyCopyFile, keyBackupFile)) 
        cmd = ["powershell.exe","Copy-Item", "-Path", r'%s' % keyCopyFile, "-Destination", r'%s' % keyBackupFile, "-Force", "-PassThru", "-Verbose"]
        log_msg.info("Issuing: %s" % (cmd))
        sshexit_code = 0
        sshargs = cmd
        sshprocess = subprocess.Popen(sshargs,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
        sshoutput, ssherror = sshprocess.communicate()
        sshexit_code = sshprocess.wait()
        if sshexit_code > 0:
          if sshoutput:
            log_msg.error("ERROR OUTPUT: \n[%s]" % sshoutput)
            log_msg.error("ERROR: the command received rc: %s error message:(IGNORE ulimit line)\n[%s]" % (sshexit_code, ssherror))
            sys.exit(sshexit_code)
        if sshoutput:
          log_msg.info("Output from CMD on %s is:\n[%s]" % (nodenameHost, sshoutput))
        else:
          #log_msg.info("Susccesfully submitted command for %s" % nodenameHost)
          log_msg.info("Susccesfully submitted command for %s" % nodenameHost)  
          
        #now the trust file       
        #trustCopyFile = '\\%s\%s%s' % (nodenameHost, trustPathRoot, trustFile)
        #trustBackupFile = '\\%s\%s%s.%s' % (nodenameHost, trustPathRoot, trustFile, date_fmt)
        trustCopyFile = '//%s/%s$%s' % (nodenameHost, trustPathRoot, trustFile)
        trustBackupFile = '//%s/%s$%s.%s' % (nodenameHost, trustPathRoot, trustFile, date_fmt)
        log_msg.info("Copy file [%s] Backup file [%s]" % (keyCopyFile, keyBackupFile)) 
        cmd = ["powershell.exe","Copy-Item", "-Path", "%s" % trustCopyFile, "-Destination", "%s" % trustBackupFile, "-Force", "-PassThru", "-Verbose"]
        log_msg.info("Issuing: %s" % (cmd))
        sshexit_code = 0
        sshargs = cmd
        sshprocess = subprocess.Popen(sshargs,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
        sshoutput, ssherror = sshprocess.communicate()
        sshexit_code = sshprocess.wait()
        if sshexit_code > 0:
          if sshoutput:
            log_msg.error("ERROR OUTPUT: \n[%s]" % sshoutput)
            log_msg.error("ERROR: the command received rc: %s error message:(IGNORE ulimit line)\n[%s]" % (sshexit_code, ssherror))
            sys.exit(sshexit_code)
        if sshoutput:
          log_msg.info("Output from CMD on %s is:\n[%s]" % (nodenameHost, sshoutput))
        else:
          #log_msg.info("Susccesfully submitted command for %s" % nodenameHost)
          log_msg.info("Susccesfully submitted command for %s" % nodenameHost)  
        localKeyFile = '//%s/%s$%s' % (localhost, localkeyPathRoot, localkeyFile)
        localTrustFile = '//%s/%s$%s' % (localhost, localtrustPathRoot, localtrustFile)
        cmd = ["powershell.exe","Copy-Item", "-Path", "%s" % localKeyFile, "-Destination", "%s" % keyCopyFile, "-Force", "-PassThru", "-Verbose"]
        log_msg.info("Issuing: %s" % (cmd))
        sshexit_code = 0
        sshargs = cmd
        sshprocess = subprocess.Popen(sshargs,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
        sshoutput, ssherror = sshprocess.communicate()
        sshexit_code = sshprocess.wait()
        if sshexit_code > 0:
          if sshoutput:
            log_msg.error("ERROR OUTPUT: \n[%s]" % sshoutput)
            log_msg.error("ERROR: the command received rc: %s error message:(IGNORE ulimit line)\n[%s]" % (sshexit_code, ssherror))
            sys.exit(sshexit_code)
        if sshoutput:
          log_msg.info("Output from CMD on %s is:\n[%s]" % (nodenameHost, sshoutput))
        else:
          #log_msg.info("Susccesfully submitted command for %s" % nodenameHost)
          log_msg.info("Susccesfully submitted command for %s" % nodenameHost)  
        cmd = ["powershell.exe","Copy-Item", "-Path", "%s" % localTrustFile, "-Destination", "%s" % trustCopyFile, "-Force", "-PassThru", "-Verbose"]
        log_msg.info("Issuing: %s" % (cmd))
        sshexit_code = 0
        sshargs = cmd
        sshprocess = subprocess.Popen(sshargs,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
        sshoutput, ssherror = sshprocess.communicate()
        sshexit_code = sshprocess.wait()
        if sshexit_code > 0:
          if sshoutput:
            log_msg.error("ERROR OUTPUT: \n[%s]" % sshoutput)
            log_msg.error("ERROR: the command received rc: %s error message:(IGNORE ulimit line)\n[%s]" % (sshexit_code, ssherror))
            sys.exit(sshexit_code)
        if sshoutput:
          log_msg.info("Output from CMD on %s is:\n[%s]" % (nodenameHost, sshoutput))
        else:
          #log_msg.info("Susccesfully submitted command for %s" % nodenameHost)
          log_msg.info("Susccesfully submitted command for %s" % nodenameHost)  
          
def linuxLogic(IHSresultSet, WASresultSet, log_msg, localhost, StepAction, wsadminpath, date_fmt):
  if len(IHSresultSet) > 0 and StepAction != 'CSR':
    log_msg.info("Working on IHS serves to backup the IHS Plugin file and SCP to each Web Server")
    for nodename, hostname, binPath, port, dmgrHost, certPath, pluginFile in IHSresultSet:
      log_msg.info("_____________________________________________________________________________________________________")
      log_msg.info("IHS - NodeName %s HostName %s Path %s Port %s DMGR Host %s CertPath %s Plugin File %s Working on SCP..." % (nodename, hostname, binPath, port, dmgrHost, certPath, pluginFile))
      # lets get some info from certPath
      cellName = certPath.split('/')[2]
      nodeName = certPath.split('/')[4]
      serverName = certPath.split('/')[6]
      log_msg.info("CellName %s nodeName %s ServerName %s derived from CertPath %s" % (cellName, nodeName, serverName, certPath))
      fullCertPath = certPath.replace("${CONFIG_ROOT}", "%s/config" % wsadminpath)
      log_msg.info("Full certificate path is %s with Web Server Plugin file %s" % (fullCertPath, pluginFile))
      #MBK before the scp we need to backup the file on the web server!
      sav_file="%s.%s" % (pluginFile, date_fmt)
      log_msg.debug("SCP File [%s] Remote File to backup [%s] Backup Name [%s]" % (fullCertPath, pluginFile, sav_file))
    
      cmd = 'cp %s %s' % (pluginFile, sav_file)
      log_msg.info("Issuing: 'ssh %s %s'" % (hostname, cmd))
      rc,output = commands.getstatusoutput('ssh %s %s' % (hostname, cmd))
      if rc > 0:
        log_msg.error("ERROR: Backup of the original Plugin file [%s] could not be completed with error: [%s], exiting!" % (fullCertPath, output))
        #sys.exit(33) 

      ssherror, sshCmd, sshargs, sshprocess, sshoutput = ('','','','','')
      # lets determine if its local host or not
      #nodenameHost = os.popen('nslookup %s' % hostname ).read().splitlines()[4].split("\t")[1].split(".")[0].upper()
      nodenameHost = os.popen('nslookup %s' % hostname ).read().split("Name:")[1].split("\t")[1].split(".")[0].upper()
      if nodenameHost == localhost:
        log_msg.info("Ignoring local host %s" % localhost)
      else:
        sshCmd = 'scp %s %s:%s' % (fullCertPath, hostname, pluginFile)  
      log_msg.debug("Issueing the following: [%s]" % sshCmd)
      sshexit_code = 0
      sshCmd_logging = ''
      sshargs = shlex.split(sshCmd)
      sshprocess = subprocess.Popen(sshargs,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
      sshoutput, ssherror = sshprocess.communicate()
      sshexit_code = sshprocess.wait()
      if sshexit_code > 0:
        if sshoutput:
          log_msg.error("ERROR OUTPUT: \n[%s]" % sshoutput)
          log_msg.error("ERROR: SCP command received rc: %s error message:(IGNORE ulimit line)\n[%s]" % (sshexit_code, ssherror))
          sys.exit(sshexit_code)
      if sshoutput:
        log_msg.info("Output from SCP on %s is:\n[%s]" % (hostname, sshoutput))
      else:
        #log_msg.info("Susccesfully submitted command for %s" % hostname)
        log_msg.info("Susccesfully submitted command for %s" % nodenameHost)  
      #MBK add logic to recycle web server......
      sshCmd = 'ssh %s nohup sudo /sbin/service websrvr_init restart > /dev/null 2>&1 & disown' % (hostname)  
      sshCmd_logging = 'ssh %s nohup sudo /sbin/service websrvr_init restart > /dev/null 2>&1 & disown' % (hostname)  
      log_msg.debug("Issueing the following: [%s]" % sshCmd_logging)
      sshexit_code = 0
      sshargs = shlex.split(sshCmd)
      sshprocess = subprocess.Popen(sshargs,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
      sshoutput, ssherror = sshprocess.communicate()
      sshexit_code = sshprocess.wait()
      if sshexit_code > 0:
        if sshoutput:
          log_msg.error("ERROR OUTPUT: \n[%s]" % sshoutput)
          log_msg.error("ERROR: SSH command received rc: %s error message:(IGNORE ulimit line)\n[%s]" % (sshexit_code, ssherror))
          #sys.exit(sshexit_code)
      if sshoutput:
        log_msg.info("Output from SSH on %s is:\n[%s]" % (hostname, sshoutput))
      else:
        #log_msg.info("Susccesfully submitted command for %s" % hostname) 
        log_msg.info("Susccesfully submitted command for %s" % nodenameHost)  
  else:
    log_msg.info("No IHS nodes with [%i] to do OR StepAction = %s!" % (len(IHSresultSet), StepAction))
  
  if len(IHSresultSet) > 0 and StepAction != 'CSR':
    log_msg.info("_____________________________________________________________________________________________________") 
  
  #Process all Application Servers
  if len(WASresultSet) > 0 and StepAction != 'CSR':
    log_msg.info("Working on Application serves to backup the Keystore's and SCP to each Application Node")
    for nodename, hostname, binPath, port, dmgrHost, keyPath, trustPath in WASresultSet:  
      # lets get some info from certPath
      fullCertKeyPath = keyPath.replace("${CONFIG_ROOT}", "%s/config" % wsadminpath)
      fullCertTrustPath = trustPath.replace("${CONFIG_ROOT}", "%s/config" % wsadminpath)
      log_msg.info("Full certificate path for CellDefaultKeyStore is [%s] and CellDefaultTrustStore is [%s]" % (fullCertKeyPath, fullCertTrustPath))
      #MBK before the scp we need to backup the file on the web server!
      # 
      sav_file="%s.%s" % (fullCertKeyPath, date_fmt)
      log_msg.debug("Copy File [%s] SAV File [%s]" % (fullCertKeyPath, sav_file))
      cmd = 'cp %s %s' % (fullCertKeyPath, sav_file)
      log_msg.info("Issuing: %s" % (cmd))
      rc,output = commands.getstatusoutput(cmd)
      if rc > 0:
        log_msg.error("ERROR: Backup of the original Plugin file [%s] could not be completed with error: [%s], exiting!" % (fullCertKeyPath, output))
        #sys.exit(33) 
        
      sav_file="%s.%s" % (fullCertTrustPath, date_fmt)
      log_msg.debug("Copy File [%s] SAV File [%s]" % (fullCertTrustPath, sav_file))
      cmd = 'cp %s %s' % (fullCertTrustPath, sav_file)
      log_msg.info("Issuing: %s" % (cmd))
      rc,output = commands.getstatusoutput(cmd)
      if rc > 0:
        log_msg.error("ERROR: Backup of the original Plugin file [%s] could not be completed with error: [%s], exiting!" % (fullCertTrustPath, output))
        #sys.exit(33)    
      ###################################################################
      # we only need to do the above for loop 1 time, thus need to break....
      break
    
    # backup and copy to each node in the cluster (app servers only) 
    log_msg.info("Working on backups of the remote servers files for the Keystores")    
    for nodename, hostname, binPath, port, dmgrHost, keyPath, trustPath in WASresultSet:
      log_msg.info("_____________________________________________________________________________________________________") 
      # lets get some info from certPath
      log_msg.info("WAS Node - NodeName %s HostName %s Path %s Port %s DMGR Host %s KeyP12 %s TrustP12 %s" % (nodename, hostname, binPath, port, dmgrHost, keyPath, trustPath))
      fullCertKeyPath = keyPath.replace("${CONFIG_ROOT}", "%s/config" % wsadminpath)
      fullCertTrustPath = trustPath.replace("${CONFIG_ROOT}", "%s/config" % wsadminpath)
      log_msg.info("Full certificate path for CellDefaultKeyStore is [%s] and CellDefaultTrustStore is [%s]" % (fullCertKeyPath, fullCertTrustPath))
      
      #first make a backup on the remote server node cert files
      in_file_key = "%s/etc/%s" % (binPath, keyPath.split('/')[-1])
      sav_file = "%s.%s" % ( in_file_key, date_fmt)        
      cmd = 'cp %s %s' % (in_file_key, sav_file)
      log_msg.info("Issuing: 'ssh %s %s'" % (hostname, cmd))
      rc,output = commands.getstatusoutput('ssh %s %s' % (hostname, cmd))
      if rc > 0:
        log_msg.error("Backup of the original Keystore file [%s] could not be completed with error: [%s], exiting!" % (in_file_key, output))
        #sys.exit(33) 
      in_file_trust = "%s/etc/%s" % (binPath, trustPath.split('/')[-1])
      sav_file = "%s.%s" % ( in_file_trust, date_fmt)        
      cmd = 'cp %s %s' % (in_file_trust, sav_file)
      log_msg.info("Issuing: 'ssh %s %s'" % (hostname, cmd))
      rc,output = commands.getstatusoutput('ssh %s %s' % (hostname, cmd))
      if rc > 0:
        log_msg.error("Backup of the original Keystore file [%s] could not be completed with error: [%s], exiting!" % (in_file_trust, output))
        #sys.exit(33) 
        
      #now SCP to each node....        
      ssherror, sshCmd, sshargs, sshprocess, sshoutput = ('','','','','')
      # lets determine if its local host or not
      #nodenameHost = os.popen('nslookup %s' % hostname ).read().splitlines()[4].split("\t")[1].split(".")[0].upper()
      nodenameHost = os.popen('nslookup %s' % hostname ).read().split("Name:")[1].split("\t")[1].split(".")[0].upper()
      if nodenameHost == localhost:
        log_msg.info("Ignoring local host %s" % localhost)
      else:
        sshCmd = 'scp %s %s:%s' % (fullCertKeyPath, hostname, in_file_key)  
      log_msg.debug("Issueing the following: [%s]" % sshCmd)
      sshexit_code = 0
      sshCmd_logging = ''
      sshargs = shlex.split(sshCmd)
      sshprocess = subprocess.Popen(sshargs,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
      sshoutput, ssherror = sshprocess.communicate()
      sshexit_code = sshprocess.wait()
      if sshexit_code > 0:
        if sshoutput:
          log_msg.error("ERROR OUTPUT: \n[%s]" % sshoutput)
          log_msg.error("ERROR: SCP command received rc: %s error message:(IGNORE ulimit line)\n[%s]" % (sshexit_code, ssherror))
          sys.exit(sshexit_code)
      if sshoutput:
        log_msg.info("Output from SCP on %s is:\n[%s]" % (hostname, sshoutput))
      else:
        #log_msg.info("Susccesfully submitted command for %s" % hostname)
        log_msg.info("Susccesfully submitted command for %s" % nodenameHost)  

      if nodenameHost == localhost:
        log_msg.info("Ignoring local host %s" % localhost)
      else:
        sshCmd = 'scp %s %s:%s' % (fullCertTrustPath, hostname, in_file_trust)  
      log_msg.debug("Issueing the following: [%s]" % sshCmd)
      sshexit_code = 0
      sshCmd_logging = ''
      sshargs = shlex.split(sshCmd)
      sshprocess = subprocess.Popen(sshargs,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
      sshoutput, ssherror = sshprocess.communicate()
      sshexit_code = sshprocess.wait()
      if sshexit_code > 0:
        if sshoutput:
          log_msg.error("ERROR OUTPUT: \n[%s]" % sshoutput)
          log_msg.error("ERROR: SCP command received rc: %s error message:(IGNORE ulimit line)\n[%s]" % (sshexit_code, ssherror))
          sys.exit(sshexit_code)
      if sshoutput:
        log_msg.info("Output from SCP on %s is:\n[%s]" % (hostname, sshoutput))
      else:
        #log_msg.info("Susccesfully submitted command for %s" % hostname)
        log_msg.info("Susccesfully submitted command for %s" % nodenameHost)  
    
    log_msg.info("_____________________________________________________________________________________________________") 
    
    """
    ###
    ### Removed this block to use existing scripts as well as stop/start DMGR
    ###
    log_msg.info("Need a stopNode.sh for each application server now....")
    
    #sync nodes now needed for each node in cluster
    for nodename, hostname, binPath, port, dmgrHost, keyPath, trustPath in WASresultSet:
      log_msg.info("_____________________________________________________________________________________________________")    
      if nodenameHost == localhost:
        log_msg.info("Ignoring local host %s for stopNode.sh command" % localhost)
      else:  
        sshCmd = 'ssh %s nohup %s/bin/stopNode.sh -username %s -password \'%s\' >> %s/logs/stopNode.log 2>&1 & disown' % (hostname, binPath, username, password, binPath)  
        sshCmd_logging = 'ssh %s nohup %s/bin/stopNode.sh -username %s -password \'%s\' >> %s/logs/stopNode.log 2>&1 & disown' % (hostname, binPath, username, 'XXXXXXXX', binPath)   
        log_msg.debug("Issueing the following: [%s]" % sshCmd_logging)
        sshexit_code = 0
        sshargs = shlex.split(sshCmd)
        sshprocess = subprocess.Popen(sshargs,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
        sshoutput, ssherror = sshprocess.communicate()
        sshexit_code = sshprocess.wait()
        if sshexit_code > 0:
          if sshoutput:
            log_msg.error("ERROR OUTPUT: \n[%s]" % sshoutput)
            log_msg.error("ERROR: SSH command received rc: %s error message:(IGNORE ulimit line)\n[%s]" % (sshexit_code, ssherror))
            #sys.exit(sshexit_code)
        if sshoutput:
          log_msg.info("Output from SSH on %s is:\n[%s]" % (hostname, sshoutput))
        else:
          log_msg.info("Susccesfully submitted command for %s" % hostname)
    
    log_msg.info("Sleeping for [%s]...." % (sleepTimeBetweenServers))
    time.sleep(sleepTimeBetweenServers)
    log_msg.info("Need a syncNode.sh for each application server now....")
    
    #sync nodes now needed for each node in cluster
    for nodename, hostname, binPath, port, dmgrHost, keyPath, trustPath in WASresultSet:
      log_msg.info("_____________________________________________________________________________________________________")    
      if nodenameHost == localhost:
        log_msg.info("Ignoring local host %s for syncNode.sh command" % localhost)
      else:
        #sshCmd = 'ssh %s nohup %s/bin/syncNode.sh %s %s -stopservers -restart -username %s -password \'%s\' >> %s/logs/syncNode.log 2>&1 & disown' % (hostname, binPath, dmgrHost, port, username, password, binPath)  
        sshCmd = 'ssh %s nohup %s/bin/syncNode.sh %s %s -restart -username %s -password \'%s\' >> %s/logs/syncNode.log 2>&1 & disown' % (hostname, binPath, dmgrHost, port, username, password, binPath)  
        sshCmd_logging = 'ssh %s nohup %s/bin/syncNode.sh %s %s -restart -username %s -password \'%s\' >> %s/logs/syncNode.log 2>&1 & disown' % (hostname, binPath, dmgrHost, port, username, 'XXXXXXXX', binPath)  
        log_msg.debug("Issueing the following: [%s]" % sshCmd_logging)
        sshexit_code = 0
        sshargs = shlex.split(sshCmd)
        sshprocess = subprocess.Popen(sshargs,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
        sshoutput, ssherror = sshprocess.communicate()
        sshexit_code = sshprocess.wait()
        if sshexit_code > 0:
          if sshoutput:
            log_msg.error("ERROR OUTPUT: \n[%s]" % sshoutput)
            log_msg.error("ERROR: SSH command received rc: %s error message:(IGNORE ulimit line)\n[%s]" % (sshexit_code, ssherror))
            #sys.exit(sshexit_code)
        if sshoutput:
          log_msg.info("Output from SSH on %s is:\n[%s]" % (hostname, sshoutput))
        else:
          log_msg.info("Susccesfully submitted command for %s" % hostname) 
    """
    
  else:
    log_msg.info("No Application Nodes with [%i] to do OR StepAction = %s!" % (len(WASresultSet), StepAction))
  
  if len(WASresultSet) > 0 and StepAction != 'CSR':
    log_msg.info("_____________________________________________________________________________________________________") 

  
def usage():
  print "Usage: %s --CellDefaultKeyStore=<value> --CellDefaultTrustStore=<value> --signatureAlgorithm=<value> --certRequestAlias=<value> --certSize=<value> --certCommonName=<value> --certOrg=<value> --certOrgUnit=<value> --certLocale=<value> --certState=<value> --certZip=<value> --certCountry=<value) --certificateRequestFilePath=<value> --certificateAliasList2=<value> --receiveCertPath=<value> --base64Encoded=<value> --replacecertAlias=<value> --deleteOldCert=<value> --deleteSigners=<value> --CMSKeyStore=<value> --SkipJythonChanges=<value> --StepAction=<value>" % sys.argv[0]
  print 'Example: %s --CellDefaultKeyStore=CellDefaultKeyStore --CellDefaultTrustStore=CellDefaultTrustStore --signatureAlgorithm=SHA256withRSA --certRequestAlias=Dmgr_WEBN208 --certSize=2048 --certCommonName=dm1.webn208.blueshieldcloud.net --certOrg="Blue Shield of California" --certOrgUnit=IT --certLocale="El Dorado Hills" --certState=California --certZip=95762 --certCountry=US --certificateRequestFilePath=/tmp/dmgrkey.csr --certificateAliasList2=bscrootca2:bscissueca2 --receiveCertPath=/tmp/dm1.webn208.blueshieldcloud.net.cer --base64Encoded=True --replacecertAlias=default --deleteOldCert=True --deleteSigners=False --CMSKeyStore=CMSKeyStore --SkipJythonChanges=False --StepAction=CSR' % sys.argv[0]

if os.name != 'nt' and getpass.getuser() != 'websphr':
  print "You must run this as the effective user 'websphr', please try again as that user, exiting!"
  sys.exit(1)

def main():

  """
  # 1st action 
  #AdminTask.createCertificateRequest('[-keyStoreName CellDefaultKeyStore -keyStoreScope (cell):WEBN208Cell -certificateAlias Dmgr_WEBN208 -certificateSize 2048 -certificateCommonName dm1.webn208.blueshieldcloud.net -certificateOrganization "Blue Shield of California" -certificateOrganizationalUnit IT -certificateLocality "El Dorado Hills" -certificateState California -certificateZip 95762 -certificateCountry US -certificateRequestFilePath /tmp/dmgrkey.csr -signatureAlgorithm SHA256withRSA ]')
  #AdminTask.getCertificate('[-keyStoreName CellDefaultKeyStore -keyStoreScope (cell):NPIN01Cell -certificateAlias Dmgr_WEBN208 ]')
  
  #1st exchange
  # AdminTask.exchangeSigners('[-keyStoreName1 CellDefaultKeyStore -keyStoreScope1 (cell):WEBN208Cell -keyStoreName2 CellDefaultTrustStore -keyStoreScope2 (cell):WEBN208Cell -certificateAliasList2 bscrootca2:bscissueca2 ]')
  #
  #receive certificate
  #AdminTask.receiveCertificate('[-certificateFilePath /tmp/dm1.webn208.blueshieldcloud.net.cer -base64Encoded True -keyStoreName CellDefaultKeyStore -keyStoreScope (cell):WEBN208Cell ]')
  #
  #deletePersonalCertDefault
  # AdminTask.replaceCertificate('[-certificateAlias default -replacementCertificateAlias dmgr_webn208 -deleteOldCert True -deleteSigners False -keyStoreName CellDefaultKeyStore -keyStoreScope (cell):WEBN208Cell ]')
  #
  # Update IHS Plugin
  # AdminTask.exchangeSigners('[-keyStoreName1 CMSKeyStore -keyStoreScope1 (cell):WEBN208Cell:(node):WEBN208WebNode01:(server):webn208-ws1 -keyStoreName2 CellDefaultTrustStore -keyStoreScope2 (cell):WEBN208Cell -certificateAliasList2 bscrootca2:bscissueca2 ]')
  #
  # Needed Cmd 1 - createCertificateRequest 
  #   CellDefaultKeyStore = CellDefaultKeyStore
  #   signatureAlgorithm = SHA256withRSA 
  #   certRequestAlias = Dmgr_WEBN208
  #   certSize = 2048 
  #   certCommonName = dm1.webn208.blueshieldcloud.net
  #   certOrg = Blue Shield of California
  #   certOrgUnit = IT
  #   certLocale = El Dorado Hills
  #   certState = California
  #   certZip = 95762
  #   certCountry = US
  #   certificateRequestFilePath = /tmp/dmgrkey.csr
  #
  # Needed Cmd 2 - Exchange Signers
  #   CellDefaultTrustStore = CellDefaultTrustStore
  #   certificateAliasList2 = bscrootca2:bscissueca2
  # 
  # Needed cmd 3 - receive Certificate 
  #   receiveCertPath = /tmp/dm1.webn208.blueshieldcloud.net.cer
  #   base64Encoded = True
  #  
  # Needed cmd 4 - replaceCertificate
  #   replacecertAlias = default
  #   newCertAlias = Dmgr_webn208  = certRequestAlias
  #   deleteOldCert = True
  #   deleteSigners = False
  #   
  # needed cmd 5 - IHS plugin update
  #   CMSKeyStore = CMSKeyStore
  # 
  #  --SkipJythonChanges = True - means we will call the jython program but skip any changes made i nthe script, thus only outputing needed arrays for future SCP's and keystore updates  (in case things need to be done manually in DMGR)
  #
  """
  
  CellDefaultKeyStore = ''
  signatureAlgorithm = ''
  certRequestAlias = ''
  certSize = ''
  certCommonName = ''
  certOrg = ''
  certOrgUnit = ''
  certLocale = ''
  certState = ''
  certZip = ''
  certCountry = ''
  certificateRequestFilePath = ''
  CellDefaultTrustStore = ''
  certificateAliasList2 = ''
  receiveCertPath = ''
  base64Encoded = ''
  replacecertAlias = ''
  newCertAlias = ''
  deleteOldCert = ''
  deleteSigners = ''
  CMSKeyStore = ''
  SkipJythonChanges = ''
  StepAction = ''

  
  try:
    opts, args = getopt.getopt(sys.argv[1:], 'a:b:c:d:e:f:g:h:i:j:k:l:m:n:o:p:q:r:s:t:u:v:w:x:', ['CellDefaultKeyStore=', 'CellDefaultTrustStore=', 'signatureAlgorithm=', 'certRequestAlias=', 'certSize=', 'certCommonName=', 'certOrg=', 'certOrgUnit=','certLocale=','certState=','certZip=','certCountry=', 'certificateRequestFilePath=', 'certificateAliasList2=', 'receiveCertPath=', 'base64Encoded=', 'replacecertAlias=', 'newCertAlias=', 'deleteOldCert=', 'deleteSigners=', 'CMSKeyStore=', 'SkipJythonChanges=', 'StepAction='])
  except getopt.GetoptError, err:
    print "exception in GETOPT with [%s]" % err
    usage()
    sys.exit(2)

  for opt, arg in opts:
    if opt in ( '-a', '--CellDefaultKeyStore'):
      CellDefaultKeyStore = arg
      #print "defined Cell Key store..."
    elif opt in ('-b', '--CellDefaultTrustStore'):
      CellDefaultTrustStore = arg
    elif opt in ('-c', '--signatureAlgorithm'):
      signatureAlgorithm = arg
    elif opt in ('-d', '--certRequestAlias'):
      certRequestAlias = arg
    elif opt in ('-e', '--certSize'):
      certSize = arg
    elif opt in ('-f', '--certCommonName'):
      certCommonName = arg
    elif opt in ('-g', '--certOrg'):
      certOrg = arg
      #print "cert org is %s" % certOrg
    elif opt in ('-h', '--certOrgUnit'):
      certOrgUnit = arg
    elif opt in ('-i', '--certLocale'):
      certLocale = arg
      #print "cert locale is %s " % certLocale
    elif opt in ('-j', '--certState'):
      certState = arg
    elif opt in ('-k', '--certZip'):
      certZip = arg
    elif opt in ('-l', '--certCountry'):
      certCountry = arg
    elif opt in ('-m', '--certificateRequestFilePath'):
      certificateRequestFilePath = arg
    elif opt in ('-n', '--certificateAliasList2'):
      certificateAliasList2 = arg
    elif opt in ('-o', '--receiveCertPath'):
      receiveCertPath = arg
    elif opt in ('-p', '--base64Encoded'):
      base64Encoded = arg
    elif opt in ('-q', '--replacecertAlias'):
      replacecertAlias = arg
#    elif opt in ('-r', '--newCertAlias'):
#      newCertAlias = arg
    elif opt in ('-s', '--deleteOldCert'):
      deleteOldCert = arg
    elif opt in ('-t', '--deleteSigners'):
      deleteSigners = arg
    elif opt in ('-u', '--CMSKeyStore'):
      CMSKeyStore = arg  
    elif opt in ('-v', '--SkipJythonChanges'):
      SkipJythonChanges = arg
      if SkipJythonChanges == 'True':
        SkipJythonChanges = True
      else:
        SkipJythonChanges = False
    elif opt in ('-x', '--StepAction'):
      StepAction = arg
    else:
      print "arg is %s and opt is %s" % (arg, opt)
      usage()
      sys.exit(3)
  
  newCertAlias = certRequestAlias.lower()
  StepAction = StepAction.upper()
  
  #validate args passed in are defined...
  if not CellDefaultKeyStore:
    print "CellDefaultKeyStore NOT passed"
    usage()
    sys.exit(4)
  if not CellDefaultTrustStore:
    print "CellDefaultTrustStore NOT passed"
    usage()
    sys.exit(5)
  if not signatureAlgorithm:
    print "signatureAlgorithm NOT passed"
    usage()
    sys.exit(6)
  if not certRequestAlias:
    print "certRequestAlias NOT passed"
    usage()
    sys.exit(7)
  if not certSize:
    print "certSize NOT passed"
    usage()
  if not certCommonName:
    print "certCommonName NOT passed"
    usage()
    sys.exit(8)
  if not certOrg:
    print "certOrg NOT passed"
    usage()
    sys.exit(9)
  if not certOrgUnit:
    print "certOrgUnit NOT passed"
    usage()
    sys.exit(10)
  if not certLocale:
    print "certLocale NOT passed"
    usage()
    sys.exit(11)
  if not certState:
    print "certState NOT passed"
    usage()
  if not certZip:
    print "certZip NOT passed"
    usage()
    sys.exit(12)
  if not certCountry:
    print "certCountry NOT passed"
    usage()
    sys.exit(13)
  if not certificateRequestFilePath:
    print "certificateRequestFilePath NOT passed"
    usage()
    sys.exit(14)
  if not certificateAliasList2:
    print "certificateAliasList2 NOT passed"
    usage()
    sys.exit(15)
  if not receiveCertPath:
    print "receiveCertPath NOT passed"
    usage()
    sys.exit(16)
  if not base64Encoded:
    print "base64Encoded NOT passed"
    usage()
    sys.exit(17)
  if not replacecertAlias:
    print "replacecertAlias NOT passed" 
    usage()
    sys.exit(18)
  if not newCertAlias:
    print "newCertAlias NOT passed"
    usage()
    sys.exit(19)
  if not deleteOldCert:
    print "deleteOldCert NOT passed"
    usage()
    sys.exit(20)
  if not deleteSigners:
    print "deleteSigners NOT passed"
    usage()
    sys.exit(21)
  if not StepAction:
    print "StepAction NOT passed"
    usage()
    sys.exit(22)
    
  #if not SkipJythonChanges:
  #  print "SkipJythonChanges NOT passed"
  #  usage()
  #  sys.exit(22)    

  #print "node %s cell %s keystore %s alias from file %s alias %s" % ( NodeDefaultSSLSettings, CellDefaultTrustStore, CustomKeyStore, certificateAliasFromKeyFile, certificateAlias )
  
  sleepTimeBetweenServers = 45
  #stopWaitTimeoutAppServers = 300
  pathname = os.path.dirname(sys.argv[0])        
  pathdir = os.path.abspath(pathname)
  localhost = platform.node().upper()
  currentscript = os.path.basename(os.path.splitext(__file__)[0])
  localhost = platform.node().upper()
  loglevel = 'DEBUG'
  date_fmt = datetime.now().strftime('%Y%m%d-%H%M')
  LOGFILE = '%s/%s_%s.log' % (LOG_DIR, currentscript, date_fmt)
  ignoreNodeList = ''
    
  log_msg = log_message.get_file_logger(currentscript, loglevel, LOGFILE, currentscript, True)
  log_msg.info("Starting program")
  #log_msg.info("node [%s] cell [%s] keystore [%s] alias from file [%s] alias [%s]" % ( NodeDefaultSSLSettings, CellDefaultTrustStore, CustomKeyStore, certificateAliasFromKeyFile, certificateAlias ))
  log_msg.info("ingore node list is %s" % ignoreNodeList)
  ignoreNodeList = "/".join(ignoreNodeList)
  log_msg.debug("ignore list as string is: %s" % ignoreNodeList)
  if len(ignoreNodeList) == 0:
    ignoreNodeList = '/'
    log_msg.debug("ignore node modified since its empty, list as string is: %s" % ignoreNodeList)
  thenodelist = ''   
  
  # lets output what was passed 
  log_msg.debug("CellDefaultKeyStore = %s" % (CellDefaultKeyStore))
  log_msg.debug("signatureAlgorithm =  %s" % (signatureAlgorithm))
  log_msg.debug("certRequestAlias =  %s" % (certRequestAlias))
  log_msg.debug("certSize =  %s" % (certSize))
  log_msg.debug("certCommonName =  %s" % (certCommonName))
  log_msg.debug("certOrg =  %s" % (certOrg))
  log_msg.debug("certOrgUnit =  %s" % (certOrgUnit))
  log_msg.debug("certLocale =  %s" % (certLocale))
  log_msg.debug("certState =  %s" % (certState))
  log_msg.debug("certZip =  %s" % (certZip))
  log_msg.debug("certCountry =  %s" % (certCountry))
  log_msg.debug("certificateRequestFilePath =  %s" % (certificateRequestFilePath)) 
  log_msg.debug("CellDefaultTrustStore =  %s" % (CellDefaultTrustStore))
  log_msg.debug("certificateAliasList2 =  %s" % (certificateAliasList2))
  log_msg.debug("receiveCertPath =  %s" % (receiveCertPath))
  log_msg.debug("base64Encoded =  %s" % (base64Encoded))
  log_msg.debug("replacecertAlias =  %s" % (replacecertAlias))
  log_msg.debug("newCertAlias =  %s" % (newCertAlias))
  log_msg.debug("deleteOldCert =  %s" % (deleteOldCert))
  log_msg.debug("deleteSigners = %s" % (deleteSigners))
  log_msg.debug("CMSKeyStore =  %s" % (CMSKeyStore))
  log_msg.debug("SkipJythonChanges =  %s" % (SkipJythonChanges))
  log_msg.debug("StepAction = %s" % (StepAction))
  
  # use manageprofiles.sh to get the WebSphere profiles on this server
  if getProfiles(profilesFile, log_msg):
    log_msg.info("Successfully got profiles for server")
  else:
    log_msg.error("ERROR: We could not get the profiles for this server, exiting!")
    sys.exit(14)
  
  #get the DMGR from the output above....
  xmlStr = ''
  aStr = ''
  temp = open(profilesFile,'r').readlines()
  for line in temp:   # there should only be 1 line....
    aStr = line.strip('\n\r[]') 
  log_msg.info("List of Profiles on server is [%s]" % aStr)
  if not aStr:
    #could not determine profiles on this system....
    log_msg.error("ERROR: We could not determine the WebSphere Profiles on this server, exiting!")
    sys.exit(15)
  
  #server may have one or more profiles, loop through them....
  profileList = aStr.split()
  for profile in profileList:
    if re.search('dmgr', profile, re.IGNORECASE):
      log_msg.info("Profile [%s] is a DMGR" % profile)
      """ 
        The following lines do not account for characters following the numeric characters matched in startNum.
        This can be an issue when we use the match to find a corresponding XML file 
        e.g. FACS02ACell.xml and FACS02BCell.xml both exist but the profile on the server is FACS02B.
          The regex would match only FACS02 so the first xml file match would be FACS02ACell.xml (i.e. not the one we want)
	re.split flags=re.IGNORECASE not supported in Python 2.6 - replaced with re.complie 
      """
      # startStr = " ".join(re.findall("[a-zA-Z]+", aStr)).split()[0]
      # startNum = " ".join(re.findall("[0-9]+", aStr)).split()[0]
      # xmlStr = '%s%s' % (startStr, startNum)
      #xmlStr = re.split('dmgr', profile, flags=re.IGNORECASE)[0]
      xmlStr = re.compile('dmgr', re.IGNORECASE).split(profile)[0]

      if len(xmlStr) < 5:
        log_msg.warn("The XML Search String [%s] is very small, which may lead to bad results!" % xmlStr)
      
  if not xmlStr:    
    log_msg.error("We could not determine if this server is a DMGR, exiting!")
    sys.exit(15)
    
  #xmlStr = serverStatusQuery('Starting tool with the ', 0, log_msg)
  log_msg.info("XML String to find files with is [%s]" % xmlStr)
  xmlString = "%s*.xml" % xmlStr
  jythonscript = '%s/%s.py' % (JYTHON_DIR, currentscript)
  
  XMLFile, username, encrypted_password, password, wsadminpath = getXMLFile(xmlString, log_msg) 
  wsadminfile = os.path.join(wsadminpath + os.sep, 'bin' + os.sep, 'wsadmin' + ext_name).replace("\\", "/")
  
  # lets validate all variables are defined
  #------------------------------------------
  if os.path.isfile(wsadminfile):
    log_msg.debug("Found the WSAdmin.sh with: [%s]" % wsadminfile)
  else:
    log_msg.error("Unable to find the WSAdmin script with: [%s], exiting!" % wsadminfile)
    sys.exit(10)    
  if os.path.isfile(jythonscript):
    log_msg.debug("Found the python script with: [%s]" % jythonscript)
  else:
    log_msg.error("Unable to find the jython script with: [%s], exiting!" % jythonscript)
    sys.exit(10)
  if os.path.isfile(XMLFile):
    log_msg.debug("Found the XML Property File with: [%s]" % XMLFile)
  else:
    log_msg.error("Unable to find the XML Property File with: [%s], exiting!" % XMLFile)
    sys.exit(10)
  if username:
    log_msg.debug("Found the user name to use with WSAdmin script with: [%s]" % username)
  else:
    log_msg.error("Unable to find the user name for WSAdmin script with: [%s], exiting!" % username)
    sys.exit(10)
  if encrypted_password:
    log_msg.debug("Obtained the encrypted password for WSAdmin script with: [%s]" % encrypted_password)
  else:
    log_msg.error("Unable to find the encrypted password for WSAdmin script with: [%s], exiting!" % encrypted_password)
    sys.exit(10)
  if password:
    log_msg.debug("Obtained the password for WSAdmin script with: [%s]" % 'XXXXXXXXXX')
  else:
    log_msg.error("Unable to find the password for WSAdmin script with: [%s], exiting!" % password)
    sys.exit(10) 
  ################################################################################################
  
  ################################################################################################
  # lets check if IBM security is set on this environment.....
  #
  IBMSecuritySet = False
  IBMSecuritySet = securityEnabledCheck(log_msg, wsadminpath)
  if IBMSecuritySet:
    if serverStatusWithNoPass(serverStatusOutFile, log_msg, wsadminpath):
      log_msg.debug("Successfully created the server status output file")
    else:
      log_msg.error("Could not determine status of the DMGR, exiting!")
      sys.exit(99) 
  else:      
    #make sure we are on a running DMGR to proceed....
    if serverStatusWithPass(serverStatusOutFile, username, password, log_msg, wsadminpath):
      log_msg.debug("Successfully created the server status output file")
    else:
      log_msg.error("Could not determine status of the DMGR, exiting!")
      sys.exit(99)
  
  #lets read the serverStatus output now....
  dFlag = False
  sfile = file(serverStatusOutFile)
  for line in sfile:
    if 'The Deployment Manager' in line:
      log_msg.debug("Found the following line in the ServerStatus output: [%s]" % line.strip())
      dFlag = True
      #get the last value to check if its 'STARTED'
      if line.rsplit(None, 1)[-1] == 'STARTED':
        log_msg.info("DMGR is running on this server, continue with script.....")
      else:
        log_msg.error("DMGR is NOT running, we can not continue with this script, please start the DMGR and run again!")
        sys.exit(45)
  # make sure its a DMGR
  if not dFlag:
    log_msg.error("This is not a DMGR server, and we can not run on this server, exiting!")
    sys.exit(55)

  WASresultSet = []  
  IHSresultSet = []  
  
  if SkipJythonChanges:
    log_msg.info("Skip Jython changes is set, and we will not change anything in WebSphere with this run")
  else:
    log_msg.info("Skip Jython changes is NOT set, we will update WebSphere on this run")
    
  if IBMSecuritySet:
    logging_cmd = '%s -lang jython -conntype SOAP -javaoption "-Dpython.path=%s" -f %s %s %s %s %s %s %s "%s" %s "%s" %s %s %s %s %s %s %s %s %s %s %s %s %s %s' % ( wsadminfile, PYTHONPATH, jythonscript, CellDefaultKeyStore, CellDefaultTrustStore, signatureAlgorithm, certRequestAlias, certSize, certCommonName, certOrg, certOrgUnit, certLocale, certState, certZip, certCountry, certificateRequestFilePath, certificateAliasList2, receiveCertPath, base64Encoded, replacecertAlias, newCertAlias, deleteOldCert, deleteSigners, CMSKeyStore, SkipJythonChanges, StepAction)
    cmd = '%s -lang jython -conntype SOAP -javaoption "-Dpython.path=%s" -f %s %s %s %s %s %s %s "%s" %s "%s" %s %s %s %s %s %s %s %s %s %s %s %s %s %s' % ( wsadminfile, PYTHONPATH, jythonscript, CellDefaultKeyStore, CellDefaultTrustStore, signatureAlgorithm, certRequestAlias, certSize, certCommonName, certOrg, certOrgUnit, certLocale, certState, certZip, certCountry, certificateRequestFilePath, certificateAliasList2, receiveCertPath, base64Encoded, replacecertAlias, newCertAlias, deleteOldCert, deleteSigners, CMSKeyStore, SkipJythonChanges, StepAction)
  else:
    logging_cmd = '%s -lang jython -conntype SOAP -user %s -password %s -javaoption "-Dpython.path=%s" -f %s %s %s %s %s %s %s "%s" %s "%s" %s %s %s %s %s %s %s %s %s %s %s %s %s %s' % ( wsadminfile, username, 'XXXXXXXXX', PYTHONPATH, jythonscript, CellDefaultKeyStore, CellDefaultTrustStore, signatureAlgorithm, certRequestAlias, certSize, certCommonName, certOrg, certOrgUnit, certLocale, certState, certZip, certCountry, certificateRequestFilePath, certificateAliasList2, receiveCertPath, base64Encoded, replacecertAlias, newCertAlias, deleteOldCert, deleteSigners, CMSKeyStore, SkipJythonChanges, StepAction)
    cmd = '%s -lang jython -conntype SOAP -user %s -password %s -javaoption "-Dpython.path=%s" -f %s %s %s %s %s %s %s "%s" %s "%s" %s %s %s %s %s %s %s %s %s %s %s %s %s %s' % ( wsadminfile, username, password, PYTHONPATH, jythonscript, CellDefaultKeyStore, CellDefaultTrustStore, signatureAlgorithm, certRequestAlias, certSize, certCommonName, certOrg, certOrgUnit, certLocale, certState, certZip, certCountry, certificateRequestFilePath, certificateAliasList2, receiveCertPath, base64Encoded, replacecertAlias, newCertAlias, deleteOldCert, deleteSigners, CMSKeyStore, SkipJythonChanges, StepAction)
  log_msg.info("Issueing: [%s]" % logging_cmd)
  
  if os.name != 'nt':
    args = shlex.split(cmd)
  else:
    args = cmd
    #log_msg.debug("Windows special with ARGS: [%s]" % args)
  process = subprocess.Popen(args,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
  
  # Poll process for new output until finished
  while True:
    nextline = process.stdout.readline().rstrip()
    if nextline == '' and process.poll() is not None:
      break
    if nextline and (not nextline.isspace()):
      log_msg.info(nextline)
      if 'Nodes to SCP updated P12 file too: ' in nextline:
        key, value = nextline.split('Nodes to SCP updated P12 file too: ')
        WASresultSet = eval(value.strip())
      if 'IHS Nodes to SCP updated P12 file too: ' in nextline:
        key, value = nextline.split('IHS Nodes to SCP updated P12 file too: ')
        IHSresultSet = eval(value.strip())
      sys.stdout.flush()
    
  output, error = process.communicate()
  exit_code = process.wait()

  if exit_code > 0:
    #print "ERROR: [%s], exiting" % error
    if output:
      log_msg.error("Received STDOUT: %s" % output)
    if error:
      #lets see if its just the 'ulimit:' open files error received all the time
      for line in error.split(os.linesep):
        if line.find('ulimit:') > 0:
          log_msg.debug("Ignoring the ULIMIT: error from stderr...")
        else:
          log_msg.error(line)
    log_msg.error("ERROR: Exiting program!")
    sys.exit(exit_code)
  else:
    if output:
      log_msg.info("Received STDOUT: %s" % output)
    log_msg.info("Success on executing [%s]" % jythonscript)

  """ 
  # save for later if needed...
  # need to get some needed variables to manage the SCP and Keys
  #
  source = 'source %s/bin/setupCmdLine.sh' % wsadminpath
  dump = '/usr/bin/python -c "import os, json;print json.dumps(dict(os.environ))"'
  pipe = subprocess.Popen(['/bin/bash', '-c', '%s && %s' %(source,dump)], stdout=subprocess.PIPE)
  env = json.loads(pipe.stdout.read())
  os.environ = env
  configRoot = environ.get('CONFIG_ROOT')
  if configRoot is None:
    log_msg.fatal("FATAL: We could not determine the CONFIG_ROOT for WebSphere, we will have to exit, this should be defined by the setupCmdLine.sh!"
    sys.exit(99)
  else:
    log_msg.info("CONFIG_ROOT is defined as %s" % configRoot)
    
  #replCertPath = certPath.replace("${CONFIG_ROOT}", "%s/config" % wsadminpath) 
  ###############################################################
  """
  
  if os.name == 'nt':
    log_msg.info("Working on Windows post Jython logic....")
    windowsLogic(IHSresultSet, WASresultSet, log_msg, localhost, StepAction, wsadminpath, date_fmt)
  else:
    log_msg.info("Linux logic being done")
    linuxLogic(IHSresultSet, WASresultSet, log_msg, localhost, StepAction, wsadminpath, date_fmt)
  #endif
    
  log_msg.info("Completed program successfully")
    
if __name__ == "__main__":
  main()

