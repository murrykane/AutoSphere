# -------------------------------------------
# Usage: wsadmin -f /opt/jenkins/AutoSphere/python/addJvmProperty.py 
# For NPE-Web team
# Prepared by: Jeffrey Apiado
# -------------------------------------------
#           IMPORTANT / IMPORTANTE / jarooree
# note for creating customProperty.txt in /tmp
# example: Below should be added in the customProperty.txt
#
# [Configservice]
# com.ibm.portal.resource.MP_AlphaThemeDynamic.contextroot = /bsca/bsc/mpo/MP_AlphaThemeDynamic
# com.ibm.portal.resource.MP_AlphaThemeDynamic.whitelist = .*
# com.ibm.portal.resource.MP_AlphaThemeDynamic.blacklist = WEB-INF/.*
#
#
import ConfigParser
import os

# Make sure customProperty.txt is created in /tmp!"
# This will house the property name and it's value."
cfgFile = "/tmp/customProperty.txt"
while 1:
    if os.path.isfile(cfgFile):
       print "<EXEC> validate_absolute_path for %s = True" % cfgFile
       break
       #end
    else:
       print "<EXEC> creating customProperty.txt in /tmp"
       f = open(cfgFile, "w")
       f.write("[Configservice]\n")
       f.write("#example: com.ibm.portal.resource.MP_AlphaThemeDynamic.contextroot = /bsca/bsc/mpo/MP_AlphaThemeDynamic\n")
       f.write("#add entries below\n")
       f.close()

    raw_input("Please <ENTER> [/tmp/customProperty.txt should exist].")
#end


def parseConf():
	section = "Configservice"   # <--- section name in customProperty.txt
	config = ConfigParser.ConfigParser()
	config.optionxform = str
	config.read(cfgFile)
	raw = {}
	for option in config.options(section):
      # option is a property name
      # lets get the value of this option or property name
      	    value = config.get(section, option)
      # Now we get the value of the property
     # attr.append([['name',option],['value',value]])
      	    raw[option] = value
      # dump every property and value in attr Array
        return raw
#end

def validate(vraw):
   if vraw == {}:
       print "<EXEC>---------No ENTRIES found in customProperty.txt-----------"
       print "<EXEC>--------------System Exit!"
       print ""
       os._exit(0)
   else:
       print "<EXEC> Entries in property file - FOUND. -------------------"
       print vraw
   # Convert a list of items separated by linefeeds into an array

def getListArray(l):
    return l.splitlines()
#end

# Obtain the "simple" server name
def getServerName(s):
    return AdminConfig.showAttribute(s, 'name')
#end

# Add common attr list to specified Server's JVM
def addPropertiesToServer(s):
    print "******************************************************"
    print "<EXEC>======================================"
    print "<EXEC> Server: %s" % s
    print "<EXEC> Type: ApplicationServer"
    print "<EXEC>======================================"
    iraw = parseConf()
    validate(iraw)
    print "<EXEC> show all entries in customProperty.txt file"
    print "<EXEC> entries: ",iraw
    print "*******************************************************"
    nd = {}
    attr = []
    jvm = AdminConfig.list('JavaVirtualMachine', s)
    print "<EXEC> server JavaVirtualMachine ids: ",jvm
    print ""
    # Look for existing property so we can replace it (by removing it first)
    currentProps = getListArray(AdminConfig.list("Property", jvm))
    if currentProps:
        print "<EXEC> server properties = True"
        for propp in currentProps:
            prop = propp.encode('ascii','ignore')
            property = AdminConfig.showAttribute(prop, "name")
            valuee = AdminConfig.showAttribute(prop, "value")
            print "*******************************************************************"
            print "<EXEC> Existing Property ",property,"  => value: ",valuee
            print "*******************************************************************"
            nd = filterArray(property, valuee, prop, iraw)
    else:
        print "<EXEC> server property list is empty [no previous properties configured]"
        nd = raw

    for x, y in nd.items():
           print "*******************************************************"
           print "<EXEC>new binding ---------------------"
           print "<EXEC> new Property: %s         Value: %s" % (x,y)
           print "<EXEC> ----- Add to list for BINDING ----------"
           print "******************************************************"
           attr.append([['name',x],['value',y]])     

    # Store new property in 'systemProperties' object
    if attr != []:
        print ""
    	print "<EXEC> Below are properties to be added"
    	print "================================================"
    	print "<EXEC> ",attr
    	print "================================================"
        print "<EXEC> Adding property to Server %s" % s
        print ""
        AdminConfig.modify(jvm,[['systemProperties',attr]])
    else:
        print "*************************************"
        print "<EXEC> No NEW PROPERTIES TO BE ADDED"
        print "<EXEC> ---- SKIP -----"
        print "*************************************"
    
#end

def filterArray(propertyn, valuen, prop, newdict):
     if newdict.has_key(propertyn): #true or match
         print "<EXEC> server existing prop name %s found in customProperty file ." % propertyn
         if valuen == newdict.get(propertyn): #true match value
            print "***********************************************************************************"
            print "<EXEC> server existing property VALUE MATCH property defined in customProperty file"
            print "<EXEC> PROPERTY => ",propertyn," VALUE: ",valuen
            print "<EXEC>    ---  SKIP ---    "
            print "************************************************************************************"
            del newdict[propertyn]
         else:
            print ""
            print "***************************************************************************************"
            print "<EXEC> server property value not match the property defined in customProperty file"
            print "<EXEC> System: PROPERTY => ",propertyn," VALUE: ",valuen
            print "<EXEC> CustomProperty file: PROPERTY => ",propertyn," VALUE: ",newdict.get(propertyn)
            print "<EXEC>     --- MODIFY VALUE to: %s --- " % newdict.get(propertyn)
            print "*******************************************************************************************"
            alt = [
                     ["value", newdict.get(propertyn)],
                     ["description", ""]
                  ]
            AdminConfig.modify(prop, alt)
            del newdict[propertyn]
     else:
           print "**********************************************************"
           pass
     return newdict   
     
#end    
#==============================================================================

# Locate all Application Servers if server is 'all'
#if (server == 'all'):

servers = AdminConfig.list('Server')
for _aServer in getListArray(servers):
     aServer = _aServer.encode('ascii','ignore')
     _Type = AdminConfig.showAttribute(aServer,'serverType')
     _type = _Type.encode('ascii','ignore')
     if (_type == 'APPLICATION_SERVER'):
            addPropertiesToServer(aServer)

     if (AdminConfig.hasChanges()):
           AdminConfig.save()
     raw_input("Press <ENTER> to continue (moving to next server).")

     #end
#end

# Save changes
#if (AdminConfig.hasChanges()):
#    AdminConfig.save()
#end
