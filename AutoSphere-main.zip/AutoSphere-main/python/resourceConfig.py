import tParser
import sys
import pickle


def invoke_for_rep(xml_file, rep_number):
   obj1 = tParser.parse(xml_file)
   (n, output) = obj1.getCustom_property(rep_number)
   if output == None:
        output = []

   with open('/tmp/rep.txt','wb') as _fileA:
        pickle.dump(output, _fileA)

#end



def invoke_for_ree(xml_file, rep_number):
   obj2 = tParser.parse(xml_file)
   (n, output) = obj2.getCustom_property(rep_number)
   if output == None:
        output = []
   with open('/tmp/ree.txt','wb') as _fileB:
        pickle.dump(output, _fileB)

#end


def usageA():
   print "USAGE: --------------------------------------------------------------------------"
   print "   For resource provider follow below syntax"
   print "      SYNTAX: python resourceConfig.py xmlfilename resourceFlag repnumber"
   print " - "
   print "   For resource entires follow below syntax"
   print "      SYNTAX: python resourceConfig.py xmlfilename resourceFlag repnumber entrynumber"
   print " - "
   print "DEFINITION:"
   print "   xmlfilename (ex: /opt/jenkins/AutoSphere/xml/employer/prtn60employer.xml"
   print "   resourceFlag (This can be either 'rep' or ree' only)"
   print "   repnumber (ex: rep1 )"
   print "   entrynumber (ex: reEntry1)"
   print "-----------------------------------------------------------------------------------"
   sys.exit(0)
#end

def usageB(message):
    print "WARNING ---------------------------------------------"
    print "%s" % message
    print "-----------------------------------------------------"
    sys.exit(0)
#end

def diplayArgs(xml,flag,repn,reeEntry):
    print ""
    print "Arguments given:======================================="
    print "XML filename: %s" % xml
    print "Resource type: %s" % flag
    print "Provider number: %s" % repn
    print "Resource Entry: %s" % reeEntry
    print "======================================================="
    print ""


#end

#=================================================================================================

if len(sys.argv) >= 3:
    xml_file = sys.argv[1] #(required)
    resourceFlag = sys.argv[2] #rep with or without entry - (required)
    rep_number = sys.argv[3] # (required)
    try:
        entry_number = sys.argv[4] # required if it is ree 
    except:
        entry_number = None
    diplayArgs( xml_file, resourceFlag, rep_number, entry_number)
    if resourceFlag == 'rep':
              invoke_for_rep(xml_file, rep_number) 
    elif resourceFlag == 'ree':
              if entry_number != None:
                  invoke_for_ree(xml_file, rep_number, entry_number)
              else:
                  usageB('entry_number can not be empty for ree')           
    else:   
           usageB('resourceFlag can not be None (ree or rep)')
else:
     usageA()
#endIf
