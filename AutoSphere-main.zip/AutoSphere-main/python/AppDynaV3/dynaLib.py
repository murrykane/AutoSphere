#-----------------------------------------------------
# Name: dynaLib.py
# Role: classes and modules called by dynRun.py script
# Author: Jeffrey Apiado
# Owner: IT NPO-WEB-TEAM
# Company: BSCA    
#------------------------------------------------------
# Last Modified: 1/12/2018
#------------------------------------------------------
import logging, os, pickle, time, sys
import subf.wsadminINFO
from ConfigParser import SafeConfigParser
import zipfile, subprocess, StringIO
import multiprocessing
import ast, re
#------------------------------------------------------
#----------- Logging  -----------------------
class appLog:
    ERROR = '\033[91m'
    ENDC = '\033[0m'
    def __init__(self, filename="somelog.log", strfmt='[%(asctime)s] %(levelname)-8s: %(message)s', lvl=logging.INFO):
        self.logger = logging.getLogger()
        if self.logger.handlers:
            self.logger.handlers = []
        logging.basicConfig(format=strfmt, level=lvl, datefmt='%Y-%m-%d %I:%M:%S %p')
        lhStdout = self.logger.handlers[0]
        fh = logging.FileHandler(filename)
        fh.setFormatter(logging.Formatter(fmt=strfmt, datefmt='%Y-%m-%d %I:%M:%S %p'))
        ch = logging.StreamHandler()
        ch.setLevel(logging.ERROR)

        self.logger.addHandler(fh)
        self.logger.removeHandler(lhStdout)
        self.logger.addHandler(ch)

    def info(self, text):
        self.logger.info(text)

    def warn(self, text):
        self.logger.warning(text)

    def error(self, text):
        self.logger.error(self.ERROR + text + self.ENDC)

    def close(self):
       logging.shutdown()

#--------------class to call ady.ini-------------------------
class AppParse:
    def __init__(self, cfg):
        self.cfgp = cfg

    def getFiles(self, f="DFiles"):
        f_entries = {}
        for entry in self.cfgp.options(f):
            f_entries[entry] = self.cfgp.get(f,entry)
        return f_entries

    def getTag(self, t="Tag"):
        return self.cfgp.get(t, "apptagname")

    def contHost(self, t="Tag"):
        return self.cfgp.get(t, "controllerhost")

    def accKey(self, t="Tag"):
        return self.cfgp.get(t, "accountkey")

    def accName(self, t="Tag"):
        return self.cfgp.get(t, "accountname")

    def contPort(self, t="Tag"):
        return self.cfgp.get(t, "controllerport")

    def sslConfig(self, t="Tag"):
        return self.cfgp.get(t, "sslenabled")

    def tierName(self, t="Tag"):
        return self.cfgp.get(t, "tiername")

    def credentialUser(self, t="CRedentials"):
        return self.cfgp.get(t, "username")

    def credentialPwd(self, t="CRedentials"):
        return self.cfgp.get(t, "password")

    def getPath(self, p="DPath"):
        p_entries = {}
        for entry in self.cfgp.options(p):
            p_entries[entry] =  self.cfgp.get(p, entry)
        return p_entries

    def getAPath(self, p="APath"):
        ldir = self.cfgp.get(p, "possiblepath")
        convert = ast.literal_eval(ldir)
        return convert

#--------------modules for main script------------------------

class appTask:
    def __init__(self, logger):
        self.logger = logger
        self.logger.info("[In appTask]")
        self.cfg = SafeConfigParser()
        self.cfg.read("ady.ini")
        self.parse = AppParse(self.cfg)
        self.ParseFiles = self.parse.getFiles()
        self.parsePath = self.parse.getPath()
        #self.environ = self.verifyEnvToRun() # determine current environment
        self.logger.info("Parse Files >")
        self.logger.info(self.ParseFiles)
        print self.ParseFiles
        self.logger.info("Parse Path >")
        self.logger.info(self.parsePath)
        print self.parsePath
        self.statPath = self.parsePath["srvstatpath"]
        #-------------------------------------
        self.apptag = self.parse.getTag()
        self.ACCname = self.parse.accName()
        self.ACCkey = self.parse.accKey()
        self.controller = self.parse.contHost()
        self.placer = self.parse.getAPath() # contain list of possible path where to look at [keyword: AppDynamics]
        self.contPort = self.parse.contPort()
        self.sslConfig = self.parse.sslConfig()
        self.tierName = self.parse.tierName()
        
        #--------------------------------CREDENTIALS-------------------------
        self.admin = self.parse.credentialUser()
        self.pwd = self.parse.credentialPwd()
        #self.admin = "svcbscwas"
        #self.pwd = "6Rm9C73d2Ea74f4A"

        #-------------------------------------------------------------------
        #if self.environ: 
        self.wsPATH = "/apps/profiles/" + self.dmgrName() + "/bin"
        print "self.wsPath =>",self.wsPATH
        #else:
        #self.wsPATH = self.parsePath['wslegacy']
        #--------------------------------------------------------------------
        self.scriptWSADM = self.parsePath['scriptdir']
        self.runPickle(self.wsPATH, self.scriptWSADM)
        self.pickled = self.unpickle()
        self.logger.info("from dynaUTIL.txt >")
        self.logger.info(self.pickled)
        #print self.pickled

    
    def dmgrName(self):
        raw = [item for item in os.listdir("/apps/profiles") if item.find("Dmgr") != -1]
        return raw[0]

 
    def setHostname(self, HOSTname):
        self.host = HOSTname
        
    def unpickle(self, infile="/tmp/dynaUTIL.txt"):
        with open(infile, "rb") as ufile:
            utilityVar = pickle.load(ufile)
        # For legacy test!
        return utilityVar    


    def runPickle(self, wspath, scripath):
        #if self.environ:
        if self.admin and self.pwd:
           cmd = "{0}/wsadmin.sh -lang jython -user {1} -password {2} -f {3}/wsadminINFO.py".format(wspath, self.admin, self.pwd, scripath)
        else:
           cmd = "{0}/wsadmin.sh -lang jython -f {1}/wsadminINFO.py".format(wspath, scripath)
        print "==========> Command to execute: ", cmd
        _return = os.system(cmd)
        #===================================
        if _return > 0:
            self.logger.warn("EXEMPTION FOUND > for script wsadminINFO.py ** ERROR")
        else:
            print "execution completed for script 'wsadminINFO.py'"

        
    #def verifyEnvToRun(self):
        #if os.path.isfile("/etc/virtualimage.properties") is False:
                #print "env > [Legacy]"
                #return 0
        #else:
            #print "env > [ReBuild]"
            #return 1

    def dynaFiles(self, verf=0):
        if os.path.isfile("/tmp/%(apsagent)s" % self.ParseFiles):
            print "[search] %(apsagent)s in /tmp . . . . . . . [found]" % self.ParseFiles
            self.logger.info("[search] %(apsagent)s in /tmp . . . . . . . [found]" % self.ParseFiles)
        else:
            print "[search] %(apsagent)s in /tmp . . . . . . . [missing]" % self.ParseFiles
            self.logger.info("[search] %(apsagent)s in /tmp . . . . . . . [missing]" % self.ParseFiles)
            verf = 1
        #--------------------------------------------------
        if verf:
            self.logger.warn("[Process] . . . . . . . . . . . . [halt]")
            print "[Process] . . . . . . . . . . . . [halt]"
            if verf == 1: mfile = self.ParseFiles['apsagent']
            print "[]=================================[]"
            self.logger.warn("[copy missing file to /tmp directory]")
            print "[copy missing file to /tmp directory]"
            print "[]=================================[]"
            self.logger.warn("[missing] [file as a requirement] [%s]" % mfile)
            print "[filename] %s" % mfile 
            sys.exit(0)
        else:
            print "[required file found]"
            self.logger.info("[required file found]")

    def macFiles(self, verf=0):
        if os.path.isfile("/tmp/%(machineagent)s" % self.ParseFiles):
            print "[search] %(machineagent)s in /tmp . . . . . . . [found]" % self.ParseFiles
            self.logger.info("[search] %(machineagent)s in /tmp . . . . . . . [found]" % self.ParseFiles)
        else:
            print "[search] %(machineagent)s in /tmp . . . . . . . [missing" % self.ParseFiles
            self.logger.info("[search] %(machineagent)s in /tmp . . . . . . . [missing]" % self.ParseFiles)
            verf = 1
        #----------------------------------------------------
        if verf:
            self.logger.warn("[Process] . . . . . . . . . . . . [halt]")
            print "[Process] . . . . . . . . . . . . [halt]"
            if verf == 1: mfile = self.ParseFiles['machineagent']
            print "[]=================================[]"
            self.logger.warn("[copy missing file to /tmp directory]")
            print "[copy missing file to /tmp directory]"
            print "[]=================================[]"
            self.logger.warn("[missing] [file as a requirement] [%s]" % mfile)
            print "[filename] %s" % mfile
            sys.exit(0)
        else:
            print "[required file found]"
            self.logger.info("[required file found]")    

    def zipFilesPrep(self, agentname):
            if agentname == "machineagent":
                try:
                    os.mkdir("/tmp/machineagent",0777)
                except:
                    print "[/tmp/machineagent directory already created]"
                    self.logger.info("[/tmp/machineagent directory already created]")
                finally:
                    v = self.ParseFiles.get(agentname)
                    self.inflateFile(v, "/tmp/machineagent")
                
            elif agentname == "apsagent":
                try:
                    os.mkdir("/tmp/appagent",0777)
                except:
                    print "[/tmp/appagent directory already created]"
                    self.logger.info("[/tmp/appagent directory already created]")
                finally:
                    v = self.ParseFiles.get(agentname)
                    self.inflateFile(v, "/tmp/appagent")
             
        
    def inflateFile(self, filename, dest):
        z = zipfile.ZipFile("/tmp/" + filename, 'r')
        try:
            z.extractall(dest)
        except:
            print "zip File: {0} => error".format(filename)
            sys.exit(0)
        z.close()
        if os.listdir(dest) == []:
            self.logger.warn("[%s is [EMPTY] unzip file FAILED]" % dest)
            sys.exit(0)
        else:
            print "[{0} unzipped files found . . . . done]".format(dest)
            self.logger.info("[%s unzipped files found . . . . done]" % dest)

    def commonSrvNodeEXEC(self, commonCMD):
        servProc = subprocess.Popen(commonCMD, stderr=subprocess.PIPE, shell=True)
        servErr = servProc.communicate()[1]
        if servErr:
            self.logger.warn(servErr)
        else:
            print "> completed without error"    


    def runProc(self, cmd):
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        except subprocess.CalledProcessError as e:
            print e.output
        stdout, stderr = proc.communicate()
        if not stderr:
            buff = StringIO.StringIO()
            buff.write(stdout)
            Output = buff.getvalue()
            buff.flush()
            buff.close()
            return Output
        else:
            return "Null"

    def Rzip(self, tdir, hn, rpath):
        # Verify if appDynamics folder already created and not empty
        tover = r'''ssh {0} "ls {1}/{2}"'''.format(hn, rpath, tdir)        
        print "Command to exec: %s" % tover
        self.logger.info("Command to exec: %s" % tover)
        holdA = self.runProc(tover)
        if holdA.find("machineagent.jar") > 0 or holdA.find("javaagent.jar") > 0:
            print "Directory {0}/{1} already exist!".format(rpath, tdir)
            self.logger.info("Directory {0}/{1} already exist!".format(rpath, tdir))
            print "Directory Content: "
            print holdA.strip()
            self.logger.info(holdA.strip())
        else:
        	copycmd = "rsync -avh --inplace /tmp/{0}/ {1}:{2}/{3}/".format(tdir, hn, rpath, tdir)
        	self.logger.info("[exec] %s" % copycmd)
        	print "[command to execute] %s" % copycmd
        	runtime = subprocess.Popen(copycmd, stderr = subprocess.PIPE, shell=True)
        	sys.stdout.write("[copy file] to remote server . . . . . . . ")
        	self.logger.info("[copy][file to remote server]")
        	error = runtime.communicate()[1]
        	if error:
            		self.logger.warn(error)
        	else:
            		self.logger.info(" - - - [copied]")
            		print "[copied]"
        self.openDirPerm(tdir, hn, rpath)


    def openDirPerm(self, tdir, hn, rpath):
        print "Opening permission to directory {0} in {1}".format(tdir, hn)
        self.logger.info("Opening permission to directory %s in %s" % (tdir, hn))
        pcmd = r'''ssh {0} "chmod -R 755 {1}/{2}"'''.format(hn, rpath, tdir)
        print "Command to execute: %s" % pcmd
        perm = os.system(pcmd)
        if perm > 0:
            self.logger.warn("Error command execution <pcmd arguments>!")
        else:
            print "Command Execution => successfull! [permission set to 755]"
            self.logger.info("Command Execution => successfull! [permission set to 755]")


    def dirVerify(self, host):
        exitpoint = 0
        designated_path = ""
        for pdir in self.placer:
            cmd = r'''ssh {0} "ls {1}"'''.format(host, pdir)
            print "Command to execute: %s" % cmd
            self.logger.info("Command to execute: %s" % cmd)
            data = self.runProc(cmd)
            print data
            if "appdynamics" in data:
                designated_path = "{0}/appdynamics".format(pdir)
                self.logger.info("appdynamics dir. . . . . . [Found] in [%s]" % pdir) 
                print "appdynamics dir. . . . . . [Found] in [%s]" % pdir
                exitpoint = 1
                break   
 
        return (designated_path, exitpoint)

    def lookup_ret(self, host):             
        msg = "Can't locate appdynamics directory in %s  [create and add path[ location: ady.ini > APATH > possiblepath]! <ENTER> to continue." % host
        while True:
            (desigpath, exitpoint) = self.dirVerify(host)
            if exitpoint and desigpath:
                  break    
            else:
                  raw_input(msg)  
            time.sleep(2)  
        return desigpath
           
    def legacyHostname(self, hostName):
        cmd = r'''ssh {0} "hostname"'''.format(hostName)
        output = self.runProc(cmd)
        return output.strip()
    
    def legacyProfile(self, hostName):
         cmd = r'''ssh {0} "cat /apps/profiles/properties/profileRegistry.xml | grep path"'''.format(hostName)
         output = self.runProc(cmd)
         pattern = re.compile(r'''path="(.*?)"''')
         val = pattern.search(output)
         if val:
             return val.group(1)
         else:
             return None
         
          
    def sshCheckpoint(self, hn, _dict={}):
        self.logger.info("[connection] [test SSH protocols]")
        sys.stdout.write("[check ssh connection] . . . . . . . . .")
        sshcmd = "ssh-keyscan {0} 2>&1".format(hn)
        print "[exec] %s" % sshcmd
        sshSys = self.runProc(sshcmd)
        #sshSys = subprocess.Popen(sshcmd, stderr = subprocess.PIPE, shell=True)
        #stderr = sshSys.communicate()[1]
        #print "stderr value: ",stderr
        if sshSys.find("No route to host") > 0:
           print ""
           self.logger.warn("[access to SSH][not possible error]")
           r =  "noposs"
        else:
           self.logger.info("[access to SSH][possible]")
           print "[accessible]"
           r =  "acposs"
        #if not self.environ:
           #if r == "acposs":
               #_dict[hn] = self.legacyHostname(hn) 
           #return r, _dict
        #else:
        return r, _dict     
    
    def checkBackupDirectoryExistance(self, host):

        self.uniPath = self.parsePath['srvpolicyrebuild']
        #if self.environ:
        #    self.uniPath = self.parsePath['srvpolicyrebuild']
        #else: # legacy
        #    n = self.legacyProfile(host)
        #    if n != None:
        #        self.uniPath = "%s/properties" % n
        #    else:
        #        self.logger.warn("Error: ................. Profile path is Null")
        #        self.uniPath = ""

        print "Verify is server.policy.orig already exist if not create it"
        self.logger.info("Verify is server.policy.orig already exist if not create it")
        commd = r'''ssh %s "ls %s"''' % (host, self.uniPath)
        print "Command to execute: %s" % commd
        self.logger.info("Command to execute: %s" % commd)
        tada = self.runProc(commd)
        if "server.policy.orig" in tada:
            print "Backup folder already exist . . . [skip]"
            self.logger.info("Backup folder already exist . . . [skip]")
            return "skip"
        else:
            return "create"

    def usedSecPolicy_backup(self, host):
        #if self.environ:
        commonPath = self.parsePath['srvpolicyrebuild']
        #======================================================================
        cmd = r'''ssh {0} "find {1} -type f -name server.policy.orig"'''.format(host, commonPath)
        print "Command to execute: %s" % cmd
        _return = self.runProc(cmd)
        if _return.find("server.policy.orig") > -1:
            print "Use server.policy.orig to restore server.policy file"
            cmd1 = r'''ssh %s "cp %s/server.policy.orig %s/server.policy"''' % (host, commonPath, commonPath)
            print "Command to execute: %s" % cmd1
            _result = os.system(cmd1)
            if _result > 0:
                print "Failed to revert to original server policy config"
            else:
                print "Execution successful[ server.policy restored]"
            #-------------------------------------
            print "Removed server.policy.orig in %s" % commonPath
            cmd3 = r'''ssh %s "rm -f %s/server.policy.orig"''' % (host, commonPath)
            print "Command to execute: %s" % cmd3
            os.system(cmd3)
        else:
            print "Can't locate server.policy.orig......."
            print "Can't revert back original config to server.policy......"

        print "============[completed]==========================="


    def createBckup(self, host, orgfile='server.policy', bckfile='server.policy.orig'):
        print "Create %s backup remotely!!!" % orgfile
        cmd = r'''ssh %s "cp %s/%s %s/%s"''' % (host, self.uniPath, orgfile, self.uniPath, bckfile)
        print "Command to execute: %s" % cmd
        self.logger.info("Command to execute: %s" % cmd)
        oss = os.system(cmd)
        if oss > 0:
            print "WARNING ------------------------------ !!!"
            print "Creating backup {0} in {1}.... [Failed]".format(orgfile, host)
            self.logger.info("WARNING ----------------------------- !!!")
            self.logger.info("Creating backup %s %s [Failed]" % (orgfile, host))
        else:
            print "Backup created . . . . [Done][%s in %s]" % (orgfile, host)
            self.logger.info("Backup created . . . . [Done][%s in %s]" % (orgfile, host))
    
    def filterLgcy(self, dom):
        print "This is dom in filterLgcy:",dom
        DICT = {}
        for key in dom.keys():
		 if key.find("CSAdmin") > -1:
                    DICT[key] = dom.get(key)
                 elif key.find("FAP") > -1:
                    DICT[key] = dom.get(key)
                 elif key.find("Provider") > -1:
                    DICT[key] = dom.get(key)
                 else:
                    pass
        print "======================================"
        Holder = {}
        for k,v in DICT.items():
            if v[0].find("batch") == -1:
                Holder[k] = v

        print "Without Batch Server:=>",Holder
        return Holder
    
    def Filterpickle(self):
        datadomx = self.unpickle()
        sshUnlist = []
        #filter datadom Dictionary

        datadom = datadomx
        #if self.environ:
        #    datadom = datadomx
        #else:
        #    datadom = self.filterLgcy(datadomx)
        holder = datadom
        return holder

    def subTask(self):
        datadom = self.Filterpickle()
        holder = datadom
        print "==================> output from pickle load: ",holder
        sshUnlist = [] 
        appDynamicsDir = []
        for k, val in datadom.items():
             h = val[0]
             print "H value:",h
             stat, cont = self.sshCheckpoint(h)
             print "====================> stat: ",stat
             print "====================> cont: ",cont
             if stat == "acposs":
                 rpath = self.lookup_ret(h)
                 appDynamicsDir.append(rpath)
                 self.Rzip('appagent',h ,rpath)
                 print "=" * 40
                 resp = self.checkBackupDirectoryExistance(h)
                 if resp == "create":
                     self.createBckup(h)
                 print ""
                 print "=====Server Policy update======"
                 print "Hostname: %s" % h
                 print "====================================================="
                 self.serverPolicyUpdate(h, rpath)
             else:
                 self.logger.warn("Can't connect to %s via SSH protocol[proceed to next]" % h)
                 sshUnlist.append(val[0])
                 continue
             #break  # ===============================================> for debugging!
        if cont != {}: 
           print cont
        else: 
           print "[Container is empty .... EXPECTED]"

        self.cont = cont
        self.logger.info("subCONTAINER:" + str(self.cont))
        dyna = set(appDynamicsDir)
        appDynamics = set.pop(dyna)
        self.unlist = sshUnlist
        self.rpath = appDynamics
        print "======================> self.rpath >",self.rpath
        self.invokeJVMPropertyScript(datadom, self.rpath)
        self.datadom = holder
        

    def controllerFunction(self):
        print "Dictionary in ControllerFunction: ",self.datadom
        for nn, val in self.datadom.items():
            print ""
            print "=============controller-info.xml change=============="
            print "Hostname: %s" % val[0]
            print "Node: %s" % nn
            print "Controller-info.xml update . . ." 
            print "====================================================="
            print ""
            
            if val[0] not in self.unlist:
                jvmHostName = self.hostnameLookUp(val[0])
                #if self.environ:
                hsplit = jvmHostName.split(".",1)[0]
                #else:
                #hsplit = self.cont.get(val[0])
                self.logger.info("---------------->>> %s" % hsplit)
                #--------------------------------------
                tpath = "{0}{1}".format(self.rpath, self.parsePath['reappgent'])
                #if self.environ:
                entry = {"controller-ssl-enabled":self.sslConfig ,"controller-port":self.contPort ,"node-name":hsplit, "application-name": self.apptag, "tier-name":self.tierName, "controller-host":self.controller, "account-name":self.ACCname, "account-access-key":self.ACCkey} 
                #else:
                #tier = self.getTier(nn)
                #entry = {"node-name":hsplit, "application-name": self.apptag, "tier-name":tier, "controller-host":self.controller, "account-name":self.ACCname, "account-access-key":self.ACCkey}
                #--------------------------------------------
                self.alterControllerValue(val[0], tpath, entry, self.rpath)
            else:
                continue 
            time.sleep(5) 
            #break #====================================================> for debugging!

    def macControllerFunction(self, srvDict, unlisted, wpath, contt):
        print "Dictionary in ControllerFunction: ",srvDict
        for nn, val in srvDict.items():
            print ""
            print "=============controller-info.xml change=============="
            print "Hostname: %s" % val[0]
            print "Node: %s" % nn
            print "Controller-info.xml update . . ."
            print "====================================================="
            print ""
            if val[0] not in unlisted:
                #if self.environ:
                jvmHostName = self.hostnameLookUp(val[0])
                hsplit = jvmHostName.split(".",1)[0]
                #else:
                #hsplit = contt.get(val[0])
                self.logger.info("---------------->>> %s" % hsplit)
                #--------------------------------------
                tpath = "{0}{1}".format(wpath, self.parsePath['remacgent'])
                entry = {"sim-enabled":"true", "unique-host-id":hsplit, "controller-host":self.controller, "account-name":self.ACCname, "account-access-key":self.ACCkey, "controller-port":self.contPort, "controller-ssl-enabled":self.sslConfig}
                #--------------------------------------------
                self.alterControllerValue(val[0], tpath, entry, wpath, agent=1)
            else:
                continue
        time.sleep(5)


    #def getTier(self, node):
        #if node.find("CSAdmin") > -1:
             #t = "CSAdmin"
        #elif node.find("FAP") > -1:
             #t = "FaD"
        #elif node.find("Provider") > -1:
             #t = "Provider"
        #else:
             #self.logger.warn("Error: Can't determine the tier Name!!!")
             #t = "Null"
        #return t

    def restartJVM(self, node, vZero, vOne):
            print ""
            print "=======RESTART JVM======="
            print "Nodename: %s" % node
            print "Servername: %s" % vOne
            print "Hostname: %s" % vZero
            print "================================="
            if self.environ:
                if self.admin == "" and self.pwd == "":
                     ecmd = r'''{0}/wsadmin.sh -lang jython -f {1}/appsrvRestart.py {2}'''.format(self.wsPATH, self.scriptWSADM, node)
                else:
                     ecmd = r'''{0}/wsadmin.sh -lang jython -user {1} -password {2} -f {3}/appsrvRestart.py {4}'''.format(self.wsPATH, self.admin, self.pwd, self.scriptWSADM, node)
                print "Command to exec: %s" % ecmd
                self.logger.info("Command to exec: %s" % ecmd)
                self.commonSrvNodeEXEC(ecmd)
            else:
                if self.admin == "" and self.pwd == "":
                    ecmd = r'''{0}/bin/wsadmin.sh -lang jython -f {1}/appsrvRestart.py {2}'''.format(self.wsPATH, self.scriptWSADM, node)
                else:
                    ecmd = r'''{0}/bin/wsadmin.sh -lang jython -user {1} -password (2) -f {3}/appsrvRestart.py {4}'''.format(self.wsPATH, self.admin, self.pwd, self.scriptWSADM, node)
                print "Command to exec: %s" % ecmd
                self.logger.info("Command to exec: %s" % ecmd)
                self.commonSrvNodeEXEC(ecmd)
    
    def run(self, hostn, srvname, key):
         que = multiprocessing.Queue()
         t1 = multiprocessing.Process(target=self.display_wait, args=(que,))
         t1.start()
         self.checkJVMstat(que, hostn, srvname, key)
         t1.join()
         print " [STARTED]"  
         

    def checkJVMstat(self, q, hostn, srvname, noden):
        timer=0
        if self.environ:
             if self.admin == "" and self.pwd == "":
                 trig = r'''ssh %s "%s/serverStatus.sh -all | grep '\"%s\" is STARTED'"''' % (hostn, self.statPath, srvname) 
             else:
                 trig = r'''ssh %s "%s/serverStatus.sh -all -username %s -password %s | grep '\"%s\" is STARTED'"''' % (hostn, self.statPath, self.admin, self.pwd, srvname) 
        else:
             sp = hostn.split(".",1)
             lpath = "%s-%s" % (sp[1].upper(),sp[0])
             legcyPath = "/apps/{0}/profiles/{1}/bin".format(lpath ,noden)
             if self.admin == "" and self.pwd == "":
                 trig = r'''ssh %s "%s/serverStatus.sh -all | grep '\"%s\" is STARTED'"''' % (hostn, legcyPath, srvname) 
             else:
                 trig = r'''ssh %s "%s/serverStatus.sh -all -username %s -password %s | grep '\"%s\" is STARTED'"''' % (hostn, legcyPath, self.admin, self.pwd, srvname) 
        while True:
             #trig = r'''ssh %s "%s/serverStatus.sh -all | grep '\"%s\" is STARTED'"''' % (hostn, self.statPath, srvname) 
             self.logger.info("[command] %s" % trig)
             hold = self.runProc(trig)
             self.logger.info(hold)
             if hold.find('STARTED') > -1:
                 q.put("done")
                 break
             elif timer == 8: #8 minutes
                 q.put("TIMEOUT")
                 break
             time.sleep(60)
             timer+=1
                            

    def serverPolicyUpdate(self, hn, rpath):
        print "Verify existance keyword > appdynamics"
        self.logger.info("Verify existance keyword > appdynamics")
        cmd = r'''ssh %s "grep '%s' %s/server.policy"''' % (hn, 'appdynamics', self.uniPath)
        print "Command to execute: %s" % cmd
        self.logger.info("Command to execute: %s" % cmd)
        tata = self.runProc(cmd)
        if "appdynamics" not in tata:
            print "Adding statement grant codeBase >> server.policy"
            self.logger.info("Adding statement grant codeBase >> server.policy")
            cmd1 = r'''ssh %s "echo -e '//\ngrant codeBase \"file:%s/appagent/-\" { permission java.security.AllPermission; };' >> %s/server.policy"''' % (hn, rpath, self.uniPath)
            print "Command to execute: %s" % cmd1
            self.logger.info("Command to execute: %s" % cmd1)
            c = os.system(cmd1)
            if c > 0: 
                self.logger.warn("Process failed to append codeBase statement to server.policy remotely") 
            else:
                print "Statement added succesfully to server.policy"
                self.logger.info("Statement added succesfully to server.policy")
        else:
            print "Statement codeBase already exist in server.policy [skip]"
            self.logger.info("Statement codeBase already exist in server.policy [skip]")           
       

    def invokeJVMPropertyScript(self, datadom, rpath):
         self.logger.info("=> call invokeJVMPropertyScrip method")
         LIST = self.unlist
         for nn, val in datadom.items():
              if val[0] not in LIST:
                  jvmHostName = self.hostnameLookUp(val[0])
                  print ""
                  print "======JVM PROPERTY modify====="
                  self.logger.info("ServerName: %s" % val[1])
                  print "ServerName: %s" % val[1]
                  self.logger.info("Hostname: %s" % val[0])
                  print "Hostname: %s" % jvmHostName
	          print "===================================================================================="
                  #if self.environ:
                  if self.admin and self.pwd:
                     textForm = r'''{0}/wsadmin.sh -lang jython -user {1} -password {2} -f {3}/wsadminJVM.py {4} {5} {6} {7}'''
                     cmd = textForm.format(self.wsPATH, self.admin, self.pwd, self.scriptWSADM, nn, val[1], jvmHostName, rpath)
                  else:
                     textForm = r'''{0}/wsadmin.sh -lang jython -f {1}/wsadminJVM.py {2} {3} {4} {5}'''
                     cmd = textForm.format(self.wsPATH, self.scriptWSADM, nn, val[1], jvmHostName, rpath)
                  self.logger.info("Command to execute: %s" % cmd)
                  print "Command to execute: ", cmd
                  #==================================================================================
                  osys = os.system(cmd)
                  if osys > 0:
                      self.logger.warn("error in executing wsadminJVM.py script")
                  else:
                      print "wsadminJVM => script execution completed"
                      self.logger.info("wsadminJVM => script execution completed")
                  time.sleep(5)
              else:
                  pass
              #break #=======================================================> for debugging!

    def hostnameLookUp(self, testhn):
         cmd = r'''nslookup {0} | grep Name:'''.format(testhn)
         result = self.runProc(cmd)         
         fhostname = result.split()[1].strip()
         return fhostname

    def invokeJVMreverse(self, hostname, servername, contr):
                  self.logger.info("=> call invokeJVMreverse method")
                  print ""
                  print "======JVM PROPERTY rollback====="
                  print "ServerName: %s" % servername
                  self.logger.info("ServerName: %s" % servername)
                  print "Hostname: %s" % hostname
                  self.logger.info("Hostname: %s" % hostname)
                  print "===================================================================================="
                  check = self.panoramaExistance(hostname)
                  #if self.environ:
                  envr = "Rebuild"
                  if self.admin and self.pwd:
                       textForm = r'''{0}/wsadmin.sh -lang jython -user {1} -password {2} -f {3}/wsadminJVMreverse.py {4} {5} {6} {7}'''
                       cmd = textForm.format(self.wsPATH, self.admin, self.pwd, self.scriptWSADM, check, servername, hostname.split(".",1)[0], envr)
                  else:
                       textForm = r'''{0}/wsadmin.sh -lang jython -f {1}/wsadminJVMreverse.py {2} {3} {4} {5}'''
                       cmd = textForm.format(self.wsPATH, self.scriptWSADM, check, servername, hostname.split(".",1)[0], envr)
                  print "Command to execute: ", cmd
                  self.logger.info("Command to execute: %s" % cmd)
                  rsys = os.system(cmd)
                  if rsys > 0:
                      self.logger.warn("error in executing wsadminJVMreverse.py script")
                  else:
                      self.logger.info("wsadminJVM => script execution completed")
                      print "wsadminJVM => script execution completed"


        
    def panoramaExistance(self, hostname):
        self.logger.info("=> check if Panorama directory and its content exists in the filesystem")
        if self.environ:
            cmd = r'''ssh {0} "find /opt/Panorama -type d -name hedzup"'''.format(hostname)
        else:
            cmd = r'''ssh {0} "find /apps/opnet/Panorama -type d -name hedzup"'''.format(hostname)
        print "Command to Execute: %s" % cmd
        self.logger.info("Command to Execute: %s" % cmd)
        output = self.runProc(cmd)
        if output.find("hedzup") > -1:
            self.logger.info("Append Panorama statement in JVM arguments and bootClasspath")
            return "Initiate"
        else:
            self.logger.info("Ignore Panorama statement and don't append to JVM arguments")
            return "Skipped"


    def rollOverProc(self, databox, redlist, wpath, contrain):
         self.logger.info("Initiate rollBack call rollOverProc method")
         for n, others in databox.items():
             print "key:",n
             print "value:",others
             pcont = 0
             if others[0] not in redlist:
                 msg = "Is {0} {1} candidate for rollback? [yes or no]: ".format(others[0], others[1])
                 while True:  
                    print "==========================================="
                    resp = raw_input(msg) or 'q'
                    if resp == 'yes' or resp == 'y':
                        pcont = 1
                        break
                    elif resp == 'no' or resp == 'n':
                        break
                    elif resp == "q":
                        sys.exit(0)
                    else:
                        print "Invalid input!"
                 print "=========================================="
                 print ""
                 #---------------------------------------------------------
                 #todo here
                 if pcont:
                     print "Stop server {0}".format(others[0])
                     self.logger.info("Stop server %s" % others[0])
                     #if self.environ:
                     if self.admin and self.pwd:
                             cmd = r'''{0}/wsadmin.sh -lang jython -user {1} -password {2} -f {3}/wsadminAppCmd.py {4} stop'''
                             pre = cmd.format(self.wsPATH, self.admin, self.pwd, self.scriptWSADM, others[1])
                     else:
                             cmd = r'''{0}/wsadmin.sh -lang jython -f {1}/wsadminAppCmd.py {2} stop'''
                             pre = cmd.format(self.wsPATH, self.scriptWSADM, others[1])
                     print "Command to execute: %s" % pre
                     self.logger.info("Command to execute: %s" % pre)
                     v = os.system(pre)
                     if v > 0:
                         self.logger.warn("error in executing wsadminAppCmd.py script")
                     else:
                         print "wsadminAppCmd.py script execution completed"
                         self.logger.info("wsadminAppCmd.py script execution completed")
                         print "Server status ==========>> STOPPED"
                         self.logger.info("Server status =======>> STOPPED")

                     #---------------------------------------------------------
                     print "==========================================="
                     print "Verify if machine-agent process exists"
                     self.logger.info("Verify if machine-agent process exists")
                     out = self.machineAgentStat(others[0])
                     if out == []:
                         self.logger.info("No machine-agent found running!")
                         print "No machine-agent found running!"
                     else:
                         for pp in out:
                             k = r'''ssh {0} "kill -9 {1}"'''.format(others[0], pp)
                             ll = os.system(k)
                             if ll > 0:
                                 print "Failed to kill process {0}".format(pp)
                             else:
                                 print "Machine-agent process {0} stop [completed]".format(pp)
                             time.sleep(3)
                     #---------------------------------
                     self.invokeJVMreverse(others[0], others[1], contrain)
                     self.usedSecPolicy_backup(others[0])
                     self.AppDynamicsCleanUp(others[0], wpath)
                     #=================================
                     print ""
                     print "----------Server-Rollback [completed]---------------->"
                     print "Don't forget to start server {0} manually!".format(others[0])
                     print "EOF---------------------------------------------->"
                     print ""
             else:
                pass
 
    def AppDynamicsCleanUp(self, hostname, ppath):
        print "Remove directory and files in /appdynamics folder"
        self.logger.info("Remove directory and files in /appdynamics folder")
        cmd2 = r'''ssh {0} "rm -rf {1}/*"'''.format(hostname, ppath)
        print "Command to execute: %s" % cmd2
        self.logger.info("Command to execute: %s" % cmd2)
        _others = os.system(cmd2)
        if _others > 0:
            self.logger.warn("[failed to clean-up appDynamics folder]")
        else:
            print "[appagent and machine-agent directory removed]"
            self.logger.info("[appagent and machine-agent directory removed]")
        print "===========[completed]===================="
        
 

    def alterControllerValue(self, hostname, appDynamicPath, ENTRY, gpath, agent=0):
             ffile="controller-info.xml"
             rdpath = os.path.join(appDynamicPath, ffile)
             
             for k, v in ENTRY.items(): # address multiple tag and text ENTRY({"key":"value"})
                 print ""
		 print "Detail change below=================================="
                 print "NewValue:         <Tag> %s <Value> %s" % (k, v)
                 print "Controller xml path: %s" % appDynamicPath
                 print "====================================================="
                 print ""
                 #command = r'''ssh {0} "sed -i.bak 's/\(<{1}>\)[a-zA-Z0-9]*\(<\/{1}>\)/\1{2}\2/' {3}"'''
                 command = r'''ssh {0} "sed -i.bak 's/\(<{1}>\).*\(<\/{1}>\)/\1{2}\2/' {3}"'''
                 xcommand = command.format(hostname, k, v, rdpath)
                 print "Command to execute: %s" % xcommand
                 nn = os.system(xcommand)
                 if nn > 0:
                     print "Traceback error > for executed process!"
                 else:
                     print "Execution completed!"

                 if not agent: confXMLpath = gpath + "/appagent/conf/" + ffile
                 elif agent: confXMLpath = gpath + "/machineagent/conf/" + ffile
                 time.sleep(3)
                 if not agent:
                     # copy controller-info.xml 2 directory back
                     print "copy controller-info.xml to ../../conf"
                     self.logger.info("copy controller-info.xml to ../../conf")
                     command1 = r'''ssh {0} "cp {1} {2}"'''
                     triger = command1.format(hostname, rdpath, confXMLpath)
                     print "Command to execute: %s" % triger
                     xx = os.system(triger)
                     if xx > 0:
                         print "Traceback error > for executed process!"
                     else:
                         print "Execution completed!"


    def nohupMacAgent(self, srvDict, unlisted, wpath):
        print "[Starting machineagent . . . . . .]"
        self.logger.info("Starting machineagent . . . . . . ")
        tmpPath = self.parsePath['remacexec'] + "/machine-agent"
        for n, val in srvDict.items():
            if val[0] not in unlisted:
                print ""
                print "===============run in background [machineagent]=========="
                print "HostName: %s" % val[0]
                print "NodeName: %s" % n
                print "ServerName: %s" % val[1]
                print "Appdynamics path: %s" % wpath
                print "=========================================================="
                cmd = r'''ssh {0} "nohup {1}{2} 2>&1 &"'''.format(val[0], wpath, tmpPath)
                print "Command to exec: %s" % cmd
                self.logger.info("Command to exec: %s" % cmd)
                # Execute it and forget, can't wait for output which is null!
                subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, stdin=subprocess.PIPE, shell=True)
                #self.commonSrvNodeEXEC(cmd)
                print "=============================="
                time.sleep(5) 
                print "Verify if machine-agent is running in the background!"
                self.logger.info("Verify if machineagent is running in the background!")
                hashy = self.machineAgentStat(val[0])
                print hashy


    def machineAgentStat(self, hnn):
                vcmd = r'''ssh {0} "ps -ef | grep machine"'''.format(hnn)
                print "Command to execute: %s" % vcmd
                vout = self.runProc(vcmd)
                if vout.find("machineagent.jar") > 0:
                    print "Running process /opt/appdynamics/machineagent/machineagent.jar [active]"
                    self.logger.info("Running process /opt/appdynamics/machineagent/machineagent.jar [active]")
                    procs = self.getProcID(vout)             
                    return procs
                else:
                    self.logger.warn("No instance for(machineagent.jar) in proc!")
                    return [] 

    def getProcID(self, voutStr):
        pattern = r'^\s+(\d+)\s'
        ds = []
        dx = voutStr.split("websphr  ")
        hold = [line for line in dx if line.find("appdynamics") > -1]
        for pline in hold:
            pattern = r'^\s*(\d+)\s'  #   \s* zero or more     \s? zero or one
            k = re.compile(pattern)
            l = k.search(pline)
            if l: 
              kk = l.group(1)
              ds.append(kk)
            #==================
        re.purge()
        return ds 
        

    def display_wait(self, q, cnt=0, r=20):
        q.put(" > ")
        fr = range(r)
        while True:
            x = q.get()
            if x == "done":
                break

            for d in fr:
                sys.stdout.write("\rRunning " + x * d + "\033[K")
                sys.stdout.flush() # flush is needed
                time.sleep(1)

            if cnt % 2 == 0: 
                   fr = reversed(range(r))
                   q.put(" < ")
            else: 
                fr = range(r)
                q.put(" > ")
            cnt += 1

        q.close() # need to close the que to avoid exception

#-------------------------------End of File--------------------------------------------------
         
