import sys, re

def comdProc(serverName, command):
    print "Get ID => %s" % serverName
    ids = AdminConfig.getid("/Server:%s/" % serverName)
    patt = r'nodes/(.*?)/'
    cc = re.compile(patt).search(ids)
    nodeName = cc.group(1)
    print "Node Name: %s" % nodeName
    if command == "stop":
        mbean = AdminConfig.getObjectName(ids)
        print "Invoke stop command in server."
        try:  
            AdminControl.invoke(mbean, 'stop')
        except:
            AdminControl.stopServer(serverName, nodeName)
        print "done"
    elif command == "start":
        print "Start App server initiated"
        AdminControl.startServer(serverName, nodeName)
        print "done"
    else:
        print "Invalid command : ['stop' or 'start'] only"
        sys.exit(0)

if __name__=="__main__":
    if len(sys.argv) == 2:
        srv = sys.argv[0]
        cmd = sys.argv[1]
        comdProc(srv, cmd)
    else:
        print "====================================================================="
        print "Usage:               2 Arguments as parameter"
        print "Arguments: =>        servername and ['start' or 'stop'] command" 
        print "syntax: wsadmin.sh -lang jython -f wsadminAppCmd.py servername command"
        print "======================================================================"       
        sys.exit(0)
