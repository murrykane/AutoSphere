#------------------------------------------
# Name: wsadminJVMrestore.py
# Author: Jeffrey Apiado
# Team: IT NPO WEB
# Date: 12/05/17
# Role: Updating genericJVMArguments
#       Verify if bootClasspath has no value
#-------------------------------------------
import sys, os

def jvmProperties(argsl):
    checker = argsl[0]
    serverName = argsl[1]
    hostName = argsl[2]
    env = argsl[3]
    # checker = "Initiate" # for testing only
    # Get config id
    jId = AdminConfig.getid("/Server:%s" % serverName)
    # Get jvm Id
    jvm = AdminConfig.list("JavaVirtualMachine", jId)
    # get current value for genericJvmArguments
    currentArgs = AdminConfig.showAttribute(jvm, "genericJvmArguments")
    print currentArgs
    #--------------------------------------------
    ff = "/tmp/%s-jvm.txt" % hostName
    if os.path.isfile(ff):
        print "JVM arguments backup found"
        print "Used to restore JVM arguments!"
        ofile = open(ff, "r")
        data = ofile.read()
        ofile.close()
    else:
        data = currentArgs
    #--------------------------------------------
    if data.find("AppDynamics") > -1:
          w = "-javaagent:"
          y = "-Dappdynamics.agent"
          newArgs = filterArgs(data, w, y) 
    else:
          newArgs = data
    #Rebuild vs Legacy
    if env == "Rebuild": 
        absp = "/opt" 
    else: 
        absp = "/apps/opnet"

    bootClass(jvm, hostName, absp, checker)
    #============================================
    if checker == "Initiate":
        # concatenate output from wsadmin and define new arguments
        if newArgs.find("-Dpanorama.jida") == -1:
            defArgs = "-Dpanorama.jida.instance=WebSphere_Portal -agentpath:%s/Panorama/hedzup/mn/lib/libAwProfile64.so=verbose" % absp
            inputArgs = newArgs.strip() + ' ' + defArgs
        else:
            inputArgs = newArgs
    else: # skipped
        w = "-Dpanorama"
        y = "-agentpath:"
        cleanArgs = filterArgs(newArgs, w, y)
        inputArgs = cleanArgs

    print "[New Arguments] ==> %s" % inputArgs
    AdminConfig.modify(jvm,[['genericJvmArguments',inputArgs]])
    AdminConfig.save()
    print "JVM generic Property rollback [done]"
    print "[completed]"

#----------------------------------------
def bootClass(jvmID, hostName, absp, checker):
    bootArgs = AdminConfig.showAttribute(jvmID, "bootClasspath")
    bf = "/tmp/%s-bootpath.txt" % hostName
    if os.path.isfile(bf):
        print "Use backup for bootClassPath restore"
        ofbile = open(bf, "r")
        mrf = ofbile.read()
        ofbile.close()
    else:
        mrf = bootArgs
    #===========================
    if mrf == '' or mrf == '[]':
        print "BootclassPath current argument is Null"     
        if checker == "Initiate":
           bdata = "%s/Panorama/hedzup/mn/lib/awcore/JIDAcore.jar" % absp
        else:
           bdata = ''
        AdminConfig.modify(jvmID,[['bootClasspath', bdata]])
        AdminConfig.save()
    else:
        AdminConfig.modify(jvmID,[['bootClasspath', '']])
        AdminConfig.save()
        if checker == "Initiate":
           if mrf.find("hedzup") == -1:
               predata = "%s/Panorama/hedzup/mn/lib/awcore/JIDAcore.jar" % absp
               bdata = "%s;%s" % (mrf, predata)
           else:
               bdata = mrf
        else:
           if mrf.find("hedzup") == -1:
               bdata = mrf
           else:
               val = mrf.split(";")
               hold = [line for line in val if line.find("hedzup") == -1]
               findata = ";".join(hold)
               bdata = findata
 
        AdminConfig.modify(jvmID,[['bootClasspath', bdata]])
        AdminConfig.save()
    print "Set bootClasspath arguments [restore]"

#----------------------------------------
def filterArgs(currentArgs, w, y):
    a1 = currentArgs.find(w)
    if a1 != -1:
        k1 = currentArgs[:a1]  # keep it
        t1 = currentArgs[a1:]
        i1 = t1.find(' ')
        if i1 != -1:
            k2 = t1[i1:]  # keep it
            cArgs = k1 + k2.strip()
        else:
            cArgs = k1
    else:
        cArgs = currentArgs
    print "=====After removing %s if exists===================" % w
    print cArgs

    a2 = cArgs.find(y)
    if a2 != -1:
        keep1 = cArgs[:a2] # keep me
        tmp = cArgs[a2:]
        idx = tmp.find(' ')
        if idx != -1:
            keep2 = tmp[idx:]
            final = keep1 + keep2.strip()
        else:
            final = keep1
    else:
        final = cArgs
    print "======After removing %s if exists ==================" % y
    print final
    return final

#-----------------------------------
def usage():
    print "= " * 30
    print "Usage: Required 3 Argument to pass"
    print "SYNTAX:"
    print "  wsadmin.sh -lang jython -f wsadminJVMrestore.py nodename servername hostname"
    print "  <arguments: checker, servername, hostname, environment>"
    print "= " * 30

#-----------------------------------
if __name__=="__main__":
    if len(sys.argv) != 4:
        usage()
        sys.exit(0)
    else:
      nlist = [line for line in sys.argv]
    #--------------------------
    print "List arguments:", nlist
    jvmProperties(nlist)
 
