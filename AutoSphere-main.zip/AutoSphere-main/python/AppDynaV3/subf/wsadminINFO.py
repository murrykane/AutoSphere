import pickle
import os

#--------------------------------------------------------------------------
class dynaUtility:
    def __init__(self, filename="/tmp/dynaUTIL.txt"):
        # get all Nodes that this dmgr managed
        self.allNodeInList = AdminTask.listManagedNodes().splitlines()
        self.fname = filename

    def allNodeLoop(self):
        contain = {}
        for NODE in self.allNodeInList:
            getID = AdminConfig.getid("/Node:%s" % NODE)
            hostname = AdminConfig.showAttribute(getID, 'hostName')   # needed
            getServer = AdminConfig.list('Server', getID).splitlines()
            TYPESRV = self.getType(getServer)
            if TYPESRV != "WEB_SERVER":
                getSrvNamePrime = [srv.split("(")[0] for srv in getServer if srv.split("(")[0] != "nodeagent"]
                if getSrvNamePrime == []:
                    srvName = "nodeagent"  # no server name defined
                else:
                    srvName = getSrvNamePrime[0]    # needed
                contain[NODE] = [hostname, srvName]
            else:
                pass
        return contain

    def getType(self, sidname):
        d = [item for item in sidname if item.find("nodeagent") == -1]
        v = AdminConfig.showAttribute(d[0], 'serverType')
        return v
        
 
    def writeOutput(self, holder):
        ffile = open(self.fname, "wb")
        pickle.dump(holder,ffile)
        ffile.close()
        # verify if file exists and change permission
        out = os.system("chmod 777 %s" % self.fname)     
        if out != 0 and out > 0:
            print "[exec] change perm for file %s [failed[x]" % ffile
        else:
            print "[exec] change perm for file %s [completed[]" % ffile
               
#-----------------------------------------------------------------------------
if  __name__ == "__main__":
     util = dynaUtility()
     holder = util.allNodeLoop()
     util.writeOutput(holder)

