#------------------------------------------
# Name: wsadminJVM.sh
# Author: Jeffrey Apiado
# Team: IT NPO WEB
# Date: 10/27/17
# Role: Updating genericJVMArguments
#       Verify if bootClasspath has no value
#-------------------------------------------
import sys, os

def jvmProperties(argsl):
    nodeName = argsl[0]
    serverName = argsl[1]
    hostName = argsl[2]
    absp = argsl[3]
    flag=0
    # Get config id
    jId = AdminConfig.getid("/Server:%s" % serverName)
    # Get jvm Id
    jvm = AdminConfig.list("JavaVirtualMachine", jId)
    # get current value for genericJvmArguments
    currentArgs = AdminConfig.showAttribute(jvm, "genericJvmArguments")
    print currentArgs
    #--------------------------------------------
    ff = "/tmp/%s-jvm.txt" % hostName
    if not os.path.isfile(ff):
        print "Copy current JVM arguments to /tmp"
        ofile = open(ff, "w")
        ofile.write(currentArgs)
        ofile.close()
    else:
        print "%s already exists!" % ff
    #--------------------------------------------
    if currentArgs.find("AppDynamics") != -1: flag=1
    # get current value for bootClasspath
    bootClass(jvm, hostName)
    # Analyze currentArgs output
    # nake sure Panorama was not include remove it
    newArgs = filterArgs(currentArgs)
    defArgs = "-javaagent:%s/appagent/javaagent.jar -Dappdynamics.agent.uniqueHostId=%s" % (absp, hostName)
    # concatenate output from wsadmin and define new arguments
    inputArgs = newArgs.strip() + ' ' + defArgs
    print "[New Arguments] ==> %s" % inputArgs
    if not flag:
        AdminConfig.modify(jvm,[['genericJvmArguments',inputArgs]])
        AdminConfig.save()
        print "AppDynamics added in JVM generic Property"
    else:
        print "AppDynamics already exist in JVM generic Property"
    print "[completed]"

#----------------------------------------
def bootClass(jvmID, hostName):
    bootArgs = AdminConfig.showAttribute(jvmID, "bootClasspath")
    bf = "/tmp/%s-bootpath.txt" % hostName
    if not os.path.isfile(bf):
        print "Create backup for bootClassPath"
        ofbile = open(bf, "w")
        ofbile.write(bootArgs)
        ofbile.close()
    else:
        print "%s already exists" % bf
    if bootArgs == '' or bootArgs == '[]':
        print "BootclassPath current argument is Null[skip]"     
    else:
        holdA =  bootArgs.find("Panorama") 
        if holdA > - 1:
           holdB = bootArgs.find("JIDAcore.jar")
           idA = bootArgs[:holdA].split(" ")
           idA.pop(-1)
           idB = bootArgs[holdB:].split(" ")
           idB.pop(0)
           #--------------------------------------------
           val = "%s %s" % (" ".join(idA)," ".join(idB))
        else:
           val = bootArgs

        AdminConfig.modify(jvmID,[['bootClasspath', val]])
        AdminConfig.save()
        print "Set bootClasspath arguments [done]"

#----------------------------------------
def filterArgs(currentArgs):
    w = "-Dpanorama"
    a1 = currentArgs.find(w)
    if a1 != -1:
        k1 = currentArgs[:a1]  # keep it
        t1 = currentArgs[a1:]
        i1 = t1.find(' ')
        if i1 != -1:
            k2 = t1[i1:]  # keep it
            cArgs = k1 + k2.strip()
        else:
            cArgs = k1
    else:
        cArgs = currentArgs
    print "=====After removing %s if exists===================" % w
    print cArgs

    #y = "-agentpath:/opt/Panorama"
    y = "-agentpath:"
    a2 = cArgs.find(y)
    if a2 != -1:
        keep1 = cArgs[:a2] # keep me
        tmp = cArgs[a2:]
        idx = tmp.find(' ')
        if idx != -1:
            keep2 = tmp[idx:]
            final = keep1 + keep2.strip()
        else:
            final = keep1
    else:
        final = cArgs
    print "======After removing %s if exists ==================" % y
    print final
    return final

#-----------------------------------
def usage():
    print "= " * 30
    print "Usage: Required 3 Argument to pass"
    print "SYNTAX:"
    print "  wsadmin.sh -lang jython -f wsadminJVM.py nodename servername hostname"
    print "  <arguments: nodename, servername, hostname>"
    print "= " * 30

#-----------------------------------
if __name__=="__main__":
    if len(sys.argv) != 4:
        usage()
        sys.exit(0)
    else:
      nlist = [line for line in sys.argv]
    #--------------------------
    jvmProperties(nlist)
 
