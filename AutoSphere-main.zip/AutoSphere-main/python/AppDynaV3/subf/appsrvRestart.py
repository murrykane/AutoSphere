# ---- To Restart the Portal Server
import sys

def rstartAppSrv(nodeName):
    getSrvname = AdminConfig.getid("/Node:%s/Server:/" % nodeName).splitlines()
    Srvn = [item for item in getSrvname if item.find('nodeagent') == -1]
    serverName = AdminConfig.showAttribute(Srvn[0], 'name')

    getID = AdminConfig.getid("/Server:%s/" % serverName)
    mbean = AdminConfig.getObjectName(getID)
    other = AdminControl.queryNames('WebSphere:*,type=NodeAgent,node=%s' % nodeName)
    # restart 
    try:
        AdminControl.invoke(mbean, 'restart')
        print "[Invoke restart directly from DMGR completed]"
    except:
        AdminControl.invoke(other, 'launchProcess', [serverName],['java.lang.String'])        
        print "[Invoke restart from nodeagent]"

if __name__== "__main__":
    if len(sys.argv) == 1:
        noda = sys.argv[0]
    else:
        print "Usage: need ONE(1) argument to pass"
        print "       argument[ nodeName ]"
        sys.exit(0)
    # run funtion
    rstartAppSrv(noda)
