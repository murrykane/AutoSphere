#--------------------------------------------
# Name: dynaRun.py
# Role: Main excutable script
# Author: Jeffrey Apiado
# Owner: IT NPO-WEB TEAM
# Company: BSCA
#-------------------------------------------

# call custom library
import dynaLib as dlb
# call built in library
import os, sys, time
import argparse

# ----- MAIN ------------------------------
def main():
    logging = dlb.appLog("appdyna.log")
    logging.info("Start =========[java agent]==============================")
    print "Start =========[java agent]=============================="
    dtask = dlb.appTask(logging)
    dtask.dynaFiles() 
    dtask.zipFilesPrep("apsagent")
    print "=" * 40
    dtask.subTask()
    dtask.controllerFunction()

    print "End ============[java agent]========================"
    logging.info("End ============[java agent]========================")
    print "      ***EOF***             "
    logging.info("      ***EOF***      ")

def restartAll():
    logging = dlb.appLog("appRestart.log")
    logging.info("=> JVM restart = start now!")
    dtask = dlb.appTask(logging)
    dataBox = dtask.Filterpickle()
    logging.info("List managed supported nodes filter ")
    logging.info(dataBox)
    notListed = []
    for k, v in dataBox.items():
             h = v[0]
             stat, cont = dtask.sshCheckpoint(h)
             if stat == "acposs":
                 print "Connection established...proceed!"
             else:
                 print "Added in notListed..."
                 notListed.append(h)
    logging.info("Verify host who unsuccesfully failed to connect[protocol: ssh]")
    logging.info(notListed)
    for key, val in dataBox.items():
        if val[0] not in notListed:
            dtask.restartJVM(key, val[0], val[1])
            dtask.run(val[0], val[1], key)
            time.sleep(5)
    time.sleep(10) # give time to let queue finish before script exit
    print "=======done==================="
    logging.info("========done===========")
                            
def startMacagent():
    logging = dlb.appLog("startMachineAgent.log")
    logging.info("=> start now! [machine-agent]")
    dtask = dlb.appTask(logging)
    dataBox = dtask.Filterpickle()
    logging.info("List managed supported nodes filter ")
    logging.info(dataBox)
    notListed = []
    apool = []
    for kk, vv in dataBox.items():
           h = vv[0]
           stat, cont = dtask.sshCheckpoint(h)
           if stat == "acposs":
              print "Connection established...proceed!"
              wildPath = dtask.lookup_ret(h)
              apool.append(wildPath)
           else:
              print "Added in notListed..."
              notListed.append(h)
    logging.info("Verify host who unsuccesfully failed to connect[protocol: ssh]")
    logging.info(notListed)
    sm = set(apool)
    macPath = set.pop(sm)
    dtask.nohupMacAgent(dataBox, notListed, macPath)
    print "=============end=============="
    logging.info("===========end=========")            

def installMacagent():
    logging = dlb.appLog("appdyna.log")
    logging.info("Start ==========[Machine agent]================")
    print "Start ==========[Machine agent]================"
    dtask = dlb.appTask(logging)
    dtask.macFiles() 
    dtask.zipFilesPrep("machineagent")
    print "=" * 40
    dataBox = dtask.Filterpickle()
    logging.info("List managed supported nodes filter ")
    logging.info(dataBox)
    notListed = []
    pool = []
    for kkk, vvv in dataBox.items():
           h = vvv[0]
           stat, cont = dtask.sshCheckpoint(h)
           if stat == "acposs":
              print "Connection established...proceed!"
              wildPath = dtask.lookup_ret(h)
              pool.append(wildPath)
              dtask.Rzip('machineagent',h ,wildPath)
           else:
              print "Added in notListed..."
              notListed.append(h)
    logging.info("Verify host who unsuccesfully failed to connect[protocol: ssh]")
    logging.info(notListed)
    wpath = set(pool)
    xpath = set.pop(wpath)
    dtask.macControllerFunction(dataBox, notListed, xpath, cont)
    print "End ============[Machine agent]=================="
    logging.info("End ============[Machine agent]==================")
    print "          ***EOF***           "
    logging.info("       ***EOF***      ")

def rollBack():
    logging = dlb.appLog("appdyna.log")
    logging.info("Start ==========[RollBack]================")
    print "Start ==========[RollBack]================"
    dtask = dlb.appTask(logging)
    print "=" * 40
    dataBox = dtask.Filterpickle()
    logging.info("List managed supported nodes filter ")
    logging.info(dataBox)
    notListed = []
    rool = []
    for Key, Val in dataBox.items():
       h = Val[0]
       stat, cont = dtask.sshCheckpoint(h)
       if stat == "acposs":
           print "Connection established...proceed!"
           wildPath = dtask.lookup_ret(h)
           rool.append(wildPath)
       else:
           print "Added in notListed..."
           notListed.append(h)
    logging.info("Verify host who unsuccesfully failed to connect[protocol: ssh]")
    logging.info(notListed)
    rollPath = set(rool)
    rp = set.pop(rollPath)
    dtask.rollOverProc(dataBox, notListed, rp, cont)
    



if __name__=="__main__":
    parser = argparse.ArgumentParser(description="AppDynamics agent installation")
    parser.add_argument("-a",
                          "--action",
                            required=True,
                            	help="Select Action [ ia=install AppAgent; ma=install MacAgent; sm=start MacAgent; ro=rollBack]",
                              		choices=["ia", "ma", "sm", "ro"],
                                		type=str)
    args = parser.parse_args()
    if args.action == "ia":                          
        main()
    elif args.action == "ma":
        installMacagent()
    elif args.action == "sm":
        startMacagent()
    elif args.action == "ro":
        rollBack()
    else:
        sys.exit()
        
        









        




