# ===============================================
# Role: manage websphere shared library reference
# Author: Jeffrey Apiado
# Property: IT NPE WEB TEAM
# Input: shared library name 
# Support Data Type: STRING or Array
# Action/Result/output: deletion/removal
# Created: 1/19/2020
# ===============================================
import re, os

__FILE__ = "removeSharedLib.py"

class sharedlib:
     def __init__(self, share_libaries):
          # share_libraries type list - pass as an argumrnt to main script
          self.libshare = share_libaries
          # lets get all application server bean managed by this dmgr
          self.servers = AdminTask.listServers('[-serverType APPLICATION_SERVER ]').splitlines()
     
     #====================================================
     # main method: tasklist
     # input: None
     # return: None
     # ===================================================
     def tasklist(self):
         for srv in self.servers:
             gidvar = self.__varFormat_value(srv)
             print "CONSTRUCT argument to pass: %s" % gidvar
           
             gid = AdminConfig.getid(gidvar)   
             classloader = AdminConfig.list('Classloader', gid)
             print "ClassLoader: %s" % classloader
             libname_raw = self.__getSharedLib_inLoader(classloader)
             # =====================================================
             for library in self.libshare:
                  for libraw in libname_raw:
                       yyy = AdminConfig.showAttribute(libraw,'libraryName').strip()
                       rxcompile = re.compile(library, re.IGNORECASE)
                       rxmatch = rxcompile.match(yyy)
                       if rxmatch:
                          #remove it here!  
                          AdminConfig.remove(libraw)
                       else:
                          continue
                       print "Library shared name %s removed SUCCESFULLY .... for %s" % (yyy, srv)
             # ==== save after removing ===================================             
             AdminConfig.save()          
             
     # ======================================================
     # private class method: __varFormat_value
     # input: server java bean
     # output: return string pass asan  argument for config id
     # =======================================================    
     def __varFormat_value(self, _srv):
          servern, prop = _srv.split("(")
          print "SERVER NAME: %s ===============================================" % servern
          rest = prop.split("/")
          STR = "/"
          for line in rest:
            if line.startswith("cells") or line.startswith("nodes") or line.startswith("servers"):
               STR += line[0:-1].capitalize() + ":"
            elif line.find("|") > -1:
               s, xml = line.split("|")
               STR += s + "/"
            else:
               STR += line + "/"
          return STR

     # ==============================================
     # private class method: __getSharedLib_inLoader
     # input: classloader resource
     # output: return a list of formatted classloader
     # ==============================================
     def __getSharedLib_inLoader(self, loader):
          holder = []
          line = AdminConfig.showAttribute(loader, 'libraries')
          if line.find(" ") != -1:
             splitter = line.split(" ")
             for item in splitter:
                 if item.find("[") != -1:
                    item = item[1:].strip()
                 elif item.find("]") != -1:
                    item = item[:-1].strip()
                 holder.append(item)
                    
          else:
             if line.startswith("[") and line.endswith("]"):
                     var = line[1:-1]
                     item = var.strip()
             else:
                  item = line
             holder.append(item)
          return holder


if __name__ == "__main__":
     if len(sys.argv) > 0:
            shrlib = sys.argv
     else:
         print ""
         print "------------------------USAGE----------------"
         print "Invoke %s with wsadmin.sh" % __FILE__
         print "syntax: %s [args]: shared libraries" % __FILE__
         print "example: %s bar foo zoi" % __FILE__
         print "         %s foo" % __FILE__
         print "accept: string or array as data type"
         print "---------------------------------------------"
         print ""
         os._exit(0)       
     # ====================================================
     print "Using shared library name: %s" % shrlib
     # create an instance class instance called obj
     obj = sharedlib(shrlib)
     obj.tasklist()




      
