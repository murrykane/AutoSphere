#--------------------------------------------
# Name: apmLIB.py
# Role: common libraries 
# Author: Jeffrey Apiado (IT_NPO_WEB_TEAM)
# Last Modification Date: 1/31/2018
#--------------------------------------------
import ConfigParser
import StringIO
import subprocess
import os, pickle, re, sys
from base64 import binascii
import ast, time, logging, random
#-----------------------------------------------------------------
# Class description: for parsing item values in apmCONFIG.ini file
#-----------------------------------------------------------------
class UTILITY:
    def __init__(self,parse):
        self.parse = parse 
       
    def apmConfigSelect(self):
        hold = []
        for name, value in self.parse.items("AGENT"):
            f = self.parse.getint("AGENT",name)
            if f is 1:
               hold.append(name)
            else:
               pass
        return hold

    def DmgrAgent(self):
       OPT = self.parse.get("DMGR", "opt")
       return OPT

    def WebAgent(self):
        OPT = self.parse.get("IHS","opt") 
        return OPT

    def AppAgent(self):
        OPT = self.parse.get("APP", "opt")
        return OPT

    def wsadminVar(self):
        VAR = self.parse.get("WPATH", "wsvar")
        return VAR

    def wsadminNode(self):
        NOD = self.parse.get("WPATH", "wsallnode")
        return NOD
 
    def wsadminVeal(self):
        VER = self.parse.get("WPATH", "wsunveal")
        return VER

    def getTarfilename(self):
        tar = self.parse.get("TARFILE", "tarfile")
        return tar

    def credentialDefault(self):
        adm = self.parse.get("CREDENTIAL", "adm_id")
        admr = ast.literal_eval(adm)
        pwd = self.parse.get("CREDENTIAL", "pwd_id")
        pwdr = ast.literal_eval(pwd)
        return (admr, pwdr)

    def getAPMshell(self):
        extr = self.parse.get("TARFILE", "extract")
        return extr

    def getCerts(self):
        certif = self.parse.get("CERTS", "cert")
        certs = ast.literal_eval(certif)
        return certs

#----------------------------------------------------------------------
# class description: contains utility modules, used by apmEngine script
#----------------------------------------------------------------------
class SOURCE:
    def execProc(self, cmd):
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr = subprocess.PIPE, shell=True)
        except subprocess.CalledProcessError as e:
            print e.output
        stdout, stderr = proc.communicate()
        if not stderr or stderr == "":
            buff = StringIO.StringIO()
            buff.write(stdout)
            Output = buff.getvalue()
            buff.flush()
            buff.close()
            return Output
        else:
            Output = ""
            return Output 
      
    def simpleProc(self, cmd):
        ex = os.system(cmd)
        print "execution return value %d" % ex
        if ex > 0:
            print "[Running] external command [error]" 
        else:
            print "[Running] external process [completed]" 
    
    def verifyEnvToRun(self):
        if os.path.isfile("/etc/virtualimage.properties") is False:
            print "[env] => [Legacy][BlueClouds]"
            return 0
        else:
            print "[env] => [Rebuild][PureApps]"
            return 1

    def pre_execWsadmin(self):
        xval = []
        for directory in os.listdir("/opt"):
             d = "/opt/{0}/WebSphere/AppServer/bin/wsadmin.sh".format(directory)
             if os.path.isfile(d) == True:
                 val1 = "/opt/{0}/WebSphere/".format(directory)
                 xval.append(val1)
        #<=============================================================>
        if xval == []: # default
            xval.append("/opt/WebSphere/")
        print "[Return value for wsadmin path:] ==> ", xval
        global wasppath
        wasppath = xval[0]
        print "[wasppath] >",wasppath
        return xval[0]    

    def DEserialized(self, filename):
        if os.path.isfile(filename):
            with open(filename, "rb") as frr:
                dumpster = pickle.load(frr)
            return dumpster 
        else: 
            print "[filename can't locate]"
            return {}

    def appBuildname(self, finalForm):
          k, l = finalForm.split(".", 1)
          h = l.upper()
          apps = "%s-%s" % (h, k)
          return apps

    def getProfile(self, userPath):
        profile = userPath.split("/")[-1]
        appName = userPath.split("/")[2]
        return profile, appName

    def DMGRDisplay(self, connHost, cellName):
       dmgr = "[START][APPS NAME: DMGR (%s)] .............[CELL: %s]" % (connHost, cellName)
       DMG = len(dmgr)
       print ""
       print "\t\t" + "=" * DMG
       print "\t\t" + dmgr
       print "\t\t" + "=" * DMG
       print ""
       self.cellName = cellName

    def installBUILD(self, agentVar, aname, filename, wpath, cenv, rt=0):
       installFile = open(filename, "w")
       installFile.write('License_Agreement="I agree to use the software only in accordance with the installed license."\n')
       installFile.write("INSTALL_AGENT=%s\n" % agentVar)
       if rt:
           print "[Adding rtm to http_server response file]"
           installFile.write("INSTALL_AGENT=rt\n")
       if not cenv:
           installFile.write("AGENT_HOME=/apps/%s/apm/agent/\n" % aname)
       else:
           installFile.write("AGENT_HOME=%sapm/agent/\n" % wpath)
       installFile.close()
       print "\tcustom_installation file done"
       print ""

    def wimConfig(self, appName, profileName, userID, passwordID, filename, wpath, env, upathh):
        responseFile = open(filename, "w")
        if not env:
            responseFile.write("JAVA_HOME=/apps/%s/apm/agent/JRE/lx8266/jre\n" % appName)
            responseFile.write("KQZ_JMX_JSR160_JSR160_WAS_HOME=/apps/%s/profiles/%s\n" % (appName, profileName))
        else:
            responseFile.write("JAVA_HOME=%sapm/agent/JRE/lx8266/jre\n" % wpath)
            responseFile.write("KQZ_JMX_JSR160_JSR160_WAS_HOME=%s\n" % upathh)

        responseFile.write("KQZ_JMX_JSR160_JSR160_USER_ID=%s\n" % userID)  
        responseFile.write("KQZ_JMX_JSR160_JSR160_PASSWORD=%s\n" % passwordID)
        responseFile.close()
        print "\twimresponse_config file done"
        print ""

    def checkInstance(self, appNAME, agent, wpath, env, connectTo="Dmgr"):
        print "[checkInstance]: ", wpath
        if connectTo == "Dmgr":
            if not env: #legacy"
                STRING = "/apps/{0}/apm/agent/bin/{1}".format(appNAME, agent)
            else:
                STRING = "{0}apm/agent/bin/{1}".format(wpath, agent)
            if os.path.isfile(STRING): # True
                return "Skip"
            else:
                return "Install"
        else:
            if not env:
                cmd = "ssh {0} 'find /apps/{1}/apm/agent/bin -type f -name {2}'".format(connectTo, appNAME, agent)
            else:
                cmd = "ssh {0} 'find {1}apm/agent/bin -type f -name {2}'".format(connectTo, wpath, agent)

            result = self.execProc(cmd)
            if agent in result and result != "":
                return "Skip"
            else:
                return "Install"

    def chkwimInstance(self, appName, wpath, env):
        if not env:
            command = "/apps/{0}/apm/agent/bin/wim-agent.sh status".format(appName)
        else:
            command = "{0}apm/agent/bin/wim-agent.sh status".format(wpath)
        print "[command] %s" % command
        result = self.execProc(command)
        if result.find("No instance") != -1:
            return "Config"
        else:
            return "Skip"

    def chkDirExists(self, dirpath, connectTo="Local"):
        if connectTo == "Local":
            if os.path.exists(dirpath) == False:
                try:
                    os.makedirs(dirpath)
                    return "Created"
                except:
                    print "[error in creating directory {0}]".format(dirpath)
            return "Skip"      
        else:
            cmd = 'ssh %s "mkdir -vp %s"' % (connectTo, dirpath)
            self.simpleProc(cmd)


    def silentEngine(self, shellpath, connectTo="Local"):
        if connectTo == "Local":
            command = "{0} -p /tmp/custom_silent_install.txt".format(shellpath)
        else:
            command = "ssh {0} '{1} -p /tmp/custom_silent_install.txt'".format(connectTo, shellpath)
        result = self.execProc(command)
        if "successfully" in result:
            n = result.find("successfully")
            print "\t:-)"
            print "\t[info] %s" % result[n:]
            print "\t[completed]"
            print ""
        else:
            print "\t:-("
            print "\t[ERROR]"
            print ""

    def wasConfigEngine(self, Cname, appname, yndf, env, wwpath):
        if not env:
            pvcmd = 'ssh %s "/apps/%s/apm/agent/yndchome/%s/bin/config.sh -silent /tmp/custom_silent_config.txt"' % (Cname, appname, yndf)
        else:
            pvcmd = r'''ssh %s "export JAVA_HOME=%sAppServer/java;export PYTHONPATH="";%sapm/agent/yndchome/%s/bin/config.sh -silent /tmp/custom_silent_config.txt"''' % (Cname, wwpath, wwpath, yndf)
        print "[exec] %s" % pvcmd
        resp = self.execProc(pvcmd)
        if "(OK)" in resp:
            print "\t:-)"
            print "\tSummary ",resp[resp.find("(OK)"):]
            print "\tAgent configuration completed without error"
            print ""
        else:
            print "\t:-("
            print "\tAgent configuration error occur"
            print resp

        

    def wimConfigEngine(self, appName, hostName, wpath, env):
         rand = random.randint(100, 500)
         instanceName = "INSTANCE{0}".format(rand)
         if not env:
              command = "/apps/{0}/apm/agent/bin/wim-agent.sh config {1} /tmp/wimresponse_config.txt".format(appName, instanceName)
         else:
              print "INSTANCE_NAME: ",instanceName
              command = "{0}apm/agent/bin/wim-agent.sh config {1} /tmp/wimresponse_config.txt".format(wpath, instanceName)
         self.instance = instanceName
         print "[command to exec] %s" % command
         result = self.execProc(command)
         if "completed successfully" in result:
            n = result.find("completed")
            print "\t:-)"
            print "\t[info] %s" % result[n:]
            print "\t[completed]"
            print ""
         else:
            print "\t:-("
            print "\t[ERROR]"
            print ""

    #======================================================================
    def profileRx(self, hostName, wwpath):
         cmd = r'''ssh {0} "cat {1}AppServer/properties/profileRegistry.xml | grep path"'''.format(hostName, wwpath)
         output = self.execProc(cmd)
         pattern = re.compile(r'''path="(.*?)"''')
         val = pattern.search(output)
         if val:
             return val.group(1)
         else:
             return None


    def createSYMLINK(self, appName, profName, wpath, env, userPath):
        if not env:
            cmd = "ln -s /opt/WebSphere/AppServer/runtimes /apps/{0}/profiles/{1}".format(appName, profName)
        else:
            cmd = "ln -s {0}AppServer/runtimes {1}".format(wpath, userPath)
        try:
            os.system(cmd)
            print "[symbolic link created]"
        except:
            print "File exists [symbolic link]"

    def verifyCerts(self, appName, profName, cert):
        # ---- Generate Certificate -----
        print "[command exec to extract root cert]"
        head = "/opt/WebSphere/AppServer/java/bin/java com.ibm.gsk.ikeyman.ikeycmd -cert -extract -db"
        tail = "/apps/WEB*-dm1/profiles/WEB*/config/cells/WEB*/nodes/WEB*Dmg*/root-key.p12 -pw WebAS -label root -target /tmp/root.cer"
        pre_cmd = "{0} {1}".format(head, tail)
        print "[command to exec] %s" % pre_cmd
        self.simpleProc(pre_cmd)
        print "[command complete]"
        # -------------------------------------
        if os.path.isfile("/tmp/root.cer"): 
            for item in os.listdir("/tmp"):
                if item.find("root.cer") != -1:
                    cert.append(item)
        else:
            print "[Failed to extract root cert]"
        # --------------------------------------
        #com, end = appName.split("-", 1)
        #commonName = com + "-common"
        for certificate in cert:
            r1path = "/tmp/{0}".format(certificate)
            msg = "COPY the {0} to /tmp directory then, <HIT ENTER>".format(certificate)
            self.promptForCert(r1path, msg)   
            self.addKeystoreCert(appName, profName, certificate)
 
    def rebuildCerts(self, cert, upath, wpath, cellName, nodeName):
       # ---- Generate Certificate -----
        print "[command exec to extract root cert]"
        head = "{0}AppServer/java/bin/java com.ibm.gsk.ikeyman.ikeycmd -cert -extract -db".format(wpath)
	tail = "{0}/config/cells/{1}/nodes/{2}/root-key.p12 -pw WebAS -label root -target /tmp/root.cer".format(upath, cellName, nodeName)
        pre_cmd = "{0} {1}".format(head, tail)
        print "[command to exec] %s" % pre_cmd
        self.simpleProc(pre_cmd)
        print "[command complete]"
        # -------------------------------------
        if os.path.isfile("/tmp/root.cer"):
            for item in os.listdir("/tmp"):
                if item.find("root.cer") != -1:
                    cert.append(item)
        else:
            print "[Failed to extract root cert]"
        #---------------------------------------
        for certificate in cert:
            r1path = "/tmp/{0}".format(certificate)
            msg = "COPY the {0} to /tmp directory then, <HIT ENTER>".format(certificate)
            self.promptForCert(r1path, msg)   
            self.rebuildKeystoreCert(certificate, upath, wpath)

    def promptForCert(self, path, msg):
        while True:
           if os.path.isfile(path):
               break
           response = raw_input(msg) 
        print "[certificate FOUND]"

    def addKeystoreCert(self, APPNAME, PROFILE, certificate):
       label, x = certificate.split(".",1)
       pre = "/opt/WebSphere/AppServer/java/jre/bin/java com.ibm.gsk.ikeyman.ikeycmd -cert -add -db"
       mid = "/apps/{0}/profiles/{1}/etc/DummyClientTrustFile.jks -pw WebAS".format(APPNAME, PROFILE)
       end = "-file /tmp/{0} -label {1}".format(certificate, label)
       construct = "{0} {1} {2}".format(pre, mid, end)
       print "[command] %s" % construct
       output = self.execProc(construct)
       if output == "":
           print "[certificate added]"
       else:
           print "[error] ", output
       print "[done]"


    def rebuildKeystoreCert(self, certificate, userPath, wwpath):
       label, x = certificate.split(".",1)
       pre = "{0}AppServer/java/jre/bin/java com.ibm.gsk.ikeyman.ikeycmd -cert -add -db".format(wwpath)
       mid = "{0}/etc/DummyClientTrustFile.jks -pw WebAS".format(userPath)
       end = "-file /tmp/{0} -label {1}".format(certificate, label)
       construct = "{0} {1} {2}".format(pre, mid, end)
       print "[command] %s" % construct
       output = self.execProc(construct)
       if output == "":
           print "[certificate added]"
       else:
           print "[error] ", output
       print "[done]"

    def startAgent(self, appname, agent, wpath, env, connectTo=None):
        print "[connect to:] [%s]" % connectTo
        if connectTo is None:
            if agent == "wim":
                 if not env:
                     command1 = "/apps/{0}/apm/agent/bin/wim-agent.sh status".format(appname)
                 else:
                     command1 = "{0}apm/agent/bin/wim-agent.sh status".format(wpath)
                 result = self.execProc(command1)
                 print "[command output]: ",result
                 if "not" in result:
                     print "[starting wim agent]"
                     if not env:
                          command2 = "/apps/{0}/apm/agent/bin/wim-agent.sh start {1}".format(appname, self.instance)
                     else:
                          command2 = "{0}apm/agent/bin/wim-agent.sh start {1}".format(wpath, self.instance)
                     print "[command] %s" % command2
                     output = self.execProc(command2)
                     if "started" in output:
                         x = output.find('started')
                         print output[x:]
                         print "[succesfully started]"
                     else:
                         print "[starting failed]"
                 else:
                     print "[wim agent already started]"

    def startHTTPAgent(self, appname, agent, connectTo, env, wasPathIHS):
            if agent == "http_server":
                if not env:
                    command1 = "ssh {0} '/apps/{1}/apm/agent/bin/http_server-agent.sh status'".format(connectTo, appname)
                else:
                    command1 = "ssh {0} '{1}apm/agent/bin/http_server-agent.sh status'".format(connectTo, wasPathIHS)
                result = self.execProc(command1)
                time.sleep(5)
                if "running" in result:
                    # STOP
                    print "Stopping the agent [http_server]"
                    if not env:
                        command2 = "ssh {0} '/apps/{1}/apm/agent/bin/http_server-agent.sh stop'".format(connectTo, appname)
                    else:
                        command2 = "ssh {0} '{1}apm/agent/bin/http_server-agent.sh stop'".format(connectTo, wasPathIHS)
                    self.simpleProc(command2)
                    time.sleep(5)
                    # STARTING
                    print "Starting the agent [http_server]"
                    if not env:
                        command3 = "ssh {0} '/apps/{1}/apm/agent/bin/http_server-agent.sh start'".format(connectTo, appname)
                    else:
                        command3 = "ssh {0} '{1}apm/agent/bin/http_server-agent.sh start'".format(connectTo, wasPathIHS)
                    self.simpleProc(command3)
                    time.sleep(5)
                else:
                    print "HTTP agent is down"
                    # STARTING
                    print "Starting the agent [http_server]"
                    if not env:
                        command3 = "ssh {0} '/apps/{1}/apm/agent/bin/http_server-agent.sh start'".format(connectTo, appname)
                    else:
                        command3 = "ssh {0} '{1}apm/agent/bin/http_server-agent.sh start'".format(connectTo, wasPathIHS)
                    self.simpleProc(command3)
                    time.sleep(5)

   
    def sshCheckpoint(self, remoteHost):
        sys.stdout.write("[check ssh connection] . . . . . . . . .")
        sshcmd = "ssh -q -o BatchMode=yes -o ConnectTimeout=10 {0} exit".format(remoteHost)
        print "[exec] %s" % sshcmd
        sshSys = subprocess.Popen(sshcmd, stderr = subprocess.PIPE, shell=True)
        stderr = sshSys.communicate()[1]
        print "stderr value: ",stderr
        if stderr:
           print ""
           return "noposs"
        elif not stderr:
           print "[accessible]"
           return "acposs"        

    def Rsync(self, hostName, fg=1, cfile=None):
        if fg and cfile == None:
            copycmd = "rsync -avh --inplace /tmp/APM/** %s:/tmp/APM" % hostName
        if not fg and cfile != None:
            copycmd = "rsync -avh --inplace %s %s:/tmp/" % (cfile,hostName)
        print "[command to execute] %s" % copycmd
        runtime = subprocess.Popen(copycmd, stderr = subprocess.PIPE, shell=True)
        sys.stdout.write("[copy file] to remote server . . . . . . . ")
        error = runtime.communicate()[1]
        if error:
            print error
        else:
            print "[completed]"
 
    def setUP(self, hostname, apn, env, wwpath):
        if not env:
            dpath = "/apps/{0}/apm/agent".format(apn)
        else:
            dpath = "{0}apm/agent".format(wwpath)
        print "[command] %s" % dpath
        self.chkDirExists(dpath, hostname)     #/apps/<name>/apm/agent
        self.Rsync(hostname)


    def setdisplay(self, hostName, serverName, serverType, nodeName, cellName, profileName):
        appvar = "[] App Server : %s.blueshieldcloud.net" % hostName
        napp = len(appvar)
        print ""
        print "\t\t" + ("=" * napp)
        print "\t\t%s" % appvar
        print "\t\t" + ("=" * napp)
        print "\t\t Server Name: ", serverName
        print "\t\t Server Alias: ", serverName
        print "\t\t Server Type: ", serverType
        print "\t\t Node name: ", nodeName
        print "\t\t Cell Name: ", cellName
        print "\t\t Profile Name: ", profileName
        print "\t\t" + ("=" * napp)

    def checkHTTPDstatus(self, remoteSrv, env, wasPath):
        cmd = r'''ssh {0} "ps -ef | sed -n '/HTTPServer -k start -f/p'"'''.format(remoteSrv)
        print "[command to execute] %s" % cmd
        result =  self.execProc(cmd)
        print "result: ",result
        patt = re.compile("start -f (.*)")
        src = re.search(patt, result)
        print "SRCregeX:",src
        if src.group(1):
                print "HTTP server is [running]"
                return src.group(1)
        else:
                print "HTTP server [need to start]"
                self.apacheSTOPSTART(remoteSrv, src.group(1), env, wasPath, "green")
                return None

    def webName(self, rsrv):
        v = rsrv.split(".")
        n = "{0}-{1}".format(v[1], v[0])
        return n
    
    def apacheSTOPSTART(self, remoteSrv, confpath, env, wasPathIHS, ext):
        if ext == "red":
            print "APACHE --------- [STOP]"
            if not env: # Legacy
                remSrv = self.webName(remoteSrv)
                command = "ssh {0} '/opt/WebSphere/HTTPServer/bin/apachectl -k stop -f /apps/WEB*/conf/{1}.conf' >> /tmp/Apache.txt".format(remoteSrv, remSrv)
            else:
                command = "ssh {0} '{1}HTTPServer/bin/apachectl -k stop -f {2}' >> /tmp/Apache.txt".format(remoteSrv, wasPathIHS, confpath)
            print "[command] %s" % command
            self.simpleProc(command)
            ext = "echo '     output from--> %s' >> /tmp/Apache.txt" % remoteSrv
            self.simpleProc(ext)

        elif ext == "green":
            print "APACHE --------- [START]"
            if not env: # Legacy
                remSrv = self.webName(remoteSrv)
                command = "ssh {0} '/opt/WebSphere/HTTPServer/bin/apachectl -k start -f /apps/WEB*/conf/{1}.conf' >> /tmp/Apache.txt".format(remoteSrv, remSrv)
            else:
                command = "ssh {0} '{1}HTTPServer/bin/apachectl -k start -f {2}' >> /tmp/Apache.txt".format(remoteSrv, wasPathIHS, confpath)
            print "[command] %s" % command
            self.simpleProc(command)
            est = "echo '     output from--> %s' >> /tmp/Apache.txt" % remoteSrv
            self.simpleProc(est)
        print "[done]"

    def addKhutoHTTPD(self, appname, hostname, env, wpath, confp):
        if not env:
            httpDIR = "/apps/{0}/conf/{1}.conf".format(appname,appname.lower())
            confDIR = "/apps/{0}/apm/agent/tmp/khu".format(appname)
            confFILE = "khu.apps.{0}.conf.{1}.conf".format(appname,appname.lower())
            cmd = "ssh {0} 'find {1} -type f -name {2}'".format(hostname, confDIR, confFILE)
            print "[command] %s" % cmd
            result = self.execProc(cmd)
            if "khu.apps" in result:
                print "[KHU config file found]"
                pass
            else: 
                print "WARNING: [missing http_server config file [RESTART THE HTTP AGENT]"
                self.startHTTPAgent(appname, "http_server", hostname, env)
            # ---------------------Create Backup-------------------------------
            print "[creating backup for http config file]"
            command = "ssh {0} 'cp {1} /apps/{2}/conf/web_apmbackup.conf'".format(hostname, httpDIR, appname)
            #command = "ssh {0} 'cp /apps/{1}/conf/web*.conf /apps/{2}/conf/web_apmbackup.conf'".format(hostname, appname, appname)
            print "[command] %s" % command
            self.simpleProc(command)
            print "[command completed]"
            # -----------------------------------------------------------------
            subcmd = r"""grep "{0}" {1} -c""".format("khu.apps", httpDIR)
            xcmd = "ssh {0} '{1}'".format(hostname, subcmd)
            print "[command] %s" % xcmd
            result = self.execProc(xcmd)
            if int(result) != 0:
                    print "[Include statement already added in the http file]"
            else:
                    print "[Adding Include statement to http config]"
                    statement = os.path.join(confDIR,confFILE)
                    print "[statement] Include '{0}'".format(statement)
                    cmd = r"""echo -e "\nInclude '{0}'" >> {1}""".format(statement, httpDIR)
                    xcmd = "ssh {0} '{1}'".format(hostname, cmd)
                    print "[command] %s" % xcmd
                    self.simpleProc(xcmd)
                    print "[completed]"
        # PureApps/Rebuild ======================================================
        elif env:
            hold1 = confp.split("/")
            print "hold1 >",hold1
            hold2 = ".".join(hold1)
            print "hold2 >",hold2
            hold3 = hold1[-1]
            print "hold3 >",hold3
            hold4 = hold1[1:-1]
            hold5 = "/".join(hold4)
            print "hold4 > ",hold4
            confDIR = "{0}apm/agent/tmp/khu".format(wpath)
            confFILE = "khu{0}".format(hold2)
            cmd = "ssh {0} 'find {1} -type f -name {2}'".format(hostname, confDIR, confFILE)
            print "[command] %s" % cmd
            result = self.execProc(cmd)
            if hold2 in result:
                print "[continue]"    
            else:
                print "WARNING: [missing http_server config file [RESTART THE WEB SERVER]]"
		self.startHTTPAgent(appname, "http_server", hostname, env, wpath)
            #===================================================================================
            #httpDIR = "{0}".format(confp)
            #-----------------Create Backup------------------
            print "[Backup for httpd config file]"
            cmd = "ssh {0} 'cp {1} {2}.bak'".format(hostname, confp, confp)
            print "[command] %s" % cmd
            self.simpleProc(cmd)
            print "[creating backup done]"
            #-----------------------------------------------
            subcmd = r"""grep "{0}" /{1} -c""".format(hold3, confp)
            xcmd = "ssh {0} '{1}'".format(hostname, subcmd)
            print "[command] %s" % xcmd
            result = self.execProc(xcmd)
            if int(result) != 0:
                  print "[Include statement already added in the http file]"
            else:
                  print "[Adding Include statement to http config]"
                  statement = os.path.join(confDIR, confFILE)
                  print "[statement] Include '{0}'".format(statement) 
                  cmd = r"""echo -e "\nInclude '{0}'" >> {1}""".format(statement, confp)
                  xcmd = "ssh {0} '{1}'".format(hostname, cmd)
                  print "[command] %s" % xcmd
                  self.simpleProc(xcmd)
                  print "[completed]"
            

    def yndchome(self, appn, srvRemote, env, wwpath):
        ynd = ""
        valf = 0
        sys.stdout.write("[yndchome folder lookup] . . . . .  . . .  . ")
        if not env:
            cmd = 'ssh %s "ls /apps/%s/apm/agent/yndchome/"' % (srvRemote, appn)
        else:
            cmd = 'ssh %s "ls %sapm/agent/yndchome/"' % (srvRemote, wwpath)
        print "[exec] %s" % cmd
        yss = self.execProc(cmd)         
        if yss is False or yss == "":
            print "WARNING: [missing dir] in /yndchome folder > was agent need to be configured"
            print "[configuring]"
            return "Config"
        else:
            print "[acquired folder name for yndchome directory] ",yss 
            directory = yss.strip() # strip end spaces in a STRING
            print "[confirm if current installation was done . . .]"
            if not env:
                sh = "find /apps/{0}/apm/agent/yndchome/{1}/data -type f -name {2}".format(appn, directory, "config-trace.log")
            else:
                sh = "find {0}apm/agent/yndchome/{1}/data -type f -name {2}".format(wwpath, directory, "config-trace.log")
            cmd = 'ssh {0} "{1}"'.format(srvRemote, sh)
            print "[exec] %s" % cmd
            datas = self.execProc(cmd)
            print "<datas> ",datas
            if datas.find("config-trace.log") == -1 or datas == "":
                print "[no file found] [configuring]" 
                return directory
            else:
                print "[files found (config-trace.log) ['previous configuration was done already'][skipping]"
                return "Skip"


    def wasconfigBuild(self, defaultSection, serverSection):
          sys.stdout.write("[Creating silent_config.txt file] . . . . . . ")
          cfgFile = open("/tmp/custom_silent_config.txt", "wb")
          cfgFile.write("[DEFAULT SECTION]\n")
          #---------------------------------------------------------
          # Note: wishing to make this part flexible in next release
          # Websphere Applications monitoring agent
          #---------------------------------------------------------
          cfgFile.write("temaconnect=True\n")
          cfgFile.write("tema.appserver=True\n")
          cfgFile.write("tema.host=127.0.0.1\n")
          cfgFile.write("tema.port=63335\n")
          cfgFile.write("tema.jmxport=63355\n")

          # disable V6 agent
          cfgFile.write("config.tema.v6=False\n")
          cfgFile.write("was.wsadmin.connection.host=%s\n" % defaultSection[0])
          cfgFile.write("was.wsadmin.connection.type=%s\n" % defaultSection[1])
          cfgFile.write("was.wsadmin.connection.port=%s\n" % defaultSection[2])
          cfgFile.write("was.wsadmin.username=%s\n" % defaultSection[3])
          cfgFile.write("was.wsadmin.password=%s\n" % defaultSection[4])
          cfgFile.write("was.client.props=%s\n" % defaultSection[5])
          cfgFile.write("was.appserver.profile.name=%s\n" % defaultSection[6])
          cfgFile.write("was.appserver.home=%s\n" % defaultSection[7])
          cfgFile.write("was.appserver.cell.name=%s\n" % defaultSection[8])
          cfgFile.write("was.appserver.node.name=%s\n" % defaultSection[9])
          cfgFile.write("\n")
          cfgFile.write("[SERVER]\n")
          cfgFile.write("was.appserver.server.name=%s\n" % serverSection[0])
          cfgFile.write("tema.serveralias=%s\n" % serverSection[1])
          cfgFile.close()
          print "[done]"
          sys.stdout.write("[opening permission] . . . . . . ")
          sos = os.system("chmod 777 /tmp/custom_silent_config.txt")
          if sos > 0:
              print ""
          else:
              print "[done]"
  
    def wasRestart(self, appname, env, wwpath, connectTo="Local"):
        stop = 0
        if connectTo != "Local":
            if not env:
                wasRemote_cmd = 'ssh %s "/apps/%s/apm/agent/bin/was-agent.sh status"' % (connectTo, appname)
            else:
                wasRemote_cmd = 'ssh %s "%sapm/agent/bin/was-agent.sh status"' % (connectTo, wwpath)
	    ans = self.execProc(wasRemote_cmd)
            if "not" in ans:
                stop = 1
            elif "running" in ans:
                print ans[ans.find("running"):]
            elif "Connected" in ans:
                print ans[ans.find("Connected"):]
            elif "Connecting" in ans:
                print ans[ans.find("Connecting"):]
            #------------------------------------------------------------
            if not stop:
                print "[stopping was-agent]"
                if not env:
                    wasRemote_cmd = 'ssh %s "/apps/%s/apm/agent/bin/was-agent.sh stop"' % (connectTo, appname)
                else:
                    wasRemote_cmd = 'ssh %s "%sapm/agent/bin/was-agent.sh stop"' % (connectTo, wwpath)
                sas = self.execProc(wasRemote_cmd)
                if "gracefully" in sas:
                    print sas[sas.find("gracefully"):]
                elif "force" in sas:
                    print sas[sas.find("force"):]
            else:
               print "[was-agent already stopped]"
           #---------------------------------------------------------------
            print "[starting was-agent]"
            if not env:
                 wasRemote_cmd = 'ssh %s "/apps/%s/apm/agent/bin/was-agent.sh start"' % (connectTo, appname)
            else:
                 wasRemote_cmd = 'ssh %s "%sapm/agent/bin/was-agent.sh start"' % (connectTo, wwpath)
            stas = self.execProc(wasRemote_cmd)
            if "started" in stas:
               print stas[stas.find("started"):]
            else:
               print "[failed to start was-agent]"

#---------------------------------------------------------------------------
# class description: for obtaining user adminid and password for wsadmin shell
#                    parially working (in progress)
#----------------------------------------------------------------------------
class APMAUTH:
    def __init__(self, sdirname, basename="security.xml"):
        self.secPath = os.path.join(sdirname, basename)
        print "> ",self.secPath
        #self.adm = "serverId"
        self.adm = "primaryAdminId"
        #self.bind = "serverPassword="
        self.bind = "bindPassword="
        self.admC = re.compile(r'primaryAdminId=(.*?)\s')
        self.pwdC = re.compile(r'bindPassword=(.*?)\s')

    def searchEng(self, searchHold= []):
        """search every line with 'serverPassword=' string then append to the list """
        with open(self.secPath, "r") as xmlSec:
            line = xmlSec.readline()
            while line != "":
                xmlOut = line.find(self.adm)
                if xmlOut != -1:
                    idxSearch = line[xmlOut:]
                    searchHold.append(idxSearch)
                line = xmlSec.readline()
	var = ""
        #patt = re.compile(r'serverId=(.*?)\s', re.I)
        patt = self.pwdC
        for s_item in searchHold:
            inspect = patt.search(s_item)
            if inspect or inspect != None:
                var = s_item
                break
            #x =  eval(inspect.group(1))
            #if bool(x) != False:
        return var

    def search_LookUp(self, someSTR):
        """Look through the following item in list with 'primaryAdminId=' string then capture its value as well the AdminId"""
        try:
            xmlPwd = self.pwdC.search(someSTR)
            if xmlPwd:
                xmlBindPassword = xmlPwd.group(1)
            else:
                xmlBindPassword = "default"
            #print xmlPwd.group(1)
        except:
            xmlBindPassword = "default"
        # - - - - - - - - - - - - - - - - - - -
        try:
            xmlAdm = self.admC.search(someSTR)
            if xmlAdm:
            #print xmlAdm.group(1)
                xmlAdminId = xmlAdm.group(1)
            else:
                xmlAdminId = "default"
        except:
            xmlAdminId = "default"

        return xmlAdminId, xmlBindPassword

    def decrypt (self, word ):
        """decrypt encrypted password"""
        if "xor" in word:
            # remove {xor} tag
            word = word[5:]

        if not len(word) > 1: exit()
        word = word.replace(':', '')
        value1 = binascii.a2b_base64(word)
        value2 = '_' * len(value1)
        out = ''
        for a, b in zip(value1, value2):
            out = ''.join([out, chr(ord(a) ^ ord(b))])
        return out

#----------------------------------------------------------
# class description: custom logs ready to used
#                    accept log filename as an arguments
#----------------------------------------------------------
class apmLog:
    ERROR = '\033[91m'
    ENDC = '\033[0m'
    def __init__(self, filename="somelog.log", strfmt='[%(asctime)s] %(levelname)-8s: %(message)s', lvl=logging.INFO):
        self.logger = logging.getLogger()
        if self.logger.handlers:
            self.logger.handlers = []
        logging.basicConfig(format=strfmt, level=lvl, datefmt='%Y-%m-%d %I:%M:%S %p')
        lhStdout = self.logger.handlers[0]
        fh = logging.FileHandler(filename)
        fh.setFormatter(logging.Formatter(fmt=strfmt, datefmt='%Y-%m-%d %I:%M:%S %p'))
        ch = logging.StreamHandler()
        ch.setLevel(logging.ERROR)

        self.logger.addHandler(fh)
        self.logger.removeHandler(lhStdout)
        self.logger.addHandler(ch)

    def info(self, text):
        self.logger.info(text)

    def warn(self, text):
        self.logger.warning(text)

    def error(self, text):
        self.logger.error(self.ERROR + text + self.ENDC)

    def close(self):
       logging.shutdown()

