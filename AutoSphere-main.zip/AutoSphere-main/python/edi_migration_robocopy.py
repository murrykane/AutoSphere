# !/usr/bin/python
# Vitaliy Fanin
# Version 1.0

# This script has been created to read a file with a listing of the directories to be copied.  The robocopy process
# is called for each directory identified.  
# 
# ***********************************************
# ***********************************************
# ***********************************************
# ROBOCOPY USES A MIRROR SWITCH WHICH WILL DELETE FILES IN THE DESTINATION DIRECTORY 
# IF THEY DO NOT EXIST IN THE SOURCE DIRECTORY!!!
# ***********************************************
# ***********************************************
# ***********************************************

import os, sys, time, subprocess, re
from datetime import datetime

os.system('cls')
startTime = time.time()

listingFiles = ["D:\Temp\prod\editm_os_walk_listing_2020-03-29.txt"]
#    "C:\TEMP\edih03-V1\SOR_os_walk_listing_2020-02-13.txt", \
#        "C:\TEMP\edih03-V1\edienl_os_walk_listing_2020-02-13.txt", \
#            "C:\TEMP\edih03-V1\ediclm_os_walk_listing_2020-02-13.txt"]
#                "C:\TEMP\edih03-V1\edibound_os_walk_listing_2020-02-12.txt"]

for filepath in listingFiles:
    #filepath = 'C:\TEMP\edih03-V1\edibound_os_walk_listing_2020-02-12.txt'
    print(filepath)

    re_string = r".*\\(.*)_os_walk_.*.txt"
    try:
        org_dir = re.search(re_string, filepath).group(1)
    except Exception:
        print("Could not determine proper log file name. Exiting...")
        sys.exit()

    LOG_FILE_PATH = r"D:\TEMP\robocopy_logs\{}_{}.txt".format(org_dir, datetime.now().strftime("%Y-%m-%d_%I-%M-%S-%p"))
    print(LOG_FILE_PATH)

    if not os.path.isfile(filepath):
        print("File path {} does not exist. Exiting...".format(filepath))
        sys.exit()

    with open(filepath) as fp:
        for cnt, line in enumerate(fp):
            line = line.rstrip()
            #print("Line {}: {}".format(cnt, line))
            org_share = r"\\ainf513p\editm"
            dir = line.replace(org_share, "").replace("\\", "", 1) #remove share from line read in from file and remove the first \ from the directory name
            #print("org_share: " + org_share)
            print("dir: " + dir)
            destination_share = r"\\sacbscprtp-801\apps_edip01"
            #print("destination_share: " + destination_share)
        
            robocopy_start_time = time.time()
            ret_code = subprocess.call(
                ["robocopy", line, os.path.join(destination_share, dir), "/MIR", "/E", "/XX", "/FFT", "/Z", "/DCOPY:DAT", "/COPY:DAT", "/XA:H", 
                "/W:5", "/R:2", "/NFL", "/NP", "/MT:32", "/LOG+:" + LOG_FILE_PATH]) 
            print('Duration: {0:.2f} seconds'.format(time.time() - robocopy_start_time))
            print('Return code: {0}\n'.format(ret_code))
            if ret_code > 3:
                sys.exit(1)

print('The script took {0:.2f} seconds!'.format(time.time() - startTime))
