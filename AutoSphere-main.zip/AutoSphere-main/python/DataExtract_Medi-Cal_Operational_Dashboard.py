# -*- coding: utf-8 -*-
"""
Created on Tue Jul 28 14:59:39 2020

@author: kparro01
"""

import pandas as pd
from pandasql import sqldf
import requests
from datetime import datetime
from dateutil.relativedelta import relativedelta
from cryptography.fernet import Fernet
import shutil
import os
import sys
import re


def exitHandler(exitCode,functionName):
    print('An error occured in {}. Exiting with code {}'.format(functionName,exitCode))
    sys.exit(exitCode)

# FROM SRE Security
def decryptStringWithKey(theString, key):
  if key is not bytes:
    key = key.encode()
  if theString is not bytes:
    theString = theString.encode()
  cipher_suite = Fernet(key)
  unciphered_text = (cipher_suite.decrypt(theString))
  #print(unciphered_text)
  return unciphered_text.decode()

def setSnowVars():
    try:
        sn_instance = "https://blueshieldca.service-now.com"
        sn_username = "gAAAAABefNY--nbWAI1Cg-eJMlPrxbIqBQqKmuLsG8MqGLXG_wF6uYuqPQLJO8PZLJmHhMkMKSoBtzHmMEsLPbNzgJxY4qlgjA=="
        sn_password = "gAAAAABefNd_3nbCv6hu0n2htJ-06Hm7NwYkXGM-MH8He6bIjmanXMcXbyuUMhM20C3qtm2ESAkHM7RoE2XSyzMKHMR-t_qWRQ=="
        encryptKey = "7LbYdIxza71cWMho8Ru6kg3ZaBjxJFIuqWGDuhyfTDM="
        
        snow_user = decryptStringWithKey(sn_username,encryptKey)
        snow_pass = decryptStringWithKey(sn_password,encryptKey)
    
        if bool(sn_instance) and bool(snow_user) and bool(snow_pass):
            return snow_user, snow_pass, sn_instance
        else:
            print('ERROR: Unable to get valid ServiceNow variables.')
            return None, None, None
    except:
        print("Unexpected error:", sys.exc_info())
        return None, None, None


def querySnow(url,user,pwd):
    try:
        # Set proper headers
        headers = {"Content-Type":"application/json","Accept":"application/json"}
        
        # Do the HTTP request
        response = requests.get(url, auth=(user, pwd), headers=headers)
        
        # Check for HTTP codes other than 200
        if response.status_code != 200: 
            print('An ERROR occurred in the querySnow() function.')
            print('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:',response.json())
            return None
        
        # Decode the JSON response into a dictionary and use the data
        data = response.json()
        return data
    except:
        print("Unexpected error:", sys.exc_info())
        return None
    

def getSysparamQueryFromSavedReport(snow_user,snow_pass,sn_instance,report_name):
    try:
        queryHeader= '====================================================='
        report_keywords = re.split(r'\W+',report_name)
        report_sysparam_contains = '%2C'.join(report_keywords)
        report_url = '{}/api/now/reporting?sysparm_contains={}'.format(sn_instance,report_sysparam_contains)
        
        print('Querying ServiceNow for the sysparam queries related to [{}]'.format(report_name))
        
        report_response = querySnow(report_url,snow_user,snow_pass)
        
        if report_response == None:
            print('ERROR: Report response returned None.')
            return None
        
        df_report = pd.DataFrame(report_response['result']['reports'])        
        
        # Loop through reports and collect portfolios / sysparam queries
        query_dict = {}
        for index, row in df_report.iterrows():    
            title = row['title']
            print('Attempting to extract portfolio from the following report: [{}]'.format(title))
            match = re.search(report_name,title)
            if match:
                portfolio = match.group(1).strip()
                sysparam_query = row['query']
                
                # Append to dictionary
                query_dict[portfolio] = sysparam_query
                
                # Print / validate results
                if len(sysparam_query) > 0:
                    print('Found the following sysparam_query for portfolio [{}]:\n{}\n{}\n{}'.format(portfolio,queryHeader,sysparam_query,queryHeader))
                else:
                    print('ERROR: No sysparam query was found!')
                    return None
            else:
                print('Unable to extract portfolio name from the report [{}]'.format(title))
        
        if len(query_dict) > 0:
            return query_dict
        else:
            print('ERROR: No sysparam query was returned!')
            return None
        
    except:
        print("Unexpected error:", sys.exc_info())
        return None


def incMadeSla(row):
    resolvedDate = row['resolved_at']
    slaDate = row['sla_due']
    nowDate = datetime.now()
    
    if pd.isnull(resolvedDate) and slaDate < nowDate:
        return 0
    elif slaDate < resolvedDate:
        return 0
    else:
        return 1
    
    
def getSnowIncidentData(snow_user,snow_pass,sn_instance,inc_query_dict):
    try:    
        # Query Incident Data
        inc_field_list = ['number',
                          'incident_state',
                          'priority',
                          'opened_at',
                          'closed_at',
                          'resolved_at',
                          'u_environment',
                          'u_cause_code',
                          'close_code',
                          'u_action_taken',
                          'cmdb_ci',
                          'service_offering',
                          #'problem_id',
                          'assignment_group',
                          'sla_due'
                          ]
        inc_fields = '%2C'.join(inc_field_list)
        
        first_portfolio = True
        
        for portfolio in inc_query_dict:
            print('    Querying incident data for the [{}] portfolio...'.format(portfolio))
            
            
            inc_sysparam_query = inc_query_dict[portfolio]
            inc_url = '{}/api/now/table/incident?sysparm_query={}&sysparm_display_value=true&sysparm_fields={}&sysparm_limit=10000'.format(sn_instance,
                                                                                                                                           inc_sysparam_query,
                                                                                                                                           inc_fields)

            inc_response = querySnow(inc_url,snow_user,snow_pass)

            if inc_response == None:
                print('ERROR: Incident query returned None.')
                return None

            df_inc_tmp = pd.DataFrame(inc_response['result'])
            df_inc_tmp['assignment_group'] = [d.get('display_value') if type(d) == dict else None for d in df_inc_tmp['assignment_group']]
            df_inc_tmp['cmdb_ci'] = [d.get('display_value') if type(d) == dict else None for d in df_inc_tmp['cmdb_ci']]
            df_inc_tmp['service_offering'] = [d.get('display_value') if type(d) == dict else None for d in df_inc_tmp['service_offering']]
            df_inc_tmp['opened_at'] = pd.to_datetime(df_inc_tmp['opened_at'])
            df_inc_tmp['resolved_at'] = pd.to_datetime(df_inc_tmp['resolved_at'])
            df_inc_tmp['closed_at'] = pd.to_datetime(df_inc_tmp['closed_at'])
            df_inc_tmp['sla_due'] = pd.to_datetime(df_inc_tmp['sla_due'])

            df_inc_tmp['made_sla'] = df_inc_tmp.apply(lambda row: incMadeSla(row), axis=1)
            df_inc_tmp['portfolio'] = portfolio
            
            # Append the data to df_inc
            if first_portfolio:
                first_portfolio = False
                df_inc = df_inc_tmp.copy()
            else:
                df_inc = df_inc.append(df_inc_tmp,ignore_index=True)
                
        return df_inc        
    except:
        print("Unexpected error:", sys.exc_info())
        return None

def getDateDataFrame():
    try:
        startMonth = datetime(2019, 6, 1)
        nowMonth = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0, day=1)
        
        currMonth = startMonth
        months = list()
        
        while currMonth <= nowMonth:
            months.append(currMonth)
            currMonth = currMonth + relativedelta(months=+1)
        
        df_dates = pd.DataFrame(months,columns=['backlog_month'])
        df_dates['start_of_month'] = 1
        df_dates['end_of_month'] = 0
        
        return df_dates
    except:
        print("Unexpected error:", sys.exc_info())
        return None

def getLastDayOfMonth(currentDay):
    nextMonth = currentDay.replace(day=28) + relativedelta(days=+4)
    return nextMonth - relativedelta(days=nextMonth.day)

def getDateDataFrameDetailed():
    try:
        startMonth = datetime(2019, 6, 1)
        nowMonth = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        
        currMonth = startMonth
        months = list()
        
        while currMonth <= nowMonth:
            months.append(currMonth)
            currMonth = currMonth + relativedelta(days=+1)
        
        df_dates = pd.DataFrame(months,columns=['backlog_date'])
        df_dates['start_of_month'] = df_dates.apply(lambda x: 1 if x['backlog_date'] == x['backlog_date'].replace(hour=0, minute=0, second=0, microsecond=0, day=1) else 0,axis=1)
        df_dates['end_of_month'] = df_dates.apply(lambda x: 1 if x['backlog_date'] == getLastDayOfMonth(x['backlog_date']).replace(hour=0, minute=0, second=0) else 0,axis=1)
        
        return df_dates
    except:
        print("Unexpected error:", sys.exc_info())
        return None

def getSnowIncidentBacklogData(df_inc,df_dates):
    try:
        inc_backlog_sql = '''
        Select
            a.*
            ,b.*
        From df_dates a
            Inner Join df_inc b
                On datetime(b.opened_at,'start of month') <= datetime(a.backlog_month,'start of month')
                    And datetime(a.backlog_month,'start of month') <= datetime(Coalesce(b.resolved_at,datetime('now')),'start of month')
        Where 1=1
            And (datetime(a.backlog_month,'start of month') < datetime(Coalesce(b.resolved_at,datetime('now')),'start of month')
                Or b.incident_state Not In ('Closed','Resolved')
                )
        Order by b.number, a.backlog_month
        ;
        '''
        
        df_inc_backlog = sqldf(inc_backlog_sql, locals())
        
        return df_inc_backlog
    except:
        print("Unexpected error:", sys.exc_info())
        return None

def getSnowDataAnalyticsData(snow_user,snow_pass,sn_instance,da_query_dict):
    try:    
        # Query Data & Analytics Data
        da_field_list = [# Task Fields
                         'number',
                         'opened_at',
                         'closed_at',
                         # Request Fields
                         'request',
                         'request.opened_at',
                         'request.closed_at',
                         'request.opened_by',
                         'request.opened_by.manager',
                         'request.request_state'
                          ]
        da_fields = '%2C'.join(da_field_list)
        
        first_portfolio = True
        
        for portfolio in da_query_dict:
            print('    Querying data & analytics data for the [{}] portfolio...'.format(portfolio))
            
            da_sysparam_query = da_query_dict[portfolio]
            da_url = '{}/api/now/table/sc_task?sysparm_query={}&sysparm_display_value=true&sysparm_fields={}&sysparm_limit=10000'.format(sn_instance,da_sysparam_query,da_fields)

            response = querySnow(da_url,snow_user,snow_pass)

            if response == None:
                print('ERROR: Data & Analytics query returned None.')
                return None

            df_da_tmp = pd.DataFrame(response['result'])
            df_da_tmp['request'] = [d.get('display_value') if type(d) == dict else None for d in df_da_tmp['request']]
            df_da_tmp['request.opened_by'] = [d.get('display_value') if type(d) == dict else None for d in df_da_tmp['request.opened_by']]
            df_da_tmp['request.opened_by.manager'] = [d.get('display_value') if type(d) == dict else None for d in df_da_tmp['request.opened_by.manager']]
            df_da_tmp['opened_at'] = pd.to_datetime(df_da_tmp['opened_at'])
            df_da_tmp['closed_at'] = pd.to_datetime(df_da_tmp['closed_at'])
            df_da_tmp['request.opened_at'] = pd.to_datetime(df_da_tmp['request.opened_at'])
            df_da_tmp['request.closed_at'] = pd.to_datetime(df_da_tmp['request.closed_at'])

            df_da_tmp['task.rank_by_request'] = df_da_tmp.groupby('request')['opened_at'].rank(method='first')
            
            df_da_tmp['portfolio'] = portfolio
            
            # Append the data to df_inc
            if first_portfolio:
                first_portfolio = False
                df_da = df_da_tmp.copy()
            else:
                df_da = df_da.append(df_da_tmp,ignore_index=True)
            
        return df_da        
    except:
        print("Unexpected error:", sys.exc_info())
        return None

def getSnowDataAnalyticsBacklogData(df_da,df_dates,df_dates_detail):
    try:
        sql = '''
        Select
            'Daily' As aggregation_level
            ,a.*
            ,b.*
        From df_dates_detail a
            Inner Join df_da b
                On datetime(b.`request.opened_at`,'start of day') <= datetime(a.backlog_date,'start of day')
                    And datetime(a.backlog_date,'start of day') <= datetime(Coalesce(b.`request.closed_at`,datetime('now')),'start of day')
        Where 1=1
            And datetime('now', '-60 day') <= datetime(a.backlog_date,'start of day')
        
        Union All 
        
        Select
            'Monthly' As aggregation_level
            ,a.*
            ,b.*
        From df_dates a
            Inner Join df_da b
                On datetime(b.`request.opened_at`,'start of month') <= datetime(a.backlog_month,'start of month')
                    And datetime(a.backlog_month,'start of month') <= datetime(Coalesce(b.`request.closed_at`,datetime('now')),'start of month')
        Where 1=1
            And datetime('now', '-14 month') <= datetime(a.backlog_month,'start of month')
            And (datetime(a.backlog_month,'start of month') < datetime(Coalesce(b.`request.closed_at`,datetime('now')),'start of month')
                Or b.`request.request_state` Not Like '%Closed%'
                )
        ;
        '''
        
        df_da_backlog = sqldf(sql, locals())
        
        return df_da_backlog
    except:
        print("Unexpected error:", sys.exc_info())
        return None

#def getSnowDataAnalyticsBacklogData(df_da,df_dates_detail):
#    try:
#        sql = '''
#        Select
#            a.*
#            ,b.*
#        From df_dates_detail a
#            Inner Join df_da b
#                On datetime(b.`request.opened_at`,'start of day') <= datetime(a.backlog_date,'start of day')
#                    And datetime(a.backlog_date,'start of day') <= datetime(Coalesce(b.`request.closed_at`,datetime('now')),'start of day')
#        Where 1=1
#            And datetime('now', '-60 day') <= datetime(a.backlog_date,'start of day')
#        Order by b.number, a.backlog_date
#        ;
#        '''
#        
#        df_da_backlog = sqldf(sql, locals())
#        
#        return df_da_backlog
#    except:
#        print("Unexpected error:", sys.exc_info())
#        return None
    

def archiveExistingFile(data_dir,archive_dir,file_name):
    try:
        file = data_dir + file_name
        archiveTimeStamp = datetime.now().strftime('%Y%m%d-%H%M%S')
        archive_file_name = archiveTimeStamp + '_' + file_name
        archive_file = archive_dir + archive_file_name
        
        print('Attempting to archive [{}]...'.format(file))
        
        if os.path.isfile(file):
            shutil.copy(file,archive_file)
            print('Successfully archived file as [{}]'.format(archive_file))
        else:
            print('WARNING: File [{}] does not exist, so it will NOT be archived.'.format(file))
        
        return True
    except:
        print("Unexpected error:", sys.exc_info())
        return False

def saveMediCalData(data_dir,file_name,df_inc,df_inc_backlog,last_update_df,df_da,df_da_backlog,df_dates_detail):
    try:
        file = data_dir + file_name
        
        with pd.ExcelWriter(file) as writer:
            df_inc.to_excel(writer, index=False, sheet_name='incident')
            df_inc_backlog.to_excel(writer, index=False, sheet_name='incident_backlog')
            last_update_df.to_excel(writer, index=False, sheet_name='last_update')
            df_da.to_excel(writer, index=False, sheet_name='data_analytics_requests')
            df_da_backlog.to_excel(writer, index=False, sheet_name='data_analytics_requests_backlog')
            df_dates_detail.to_excel(writer, index=False, sheet_name='dim_date')
        
        return True
    except:
        print("Unexpected error:", sys.exc_info())
        return False


def cleanUpArchive(numberArchiveFilesToKeep,archive_dir,file_name):
    try:
        archiveFiles = [f for f in os.listdir(archive_dir) if os.path.isfile(os.path.join(archive_dir, f)) and file_name in f]
        archiveFiles.sort(reverse = True)
        archiveFilesToDelete = archiveFiles[numberArchiveFilesToKeep:]
        
        print('Removing files whose name contains [{}] in the archive directory [{}]'.format(file_name,archive_dir))
        print('Number of files to keep is [{}]'.format(numberArchiveFilesToKeep))
        
        if len(archiveFilesToDelete) > 0:
            for f in archiveFilesToDelete:
                archiveFileToDelete = archive_dir + f
                print('Deleting: {}'.format(archiveFileToDelete))
                os.remove(archiveFileToDelete)
        else:
            print('Less than [{}] files found in the archive directory, no need to delete any.'.format(numberArchiveFilesToKeep))
        
        return True
    except:
        print("Unexpected error:", sys.exc_info())
        return False




def main():
    try:
        header = '-------------------------------------------------------------------'
        
        print(header)
        print('Setting ServiceNow variables...')
        snow_user, snow_pass, sn_instance = setSnowVars()
        if snow_user is None or snow_pass is None or sn_instance is None:
            exitHandler(10,'setSnowVars')
        else:
            print('ServiceNow Instance is {}'.format(sn_instance))
            print('Success')
        print(header)
        
        print('')
        
        # --------------------------------- Incident Data --------------------------------- #
        
        print(header)
        print('Setting ServiceNow Incident Query...')
        inc_query_dict = getSysparamQueryFromSavedReport(snow_user,snow_pass,sn_instance,'Tableau - (.*) Incident Data')
        if inc_query_dict == None:
            exitHandler(20,'getSysparamQueryFromSavedReport')
        else:
            print('Success')
        print(header)
        
        print('')
        
        print(header)
        print('Querying ServiceNow for Portfolio related incidents...')
        df_inc = getSnowIncidentData(snow_user,snow_pass,sn_instance,inc_query_dict)
        if df_inc is not None:
            print('Success')
        else:
            exitHandler(30,'getSnowIncidentData')
        
        print(header)
        
        print('')
        
        print(header)
        print('Generating list of dates as data frame...')
        df_dates = getDateDataFrame()
        if df_dates is not None:
            print('Success')
        else:
            exitHandler(40,'getDateDataFrame')
        print(header)
        
        print('')
        
        print(header)
        print('Genereating incident backlog data frame...')
        df_inc_backlog = getSnowIncidentBacklogData(df_inc,df_dates)
        if df_inc_backlog is not None:
            print('Success')
        else:
            exitHandler(50,'getSnowIncidentBacklogData')
        print(header)
        
        print('')
        
        print(header)
        print('Generating last update data frame...')
        last_update_df = pd.DataFrame.from_dict({'last_update':[datetime.now()]})
        print('Success')
        print(header)
        
        print('')
        
        # ----------------------------- Data & Analytics Data ----------------------------- #
        
        print(header)
        print('Setting ServiceNow Data & Analytics Query...')
        da_query_dict = getSysparamQueryFromSavedReport(snow_user,snow_pass,sn_instance,'Tableau - (.*) Data and Analytics Requests')
        if da_query_dict == None:
            exitHandler(21,'getSysparamQueryFromSavedReport')
        else:
            print('Success')
        print(header)
        
        print('')
        
        print(header)
        print('Querying ServiceNow for Portfolio related data & analytics requests...')
        df_da = getSnowDataAnalyticsData(snow_user,snow_pass,sn_instance,da_query_dict)
        if df_da is not None:
            print('Success')
        else:
            exitHandler(31,'getSnowDataAnalyticsData')
        
        print(header)
        
        print('')
        
        print(header)
        print('Generating detailed list of dates as data frame...')
        df_dates_detail = getDateDataFrameDetailed()
        if df_dates_detail is not None:
            print('Success')
        else:
            exitHandler(41,'getDateDataFrameDetailed')
        print(header)
        
        print('')
        
        print(header)
        print('Genereating data & analytics backlog data frame...')
        df_da_backlog = getSnowDataAnalyticsBacklogData(df_da,df_dates,df_dates_detail)
        if df_da_backlog is not None:
            print('Success')
        else:
            exitHandler(50,'getSnowDataAnalyticsBacklogData')
        print(header)
        
        print('')
        
        data_dir = '//bsc/it/IT_Portfolios/Medi-Cal/Tableau/Medi-Cal Operational Dashboard/'
        file_name = 'Medi-Cal Operational Data.xlsx'
        archive_dir = data_dir + 'Archive/'
        
        print(header)
        print('Attempting to archive existing file [{}] in archive directory [{}]'.format(file_name,archive_dir))
        archiveExistingFileSuccess = archiveExistingFile(data_dir,archive_dir,file_name)
        if archiveExistingFileSuccess:
            print('Success')
        else:
            exitHandler(60,'archiveExistingFile')
        print(header)
        
        print('')
        
        print(header)
        print('Attempting to save Medi-Cal incident data to [{}{}]...'.format(data_dir,file_name))
        saveMediCalDataSuccess = saveMediCalData(data_dir,file_name,df_inc,df_inc_backlog,last_update_df,df_da,df_da_backlog,df_dates_detail)
        if saveMediCalDataSuccess:
            print('Success')
        else:
            exitHandler(70,'saveMediCalData')
        print(header)
        
        print('')
        
        print(header)
        print('Attempting to clean up archive directory...'.format(data_dir,file_name))
        cleanUpArchiveSuccess = cleanUpArchive(7,archive_dir,file_name)
        if cleanUpArchiveSuccess:
            print('Success')
        else:
            exitHandler(80,'cleanUpArchive')
        print(header)
        
        print('Completed successfully.')
        sys.exit(0)        
        
    except SystemExit:
        raise # Re-raise the system exit
    except:
        print("Unexpected error:", sys.exc_info())
        exitHandler(99,'main')
        
if __name__ == '__main__':
    main()
    