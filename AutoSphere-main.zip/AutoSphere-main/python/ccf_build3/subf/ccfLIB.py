import logging
import os, re, subprocess, sys 
from base64 import binascii

class ccfParse:
    def __init__(self, cfg):
        self.cfgp = cfg

    #def getServer(self, s="Server"):
        #srvname = self.cfgp.get(s, "server_name")
        #return srvname
  
    def getFiles(self, f="CFiles"):
        f_entries = {}
        for entry in self.cfgp.options(f):
            f_entries[entry] = self.cfgp.get(f,entry)
        return f_entries

    def getDirectories(self, d="Directory"):
        d_entries = {}
        for entry in self.cfgp.options(d):
           d_entries[entry] = self.cfgp.get(d, entry)
        return d_entries
                
    def getPath(self, p="Path"):
        p_entries = {}
        for entry in self.cfgp.options(p):
            p_entries[entry] =  self.cfgp.get(p, entry)
        return p_entries

class ccfLog:
    ERROR = '\033[91m'
    ENDC = '\033[0m'
    def __init__(self, filename="somelog.log", strfmt='[%(asctime)s] %(levelname)-8s: %(message)s', lvl=logging.INFO):
        self.logger = logging.getLogger()
        if self.logger.handlers:
            self.logger.handlers = []
        logging.basicConfig(format=strfmt, level=lvl, datefmt='%Y-%m-%d %I:%M:%S %p')
        lhStdout = self.logger.handlers[0]
        fh = logging.FileHandler(filename)
        fh.setFormatter(logging.Formatter(fmt=strfmt, datefmt='%Y-%m-%d %I:%M:%S %p'))
        ch = logging.StreamHandler()
        ch.setLevel(logging.ERROR)

        self.logger.addHandler(fh)
        self.logger.removeHandler(lhStdout)
        self.logger.addHandler(ch)

    def info(self, text):
        self.logger.info(text)

    def warn(self, text):
        self.logger.warning(text)

    def error(self, text):
        self.logger.error(self.ERROR + text + self.ENDC)

    def close(self):
       logging.shutdown()

class ccfAuth:
    def __init__(self, sdirname, basename):
        self.secPath = os.path.join(sdirname, basename)
        self.adm = "serverId"
        self.bind = "serverPassword="
        self.admC = re.compile(r'serverId=(.*?)\s')
        self.pwdC = re.compile(r'serverPassword=(.*?)\s')

    def searchEng(self, searchHold= []):
        """search every line with 'serverPassword=' string then append to the list """
        with open(self.secPath, "r") as xmlSec:
            line = xmlSec.readline()
            while line != "":
                xmlOut = line.find(self.adm)
                if xmlOut != -1:
                    idxSearch = line[xmlOut:]
                    searchHold.append(idxSearch)
                line = xmlSec.readline()
        
        patt = re.compile(r'serverId=(.*?)\s', re.I)
        for s_item in searchHold:
            inspect = patt.search(s_item)
            x =  eval(inspect.group(1))
            if bool(x) != False: 
                return s_item
            else:
                print "[Failed to parse adminId and password]"
                print "[s_item] from security.xml ",s_item   
                print "[Use defined credentials]"

    def search_LookUp(self, someSTR):
        """Look through the following item in list with 'primaryAdminId=' string then capture its value as well the AdminId"""
        try:
            xmlPwd = self.pwdC.search(someSTR)
            xmlBindPassword = xmlPwd.group(1)
        except:
            xmlBindPassword = '6Rm9C73d2Ea74f4A'

        try:
            xmlAdm = self.admC.search(someSTR)
            xmlAdminId =  xmlAdm.group(1)
        except:
            xmlAdminId = '[svcbscwpadmin-npe]' # in string
        
        #xmlAdminId = xmlAdm.group(1)
        #xmlBindPassword = xmlPwd.group(1)
        return xmlAdminId, xmlBindPassword

    def decrypt (self, word ):
        """decrypt encrypted password"""
        # remove {xor} tag

        if word.find("xor") == -1:
            return word

        word = word[5:]
        if not len(word) > 1: exit()
        word = word.replace(':', '')
        value1 = binascii.a2b_base64(word)
        value2 = '_' * len(value1)
        out = ''
        for a, b in zip(value1, value2):
            out = ''.join([out, chr(ord(a) ^ ord(b))])
        return out

class ccfUtil:
    def getHostname(self):
        """get the hostname of the DMGR"""
        print "[Module description]  . . . get the hostname of the DMGR"
        print "[Module name] . . . ccfUtil.getHostname"
        command = "hostname"
        proc = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
        stdout = proc.communicate()[0]
        return stdout
    
    def getAgentName(self, filename, someString):
        """get AgentName in the file output"""
        print "[Module description] . . . get AgentName in the file output"
        print "[Module name] . . . ccfUtil.getAgentName"
        itContain = []
        ffile = "/tmp/{0}".format(filename)
        with open(ffile, "r") as FILE:
            for fileLine in FILE:
                check = fileLine.find(someString)
                if check != -1:
                    itContain.append(fileLine)
        # verify if list is not empty and length is 1
        if itContain != [] and len(itContain) == 1:
            patt = re.compile(r'^.*node\s(.*?)\s')
            match = patt.search(itContain[0])
            if match:
                print "[info] match found"
                return match.group(1)
            else:
                print "[warn] No match found"
                sys.exit(1)
        else:
            print "[warn] Can't return an empty list"
            print "[warn] Failed to capture expected value from a String"
            sys.exit(1)
    
    def getPortNumber(self, path, filename):
        contain = []
        patt = re.compile(r'^.*=(\d+)')
        abspath = os.path.join(path, filename)
        with open(abspath, "r") as ABSP:
            for readLine in ABSP:
                if readLine.find("scripting.port") != -1:
                    contain.append(readLine)
        
        if contain != [] and len(contain) == 1:
            match = patt.search(contain[0])
            if match:
                print "match found"
                return match.group(1)
            else:
                print "no match found"
                sys.exit(1)
        else:
            print "Can't return an empty list or more than 1 element"
            sys.exit(1)

#////////////////////////////////////END////////////////////////////////////////////




                
            

        
