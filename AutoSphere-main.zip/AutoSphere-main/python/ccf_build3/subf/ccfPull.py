#--------------------------------------------------------------------------
# Name: ccfPull.py
# Role: to get all managed nodes name
#       to get hostname of each node
#       as well the sername of each node
# Note: output in a dictionary format and written to /tmp/ccfUTIL.txt
#       it is serialized using pickle lib , retrieved it using pickle.load!
# Author: Jeffrey Apiado (IT_NPO_WEB_TEAM)
#--------------------------------------------------------------------------
import pickle
import os
#--------------------------------------------------------------------------
class ccfUtility:
    def __init__(self, filename="/tmp/ccfUTIL.txt"):
        # get all Nodes that this dmgr managed
        self.allNodeInList = AdminTask.listManagedNodes().splitlines()
        self.fname = filename

    def allNodeLoop(self):
        contain = {}
        for NODE in self.allNodeInList:
            getID = AdminConfig.getid("/Node:%s" % NODE)
            hostname = AdminConfig.showAttribute(getID, 'hostName')   # needed
            getServer = AdminConfig.list('Server', getID).splitlines()
            getSrvNamePrime = [srv.split("(")[0] for srv in getServer if srv.split("(")[0] != "nodeagent"]
            if getSrvNamePrime == []:
               srvName = "nodeagent"  # no server name defined
            else:
               srvName = getSrvNamePrime[0]    # needed
            contain[NODE] = [hostname, srvName]
        return contain
 
    def writeOutput(self, holder):
        ffile = open(self.fname, "wb")
        pickle.dump(holder,ffile)
        ffile.close()
        # verify if file exists and change permission
        out = os.system("chmod 777 %s" % self.fname)     
        if out != 0 and out > 0:
            print "[exec] change perm for file %s [failed[x]" % ffile
        else:
            print "[exec] change perm for file %s [completed[]" % ffile
               
#-----------------------------------------------------------------------------
if  __name__ == "__main__":
     util = ccfUtility()
     holder = util.allNodeLoop()
     util.writeOutput(holder)
     
     
