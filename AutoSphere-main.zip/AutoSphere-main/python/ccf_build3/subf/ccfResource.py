import ConfigParser
import os

abspath = os.path.abspath("/opt/jenkins/AutoSphere/python/ccf_build3/subf/ccfResource.py")
newpath = os.path.dirname(abspath)
cfgFile = os.path.join(newpath, "../ccfCONFIG.txt")
 
print "Config file : " + cfgFile
 
config = ConfigParser.ConfigParser()
# keep the case > optionxform was added
config.optionxform = str
config.read(cfgFile)
 
def findProperty(propSet, option):
     
    propertyList = AdminConfig.list("J2EEResourceProperty", propSet).splitlines()
     
    for elem in propertyList:
        if(AdminConfig.showAttribute(elem, "name") == option):
            return elem;
 
print "========================= Applying configuration ============================="

Section = "WP ConfigService" 
section = "Configservice" 
print "Reading properties for section : " + section
wpConfigREP = AdminConfig.getid('/ResourceEnvironmentProvider:' + Section + '/')
propSet = AdminConfig.showAttribute(wpConfigREP, 'propertySet')
     
for option in config.options(section):
    propertyy = findProperty(propSet, option)        
    if(propertyy is not None):
            currentValue = AdminConfig.showAttribute(propertyy, "value")
            currentDesc = AdminConfig.showAttribute(propertyy, "description")
             
            newValue = config.get(section, option)
            if(newValue != currentValue):
                print "UPDATING property : '" + option + "' ====>"
                newSettings = [
                                ["value", config.get(section, option)],
                                ["description ", ""]
                              ]
                               
                AdminConfig.modify(propertyy, newSettings)
            else:
                print "Property : '" + option + "' is already having latest value."
                 
    else:
            print "ADDING property : '" + option + "' ====>"
            values = config.get(section, option)
            newSettings = [
                            ["name", option],
                            ["value", values],
                            ["description ", ""]
                          ]
            AdminConfig.create('J2EEResourceProperty', propSet, newSettings)
                 
#Save configuration
AdminConfig.save()
 
print "========================= DONE ============================="
