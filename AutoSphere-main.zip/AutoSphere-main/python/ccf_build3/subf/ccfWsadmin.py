#--------------------------------------------------------------------------------------------------------------------------
# Name: ccfWsadmin.py
# Role: to disable/enable auto synchronization in a node
# Author: Jeffrey Apiado (IT_NPO_WEB_TEAM)
#---------------------------------------------------------------------------------------------------------------------------
# Syntax: /opt/IBM/WebSphere/AppServer/bin/wsadmin.sh -lang jython -f /opt/jenkins/AutoSphere/python/ccf/subf/ccfWsadmin.py
#---------------------------------------------------------------------------------------------------------------------------
import sys
#---------------------------------------------------------------------------------------------------------------------------
class AutoSync:
    def __init__(self, nodeAG):
        self.nodeAG = nodeAG
        self.getID = AdminConfig.getid("/Node:%s" % self.nodeAG)
        self.config = AdminConfig.list("ConfigSynchronizationService", self.getID)

    def uncheck(self):
        # [INFO] [enable true] meaning Enable Service at server start up, [autoSynchEnabled false] meaning uncheck AutoSynchronization 
        AdminConfig.modify(self.config, '[[enable "true"] [autoSynchEnabled "false"]]')
        AdminConfig.save()

    def check(self):
        # [INFO] [enable true] meaning Enable Service at server start up, [autoSynchEnabled true] meaning check AutoSynchronization 
        AdminConfig.modify(self.config, '[[enable "true"] [autoSynchEnabled "true"]]')
        AdminConfig.save()

if __name__ == '__main__':
#-----------------------------------------------------------------------------------------------------------------------------------
    if len(sys.argv) == 2:
         print "In ccfWsadmin.py"
         nodeAG =  sys.argv[0]
         flag = sys.argv[1]
    else:
         print "USAGE: ./wsadmin.sh -lang jython -f /abspath/ccfWsadmin.py [args:nodeName]"  
         print "[argument] Required to be passed = nodeName"
         print "--------------------------------------------------------------------------" 
    SYNC = AutoSync(nodeAG)
    if flag == "disable":
        print "autosync disable"
        # to disable autoSYNC
        SYNC.uncheck()
    elif flag == "enable":
        # to enable autoSYNC
        print "autosync enable"
        SYNC.check()
