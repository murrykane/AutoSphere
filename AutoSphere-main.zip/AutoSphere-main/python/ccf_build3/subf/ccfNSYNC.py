import sys

def syncNode(nodeNAME):
    targetNode = AdminControl.completeObjectName("type=NodeSync,node=%s,*" % nodeNAME)
    #invoke nodeSync
    try:
       output=AdminControl.invoke(targetNode, 'sync')
    except:
       err = sys.exec_info()
       output = err[2]
    return output



if __name__=="__main__":
    if len(sys.argv) > 0 and len(sys.argv) < 2:
        # which means 1
        nodename = sys.argv[0]
        nsrv = str(nodename)
        result = syncNode(nsrv)
        sys.stdout.write(result)
    else:
        print "Usage : run with wsadmin.sh ==========="
        print "Require 1 argument to pass as parameter"
        print "argument: [nodeName]"
        print "======================================="
        sys.exit(0)
    # display output . . .
