import pickle, os, subprocess, StringIO
import sys, logging, re, time

class cumFix:
    def __init__(self, logg):
          self.reference = self.unpickle()
          self.logm = logg
          self.adminId = self.reference['admName']
          self.pwdId = self.reference['admPword']
          hostDM = self.reference['dmgrhost']
          self.dmgrhost = hostDM.strip("\n")
          self.dmgrbinpath = self.reference['dmgrbinpath']
          self.wpspath = self.reference['wpspath']
          self.wpsfn = self.reference['wpsfn']
          self.newversion = self.reference['newversion']
          self.configengpath = self.reference['configengpath']
          self.wpprofilebase = self.reference['wpprofilebase']
          self.dmgrprofilepath = self.reference['dmgrprofilepath']
          self.wpprofilepath = self.reference['wpprofilepath']
          self.portalname = self.reference['portalname']
          self.dmgrPort = self.reference['dmgrPort']
          self.imclpath = self.reference['imclpath']
          self.ccfdir = self.reference['ccfdir']
          self.ccfupgpath = self.reference['ccfupgpath']
          self.wpinstall = self.reference['wpinstall']
          self.wpdir = self.reference['wpdir']
          self.wcminstall = self.reference['wcminstall']
          self.wcmdir = self.reference['wcmdir']
          self.binpath = "/opt/IBM/WebSphere/Profiles/wp_profile/PortalServer/bin"
          self.efixpath = self.reference['efixpath']
          self.ifixwcm = self.reference['ifixwcm']
          self.ifixwp = self.reference['ifixwp']
          self.PRIM = self.reference['primary']
          self.na = self.reference['nodeAgent']

    def unpickle(self):
          if os.path.isfile("/tmp/accr.txt"):
              with open("/tmp/accr.txt" ,"rb") as uar:
                  data = pickle.load(uar)
                  return data
          else:
              print "/tmp/accr.txt no <file> found"
              sys.exit(0)

    def wkplcIdSearch(self, element):
        inpath = "/opt/IBM/WebSphere/Profiles/wp_profile/ConfigEngine/properties/wkplc.properties"
        if element == "PortalAdminId":
            patt = re.compile(r'^PortalAdminId=(.*)$')
        else:
            patt = re.compile(r'^WasUserid=(.*)$')
        # -----------------------------------------------------------
        scmd = "awk '/^%s=/{print}' %s" % (element, inpath)
        remoteConn = "{0}".format(scmd)
        print "CMD to pass > ",remoteConn
        buff = self.runProc(remoteConn)
        print "BUFF ",buff
        if buff != None or buff != "":
            match = patt.search(buff)
            if match:
                 if match.group(1) != "" and "svcbscwpadmin" in match.group(1):
                    print "Found {0}: {1}".format(element, match.group(1))
                    return "passed"

        print "Verify: Return from {0} element in wkplc.properties".format(element)
        return "chkValue"     

    def runProc(self, cmd):
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        except subprocess.CalledProcessError as e:
            print e.output
        stdout, stderr = proc.communicate()
        if not stderr:
            buff = StringIO.StringIO()
            buff.write(stdout)
            Output = buff.getvalue()
            buff.flush()
            buff.close()
            return Output
        else:
            Output = None
            return Output

    def fileCheck(self, fn, testDIR="/tmp"):
        if os.path.isfile("%s/%s" % (testDIR, fn)):
            if os.path.getsize("%s/%s" % (testDIR, fn)) > 0:
                print "[file ready for parsing]"
                self.logm.info("[file] . . . [ready] [size > 0]")
            else:
                print "[file is empty] [parsing not possible]"
                self.logm.info("[[file is empty] [parsing not possible]")

    def commonSrvNodeEXEC(self, commonCMD):
         servProc = subprocess.Popen(commonCMD, stderr=subprocess.PIPE, shell=True)
         servErr = servProc.communicate()[1]
         if servErr:
            self.logm.warn(servErr)
         else:
            print "> completed without error"
     
    def outputLookup(self, fname, str1, str2="None", str3="None"):
        errOutput = 0
        self.fileCheck(fname)
        profn = "/tmp/%s" % fname
        contain = []
        containB = []
        containC = []
        if str1:
            with open(profn, "r") as ofile:
                contain = [line for line in ofile if line.find(str1) != -1]
                if contain:
                    print contain
                else:
                    print "Can't return an empty ArrayList for keyword: %s" % str1
                    self.logm.error("[ArrayList] is Null . . . . [can't return value] for keyword: %s" % str1)
                    errOutput = 1
        if str2 != "None":
            with open(profn, "r") as bfile:
                containB = [line for line in bfile if line.find(str2) != -1]
                if containB:
                    print containB
                else:
                    print "Can't return an empty ArrayList for keyword: %s" % str2
                    self.logm.error("[ArrayList] is Null . . . . [can't return value] for keyword: %s" % str2)
                    errOutput = 1
        if str3 != "None":
            with open(profn, "r") as cfile:
                containC = [line for line in cfile if line.find(str3) != -1]
                if containC:
                    print containC
                else:
                    print "Can't return an empty ArrayList for keyword: %s" % str3
                    self.logm.error("[ArrayList] is Null . . . . [can't return value] for keyword: %s" % str3)
                    errOutput = 1


        if contain and containB and containC:
           return (contain, containB, containC)
        elif contain and containB and not containC:
           return (contain, containB)
        elif contain and not containB and not containC:
           return (contain)
        elif not str1:
           self.logm.warn("Minimum 2 argument is required (str1 argument and filename)")
           print "Minimum 2 argument is required (str1 argument and filename)"
           sys.exit(1)
        elif errOutput: # meaning []
           return ([])

    def valueChecker(self, valuez, ffname):
        rightFile = "/tmp/%s" % ffname
        if bool(valuez) == False: # meaning []
           self.logm.error("[empty list] . . . . . [define value is null]")
        else:
            #rightFile = "/tmp/%s" % ffname
            valuez = set(valuez)
            if len(valuez) == 1:
                value = valuez
                self.displayPass(rightFile)
                self.logm.info("[result] . . . . %s" % value)
                print "[result] . . . . ", value
                return True

        # valuez > 1
        self.displayErr(rightFile)
        print "[checker] . . . . . . . . . [unsuccesfull]"
        self.logm.info("[checker] . . . . . . . . . [unsuccesfull]")
        return False

    def displayErr(self, myfile):
        self.logm.error("[%s]- - - - - - - - - - - - - - - - START - - - - - - - - - - - - - - - - - - -" % myfile)
        with open(myfile, "r") as dof:
            for errline in dof:
                self.logm.error(errline)
        self.logm.error("- - - - - - - - - - - - - - - - - -- -END- - - - - - - - - - - - - - - - - - - - -")

    def displayPass(self, myfile):
        self.logm.info("[%s]- - - - - - - - - - - - - - - - START - - - - - - - - - - - - - - - - - - -" % myfile)
        print "[%s]- - - - - - - - - - - - - - - -START- - - - - - - - - - - - - - - - - - -" % myfile
        with open(myfile, "r") as pof:
            for passline in pof:
                self.logm.info(passline)
                print passline
        self.logm.info("- - - - - - - - - - - - - - - - - - - -END- - - - - - - - - - - - - - - - - - - - -")
        print "- - - - - - - - - - - - - - - - - - - -END- - - - - - - - - - - - - - - - - - - - -"


    def portalCleanUp(self):
        print "[CLEAN UP target folder in PortalServer] . . . . . . . . start"
        self.logm.info(" - - - CLEAN UP target folder in PortalServer")
        self.remoteCollector("wstemp", "tranlog", "temp")
        print "[CLEAN UP] . . . . . . . . . . . . . . . . . . . done"
        self.logm.info(" - - - CLEAN UP done.")
        self.ibmShell()

    def remoteCollector(self, *args):
        dirs = args
        for directory in dirs:
            abspath = "{0}/{1}".format(self.wpprofilebase, directory)
            print "[cleanUp] . . . . [%s] DIRECTORY" % abspath
            self.logm.info("[cleanUp] . . . . [%s] DIRECTORY" % abspath)
            for item in os.listdir(abspath):
                pathFile = os.path.join(abspath, item)
                if os.path.isfile(pathFile):
                    # remove file if file exists
                    try:
                        os.unlink(pathFile)
                    except:
                       cmd = "rm -rf {0}/*".format(abspath)
                       os.system(cmd)
                else:
                   # remove directory and its content if directory
                   try:
                       shutil.rmtree(pathFile)
                   except:
                       cmd = "rm -rf {0}/*".format(abspath)
                       os.system(cmd)
        print "[target directory] ",dirs," . . . . . [cleared]"
        self.logm.info("[target directories] . . . . . [cleared]")

    def dmgrCleanUp(self):
        self.dmgrProc()
        print "[CLEAN UP target folder in DMGR] . . . . . . . . start"
        self.logm.info(" - - - CLEAN UP target folder in DMGR")
        self.garbageCollector("wstemp", "tranlog", "temp")
        print "[CLEAN UP] . . . . . . . . . . . . . . . . . . . done"
        self.logm.info(" - - - CLEAN UP done.")
        self.ibmShell(pportal=0)
        time.sleep(10)
        print "idle for 10 sec before starting dmgr"
        self.dmgrProc(flag=1) # added 9/19/17 start DMGR

    def dmgrProc(self, flag=0):
        if not flag: # stop DManager
            getRunAppCmd = "ssh %s '%s/serverStatus.sh -all' > /tmp/serverStat.txt" % (self.dmgrhost, self.dmgrbinpath)
            print "[command] %s" % getRunAppCmd
            self.logm.info("[command] %s" % getRunAppCmd)
            self.commonSrvNodeEXEC(getRunAppCmd)
            (var2) = self.outputLookup("serverStat.txt","STARTED")
            Run = 0
            for status in var2:
                if 'dmgr' in status: Run = 1

            if Run:
                print "STOP the dmgr [stopManager.sh]"
                self.logm.info("STOP the dmgr [stopManager.sh]")
                dmgrCmd = "ssh %s '%s/stopManager.sh' > /tmp/SManager.txt" % (self.dmgrhost, self.dmgrbinpath)
                self.commonSrvNodeEXEC(dmgrCmd)
                #(nresult) = self.outputLookup("SManager.txt", "stop completed")
                (nresult) = self.outputLookup("SManager.txt", "ADMU4000I:")
                self.valueChecker(nresult, "SManager.txt")
            else:
                 print "- - - DMGR already STOPPED"
                 self.logm.info("- - - DMGR already STOPPED")

        if flag: # start DManager
            print "START the dmgr [startManager.sh]"
            self.logm.info("START the dmgr [startManager.sh]")
            dmgrCmd = "ssh %s '%s/startManager.sh' > /tmp/SManager.txt" % (self.dmgrhost, self.dmgrbinpath)
            self.commonSrvNodeEXEC(dmgrCmd)
            #(wpResult) = self.outputLookup("SManager.txt", "open for e-business")
            (wpResult) = self.outputLookup("SManager.txt", "ADMU3000I:")
            self.valueChecker(wpResult, "SManager.txt")

    def garbageCollector(self, *args):
        dirs = args
        for directory in dirs:
            abspath = "{0}/{1}".format(self.dmgrprofilepath, directory)
            print "[cleanUp] . . . . [%s] DIRECTORY" % abspath
            self.logm.info("[cleanUp] . . . . [%s] DIRECTORY" % abspath)
            sshCMD = "ssh {0} 'rm -rf {1}/*'".format(self.dmgrhost, abspath)
            self.commonSrvNodeEXEC(sshCMD)
            time.sleep(1)        

    def ibmShell(self, pportal=1):
        if pportal:
            shCMD = "{0}/osgiCfgInit.sh".format(self.wpprofilepath)
            shCMD1 = "{0}/clearClassCache.sh".format(self.wpprofilepath)
            print "[command] %s . . . . . . . . . [exec]" % shCMD
            self.logm.info("[exec] %s" % shCMD)        
            print "[command] %s . . . . . . . . . [exec]" % shCMD1
            self.logm.info("[exec] %s" % shCMD1)
            self.commonSrvNodeEXEC(shCMD1)
        else:
            shCMD = "ssh {0} '{1}/osgiCfgInit.sh'".format(self.dmgrhost, self.dmgrbinpath)
            shCMD1 = "ssh {0} '{1}/clearClassCache.sh'".format(self.dmgrhost, self.dmgrbinpath)
            print "[command] %s" % shCMD
            self.logm.info("[exec] %s" % shCMD)
            self.commonSrvNodeEXEC(shCMD)
            self.logm.info("[exec] %s" % shCMD1)
            print "[command] %s" % shCMD1
            self.commonSrvNodeEXEC(shCMD1)

    def wpsPropertiesFixlevel(self):
        #hname = self.srvf
        onpath = os.path.join(self.wpspath, self.wpsfn)
        print "wpsPath : ",onpath
        newCMD = 'cat {0}'.format(onpath)
        print "[command] %s" % newCMD
        Output = self.runProc(newCMD)
        if Output != None or Output != "":
            s = Output.find('fixlevel')
            lineO = Output[s:]
            br = lineO.find(" ")
            xx = lineO[:br-20]
        else: # Assuming Output is None so set xx to empty string
            xx = ""

        if self.newversion in xx:
           print "[Cumulative Fixed upgrade was completed in this machine]"
           print xx
           return "SKP"
        #-----Going for upgrade
        print "[Cumulative Fixed - upgrade start]"
        print xx
        return "UPG"

    def pre_configEngine_shell(self):
        self.ConfigEngine("PRE-CONFIG-WP-PTF-CF")
        (preResult) = self.outputLookup("ConfigENG.txt", "BUILD SUCCESSFUL")
        result = self.valueChecker(preResult,"ConfigENG.txt")
        print "==" * 20
        self.logm.info("==" * 20)
        return result

    def ConfigEngine(self, args):
        ARGS = args
        print ""
        print ARGS
        self.logm.info(ARGS)

        engCmd = "{0}/ConfigEngine.sh {1}".format(self.configengpath, ARGS)
        engX =  "{0} > /tmp/ConfigENG.txt".format(engCmd)
        print "[command] %s" % engX
        print "[exec] . . . . [reference output file ConfigENG.txt]"
        self.logm.info("[command] %s" % engX)
        self.logm.info("[exec] . . . . [reference output file ConfigENG.txt]")
        self.commonSrvNodeEXEC(engX)
        print "[run] [command]. . . . . [done]"
        self.logm.info("[run] [command]. . . . . [done]")
        print "[idle] . . . . 10Sec"
        self.logm.info("[idle] . . . . 10Sec")
        print "[Module] . . . . ConfigEngine . . .. [exit]"
        self.logm.info("[Module] . . . . ConfigEngine . . .. [exit]")

    def last_configEngine_shell(self):
            fFlag = 0
            self.ConfigEngine("CONFIG-WP-PTF-CF")
            (confResult) = self.outputLookup("ConfigENG.txt", "BUILD SUCCESSFUL")
            if confResult != []:
                  result = self.valueChecker(confResult, "ConfigENG.txt")
                  if result is True:
                      print "[ConfigEngine.sh post-installation [completed]"
                  elif result is False:
                      print "[ConfigEngine.sh post-installation [Failed]"
                      fFlag = 1
            else:
                print "[ConfigEngine.sh post-installation [Failed]"
                fFlag = 1

            return fFlag

    def STOPPER(self, wstop, nstop):
        # stopping appServer and node
        if wstop:
            getRunAppCmd = '%s/stopServer.sh %s > /tmp/stopServer.txt' % (self.wpprofilepath, self.portalname)
            print "[command] %s" % getRunAppCmd
            print "[exec] STOP AppServer"
            self.logm.info("[command] %s" % getRunAppCmd)
            self.logm.info("[exec] - - - STOP AppSERVER")
            self.commonSrvNodeEXEC(getRunAppCmd)
            #(srvo) = self.outputLookup("stopServer.txt","stop completed")
            (srvo) = self.outputLookup("stopServer.txt","ADMU4000I:")
            self.valueChecker(srvo,"stopServer.txt")

        if nstop:
            getRunAppCmd = '%s/stopNode.sh > /tmp/stopNode.txt' % (self.wpprofilepath)
            print "[command] %s" % getRunAppCmd
            print "[exec] STOP Node"
            self.logm.info("[command] %s" % getRunAppCmd)
            self.logm.info("[exec] - - - STOP NODE")
            self.commonSrvNodeEXEC(getRunAppCmd)
            #(nodeo) = self.outputLookup("stopNode.txt","stop completed")
            (nodeo) = self.outputLookup("stopNode.txt","ADMU4000I:")   #ADMU0509I: It already stop
            self.valueChecker(nodeo,"stopNode.txt")

    def NodeSync2Dmgr(self):
        synCMD = "{0}/syncNode.sh {1} {2} > /tmp/NodeSYNC.txt"
        exCMD = synCMD.format(self.wpprofilepath, self.dmgrhost , self.dmgrPort)
        print "[command] ",exCMD
        self.commonSrvNodeEXEC(exCMD)
        (syncresult) = self.outputLookup("NodeSYNC.txt", "ADMU0402I:")
        self.valueChecker(syncresult, "NodeSYNC.txt")

    def STARTER(self, appSrv=1, nodeServ=1):
        # start the appServre and node
        if appSrv:
             getRunAppCmd = '%s/startServer.sh %s > /tmp/startServer.txt' % (self.wpprofilepath, self.portalname)
             print "[command] %s" % getRunAppCmd
             print "[exec] START AppServer"
             self.logm.info("[command] %s" % getRunAppCmd)
             self.logm.info("[exec] - - - START AppSERVER")
             self.commonSrvNodeEXEC(getRunAppCmd)
             #(startrvo) = self.outputLookup("startServer.txt","open for e-business")
             (startrvo) = self.outputLookup("startServer.txt","ADMU3000I:")
             self.valueChecker(startrvo,"startServer.txt")
        if nodeServ:
            getRunAppCmd = '%s/startNode.sh > /tmp/startNode.txt' % (self.wpprofilepath)
            print "[command] %s" % getRunAppCmd
            print "[exec] START Node"
            self.logm.info("[command] %s" % getRunAppCmd)
            self.logm.info("[exec] - - - START Node")
            self.commonSrvNodeEXEC(getRunAppCmd)
            #(startrnode) = self.outputLookup("startNode.txt","open for e-business")
            (startrnode) = self.outputLookup("startNode.txt","ADMU3000I:")
            self.valueChecker(startrnode,"startNode.txt")

    def AppStatus(self, color):
        command = '%s/serverStatus.sh -all' % self.wpprofilepath
        print "[command] %s" % command
        output = self.runProc(command)
        if color == "red":
            if output.find("ADMU0509I:") != -1: # Appserver is stopped
                return "skip"
        elif color == "green":
            if output.find("ADMU0508I:") != -1: # Appserver is started
                return "skip"

        return "invoke"  # if -1


    def STOP_START_SHOP(self, sflag=0):
        nstop = 0
        wstop = 0
        if not sflag:
            getRunAppCmd1 = '%s/serverStatus.sh -all > /tmp/serverStat.txt' % (self.wpprofilepath)
            print "[command] %s" % getRunAppCmd1
            self.logm.info("[command] %s" % getRunAppCmd1)
            self.commonSrvNodeEXEC(getRunAppCmd1)
            (var1) = self.outputLookup("serverStat.txt","STARTED")
            for output in var1:
                if "nodeagent" in output: nstop = 1
                elif "WebSphere_Portal" in output: wstop = 1
                elif "empty" in output:
                    print "No active Application Running"
                    self.logm.warn("No active Application Running")
                    pass

            if not nstop and not wstop:
                print "App servre and nodeAgent: Status: already Stopped"
            else:
                self.STOPPER(wstop, nstop)
        time.sleep(10)

    def status_servNa(self, text): # stop ADMU0509I > nodeagent; start ADMU0508I > nodeagent
        nastart=0
        nastop=0
        trig = '%s/serverStatus.sh -all > /tmp/serverStat1.txt' % (self.wpprofilepath)
        print "[command] %s" % trig
        self.logm.info("[command] %s" % trig)
        self.commonSrvNodeEXEC(trig)
        ( vars ) = self.outputLookup("serverStat.txt", text)
        for output in vars:
                if "nodeagent" in output and text == "ADMU0509I": nastop = 1
                elif "nodeagent" in output and text == "ADMU0508I": nastart = 1
                else:
                    print "Take nodeagent status default value 0!"
        return (nastop, nastart)



    def mainInstaller(self, installed):
        if installed:
            self.ccf_Install()
            (ccfResult) = self.outputLookup("ccfInstall.txt", "Portal files have been updated")
            result = self.valueChecker(ccfResult,"ccfInstall.txt")
            if not result:
                return "Installation [failed]"

            status = self.WPVersion()
            if not status:
                self.logm.info("compact cummulative fix . . . . . . . . [installed]")
                self.logm.info("Installation . . . . . . . . . . [success]")
                print "compact cummulative fix . . . . . . . . [installed]"
                print "Installation . . . . . . . . . . [success]"
            elif status:
                self.logm.error("compact cummulative fix . . . . . . . . [INSTALLATION STOP]")
                self.logm.error("Installation . . . . . . . . . . [FAILED]")
                return False

        else:
                self.logm.info("cummulative fixed version was LATEST")
                self.logm.info("compact cummulative fix . . . . . . . . [SKIPPED]")
                self.logm.info("Installation . . . . . . . . . . [SKIPPED]")
                print "cummulative fixed version was LATEST"
                print "compact cummulative fix . . . . . . . . [SKIPPED]"
                print "Installation . . . . . . . . . . [SKIPPED]"
        return "Installation [completed]!"
    
    def ccf_Install(self):
        pre_cmd = '{0}/imcl install com.ibm.websphere.PORTAL.SERVER.v80 -repositories /tmp/{1}/repository.config -installationDirectory {2} -acceptLicense > /tmp/ccfInstall.txt'
        ccf_cmd = pre_cmd.format(self.imclpath, self.ccfdir, self.ccfupgpath)
        print "[command] %s" % ccf_cmd
        self.commonSrvNodeEXEC(ccf_cmd)

    def ifixWP_Install(self):
        pre_cmd = '{0}/imcl install {1} -installationDirectory {2} -repositories /tmp/{3}/repository.config -acceptLicense > /tmp/ifixWPInstall.txt'
        ccf_cmd = pre_cmd.format(self.imclpath, self.wpinstall, self.ccfupgpath, self.wpdir)
        print "[command] %s" % ccf_cmd
        self.commonSrvNodeEXEC(ccf_cmd)

    def ifixWCM_Install(self):
        suffix = self.wcminstall
        pre_cmd = '{0}/imcl install {1} -repositories /tmp/{2}/repository.config -installationDirectory {3} -acceptLicense > /tmp/ifixWCMInstall.txt'
        ccf_cmd = pre_cmd.format(self.imclpath, suffix, self.wcmdir, self.ccfupgpath)
        print "[command] %s" % ccf_cmd
        self.commonSrvNodeEXEC(ccf_cmd)

    def WPVersion(self):
        self.sshWpv()
        iinfo = self.readWpv()
        verInfo = self.fetchWpv(iinfo)
        upgradeStat = self.checkPoint(verInfo)
        return upgradeStat
    
    def sshWpv(self):
        wpvCmd = '{0}/WPVersionInfo.sh > /tmp/wpversion.txt'.format(self.binpath)
        print "[exec] %s" % wpvCmd
        self.logm.info("[cmd exec] %s" % wpvCmd)
        sys.stdout.write("[command exec] . . . . . . . . . . . . . . . . ")
        wpvProc = subprocess.Popen(wpvCmd, stderr = subprocess.PIPE, shell=True)
        sterr = wpvProc.communicate()[1]
        if sterr:
            print ""
            self.logm.warn(sterr)
        else:
            print "[shell execution completed]"
            self.logm.info(" - - - [parsing and output redirection completed]")
        self.fileCheck("wpversion.txt")

    def fileCheck(self, fn, testDIR="/tmp"):
        if os.path.isfile("%s/%s" % (testDIR, fn)):
            if os.path.getsize("%s/%s" % (testDIR, fn)) > 0:
                print "[file ready for parsing]"
                self.logm.info("[file] . . . [ready] [size > 0]")
            else:
                print "[file is empty] [parsing not possible]"
                self.logm.info("[[file is empty] [parsing not possible]")

    def readWpv(self):
        self.logm.info("[start] ---------------WPVersionInfo.sh------------------")
        build = []
        name = []
        info = {}
        with open("/tmp/wpversion.txt", "r") as wpvf:
            for readLine in wpvf:
                self.logm.info(readLine)
                foo = readLine.find("Build Level")
                bar = readLine.find("Name")
                if bar != -1:
                    line = readLine.replace("Name","")
                    name.append(line.strip())
                if foo != -1:
                    fine = readLine.replace("Build Level","")
                    build.append(fine.strip())
        self.logm.info("[end] ----------------------WPVersionInfo.sh--------------")
        for n, b in zip(name, build):
            info[n] = b
        # return a dictionary
        return info

    def fetchWpv(self, info, head="[Current Version]"):
        pattern = re.compile(r'.*(CF\d\d?).*')
        fhold = []
        print " - " * 30
        print head
        for k, v in info.items():
            self.logm.info("%s - - - - - - - %s" % (k,v))
            print k," - - - - - - - ",v
            toss = pattern.search(v)
            if toss:
                fhold.append(toss.group(1))
        # returning no duplication
        print " - " * 30
        return set(fhold)

    def checkPoint(self, versiond):
        upgrade = 0
        var1 = versiond.pop()
        if var1 != self.newversion:
            upgrade = 1
            print "[upgrade/installation] . . . . . . . [continue]"
            self.logm.info("[upgrade/installation] . . . . . . . [continue]")
        else:
            print "-----------------------------------------------------------------------"
            print "[In latest version] [found or already installed] [version: LATEST]"
            print "-----------------------------------------------------------------------"
            self.logm.info("-----------------------------------------------------------------------")
            self.logm.info("[In latest version] [found or already installed] [version: LATEST]")
            self.logm.info("-----------------------------------------------------------------------")
        return upgrade

    def efixLookup(self):
        WCMset = 0
        WPset = 0
        cmdWCM = 'find {0} -type f -name {1}'.format(self.efixpath, self.ifixwcm)
        print "[command to exec] %s" % cmdWCM
        prowcm = subprocess.Popen(cmdWCM, stdout=subprocess.PIPE, shell=True)
        stdout = prowcm.communicate()[0]
        if self.ifixwcm in stdout:
            WCMset = 1
        #----------------------------------------------------
        cmdWP = 'find {0} -type f -name {1}'.format(self.efixpath, self.ifixwp)
        print "[command to exec] %s" % cmdWP
        prowp = subprocess.Popen(cmdWP, stdout=subprocess.PIPE, shell=True)
        stdout = prowp.communicate()[0]
        if self.ifixwp in stdout:
            WPset = 1
        #----------------------------------------------------
        print "[flagSet] WCMset %d WPset %d" % (WCMset, WPset)
        return WCMset, WPset

    def nodeStart(self):
        (nodestop, nodestart) = self.status_servNa("ADMU0508I")
        if not nodestart:
            getRunAppCmd = '%s/startNode.sh > /tmp/startNode.txt' % (self.wpprofilepath)
            print "[command] %s" % getRunAppCmd
            print "[exec] START Node"
            self.logm.info("[command] %s" % getRunAppCmd)
            self.logm.info("[exec] - - - START Node")
            self.commonSrvNodeEXEC(getRunAppCmd)
            ( startrnode ) = self.outputLookup("startNode.txt","ADMU3000I:")
            self.valueChecker(startrnode,"startNode.txt")
        else:
            print "NodeAgent already STARTED, proceed to NEXT."

    def nodeStop(self):
        (nodestop, nodestart) = self.status_servNa("ADMU0509I")
        if not nodestop:
            STOPnodeCmd = '%s/stopNode.sh > /tmp/stopNode.txt' % (self.wpprofilepath)
            print "[command] %s" % STOPnodeCmd
            print "[exec] STOP Node"
            self.logm.info("[command] %s" % STOPnodeCmd)
            self.logm.info("[exec] - - - STOP Node")
            self.commonSrvNodeEXEC(STOPnodeCmd)
            ( stopnode ) = self.outputLookup("stopNode.txt","ADMU4000I:")
            self.valueChecker(stopnode ,"stopNode.txt")
        else:
            print "NodeAgent already STOPPED, proceed to NEXT."

    def invokeWPConfigServ(self):
        print "[invoke] wsadmin running external jython script"
        self.logm.info("[invoke] wsadmin running external jython script")
        pCmd = "ssh {0} '/opt/IBM/WebSphere/Profiles/Dmgr01/bin/wsadmin.sh -lang jython -f /opt/jenkins/AutoSphere/python/ccf_build3/subf/ccfResource.py'".format(self.dmgrhost)
        print "[command] %s" % pCmd
        self.logm.info("[command] %s" % pCmd)
        self.commonSrvNodeEXEC(pCmd)
        print "[exec] . . . . . . . . . [done]"
        self.logm.info("[exec] . . . [done]")
    

    def isPrimary(self):
        primary = self.PRIM
        return primary

    def WP_ifixInstallation(self):
        self.ifixWP_Install()
        (wpResult) = self.outputLookup("ifixWPInstall.txt", "Installed")
        if wpResult != []:
            result = self.valueChecker(wpResult,"ifixWPInstall.txt")
        else:
            print "return empty list"
            result = False
        return result
        #-----------------------------------------------------------------

    def WCM_ifixInstallation(self):
        self.ifixWCM_Install()
        wcmResult = self.outputLookup("ifixWCMInstall.txt", "Installed")
        if wcmResult != []:
            result = self.valueChecker(wcmResult,"ifixWPInstall.txt")
        else:
            print "return empty list"
            result = False
        return result

#------------------------- LOGS ----------------------
class ccfLog:
    ERROR = '\033[91m'
    ENDC = '\033[0m'
    def __init__(self, filename="somelog.log", strfmt='[%(asctime)s] %(levelname)-8s: %(message)s', lvl=logging.INFO):
        self.logger = logging.getLogger()
        if self.logger.handlers:
            self.logger.handlers = []
        logging.basicConfig(format=strfmt, level=lvl, datefmt='%Y-%m-%d %I:%M:%S %p')
        lhStdout = self.logger.handlers[0]
        fh = logging.FileHandler(filename)
        fh.setFormatter(logging.Formatter(fmt=strfmt, datefmt='%Y-%m-%d %I:%M:%S %p'))
        ch = logging.StreamHandler()
        ch.setLevel(logging.ERROR)

        self.logger.addHandler(fh)
        self.logger.removeHandler(lhStdout)
        self.logger.addHandler(ch)

    def info(self, text):
        self.logger.info(text)

    def warn(self, text):
        self.logger.warning(text)

    def error(self, text):
        self.logger.error(self.ERROR + text + self.ENDC)

    def close(self):
       logging.shutdown()


#------------------------------------- MAIN -----------------------------------
def main():
    logger = ccfLog("/tmp/cf22.log")
    ccfn = cumFix(logger)
    logger.info("<start> ------------ MAIN -----------------")
    # checkpoint 1 for wkplc.properties
    for ele in ["PortalAdminId", "WasUserid"]:
        Stro = ccfn.wkplcIdSearch(ele)
        if Stro == "chkValue":
            ttxt = "Verify: value in {0} element! [c] to continue:".format(ele)
            while True:
                tt = raw_input(ttxt) or "c"
                if tt == "c":
                     Stro = ccfn.wkplcIdSearch(ele)
                     if Stro == "passed":
                        break
                else:
                     print "UnKnown input [type: c]"
    # primary portal flag
    PRFlag = ccfn.isPrimary()
    if PRFlag:
        logger.info("Notify: PRIMARY PORTAL ")
        print "Notify: PRIMARY PORTAL "
    # Exclusively for remaining portal server not primary
    else: 
        logger.info("Notify: PORTAL ")
        print "Notify: PORTAL "
    #endfor
    upgradeStat = ccfn.WPVersion()
    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
    # Stop app server and nodeagent 9/20/17 *
    ccfn.STOP_START_SHOP()
    if not PRFlag: 
        ccfn.NodeSync2Dmgr() # node agent should be sync to dmgr
    # - - - - - - - - - - - - - - - - - - - - - - - - - -  - 
    result = ccfn.mainInstaller(upgradeStat)  
    # - - -  - - -- - - - - - -- - - - - - - - - - - - - - 
    print result
    WCMset, WPset = ccfn.efixLookup()           # verify if ifixes already installed
    if not WPset:
         result = ccfn.WP_ifixInstallation()       # install ifix for WP
         if not result:
             logger.error("WP_ifixInstallation Failed")
         else:
             logger.info("WP ifix installed successfully")
             print "WP ifix installed successfully"
    else:
            print "==================================="
            print "WP ifix already installed [SKIPPED]"
            print "==================================="

    if not WCMset:
         result = ccfn.WCM_ifixInstallation()      # install ifix for WCM
         if not result:
             logger.error("WCM_ifixInstallation Failed")
         else:
             logger.info("WCM ifix installed sucessfully")
             print "WCM ifix installed sucessfully"
    else:
            print "===================================="
            print "WCM ifix already installed [SKIPPED]"
            print "===================================="

    if PRFlag:
         # For primary portal process only
         logger.info("Stop dmgr, then cleanUp")
         ccfn.dmgrCleanUp()   # stop Dmgr , do cleanup, and start dmgr
         logger.info("Clean up primary portal")
         ccfn.portalCleanUp()  # do cleanup for local portal
         logger.info("Sync nodeAgent to dmgr")
         ccfn.NodeSync2Dmgr()  # sync node to dmgr
    else:
        logger.info("Bypass: dmgrCleanUp(), portalCleanUp(), dmgrProc(flag=1), NodeSync2Dmgr() & nodeStart()")
        print "Bypass: dmgrCleanUp(), portalCleanUp(), dmgrProc(flag=1), NodeSync2Dmgr(), nodeStart()"
    # checkpoint 2 for wkplc.properties Id

    logger.info("Start NodeAgent")
    ccfn.nodeStart()   # start node agent
    for ele in ["PortalAdminId", "WasUserid"]:
        Stro = ccfn.wkplcIdSearch(ele)
        if Stro == "chkValue":
            ttxt = "Verify: value in {0} element! [c] to continue:".format(ele)
            while True:
                tt = raw_input(ttxt) or "c"
                if tt == "c":
                     Stro = ccfn.wkplcIdSearch(ele)
                     if Stro == "passed":
                        break
                else:
                     print "unknown input [type: c]"
   
    cont = ccfn.wpsPropertiesFixlevel()
    if cont == "UPG":
            resULT = ccfn.pre_configEngine_shell()
            if not resULT:
                logger.error("		==================================")
                logger.error("		pre_configEngine.sh command FAILED")
                logger.error("		==================================") 
            print "idle for 7 secs before proceed"
            time.sleep(7)    
            fFlag = ccfn.last_configEngine_shell()
            if fFlag:
                while True:
                    response = raw_input("RE-INSTALL? Enter [c]ontinue , [q]uit system exit, [e]mpty dmgr/portal wstemp/tranlog/temp directory: ")
                    if response == "c":
                        ign = ccfn.last_configEngine_shell()
                        if not ign: # assuming the proceeding attempt succeed
                            break
                    elif response == "e":
                        ccfn.dmgrCleanUp() # stop Dmgr , cleanup, start dmgr
                        ccfn.portalCleanUp() # do cleanup locally
                        #ccfn.NodeSync2Dmgr()  # removed 10/12/17 sync node to Dmgr
                        print "- - - > cleanup [done]"
                    elif response == "q":
                        sys.exit(0) # system exit if error ocuur
                    elif response == "Q":
                        sys.exit(0) # system exit if error occur
                    else:
                        print "Unknown input [valid: c ,e or q]"
    else:
            print "======================================"
            print "[SKIPPED configEngine.sh][config done]"
            print "======================================"

    # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
    if PRFlag:
        # black list white list in WPCONFIG Service
	    ccfn.invokeWPConfigServ()
        # - - -  - - - - - - - - - - - - - - - - - - - - - - - - - - 
    	print "[Stop Node Agent . . . . . ]"
        logger.info("[Stop Node Agent . . . . ]")
        # NEED to stop nodeAgent
        ccfn.nodeStop() # added 10/12/17
        print "[Run SyncNode][ . . . . . ]"
        logger.info("[Run SyncNode . . . . ]")
        ccfn.NodeSync2Dmgr()  # added 10/12/17 replace sync node in shell exec
        # start node Agent
        print "[Start Node Agent . . . . . ]"
        logger.info("[Start Node Agent]")
        ccfn.nodeStart() # added 10/12/17
    
        stst = ccfn.AppStatus("red")
        if stst == "invoke":
            print "[stop portal srv . . . . ]"
            logger.info("[stop portal srv . . . . ]")
            ccfn.STOPPER(1, 0) # stop app server

        time.sleep(15)
        print "[Appserver start . . . ]"
        logger.info("[Appserver Start . . . . ]")
        ccfn.STARTER(nodeServ=0) # start Appserver
        print "============================EOF=========================="    
        logger.info("==========End of file============")
    
if __name__ == "__main__":
    main()
 
