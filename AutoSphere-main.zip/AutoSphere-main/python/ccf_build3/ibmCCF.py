import os, sys, time, re, shutil
import subf.ccfLIB as scc
from ConfigParser import SafeConfigParser
import subprocess, pickle 
import StringIO 

class cffInstallation:
    def __init__(self, logger):
        self.logm = logger 
        self.cfg = SafeConfigParser()
        self.logm.info("[read] from ccfCONFIG.txt")
        self.cfg.read("ccfCONFIG.txt")
        self.parse = scc.ccfParse(self.cfg)
        self.zf = self.parse.getFiles()

        self.dirf = self.parse.getDirectories()
        self.pathf = self.parse.getPath()
        self.logm.info("[output][CFiles] %s" % self.zf)
        self.logm.info("[output][Path] %s" % self.pathf)
        self.logm.info("[output][Directory] %s" % self.dirf)
        self.Auth = scc.ccfAuth(self.pathf["dmgrsecpath"], self.zf["security"])
        holdSec = self.Auth.searchEng()
        aid, pwid = self.Auth.search_LookUp(holdSec)
        self.adminId = aid
        #print "[adminid] ",self.adminId
        self.pwdId = self.Auth.decrypt(pwid)
        #print "[pwdid] ",self.pwdId
        self.hname =  scc.ccfUtil().getHostname()
        self.CCFUTIL = scc.ccfUtil()
        self.dmgrPort =  self.CCFUTIL.getPortNumber(self.pathf['wsadminprop'], self.zf['wsadminfn'])
        self.wcmSTR = "#extensiontype.*=application/octet-stream"
    
    #def cffServerList(self):
        #return ast.literal_eval(self.srvf)
        
    def cff_Setters(self, newServerName):
        self.logm.info("[output][Server] %s" % newServerName) 
        self.srvf = newServerName

    def ccfFiles(self, verf=0):
        if os.path.isfile("/tmp/%(ccf)s" % self.zf):
            print "[search] %(ccf)s in /tmp . . . . . . . [found]" % self.zf
            self.logm.info("[search] %(ccf)s in /tmp . . . . . . . [found]" % self.zf)
        else:
            print "[search] %(ccf)s in /tmp . . . . . . . [missing" % self.zf
            self.logm.info("[search] %(ccf)s in /tmp . . . . . . . [missing]" % self.zf)
            verf = 1
        if os.path.isfile("/tmp/%(ifix_wp)s" % self.zf):
            print "[search] %(ifix_wp)s in /tmp . . . . . . . [found]" % self.zf
            self.logm.info("[search] %(ifix_wp)s in /tmp . . . . . . . [found]" % self.zf)
        else:
            print "[search] %(ifix_wp)s in /tmp . . . . . . . [missing]" % self.zf
            self.logm.info("[search] %(ifix_wp)s in /tmp . . . . . . . [missing]" % self.zf)
            verf = 2
        if os.path.isfile("/tmp/%(ifix_wcm)s" % self.zf):
            print "[search] %(ifix_wcm)s in /tmp . . . . . . . [found]" % self.zf
            self.logm.info("[search] %(ifix_wcm)s in /tmp . . . . . . . [found]" % self.zf)
        else:
            print "[search] %(ifix_wcm)s in /tmp . . . . . . . [missing]" % self.zf
            self.logm.info("[search] %(ifix_wcm)s in /tmp . . . . . . . [missing]" % self.zf)
            verf = 3
        #--------------------------------------------------
        if verf:
            self.logm.warn("[Process] . . . . . . . . . . . . [halt]")
            print "[Process] . . . . . . . . . . . . [halt]"
            if verf == 1: mfile = self.zf['ccf']
            elif verf == 2: mfile = self.zf['ifix_wp']
            elif verf == 3: mfile = self.zf['ifix_wcm']
            print "[]=================================[]"
            self.logm.warn("[copy missing file to /tmp directory]")
            print "[copy missing file to /tmp directory]"
            print "[]=================================[]"
            self.logm.warn("[missing] [files as a requirement] [%s]" % mfile)
            print "[filename] %s" % mfile 
            sys.exit(0)
        else:
            print "[required files all found]"
            self.logm.info("[required files all found]")
    

    def tmp_local(self, dirname): 
        self.logm.info("[creating /tmp/%s directory and set perm to 777]" % dirname)
        sys.stdout.write("[creating directory name %s and set perm to 777] . . . . . . . . " % dirname) 
        x = os.system("mkdir /tmp/%s && chmod 777 /tmp/%s" % (dirname, dirname))
        if x > 0:
            print "[err]"
            self.logm.warn("[unsuccesful (directory already exist or operation denied)]")
        else:
            self.logm.info(" - - - [created succesfully]")
            print "[created]"

    def copyScript(self, hn):
        self.logm.info("[copy ccfScript.py to portal server %s]" % hn)
        print "[copy ccfScript.py to portal server %s]" % hn
        cc = "rsync -avh --inplace /opt/jenkins/AutoSphere/python/ccf_build3/subf/ccfScript.py %s:/opt/jenkins/AutoSphere/python/" % hn
        print "[command] ",cc
        result = self.runProc(cc)
        if result != None or result != "":
            print result
            print "[rsync / ccfScript.py [done]"
            print ""
            self.logm.info("[copy accr.txt to portal server %s]" % hn)
            print "[copy accr.txt to portal server %s]" % hn
            nc = "rsync -avh --inplace /tmp/accr.txt %s:/tmp" % hn
            print "[command] ",nc
            outt = self.runProc(nc)
            if outt != "" or outt != None:
                print outt
                print "[rsync / accr.txt [done]"
            else:
                print "[rsync / accr.txt to %s [FAILED]" % hn
        else:
            print "[rsync / ccfScript.py to %s [FAILED]" % hn
        
    def ACCR_create(self, serverName, primo, nodeAgent):
        hold = {}
        hold['admName'] = self.adminId[1:-1]
        hold['admPword'] = self.pwdId
        hold['dmgrhost'] = self.hname
        hold['wpspath'] = self.pathf['wpspath']
        hold['wpsfn'] = self.zf['wpsfn']
        hold['newversion'] = self.zf['newversion']
        hold['configengpath'] = self.pathf['configengpath']
        hold['dmgrbinpath'] = self.pathf['dmgrbinpath']
        hold['wpprofilebase'] = self.pathf['wpprofilebase']
        hold['dmgrprofilepath'] = self.pathf['dmgrprofilepath']
        hold['wpprofilepath'] = self.pathf['wpprofilepath']
        hold['portalname'] = serverName
        hold['dmgrPort'] = self.dmgrPort
        hold['imclpath'] = self.pathf['imclpath']
        hold['ccfdir'] = self.dirf['ccfdir']
        hold['ccfupgpath'] = self.pathf['ccfupgpath']
        hold['wpinstall'] = self.zf['wpinstall']
        hold['wpdir'] = self.dirf['wpdir']
        hold['wcminstall'] = self.zf['wcminstall']
        hold['wcmdir'] = self.dirf['wcmdir']
        hold['efixpath'] = self.pathf['efixpath']
        hold['ifixwcm'] = self.zf['ifixwcm']
        hold['ifixwp'] = self.zf['ifixwp']
        hold['primary'] = primo
        hold['nodeAgent'] = nodeAgent

        with open("/tmp/accr.txt" ,"wb") as acc:
            pickle.dump(hold, acc)
        # --------------------------------------------------------
        out = os.system("chmod 777 /tmp/accr.txt")
        if out != 0 and out > 0:
            print "[exec] change perm for file accr.txt [failed[x]"
        else:
            print "[exec] change perm for file accr.txt [completed[y]"
 

    
    def decomprezz(self, zfile, directory):
        sys.stdout.write("[unzip in local] [%s] [/tmp/%s] . . . . . . ." % (zfile, directory))
        self.logm.info("[unzip in local] [%s] [/tmp/%s]" % (zfile, directory))
        zcommand = "unzip -o /tmp/%s -d /tmp/%s" % (zfile, directory)
        proc1 = subprocess.Popen(zcommand, stderr = subprocess.PIPE, shell=True)        
        stderr = proc1.communicate()[1]
        if stderr:
            print stderr
            self.logm.warn(stderr)
        else:
            print "[decomp done]"
            self.logm.info("- - - [decomp completed]")

    def subDecomprezz(self, xzfile, xxdirectory):
        print "[verify] . . . . . . . repository.config file existance in /tmp"
        self.logm.info("[verify] . . . . . . . repository.config file existance in /tmp")
        if os.path.isfile("/tmp/%s/repository.config" % xzfile):
            pass
        else:
            if "Combined" in xzfile:
                print "[unzip] [%s]" % self.zf['sub_ccf']
                self.logm.info("[unzip] [%s]" % self.zf['sub_ccf'])
                subCMD = "unzip -o /tmp/%s/%s -d /tmp/%s" % (xxdirectory, self.zf['sub_ccf'], xxdirectory)
		print "[command] %s" % subCMD
                self.logm.info("[command] %s" % subCMD)
                self.commonSrvNodeEXEC(subCMD)
                print "[zip file] . . . . . . . . . . . . [inflated]"
                self.logm.info("[zip file] . . . . . . . . . . . . [inflated]")
            elif "WP-IFP" in xzfile:
                print "[unzip] [%s]" % self.zf['sub_sp']
                self.logm.info("[unzip] [%s]" % self.zf['sub_sp'])
                subCMD = "unzip -o /tmp/%s/%s -d /tmp/%s" % (xxdirectory, self.zf['sub_sp'], xxdirectory)
		print "[command] %s" % subCMD
                self.logm.info("[command] %s" % subCMD)
                self.commonSrvNodeEXEC(subCMD)
                print "[zip file] . . . . . . . . . . . . [inflated]"
                self.logm.info("[zip file] . . . . . . . . . . . . [inflated]")
        print " - - - [done verification]"
        self.logm.info(" - - - [verified[done]]")
    #-------------------------------------------------------
    def Rremote_prep(self):
        filename = ""
        for k, v in self.dirf.items():
            if k == "wcmdir": filename = self.zf['ifix_wcm']
            elif k == "ccfdir": filename = self.zf['ccf']
            elif k == "wpdir": filename = self.zf['ifix_wp']
            self.tmp_local(self.dirf[k])
            self.decomprezz(filename, self.dirf[k])
            self.subDecomprezz(filename, self.dirf[k])
            #self.Rzip(self.dirf[k])
            time.sleep(5)

    def RzyncToRemote(self):
        self.logm.info("Check disk space available = required 2G")
        print "Check disk space available = required 2G"
        cmd = r"""ssh {0} 'df -m | sed -n "/dev\/sda1/p"'""".format(self.srvf)
        self.logm.info("command to exec: %s" % cmd)
        while True:
	    pproc = subprocess.Popen(cmd, stdout=subprocess.PIPE, shell=True)
            stdout = pproc.communicate()[0]
            var = stdout.split(" ")[-4]
            if int(var) >= 2000:
                break
            else:
                self.logm.info("Insufficient disk space in %s" % self.srvf)
                print "Insufficient disk space in %s" % self.srvf
                raw_input("Free up disk space: <ENTER> to continue") 
        # go copy all needed repository to remote app server                      
        for kk, vv in self.dirf.items():
            self.Rzip(self.dirf[kk])
            time.sleep(5)
                
            

    def Rzip(self, tdir):
        copycmd = "rsync -avh --inplace /tmp/%s/ %s:/tmp/%s/" % (tdir, self.srvf, tdir)
        self.logm.info("[exec] %s" % copycmd)
        print "[command to execute] %s" % copycmd
        runtime = subprocess.Popen(copycmd, stderr = subprocess.PIPE, shell=True)
        sys.stdout.write("[copy file] to remote server . . . . . . . ")
        self.logm.info("[copy][file to remote server]")
        error = runtime.communicate()[1]
        if error:
            self.logm.warn(error)
            print error
        else:
            self.logm.info(" - - - [copied]")
            print "[copied]"

    #-----------------------------------------------------------------------------------------------
    def sshCheckpoint(self):
        self.logm.info("[connection] [test SSH protocols]")
        sys.stdout.write("[check ssh connection] . . . . . . . . .")
        sshcmd = "ssh -q -o BatchMode=yes -o ConnectTimeout=10 {0} exit".format(self.srvf)
        print "[exec] %s" % sshcmd
        sshSys = subprocess.Popen(sshcmd, stderr = subprocess.PIPE, shell=True)
        stderr = sshSys.communicate()[1]
        print "stderr value: ",stderr
        if stderr:
           print ""
           self.logm.warn("[access to SSH][not possible error]")
           return "noposs"
        elif not stderr:
           self.logm.info("[access to SSH][possible]")
           print "[accessible]"
           return "acposs"


    def commonSrvNodeEXEC(self, commonCMD):
        servProc = subprocess.Popen(commonCMD, stderr=subprocess.PIPE, shell=True)
        servErr = servProc.communicate()[1]
        if servErr:
            self.logm.warn(servErr)
        else:
            print "> completed without error"

    def outputLookup(self, fname, str1, str2="None", str3="None"):
        errOutput = 0
        self.fileCheck(fname)
        profn = "/tmp/%s" % fname
        contain = []
        containB = []
        containC = []
        if str1:
            with open(profn, "r") as ofile:
                contain = [line for line in ofile if line.find(str1) != -1]
                if contain:
                    print contain
                else:
                    print "Can't return an empty ArrayList for keyword: %s" % str1
                    self.logm.error("[ArrayList] is Null . . . . [can't return value] for keyword: %s" % str1)
                    errOutput = 1     
        if str2 != "None":
            with open(profn, "r") as bfile:
                containB = [line for line in bfile if line.find(str2) != -1]
                if containB:
                    print containB
                else:
                    print "Can't return an empty ArrayList for keyword: %s" % str2
                    self.logm.error("[ArrayList] is Null . . . . [can't return value] for keyword: %s" % str2)
                    errOutput = 1  
        if str3 != "None":
            with open(profn, "r") as cfile:
                containC = [line for line in cfile if line.find(str3) != -1]
                if containC:
                    print containC
                else:
                    print "Can't return an empty ArrayList for keyword: %s" % str3
                    self.logm.error("[ArrayList] is Null . . . . [can't return value] for keyword: %s" % str3)
                    errOuput =1

	if contain and containB and containC:
           return (contain, containB, containC)
        elif contain and containB and not containC:
           return (contain, containB)
        elif contain and not containB and not containC:
           return (contain) 
        elif not str1:
           self.logm.warn("Minimum 2 argument is required (str1 argument and filename)")
           print "Minimum 2 argument is required (str1 argument and filename)"
           sys.exit(1)
        elif errOutput: # meaning []
           return []
   
    def fileCheck(self, fn, testDIR="/tmp"):
        if os.path.isfile("%s/%s" % (testDIR, fn)):
            if os.path.getsize("%s/%s" % (testDIR, fn)) > 0:
                print "[file ready for parsing]"
                self.logm.info("[file] . . . [ready] [size > 0]")
            else:
                print "[file is empty] [parsing not possible]"
                self.logm.info("[[file is empty] [parsing not possible]")
                sys.exit(1) 
    #------------------------------------------------------------------------------------------


    def autoSync(self, AGNODE, val="disable"):
        print "[invoke] wsadmin running external jython script"
        self.logm.info("[invoke] wsadmin running external jython script")
        #AGNODE =  self.CCFUTIL.getAgentName("syncNode.txt", "ADMU0402I")
        theCmd = "/opt/IBM/WebSphere/Profiles/Dmgr01/bin/wsadmin.sh -lang jython -f /opt/jenkins/AutoSphere/python/ccf_build3/subf/ccfWsadmin.py {0} {1}".format(AGNODE, val)
        print "[command] %s" % theCmd
        self.logm.info("[command] %s" % theCmd)
        self.commonSrvNodeEXEC(theCmd)
        print "[exec] . . . . . . . . . [done]"
        self.logm.info("[exec] . . . [done]")

    def invokeCCFPULL(self):
        print "[invoke] wsadmin running external jython script"
        self.logm.info("[invoke] wsadmin running external jython script")
        pCmd = "/opt/IBM/WebSphere/Profiles/Dmgr01/bin/wsadmin.sh -lang jython -f /opt/jenkins/AutoSphere/python/ccf_build3/subf/ccfPull.py"
        print "[command] %s" % pCmd
        self.logm.info("[command] %s" % pCmd)
        self.commonSrvNodeEXEC(pCmd)
        print "[exec] . . . . . . . . . [done]"
        self.logm.info("[exec] . . . [done]")

    def getVariables(self, utilityFile = "/tmp/ccfUTIL.txt"):
        with open(utilityFile, "rb") as ufile:
            utilityVar = pickle.load(ufile)
        return utilityVar


    def wcmConfigProperty(self):
        org = os.path.join(self.pathf['wcmpropertypath'], self.zf['wcmpropertyorg'])
        bck = os.path.join(self.pathf['wcmpropertypath'], self.zf['wcmpropertybak']) 

        setHashed = 0
        print "Verify property file if hashing already done"
        self.logm.info("[verify] property file if hashing already done")
        grepCmd = r"""grep "{0}" {1} -c""".format(self.wcmSTR, org)
        hcmd = "ssh {0} '{1}' > /tmp/instace.txt".format(self.srvf, grepCmd)
        self.commonSrvNodeEXEC(hcmd)
        #---------------------------------------
        with open("/tmp/instace.txt","r") as ff:
            line = ff.read()
            numb = int(line)
            if numb == 0:
                setHashed = 1
        print ""
        print "[hashed value] . . . . [%d]" % setHashed
        self.logm.info("[hashed value] . . . . [%d]" % setHashed)
        print ""
        #----------------------------------------
        if not setHashed:
            print "[hashing procedure] . . . . . [SKIPPED]"
            self.logm.info("[hashed] . . . [verfified][True]")
        elif setHashed:
            self.logm.info("[creating][property file] %s" % bck)
            print "[creating][property file] %s" % bck
            createBCKUP =  "cp {0} {1}".format(org, bck)
            execBCKUP = "ssh {0} '{1}'".format(self.srvf, createBCKUP)
            print "[command] %s" % execBCKUP
            self.logm.info("[command] %s" % execBCKUP)
            self.commonSrvNodeEXEC(execBCKUP)
            self.logm.info("[backupFile] . . . [created]")
            print "[backupFile] . . . [created]"

            self.logm.info("comment all out the extensiontype.*=application/octet-stream") 
            self.logm.info("[property fileName] %s" % org) 
            print "comment all out the extensiontype.*=application/octet-stream" 
            print "[property fileName] %s" % org 
	    raw = r"""sed -i "/extensiontype\.\*=application\/octet-stream/ s/^/#/" {0}""".format(org)
            hashed = "ssh {0} '{1}'".format(self.srvf, raw)
	    self.logm.info("[command] %s" % hashed)
	    print "[command] %s" % hashed
            self.commonSrvNodeEXEC(hashed) 
            print "[hashing] . . . . done"
            self.logm.info("[hashing] . . . . [completed]")

        print "==" * 20
        self.logm.info("==" * 20)
        print "[config] [display hashing] [WCMConfigService.properties]"
        self.logm.info("[config] [display hashing] [WCMConfigService.properties]")
        view = r"""sed -n "425,451p" {0}""".format(org)
        display = "ssh {0} '{1}' > /tmp/display.txt".format(self.srvf, view)
        self.commonSrvNodeEXEC(display)
        self.displayPass("/tmp/display.txt")
        print "[display . . . . . . [done]]"
        self.logm.info("[display . . . . . [done]]")


    def runProc(self, cmd):
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
        except subprocess.CalledProcessError as e:
            print e.output
        stdout, stderr = proc.communicate()
        if not stderr:
            buff = StringIO.StringIO()
            buff.write(stdout)
            Output = buff.getvalue()
            buff.flush()
            buff.close()
            return Output
        else:
            Output = None
            return Output


    def valueChecker(self, valuez, ffname):
        rightFile = "/tmp/%s" % ffname
        if bool(valuez) == False: # meaning []
           self.logm.error("[empty list] . . . . . [define value is null]")
        else:
            #rightFile = "/tmp/%s" % ffname
            valuez = set(valuez)
            if len(valuez) == 1:
                value = valuez
                self.displayPass(rightFile)
                self.logm.info("[result] . . . . %s" % value)
                print "[result] . . . . ", value
                return True

        # valuez > 1
        self.displayErr(rightFile)
        print "[checker] . . . . . . . . . [unsuccesfull]"
        self.logm.info("[checker] . . . . . . . . . [unsuccesfull]")
        return False

    def displayErr(self, myfile):
        self.logm.error("[%s]- - - - - - - - - - - - - - - - START - - - - - - - - - - - - - - - - - - -" % myfile)
        with open(myfile, "r") as dof:
            for errline in dof:
                self.logm.error(errline)
        self.logm.error("- - - - - - - - - - - - - - - - - -- -END- - - - - - - - - - - - - - - - - - - - -")
  
    def displayPass(self, myfile):
        self.logm.info("[%s]- - - - - - - - - - - - - - - - START - - - - - - - - - - - - - - - - - - -" % myfile)
        print "[%s]- - - - - - - - - - - - - - - -START- - - - - - - - - - - - - - - - - - -" % myfile
        with open(myfile, "r") as pof:
            for passline in pof:
                self.logm.info(passline)
                print passline
        self.logm.info("- - - - - - - - - - - - - - - - - - - -END- - - - - - - - - - - - - - - - - - - - -")
        print "- - - - - - - - - - - - - - - - - - - -END- - - - - - - - - - - - - - - - - - - - -"

    #-----------------------------------------------------------------------
    
    def wkplcIdSearch(self, element):
        inpath = "/opt/IBM/WebSphere/Profiles/wp_profile/ConfigEngine/properties/wkplc.properties"
        if element == "PortalAdminId":
            patt = re.compile(r'^PortalAdminId=(.*)$')
        else:
            patt = re.compile(r'^WasUserid=(.*)$')
        # -----------------------------------------------------------
        scmd = r"""awk "/^%s=/{print}" %s""" % (element, inpath)
        remoteConn = "ssh {0} '{1}'".format(self.srvf, scmd)
        print "CMD to pass > ",remoteConn
        buff = self.runProc(remoteConn)
        print "BUFF ",buff
        if buff != None or buff != "":
            match = patt.search(buff)
            if match:
                 if match.group(1) != "":
                    print "Found {0}: {1}".format(element, match.group(1))
                    return "passed"
        
        print "Return <empty> Missing {0} element in wkplc.properties".format(element)
        return "noValue"

    def NAstatus(self, srv, char):
        nastart=0
        nastop=0
        trig = r'''ssh %s "%s/serverStatus.sh -all " > /tmp/serverStat1.txt''' % (srv, self.pathf["wpprofilepath"])
        print "[command] %s" % trig
        self.logm.info("[command] %s" % trig)
        self.commonSrvNodeEXEC(trig)
        ( vars ) = self.outputLookup("serverStat1.txt", char)
        for output in vars:
                if "nodeagent" in output and char == "ADMU0509I": nastop = 1
                elif "nodeagent" in output and char == "ADMU0508I": nastart = 1
                else:
                    print "Set nodeagent status 0 default!"
        return (nastop, nastart)



    def NAstopper(self, server):
        (nastop, nastart) = self.NAstatus(server, "ADMU0509I")
        if not nastop:
            getRunAppCmd = 'ssh %s "%s/stopNode.sh " > /tmp/stopNode.txt' % (server, self.pathf["wpprofilepath"])
            print "[command] %s" % getRunAppCmd
            print "[exec] STOP Node"
            self.logm.info("[command] %s" % getRunAppCmd)
            self.logm.info("[exec] - - - STOP NODE")
            self.commonSrvNodeEXEC(getRunAppCmd)
            (nodeo) = self.outputLookup("stopNode.txt","ADMU4000I:")
            self.valueChecker(nodeo,"stopNode.txt")
        else:
            print "Node Agent already STOPPED, proceed to NEXT."


    def NAstarter(self, server):
        (nastop, nastart) = self.NAstatus(server, "ADMU0508I")
        if not nastart:
            getRunAppCmd = 'ssh %s "%s/startNode.sh " > /tmp/startNode.txt' % (server, self.pathf["wpprofilepath"])
            print "[command] %s" % getRunAppCmd
            print "[exec] START Node"
            self.logm.info("[command] %s" % getRunAppCmd)
            self.logm.info("[exec] - - - START Node")
            self.commonSrvNodeEXEC(getRunAppCmd)
            (startrnode) = self.outputLookup("startNode.txt","ADMU3000I:")
            self.valueChecker(startrnode,"startNode.txt")
        else:
            print "Node Agent already STARTED"

    def syncNode(self, hn="null", x=0):
        if x and hn != "null":
            self.srvf = hn

        synCMD = r"""ssh {0} "{1}/syncNode.sh {2} {3} " > /tmp/syncNode.txt"""
        exCMD = synCMD.format(self.srvf, self.pathf['wpprofilepath'], self.hname , self.dmgrPort)
        self.commonSrvNodeEXEC(exCMD)
        (syncresult) = self.outputLookup("syncNode.txt", "ADMU0402I:")
        #(syncresult) = self.outputLookup("syncNode.txt", "has been synchronized")
        self.valueChecker(syncresult, "syncNode.txt")
#----------------------------------
