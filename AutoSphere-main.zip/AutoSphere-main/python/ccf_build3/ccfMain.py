from ibmCCF import cffInstallation
import subf.ccfLIB as scc
import sys, time

def main():
    print "START [MAIN] ====================================== []"
    logging = scc.ccfLog(filename="./subf/ccfInstall.log")
    cffInstall = cffInstallation(logging)
    cffInstall.ccfFiles()
    logging.info("[START ======================================= MAIN]")
    logging.info("[set Script environment variables] . . . . [wsadmin]")
    print "[set Script environment variables] . . . . [wsadmin]"
    cffInstall.invokeCCFPULL()

    portalServers = cffInstall.getVariables()
    cffInstall.Rremote_prep()   # finish extraction of files in dmgr /tmp and create folder on each file
    # Disable autoSync in all nodes
    print "Disable autoSync in all nodes"
    logging.info("[Disable AutoSync]")
    for k in portalServers.keys():
        cffInstall.autoSync(k)

    # pick the primary node
    xrim = sorted(portalServers)
    pprim = xrim[0]
    vv = raw_input("Is this the primary node: %s? [y]es or [n]o: " % pprim) or "y"
    if vv == "y" or vv == "Y":
          print "Proceed . . "
    else:
          while True:
              rim = raw_input("Enter the correct primary node name ,then <ENTER>: ") or "ntd"
              pprim = rim.strip() # remove white spaces
              if pprim != "ntd" or pprim != "":
                 break

    print "[primary node name is: %s confirmed!" % pprim            
   

    for pnode, data in sorted(portalServers.items()):
        if pnode == pprim:
             primo = 1
        else:
             primo = 0
        getLen = len(data)
        host = data[0]
        srvN = data[1]
        print ""
        print "[start]" + " = " * 25 
        print "[] [nodeName] ",pnode
        print "[] [hostname] ",host
        print "[] [serverName] ",srvN
        print " = " * 27
        print ""
        cffInstall.cff_Setters(host) # Set hostname to make it global in ccfInstall instance
        sshStat = cffInstall.sshCheckpoint()  # check ssh connection
        if sshStat == "acposs":
            cffInstall.RzyncToRemote()
            print "< - - - - - - - Proceed - - - - - - - >"
        elif sshStat == "noposs":
            print "FIX ssh connection!"
            print "Failure to extablished remote connection"
            print "< - - - - - - - Skipped - - - - - - - >"
            continue
        #-----------------------------------------------
        cffInstall.wcmConfigProperty()             # hashed/comment extensiontype.* in WCMconfigService.properties
        					# create accesory file
        cffInstall.ACCR_create(srvN, primo, pprim)
        					# rsync files to portal server [accr.txt and cffScript.py]
        cffInstall.copyScript(host)
        print "*[done]"
        # ---------------END HERE------------------------------
    print " END [MAIN] ============================================= []"
    logging.info("[END ============================================= MAIN]")

# ////////////////////////////////////////////////////////////////////////////////

def submain():
    print "START [subMAIN] ====================================== []"
    logging = scc.ccfLog(filename="./subf/ccfInstall.log")
    cffInstall = cffInstallation(logging)
    logging.info("[START ====================================== subMAIN]")
    logging.info("[set Script environment variables] . . . . [wsadmin]")
    print "[set Script environment variables] . . . . [wsadmin]"
    cffInstall.invokeCCFPULL()
    portalServers = cffInstall.getVariables()
    print portalServers

    for sn in portalServers.keys():
        cffInstall.autoSync(sn, val="enable")

    for sn, v in portalServers.items():
        ssn = v[0]
        cffInstall.NAstopper(ssn)
        cffInstall.syncNode(hn=ssn, x=1) # syncNode.sh per apps server
        cffInstall.NAstarter(ssn)
    #====================================================================================
    print "END [subMAIN] ====================================== []"
    logging.info("[END ================================== subMAIN]")


# ////////////////////////////////////////////////////////////////////////////////////
    
if __name__ == '__main__':
     print ""
     print "\t[Select]                                  [Description]"
     print "\t  i . . . . . . . . . . . . . . . . . . .Initial process"
     print "\t  e . . . . . . . . . . ..  . . . . . . . Enable autoSync"
     print "\t  q . . . . . . . . . . . . . . . . . . . . System Exit"
     print ""
     select = raw_input("Enter selection: ") or "Q"
     if select == "I" or select == "i":
          main()
     elif select == "e" or select == "E":
          submain()
     else:
          sys.exit(0)
   
 
