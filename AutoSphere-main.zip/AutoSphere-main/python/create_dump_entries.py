import sys

global AdminTask
global AdminConfig
global AdminControl

print "*******************Creating Environment Entries for all portal servers********************"

print

print "creating the Environment Entries (javacore,heap dumps and system dumps) for WebSphere_Portal"

srvid = AdminConfig.getid('/Server:WebSphere_Portal')
pdef = AdminConfig.list('JavaProcessDef', srvid)

#AdminConfig.create(pdef, [['Property', [attrList]]]) 

#AdminConfig.create('Property', '(cells/PRTCell/nodes/PRTH72PortalNode01/servers/WebSphere_Portal|server.xml#JavaProcessDef_1505742521816)', '[[validationExpression ""] [name "IBM_JAVACOREDIR"] [description ""] [value "/home/websphr/Dumps/WebSphere_Portal_uapp9048h"] [required "false"]]')

AdminConfig.create('Property', (pdef), '[[validationExpression ""] [name "IBM_JAVACOREDIR"] [description ""] [value "/home/websphr/Dumps/WebSphere_Portal_uapp9048h"] [required "false"]]')

AdminConfig.create('Property', (pdef), '[[validationExpression ""] [name "IBM_HEAPDUMPDIR"] [description ""] [value "/home/websphr/Dumps/WebSphere_Portal_uapp9048h"] [required "false"]]')

AdminConfig.create('Property', (pdef), '[[validationExpression ""] [name "IBM_COREDIR"] [description ""] [value "/home/websphr/Dumps/WebSphere_Portal_uapp9048h"] [required "false"]]')

AdminConfig.save()

print

print "created Environment Entries for WebSphere_Portal"

print

print "creating the Environment Entries (javacore,heap dumps and system dumps) for WebSphere_Portal_2"

srvid = AdminConfig.getid('/Server:WebSphere_Portal_2')
pdef = AdminConfig.list('JavaProcessDef', srvid)


AdminConfig.create('Property', (pdef), '[[validationExpression ""] [name "IBM_JAVACOREDIR"] [description ""] [value "/home/websphr/Dumps/WebSphere_Portal_2_uapp9047h"] [required "false"]]')

AdminConfig.create('Property', (pdef), '[[validationExpression ""] [name "IBM_HEAPDUMPDIR"] [description ""] [value "/home/websphr/Dumps/WebSphere_Portal_2_uapp9047h"] [required "false"]]')

AdminConfig.create('Property', (pdef), '[[validationExpression ""] [name "IBM_COREDIR"] [description ""] [value "/home/websphr/Dumps/WebSphere_Portal_2_uapp9047h"] [required "false"]]')

AdminConfig.save()

print

print "created Environment Entries for WebSphere_Portal_2"

print

print "*******************Environment Entries created for all portal servers********************"
