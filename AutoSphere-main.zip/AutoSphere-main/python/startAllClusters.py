#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 05/10/2017 Murry Kane     Initial version
# 12/04/2017 Murry Kane     Wrote to work on Windows
# 03/18/2018 Murry Kane     Added logic to call new method to deterine if username/password needs
#                           to be sent to all IBM scripts based on IBM Security Enabled or not
#_________________________________________________________________________________________________
#

import shlex, subprocess, sys, platform, ConfigParser, os, log_message, getpass
from datetime import datetime
from constants import *
from init_websphere import *

def usage():
  print "Usage: %s" % sys.argv[0]

if os.name != 'nt' and getpass.getuser() != 'websphr':
  print "You must run this as the effective user 'websphr', please try again as that user, exiting!"
  sys.exit(1)

def main():
  if ( len(sys.argv) > 1):
    usage()
    sys.exit(1)

  pathname = os.path.dirname(sys.argv[0])        
  pathdir = os.path.abspath(pathname)
  localhost = platform.node().upper()
  currentscript = os.path.basename(os.path.splitext(__file__)[0])
  localhost = platform.node().upper()
  loglevel = 'DEBUG'
  date_fmt = datetime.now().strftime('%Y%m%d-%H%M')
  LOGFILE = '%s/%s_%s.log' % (LOG_DIR, currentscript, date_fmt)
  ignoreNodeList = ''
    
  log_msg = log_message.get_file_logger(currentscript, loglevel, LOGFILE, currentscript, True)
  log_msg.info("Starting program")
  log_msg.info("ingore node list is %s" % ignoreNodeList)
  ignoreNodeList = "/".join(ignoreNodeList)
  log_msg.debug("ignore list as string is: %s" % ignoreNodeList)
  if len(ignoreNodeList) == 0:
    ignoreNodeList = '/'
    log_msg.debug("ignore node modified due to empty, list as string is: %s" % ignoreNodeList)
  
  # use manageprofiles.sh to get the WebSphere profiles on this server
  if getProfiles(profilesFile, log_msg):
    log_msg.info("Successfully got profiles for server")
  else:
    log_msg.error("ERROR: We could not get the profiles for this server, exiting!")
    sys.exit(14)
  
  #get the DMGR from the output above....
  xmlStr = ''
  aStr = ''
  temp = open(profilesFile,'r').readlines()
  for line in temp:   # there should only be 1 line....
    aStr = line.strip('\n\r[]') 
  log_msg.info("List of Profiles on server is [%s]" % aStr)
  if not aStr:
    #could not determine profiles on this system....
    log_msg.error("ERROR: We could not determine the WebSphere Profiles on this server, exiting!")
    sys.exit(15)
  
  #server may have one or more profiles, loop through them....
  profileList = aStr.split()
  for profile in profileList:
    if re.search('dmgr', profile, re.IGNORECASE):
      log_msg.info("Profile [%s] is a DMGR" % profile)
      startStr = " ".join(re.findall("[a-zA-Z]+", aStr)).split()[0]
      startNum = " ".join(re.findall("[0-9]+", aStr)).split()[0]
      xmlStr = '%s%s' % (startStr, startNum)
      if len(xmlStr) < 5:
        log_msg.warn("The XML Search String [%s] is very small, which may lead to bad results!" % xmlStr)
        
  if not xmlStr:    
    log_msg.error("We could not determine if this server is a DMGR, exiting!")
    sys.exit(15)
    
  #xmlStr = serverStatusQuery('Starting tool with the ', 0, log_msg)
  log_msg.info("XML String to find files with is [%s]" % xmlStr)
  xmlString = "%s*.xml" % xmlStr
  jythonscript = '%s/%s.py' % (JYTHON_DIR, currentscript)
  
  XMLFile, username, encrypted_password, password, wsadminpath = getXMLFile(xmlString, log_msg) 
  wsadminfile = os.path.join(wsadminpath + os.sep, 'bin' + os.sep, 'wsadmin' + ext_name).replace("\\", "/")
  
  # lets validate all variables are defined
  #------------------------------------------
  if os.path.isfile(wsadminfile):
    log_msg.debug("Found the WSAdmin.sh with: [%s]" % wsadminfile)
  else:
    log_msg.error("Unable to find the WSAdmin script with: [%s], exiting!" % wsadminfile)
    sys.exit(10)    
  if os.path.isfile(jythonscript):
    log_msg.debug("Found the python script with: [%s]" % jythonscript)
  else:
    log_msg.error("Unable to find the jython script with: [%s], exiting!" % jythonscript)
    sys.exit(10)
  if os.path.isfile(XMLFile):
    log_msg.debug("Found the XML Property File with: [%s]" % XMLFile)
  else:
    log_msg.error("Unable to find the XML Property File with: [%s], exiting!" % XMLFile)
    sys.exit(10)
  if username:
    log_msg.debug("Found the user name to use with WSAdmin script with: [%s]" % username)
  else:
    log_msg.error("Unable to find the user name for WSAdmin script with: [%s], exiting!" % username)
    sys.exit(10)
  if encrypted_password:
    log_msg.debug("Obtained the encrypted password for WSAdmin script with: [%s]" % encrypted_password)
  else:
    log_msg.error("Unable to find the encrypted password for WSAdmin script with: [%s], exiting!" % encrypted_password)
    sys.exit(10)
  if password:
    log_msg.debug("Obtained the password for WSAdmin script with: [%s]" % 'XXXXXXXXXX')
  else:
    log_msg.error("Unable to find the password for WSAdmin script with: [%s], exiting!" % password)
    sys.exit(10) 
  ################################################################################################  
  
  ################################################################################################
  # lets check if IBM security is set on this environment.....
  #
  IBMSecuritySet = False
  IBMSecuritySet = securityEnabledCheck(log_msg, wsadminpath)
  if IBMSecuritySet:
    if serverStatusWithNoPass(serverStatusOutFile, log_msg, wsadminpath):
      log_msg.debug("Successfully created the server status output file")
    else:
      log_msg.error("Could not determine status of the DMGR, exiting!")
      sys.exit(99) 
  else:      
    #make sure we are on a running DMGR to proceed....
    if serverStatusWithPass(serverStatusOutFile, username, password, log_msg, wsadminpath):
      log_msg.debug("Successfully created the server status output file")
    else:
      log_msg.error("Could not determine status of the DMGR, exiting!")
      sys.exit(99)

     
  #lets read the serverStatus output now....
  dFlag = False
  sfile = file(serverStatusOutFile)
  for line in sfile:
    if 'The Deployment Manager' in line:
      log_msg.debug("Found the following line in the ServerStatus output: [%s]" % line.strip())
      dFlag = True
      #get the last value to check if its 'STARTED'
      if line.rsplit(None, 1)[-1] == 'STARTED':
        log_msg.info("DMGR is running on this server, continue with script.....")
      else:
        log_msg.error("DMGR is NOT running, we can not continue with this script, please start the DMGR and run again!")
        sys.exit(45)
  # make sure its a DMGR
  if not dFlag:
    log_msg.error("This is not a DMGR server, and we can not run on this server, exiting!")
    sys.exit(55)
      
  if IBMSecuritySet:
    logging_cmd = '%s -lang jython -conntype SOAP -javaoption "-Dpython.path=%s" -f %s %s' % ( wsadminfile, PYTHONPATH, jythonscript, ignoreNodeList )
    cmd = '%s -lang jython -conntype SOAP -javaoption "-Dpython.path=%s" -f %s %s' % ( wsadminfile, PYTHONPATH, jythonscript, ignoreNodeList )
  else:
    logging_cmd = '%s -lang jython -conntype SOAP -user %s -password %s -javaoption "-Dpython.path=%s" -f %s %s' % ( wsadminfile, username, 'XXXXXXXXX', PYTHONPATH, jythonscript, ignoreNodeList )
    cmd = '%s -lang jython -conntype SOAP -user %s -password %s -javaoption "-Dpython.path=%s" -f %s %s' % ( wsadminfile, username, password, PYTHONPATH, jythonscript, ignoreNodeList )
  log_msg.info("Issueing: [%s]" % logging_cmd)
  if os.name != 'nt':
    args = shlex.split(cmd)
  else:
    args = cmd
    #log_msg.debug("Windows special with ARGS: [%s]" % args)
  process = subprocess.Popen(args,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
  
  # Poll process for new output until finished
  while True:
    nextline = process.stdout.readline().rstrip()
    if nextline == '' and process.poll() is not None:
      break
    if nextline and (not nextline.isspace()):
      log_msg.info(nextline)
      sys.stdout.flush()
    
  output, error = process.communicate()
  exit_code = process.wait()

  if exit_code > 0:
    #print "ERROR: [%s], exiting" % error
    if output:
      log_msg.error("Received STDOUT: %s" % output)
    if error:
      #lets see if its just the 'ulimit:' open files error received all the time
      for line in error.split(os.linesep):
        if line.find('ulimit:') > 0:
          log_msg.debug("Ignoring the ULIMIT: error from stderr...")
        else:
          log_msg.error(line)
    log_msg.error("ERROR: Exiting program!")
    sys.exit(exit_code)
  else:
    if output:
      log_msg.info("Received STDOUT: %s" % output)
    log_msg.info("Success on executing [%s]" % jythonscript)

  log_msg.info("Completed program successfully")
    
if __name__ == "__main__":
  main()
           




