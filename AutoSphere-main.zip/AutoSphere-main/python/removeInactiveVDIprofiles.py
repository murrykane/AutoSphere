#!/usr/bin/env python
'''
Murry Kane 
Version 1.0

 Updates
 Date       By             Reason
_________________________________________________________________________________________________
 02/01/2021 Murry Kane     Initial version
 05/06/2021 Murry Kane     using shutil.rmtree didn't work going to try os.walk instead...
                           used new function removePath2
 07/08/2021 Murry Kane     Added exit code logic for Tidal if failures are > 0
_________________________________________________________________________________________________
 Description
 This script will export all contacts from ServiceNow via rest call that are recently made inactive, 
 it will process each record and determine if clean up of VDI profiles are needed 
 

'''

import shlex, subprocess, sys, platform, os, log_message, getpass, getopt, ast, requests, json, base64, re, traceback, unicodedata, shutil, stat, time
from datetime import datetime, timedelta
from SREConstants import *
from SREConfigParser import *
from SRESecurity import *

global vdiDirsToRemove
global removedDirsCnt
global removedTreeCnt
global removedFileCnt
global failedRemoveCnt
  
def strip_accents(string, accents=('COMBINING ACUTE ACCENT', 'COMBINING GRAVE ACCENT', 'COMBINING TILDE')):
  accents = set(map(unicodedata.lookup, accents))
  chars = [c for c in unicodedata.normalize('NFD', string) if c not in accents]
  normalized_chars = unicodedata.normalize('NFC', ''.join(chars))
  #lets fix en dash
  str1_chars = re.sub(u"\u2013", "-", normalized_chars)
  str2_chars = re.sub(u"\xa0", " ", str1_chars)
  return str2_chars
    
def usage():
  print("Usage: %s --environment=<PROD><DEV><QA><2015><TRAINING> (optional)--loglevel=<INFO><DEBUG><WARN><ERROR><FATAL> (optional)--help" % sys.argv[0])
  print("Usage: %s (optional)--e <PROD><DEV><QA><2015><TRAINING> (optional)--l <INFO><DEBUG><WARN><ERROR><FATAL> (optional)--h" % sys.argv[0])
  print("-------------------------------------------------------------------------------------------------------------------------------")

def removePath(path, log_msg):
  """ param <path> could either be relative or absolute. """
  global removedDirsCnt
  global removedFileCnt
  global failedRemoveCnt
  
  try:
    if os.path.isfile(path) or os.path.islink(path):
        os.remove(path)  # remove the file
        removedFileCnt += 1
    elif os.path.isdir(path):
        shutil.rmtree(path)  # remove dir and all contains
        removedDirsCnt += 1
    else:
      log_msg.warning("Path {} is not a file or dir.".format(path))
  except:
    log_msg.error("Path {} could not be removed!".format(path))
    failedRemoveCnt += 1
    
def removePath2(top, log_msg, retryCnt):
  """ param <path> could either be relative or absolute. 
      log_msg is the pointer to the log file 
      retry count is used to attempt to clean the same directory that many times due to unforseen errors"""
  
  global removedTreeCnt  
  global removedDirsCnt
  global removedFileCnt
  global failedRemoveCnt
  filename = ''
  
  try:
  
    log_msg.debug("Working on removepath2 for directory [{}]".format(top))
    
    for root, dirs, files in os.walk(top, topdown=False):
      log_msg.debug("Root is [{}]".format(root))
      log_msg.debug("dirs is [{}]".format(dirs))
      log_msg.debug("files is [{}]".format(files))
      
      for name in files:
        filename = os.path.join(root, name)
        log_msg.debug("Working on file [{}]".format(filename))
        os.chmod(filename, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO | stat.S_IWUSR)
        os.remove(filename)
        removedFileCnt += 1
      for name in dirs:
        filename = os.path.join(root, name)
        log_msg.debug("Working on dir [{}]".format(filename))
        os.chmod(filename, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO | stat.S_IWUSR)
        os.rmdir(filename)
        #MBK do we care about nested directories?
        removedDirsCnt += 1 
        
    os.chmod(top, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO | stat.S_IWUSR)  
    os.rmdir(top)
    removedTreeCnt += 1
    
  except Exception as e:
    log_msg.warning("Tree Path [{}] for file/dir [{}] could not be removed! message: {}".format(top, filename, e))
    if(retryCnt >= 3):
      log_msg.error("Retry didn't work on this directory, exiting and adding to fail counter....")
      failedRemoveCnt += 1
      return
    else:
      retryCnt += 1
      #short sleep
      time.sleep(3)
      #this will perform the loop of retries for the delete of the terminated employee
      removePath2(top, log_msg, retryCnt)
      
        
def removeFoundDirs(log_msg):

  global vdiDirsToRemove
  
  log_msg.info("Size of map to remove is: {}".format(len(vdiDirsToRemove)))
  
  for dir in vdiDirsToRemove:
    log_msg.info("Working on removal of VDI Directory: {}".format(dir))
    if(os.path.isdir(r'{}'.format(dir))):
      log_msg.debug("Directory there, deleting.....")
      removePath2(r'{}'.format(dir), log_msg, 0)
      
  
def findVDIDirs(log_msg, vdi_dirs, inactiveCntlist):

  global vdiDirsToRemove
  vdiDirsToRemove = []
  
  for vdiDir in vdi_dirs:
    log_msg.info("Working on VDI profile directory: {}".format(vdiDir))
    #tt = os.listdir('\\\\bsc\\it\\vdi_profile_sac\\')
    vdiList = os.listdir(vdiDir)
    log_msg.debug("Listing of VDI Profiles is: {}".format(vdiList))
    #now iterate through 
    for cnt in inactiveCntlist:
      log_msg.debug("Working on contact: {} of type {}".format(cnt, type(cnt)))
      for dir in vdiList:
        check1 = re.findall(r"^{}$".format(cnt), dir)
        check2 = re.findall(r"^{}_.*".format(cnt), dir)
        if(check1 or check2):
          log_msg.info("Need to clean up directories for contact: {} with directory {}".format(cnt, dir))
          vdiDirsToRemove.append(os.path.join(vdiDir,dir))
        
      
def getSNowContactData(log_msg, contact):

  sn_username = ''
  sn_sys_updated_on = ''
  sn_active = ''
  sn_u_bsc_source = ''
  sn_u_emp_type = ''
  sn_full_name = ''
  
  contactTuple = {}
  #log_msg.debug('Working on contact [{}]'.format(contact))
  for key, val in contact.items():
      
    if(key.lower() == "sys_updated_on"):
      if val is None:
        sn_sys_updated_on = ''
      else:
        sn_sys_updated_on = strip_accents(val)
      log_msg.debug('   last updated on: {}'.format(sn_sys_updated_on))
      #contactTuple["sn_sys_updated_on"] = sn_sys_updated_on
            
    if(key.lower() == "active"):
      if val is None:
        sn_active = ''
      else:
        sn_active = strip_accents(val)
      log_msg.debug('   active is: {}'.format(sn_active))
      #contactTuple["sn_active"] = sn_active
      
    if(key.lower() == "u_bsc_source"):
      if val is None:
        sn_u_bsc_source = ''
      else:
        sn_u_bsc_source = strip_accents(val)
      log_msg.debug('   BSC Source is: {}'.format(sn_u_bsc_source))
      #contactTuple["sn_u_bsc_source"] = sn_u_bsc_source
            
    if(key.lower() == "name"):
      if val is None:
        sn_full_name = ''
      else:
        sn_full_name = strip_accents(val)
      log_msg.debug('   full name is: {}'.format(sn_full_name))
      #contactTuple["sn_full_name"] = sn_full_name
      
    if(key.lower() == "u_emp_type"):
      if val is None:
        sn_u_emp_type = ''
      else:
        sn_u_emp_type = strip_accents(val)
      log_msg.debug('   employee type is: {}'.format(sn_u_emp_type))
      #contactTuple["sn_u_emp_type"] = sn_u_emp_type
            
    if(key.lower() == "user_name"):
      if val is None:
        sn_username = ''
      else:
        sn_username = strip_accents(val).lower()
      log_msg.debug('   username is: {}'.format(sn_username))
      #contactTuple["sn_username"] = sn_username      
    if sn_username:
      contactTuple[sn_username] = { 'sn_username' : sn_username, 'sys_updated_on' : sn_sys_updated_on, 'active' : sn_active, 'sn_u_bsc_source' : sn_u_bsc_source, 'sn_full_name' : sn_full_name, 'sn_u_emp_type' : sn_u_emp_type }
    
  return contactTuple

def initSetup(args):

  try:
    #opts, args = getopt.getopt(sys.argv[1:], 'hl:e:', ['help', 'loglevel=', 'environment='])
    opts, args = getopt.getopt(args[1:], 'hl:e:', ['help', 'loglevel=', 'environment='])
  except getopt.GetoptError as err:
    print("exception in GETOPT with [%s]" % err)
    usage()
    sys.exit(2)
  
  # defaults.....
  loglevel = 'INFO'
  environment = 'QA'
  
  validloglevel = [ 'DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL' ]
  
  for opt, arg in opts:
    if opt in ('--l', '--loglevel'):
      loglevel = arg.upper()
    elif opt in ('--e', '--environment'):
      environment = arg.upper()
    elif opt in ('--h', '--help'):
      usage()
      sys.exit(0)
    else:
      assert False, "unhandled option"

  pathname = os.path.dirname(sys.argv[0])        
  pathdir = os.path.abspath(pathname)
  currentscript = os.path.basename(os.path.splitext(__file__)[0])
  date_fmt = datetime.now().strftime('%Y%m%d-%H%M')
  LOGFILE = '%s/%s_%s.log' % (LOG_DIR, currentscript, date_fmt)

  if validloglevel.count(loglevel) < 1:
    usage()
    sys.exit(5)
    
  
  log_msg = log_message.get_file_logger(currentscript, loglevel, LOGFILE, currentscript, True)
  log_msg.info("Starting program running with LOG4J as [%s]" % loglevel)

  try:
  
    #get config file information....
    cfgfile, config, sections = getConfigSections(log_msg, currentscript)
    if sections is None:
      log_msg.fatal("NO configuration file found, exiting!")
      sys.exit(3)
    else:
      log_msg.debug("Sections in configuration file [{}]".format(sections))
    
    if environment not in sections:
      log_msg.fatal("Provided Section [{}] does not exist in configuration file [{}], exiting!".format(environment,cfgfile))
      sys.exit(8)
      
    #get variables....    
    sn_maxResultCnt = config.getint('DEFAULT', 'sn_maxResultCnt', fallback=None)
    encryptKey = config.get(environment, 'encryptKey', fallback=None)
    sn_instance = config.get(environment, 'sn_instance', fallback=None)
    sn_username_encrypt = config.get(environment, 'sn_username', fallback=None)
    sn_password_encrypt = config.get(environment, 'sn_password', fallback=None)
    sn_getContacts = config.get('DEFAULT', 'sn_getContacts', fallback=None)
    vdi_dirs = config.get('DEFAULT', 'vdi_dirs', fallback=None)
      
    if sn_getContacts is None:
      log_msg.error("We must have a query lookup for Contacts in ServiceNow, exiting!")
      sys.exit(3)
      
    if sn_instance is None:
      log_msg.error("We must have a ServiceNow instance to query against, exiting!")
      sys.exit(3)

    if encryptKey is None:
      log_msg.error("We must have a must have an encrypting key, exiting!")
      sys.exit(3)
    
    if sn_maxResultCnt is None:
      log_msg.error("We must have a ServiceNow Max Return count of contacts, exiting!")
      sys.exit(3)

    if sn_username_encrypt is None:
      log_msg.error("We must have a ServiceNow username, exiting!")
      sys.exit(3)

    if sn_password_encrypt is None:
      log_msg.error("We must have a ServiceNow password, exiting!")
      sys.exit(3)
    
    if vdi_dirs is None:
      log_msg.error("We must have a VDI locations for cleanup (share mounts), exiting!")
      sys.exit(3)
    else:
      vdi_dirs = ast.literal_eval(vdi_dirs)
      
    log_msg.debug("sn_maxResultCnt is {} Environment {} ServiceNow Instance {}".format(sn_maxResultCnt, environment, sn_instance))
    log_msg.debug("encrypt key {} sn_username_encrypted {} sn_password_encrypt {} vdi dirs {}".format(encryptKey, sn_username_encrypt, sn_password_encrypt, vdi_dirs))
    
    
    #use security functions to get username/password
    sn_username = decryptStringWithKey(log_msg, sn_username_encrypt, encryptKey)
    log_msg.debug("ServiceNow username [{}]".format(sn_username))
    sn_password = decryptStringWithKey(log_msg, sn_password_encrypt, encryptKey)
    log_msg.debug("ServiceNow password [{}]".format('XXXXXXXXXX'))

  except OSError as err:
    log_msg.error("OS error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except ValueError as err:
    log_msg.error("VALUE error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except KeyboardInterrupt:
    log_msg.error('You cancelled the operation.')
    log_msg.error(traceback.format_exc())
    raise
  except IOError as err:
    log_msg.error("IOError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except EOFError as err:
    log_msg.error("EOFError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except KeyError as err:
    log_msg.error("KeyError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except Exception as err:
    log_msg.error("Unexpected error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
    
  
  return log_msg, sn_maxResultCnt, encryptKey, sn_instance, sn_username, sn_password, sn_getContacts, vdi_dirs
 
 
def main():
    
  #counters
  global removedTreeCnt
  global removedDirsCnt
  global removedFileCnt
  global failedRemoveCnt
  removedDirsCnt = 0
  removedFileCnt = 0
  failedRemoveCnt = 0
  removedTreeCnt = 0
  
  skipContactCnt = 0
  sn_recordCnt = 0
  sn_paginationCnt = 0
  
  #setup the script
  log_msg, sn_maxResultCnt, encryptKey, sn_instance, sn_username, sn_password, sn_getContacts, vdi_dirs = initSetup(sys.argv)
   
  try:
    
    # we will just get the first record, to get the total count of records....
    url = sn_getContacts.format(sn_instance, 1,1)
    resp = requests.get(url, auth=(sn_username, sn_password)) 
    log_msg.debug("HTTP REST call received: %s" % resp.status_code)
    
    if resp.status_code != 200:
      # This means something went wrong.
      log_msg.error("ServiceNow Status [{}] Headers [{}] Error Response: [{}]".format(resp.status_code, resp.headers, resp.text))
      sys.exit(14)
    
    #log the headers
    log_msg.debug("Headers are: [{}]".format(resp.headers))
    totalCnt = int(resp.headers['X-Total-Count'])
    
    log_msg.info("Total Count of records to process in ServiceNow is [{}]".format(totalCnt))
    
    #MBK hard-coding total records for testing...
    #totalCnt = 15
    
    #contact array
    inactiveCntlist = {}
    sn_contactAttrs = {}
    
    #While loop to get all contacts from ServiceNow
    while sn_paginationCnt <= totalCnt:   

      resp = None
      json_objs = None
      contacts = None
      key = None
      
      log_msg.info("Pagination is now [{}]".format(sn_paginationCnt))
      url = sn_getContacts.format(sn_instance, sn_maxResultCnt, sn_paginationCnt) 
      log_msg.debug("Making REST call: [{}]".format(url))
      resp = requests.get(url, auth=(sn_username, sn_password)) 
      log_msg.debug("HTTP REST call received: %s" % resp.status_code)
      
      if resp.status_code != 200:
        # This means something went wrong.
        log_msg.error("ServiceNow Status [{}] Headers [{}] Error Response: [{}]".format(resp.status_code, resp.headers, resp.text))
        sys.exit(15)
       
      json_objs=resp.json()
      for keyvalue in json_objs.items():
        key, contacts = keyvalue[0], keyvalue[1]
      
      #contacts will now be all rows returned

      for contact in contacts:
        #counter....
        sn_recordCnt += 1
        
        if sn_recordCnt > totalCnt:
          log_msg.info("Reached are last record....")
          sn_recordCnt = sn_recordCnt -1
          break
        
        log_msg.debug('Working on ServiceNow contact [{}]'.format(contact))
        #process the record 
        sn_contactAttrs = getSNowContactData(log_msg, contact)
        
        log_msg.debug('Contact processing data is [{}]'.format(sn_contactAttrs))
        
        if sn_contactAttrs:
          inactiveCntlist = dict(list(inactiveCntlist.items()) + list(sn_contactAttrs.items())) 
        else:
          #MBK counted a different way.... skipContactCnt += 1
          log_msg.debug("Contact data was invalid.... for contact: ".format(contact))
          
      #last thing is to increment counter
      sn_paginationCnt += sn_maxResultCnt
    
    # final output of inactive contacts 
    log_msg.debug("Complete list of contacts is {}".format(inactiveCntlist))  
    log_msg.info("Size of valid contacts is {}".format(len(inactiveCntlist)))
    #lets work on the clean up now...
    findVDIDirs(log_msg, vdi_dirs, inactiveCntlist)
    #now delete the found directories
    removeFoundDirs(log_msg)
    
  except OSError as err:
    log_msg.error("OS error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except ValueError as err:
    log_msg.error("VALUE error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except KeyboardInterrupt:
    log_msg.error('You cancelled the operation.')
    log_msg.error(traceback.format_exc())
    raise
  except IOError as err:
    log_msg.error("IOError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except EOFError as err:
    log_msg.error("EOFError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except KeyError as err:
    log_msg.error("KeyError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except Exception as err:
    log_msg.error("Unexpected error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  finally:
    #add up to get skip count
    skipContactCnt = sn_recordCnt - (removedTreeCnt + failedRemoveCnt)
    log_msg.info("---------------------------------------------------------------------------------------------------------------------------------------------------------------")
    log_msg.info("Counts: Directory Tree Deletes [{}] Directory Deletes [{}] File Deletes [{}] Skip Records [{}] Delete Errors [{}] Total Dir Trees Processed [{}]".format(removedTreeCnt, removedDirsCnt, removedFileCnt, skipContactCnt, failedRemoveCnt, sn_recordCnt))
    log_msg.info("---------------------------------------------------------------------------------------------------------------------------------------------------------------")

  if(failedRemoveCnt > 0):
    log_msg.error("Failure to remove all needed VDI profiles, exiting badly!")
    sys.exit(failedRemoveCnt)
  else:
    log_msg.info("Completed program successfully")
    sys.exit(0)
   
if __name__ == "__main__":
  main()
