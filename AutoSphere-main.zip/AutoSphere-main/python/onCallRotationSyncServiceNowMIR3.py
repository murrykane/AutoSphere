# -*- coding: utf-8 -*-
"""
Created on Mon Jun  1 14:45:01 2020

@author: kparro01


 Updated
 Date       By             Reason
_________________________________________________________________________________________________
 02/20/2021 Murry Kane     Found a bug in servicenow whoisoncall rest method, if the group has
                           only a primary defined with no secondary then the entire group is 
                           returned, therefore we need to check if the roster field is same
                           for 1.0 and 2.0 if they are then do not add a secondary. 
                           Also updated to use sn_instance as a global variable and removed 
                           hard-coding to URL
 05/18/2021 Murry Kane     Added a debug statement for queryMIR3 to display the payload
 11/11/2021 Hung Ly        Changed some log type for some console output.
 01/28/2022 Jeff Angstadt  Added https session logic for retries to resolve issue with timeouts
 03/04/2022 Murry Kane     Added retry into MIR3 calls, updated deprecated WARN to WARNING for log
                           messages, made some lines debug only, adding getlogger to retry logic
____________________________ _____________________________________________________________________
 Description
 This script will sync on-call information from ServiceNow to MIR3 schedules. It is intended to 
 be ran every 30 minutes to keep things in sync for every half hour. 
 *Testing can be done by changing the LiveRun value to False
 
"""
#temp below
from logging import exception, getLogger
import logging
import requests
import xml.etree.ElementTree as ET
from pprint import pprint
import random # DELETE LATER
import sys
import re
import getopt, traceback, log_message
from datetime import datetime
from SREConstants import *
from SRESecurity import *
from SREConfigParser import *
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

requests.packages.urllib3.disable_warnings()

mir3_username=''
mir3_password=''
sn_username=''
sn_password=''
maxParmsToMIR3 = 50
mir3_soapVars = {}

#Retry wrapper (super) so retry attempts can be logged
class CallbackRetry(Retry):
    
  currentscript = os.path.basename(os.path.splitext(__file__)[0])
  log_msg = logging.getLogger(currentscript)
  now = datetime.now()
  log_msg.info('CallBackRetry invoked at {}'.format(now.strftime("%Y-%m-%d %H:%M:%S")))
  
  def __init__(self, *args, **kwargs):
    self._callback = kwargs.pop('callback', None)
    super(CallbackRetry, self).__init__(*args, **kwargs)
  def new(self, **kw):
    # pass along the subclass additional information when creating
    # a new instance.
    kw['callback'] = self._callback
    return super(CallbackRetry, self).new(**kw)
  def increment(self, method, url, *args, **kwargs):
    currentscript = os.path.basename(os.path.splitext(__file__)[0])
    log_msg = logging.getLogger(currentscript)
    if self._callback:
      try:
        self._callback(url)
      except Exception:
        log_msg.warning('Callback raised an exception, ignoring')
    return super(CallbackRetry, self).increment(method, url, *args, **kwargs)

#logs retry attempts
def retry_callback(url):
  currentscript = os.path.basename(os.path.splitext(__file__)[0])
  #log_msg = log_message.get_file_logger(currentscript, loglevel, LOGFILE, currentscript, True)
  log_msg = logging.getLogger(currentscript)
  now = datetime.now()
  #print('Retry invoked at ', now.strftime("%Y-%m-%d %H:%M:%S"), ' for ', url)
  log_msg('Retry invoked at {}, for {}'.format(now.strftime("%Y-%m-%d %H:%M:%S"), url))

def usage():
  print("Usage: %s --environment=<PROD><DEV><QA><2015><TRAINING> (optional)--loglevel=<INFO><DEBUG><WARN><ERROR><FATAL> (optional)--help" % sys.argv[0])
  print("Usage: %s (optional)--e <PROD><DEV><QA><2015><TRAINING> (optional)--l <INFO><DEBUG><WARN><ERROR><FATAL> (optional)--h" % sys.argv[0])
  print("-------------------------------------------------------------------------------------------------------------------------------")

# ========================================= Snow Functions ========================================= #
def querySnow(url, log_msg):
    global sn_username 
    global sn_password

    #log = logging.getLogger(__name__)
    #logging.getLogger("urllib3").setLevel(logging.DEBUG)

    log_msg.debug('Calling URL: {}'.format(url))

    # Setup the session
    session = requests.Session()
    session.headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.1.2222.33 Safari/537.36",
    "Accept-Encoding": "*",
    "Connection": "keep-alive",
    "Content-Type":"application/json",
    "Accept":"application/json"
    }

    # retry solution derived from https://stackoverflow.com/questions/23267409/how-to-implement-retry-mechanism-into-python-requests-library
    #                             https://stackoverflow.com/questions/58724052/urllib3-how-to-get-response-when-maxretryerror-is-thrown
    #                             https://stackoverflow.com/questions/51188661/adding-callback-function-on-each-retry-attempt-using-requests-urllib3
    # Define the retries for use when attaching to the http adapter
    #  backoff_factor defines sleeping between retries with an increasing backoff of 0s, 2s, 4s, 8s, 16s
    #retries = Retry(total=1, backoff_factor=1, status_forcelist=[400, 404, 500, 502, 503, 504 ], raise_on_status=True)
    retries = CallbackRetry(total=5, backoff_factor=1, status_forcelist=[400, 404, 500, 502, 503, 504 ], raise_on_status=True, callback=retry_callback)
    # attach retry parameters to the adapter for all sessions starting with 'http://' or 'https://'
    #session.mount('http://', HTTPAdapter(max_retries=retries))
    session.mount('https://', HTTPAdapter(max_retries=retries))
    
    # Set proper headers
    # ORIGINAL headers = {"Content-Type":"application/json","Accept":"application/json"}
    
    # Do the HTTP request
    # ORIGINAL response = requests.get(url, auth=(sn_username, sn_password), headers=headers)

    try:
        header = '-------------------------------------------------------------------------------------------'
        header2 = '{}\n{}'.format(header,header)
        log_msg.debug(header2)
        log_msg.debug('SNOW session request started')

        #real connection
        response = session.get(url, auth=(sn_username, sn_password), headers=session.headers)
        #test connections - following 2 lines can be used for testing http and https
        #response = session.get('http://httpstat.us/502', auth=(sn_username, sn_password), headers=session.headers)
        #response = session.get(url="https://httpbin.org/status/502", auth=(sn_username, sn_password), headers=session.headers)
        response.raise_for_status()
        
        #format this line
        #log_msg.debug('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:',response.json())
        log_msg.debug('Status: {} Headers: {} Error Response: {}'.format(response.status_code, response.headers, response.json()))
        # Decode the JSON response into a dictionary and use the data
        data = response.json()
        log_msg.debug(data)

        log_msg.debug('SNOW session request ended')    
        log_msg.debug(header2)

    except Exception as e:
        log_msg.fatal('Exception received: {}'.format(e))
        sys.exit(22)

    return data

# Object:
#       {'<group_sys_id>': {'manager': '<manager_sys_id>', 'name': '<group_name>'}}

def getSnowGroupInfo(log_msg):  

    global sn_instance
    #url = 'https://blueshieldca2015.service-now.com/api/now/table/sys_user_group?sysparm_query=active%3Dtrue%5EtypeLIKE09a29c916f468940608a0302be3ee4ad&sysparm_fields=sys_id%2Cmanager%2Cname'
    #url = 'https://blueshieldca.service-now.com/api/now/table/sys_user_group?sysparm_query=active%3Dtrue%5EtypeLIKE09a29c916f468940608a0302be3ee4ad&sysparm_fields=sys_id%2Cmanager%2Cname'
    #url = 'https://blueshieldca2015.service-now.com/api/now/table/sys_user_group?sysparm_query=name%3DIT Site Reliability Engineering (SRE)'
    url = '{}/api/now/table/sys_user_group?sysparm_query=active%3Dtrue%5EtypeLIKE09a29c916f468940608a0302be3ee4ad&sysparm_fields=sys_id%2Cmanager%2Cname'.format(sn_instance)
    data = querySnow(url, log_msg=log_msg)
    results = data['result']
    snowGroups = {}
    
#&sysparm_fields=manager%2Csys_id%2Cname
#type contains assignment 
#delimited with %2C

    for result in results:
        group = {}
        
        result_sys_id = result['sys_id']
        result_name = result['name']
        
        if isinstance(result['manager'],dict):
            result_manager = result['manager']['value']
        else:
            result_manager = None
        
        group['manager'] = result_manager
        group['name'] = result_name
        
        snowGroups[result_sys_id] = group
    
    log_msg.info('Found {} active Groups in ServiceNow.'.format(len(snowGroups)))
    return snowGroups



def createOnCallUrlSnow(snowGroups):
    global sn_instance
    
    #url = 'https://blueshieldca2015.service-now.com/api/now/on_call_rota/whoisoncall?group_ids='
    #url = 'https://blueshieldca.service-now.com/api/now/on_call_rota/whoisoncall?group_ids='
    url = '{}/api/now/on_call_rota/whoisoncall?group_ids='.format(sn_instance)
    
    for i,group in enumerate(snowGroups.keys()):
        
        if i == 0:
            url += group
        else:
            url += '%2C' + group
    
    return url

def createOnCallUrlSnowBatch(snowGroupList):
    global sn_instance 
    #url = 'https://blueshieldca2015.service-now.com/api/now/on_call_rota/whoisoncall?group_ids='
    #url = 'https://blueshieldca.service-now.com/api/now/on_call_rota/whoisoncall?group_ids='
    url = '{}/api/now/on_call_rota/whoisoncall?group_ids='.format(sn_instance)
    
    for i,group in enumerate(snowGroupList):
        
        if i == 0:
            url += group
        else:
            url += '%2C' + group
    
    return url

# Object key is group sys_id
# Attributes are manager, name, 1.0, 2.0
def getOnCallScheduleSnow(log_msg):
    snowGroups = getSnowGroupInfo(log_msg=log_msg)
    
    log_msg.debug('Snow groups is: [{}]'.format(snowGroups))
    
    onCallGroups = {}

    if len(snowGroups) > maxParmsToMIR3:

        snowGroupsList = list(snowGroups.keys())

        while len(snowGroupsList) > 0:
            tempListForUrl = []
            for i, tempGroup in enumerate(snowGroupsList):
                if i < maxParmsToMIR3:
                    tempListForUrl.append(tempGroup)
                else:
                    break
            
            url = createOnCallUrlSnowBatch(tempListForUrl)
            log_msg.debug('Using on call URL: {}'.format(url))
            data = querySnow(url, log_msg=log_msg)
            
            results = data['result']
            
            for result in results:
                
                result_sys_id = result['group']
                if not result_sys_id in onCallGroups:
                    onCallGroups[result_sys_id] = {}
                    onCallGroups[result_sys_id]['manager'] = snowGroups[result_sys_id]['manager']
                    onCallGroups[result_sys_id]['name'] = snowGroups[result_sys_id]['name']
                    
                orderStr = str(result['order'])
                onCallGroups[result_sys_id][orderStr] = result['userId']
                onCallGroups[result_sys_id][orderStr + '-roster'] = result['roster']
                
            
            #remove proccessed records from snowGroupsList for next iteration of while loop
            for groupKey in tempListForUrl:
                if groupKey in snowGroupsList:
                    snowGroupsList.remove(groupKey)
    
    else:
        
        url = createOnCallUrlSnow(snowGroups)
        log_msg.debug('Using on call URL: {}'.format(url))
        data = querySnow(url, log_msg=log_msg)
        
        results = data['result']
        
        for result in results:
            
            result_sys_id = result['group']
            if not result_sys_id in onCallGroups:
                onCallGroups[result_sys_id] = {}
                onCallGroups[result_sys_id]['manager'] = snowGroups[result_sys_id]['manager']
                onCallGroups[result_sys_id]['name'] = snowGroups[result_sys_id]['name']
            
            orderStr = str(result['order'])
            onCallGroups[result_sys_id][orderStr] = result['userId']

    snowGroups = []
    
    for group in onCallGroups:
        snowGroups.append(onCallGroups[group])
    
    log_msg.info('Found {} active on-call Groups in ServiceNow.'.format(len(snowGroups)))
    return snowGroups

def createListOfSnowUsers(snowGroups, log_msg):
    snowUsers = []
    
    for snowGroup in snowGroups:
        if snowGroup['manager'] is not None:
            snowUsers.append(snowGroup['manager'])
        if '1.0' in snowGroup.keys():
            snowUsers.append(snowGroup['1.0'])
        else:
            log_msg.warning('Could not find Snow User for group [' + snowGroup['name'] + '] missing for 1.0(Primary)')
        if '2.0' in snowGroup.keys():
            snowUsers.append(snowGroup['2.0'])
        else:
            log_msg.warning('Could not find Snow User for group [' + snowGroup['name'] + '] missing for 2.0(Secondary)')
    
    snowUsers = list(set(snowUsers))
    
    log_msg.info('Found {} active on-call users in ServiceNow.'.format(len(snowUsers)))
    return snowUsers

# ========================================= Mir3 Functions ========================================= #

def queryMir3(mir3_payload, incomingMethodName, exitOnError, log_msg):

    # Setup the session
    session = requests.Session()
    session.headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.1.2222.33 Safari/537.36",
    "Accept-Encoding": "*",
    "Connection": "keep-alive",
    "Content-Type":"application/json",
    "Accept":"application/json"
    }
    # retry solution derived from https://stackoverflow.com/questions/23267409/how-to-implement-retry-mechanism-into-python-requests-library
    #                             https://stackoverflow.com/questions/58724052/urllib3-how-to-get-response-when-maxretryerror-is-thrown
    #                             https://stackoverflow.com/questions/51188661/adding-callback-function-on-each-retry-attempt-using-requests-urllib3
    # Define the retries for use when attaching to the http adapter
    #  backoff_factor defines sleeping between retries with an increasing backoff of 0s, 2s, 4s, 8s, 16s
    #retries = Retry(total=1, backoff_factor=1, status_forcelist=[400, 404, 500, 502, 503, 504 ], raise_on_status=True)
    retries = CallbackRetry(total=5, backoff_factor=1, status_forcelist=[400, 404, 500, 502, 503, 504 ], raise_on_status=True, callback=retry_callback)
    # attach retry parameters to the adapter for all sessions starting with 'http://' or 'https://'
    #session.mount('http://', HTTPAdapter(max_retries=retries))
    session.mount('https://', HTTPAdapter(max_retries=retries))
    
    # Set proper headers
    # ORIGINAL headers = {"Content-Type":"application/json","Accept":"application/json"}
    
    # Do the HTTP request
    # ORIGINAL response = requests.get(url, auth=(sn_username, sn_password), headers=headers)   
    
    try:
        mir3_url = 'https://inwebservices.mir3.com/services/mir3'
        log_msg.debug('MIR3 URL is: {}'.format(mir3_url))
        log_msg.debug('Payload is: {}'.format(mir3_payload))
        #response = requests.request('POST', mir3_url, data = mir3_payload, verify=False)
        response = session.get(url, auth=(sn_username, sn_password), headers=session.headers)
        #test connections - following 2 lines can be used for testing http and https
        #response = session.get('http://httpstat.us/502', auth=(sn_username, sn_password), headers=session.headers)
        #response = session.get(url="https://httpbin.org/status/502", auth=(sn_username, sn_password), headers=session.headers)
        response.raise_for_status()
        
        validateMIR3Response(response, exitOnError, incomingMethodName, log_msg)
        
        return response.content
        #return None
        
    except requests.exceptions.RequestException as e:
        sys.stderr.write('ERROR: %sn' % str(e))
        log_msg.fatal('ERROR: %sn' % str(e))
        sys.exit(20)

def validateMIR3Response(mir3response, exitOnError, incomingMethodName, log_msg):
    if mir3response.status_code != 200:
        sys.stderr.write("MIR3 Status [{}] Headers [{}] Error Response: [{}]".format(mir3response.status_code, mir3response.headers, mir3response.text))
        log_msg.fatal("MIR3 Status [{}] Headers [{}] Error Response: [{}]".format(mir3response.status_code, mir3response.headers, mir3response.text))
        sys.exit(10)
  
    #lets validate we got 'success' = 'true' from the response....
    successValue = re.search("<success>.*</success>", mir3response.text, flags=re.IGNORECASE)
    responseCode = successValue.group(0).split('>')[1].split('</')[0]
    if len(responseCode) > 0:
        log_msg.debug("Success boolean from MIR3 response is [{}]".format(responseCode))
        if responseCode.lower() == 'false':
            if exitOnError:
                log_msg.fatal("Error! Unsuccessful MIR3 transaction! {} from method {}".format(mir3response.text, incomingMethodName))
                exit(29)
            else: 
                log_msg.warning("Warning! Unsuccessful MIR3 transaction! {} from method {}".format(mir3response.text, incomingMethodName))
    else:
        log_msg.warning("Could not find <success> in the response from MIR3 from method {}. {}".format(incomingMethodName, mir3response.text))

    #check for non-critical errors....
    errorStr = re.search("<errorcode>.*</errorcode>", mir3response.text, flags=re.IGNORECASE)
    if errorStr is not None:
        errorNum = errorStr.group(0).split('>')[1].split('</')[0]
        if len(errorNum) > 0:
            log_msg.error("Received non-critical error message: [{}] from method {}".format(errorNum, incomingMethodName))
            errorMsgStr = re.search("<errormessage>.*</errormessage>", mir3response.text, flags=re.IGNORECASE)
            errorMsg = errorMsgStr.group(0).split('>')[1].split('</')[0]
            log_msg.error("Non-Critical Error Message received: [{}] from method {}".format(errorMsg, incomingMethodName))

def createSearchRecipient(sys_id):
    payload = '''               <ws:customField>
                  <ws:name>snow_sysid</ws:name>
                  <ws:value>{}</ws:value>
               </ws:customField>'''.format(sys_id)
    return payload


def createSearchRecipientsPayload(snowUsers):
    payload = None
    for user in snowUsers:
        if payload == None:
            payload = createSearchRecipient(user)
        else:
            payload += '\n' + createSearchRecipient(user)
    # DELETE MAXRESULTS 10 
    mir3_payload = '''<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ws="http://www.mir3.com/ws">
   <soapenv:Header/>
   <soapenv:Body>
      <ws:searchRecipients>
         <ws:apiVersion>{}</ws:apiVersion>
         <ws:authorization>
            <ws:username>{}</ws:username>
            <ws:password><![CDATA[{}]]></ws:password>
         </ws:authorization>
<!--         <ws:maxResults>10</ws:maxResults>  -->
         <ws:includeDetail>true</ws:includeDetail>
         <ws:query>
            <ws:or>
{}
            </ws:or>
         </ws:query>
      </ws:searchRecipients>
   </soapenv:Body>
</soapenv:Envelope>'''.format(mir3_soapVars['apiVersion'],
                              mir3_username,
                              mir3_password,
                              payload
                              )
    return mir3_payload

def getMir3RecipientIds(snowUsers, log_msg):
    
    currentCount = 0
    currentTopLimit = maxParmsToMIR3 + currentCount
    users = {}

    while len(snowUsers) > currentCount:

        tempListForUrl = []
        
        if currentCount + maxParmsToMIR3 < len(snowUsers):
            currentTopLimit = maxParmsToMIR3 + currentCount
        else:
            currentTopLimit = len(snowUsers)

        for i, tempUser in enumerate(snowUsers, currentCount):
            if i < currentTopLimit:
                tempListForUrl.append(snowUsers[i])
                currentCount += 1
            else:
                break

        mir3_payload = createSearchRecipientsPayload(tempListForUrl)
    
        response = queryMir3(mir3_payload, incomingMethodName='getMir3RecipientIds', exitOnError=False, log_msg=log_msg)
    
        if response is not None:
            root = ET.fromstring(response)
        
            mir3_ns = '{http://www.mir3.com/ws}'
            for user in root.iter('{}recipientDetail'.format(mir3_ns)):
                mir3_id = user.find('{}userUUID'.format(mir3_ns)).text
                
                for customField in user.iter('{}customField'.format(mir3_ns)):
                    if customField.find('{}name'.format(mir3_ns)).text == 'snow_sysid':
                        snow_id = customField.find('{}value'.format(mir3_ns)).text
                
                users[snow_id] = mir3_id
        
    if len(snowUsers) != len(users):
        log_msg.warning("Warning! We have {} ServiceNow users and only found {} MIR3 users.".format(len(snowUsers), len(users)))
        for user in snowUsers:
            if user not in users.keys():
                log_msg.warning('ServiceNow User with sys_id={} not found in MIR3.'.format(user))
#            sys.exit(11)

    return users


def getScheduleNamesMir3(log_msg):
    mir3_payload='''<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ws="http://www.mir3.com/ws">
       <soapenv:Header/>
       <soapenv:Body>
          <ws:searchRecipientSchedules>
             <ws:apiVersion>{}</ws:apiVersion>
             <ws:authorization>
                <ws:username>{}</ws:username>
                <ws:password><![CDATA[{}]]></ws:password>
             </ws:authorization>
             <ws:includeDetail>true</ws:includeDetail>
             <ws:query>
                <ws:division>{}</ws:division>
             </ws:query>
          </ws:searchRecipientSchedules>
       </soapenv:Body>
    </soapenv:Envelope>'''.format(mir3_soapVars['apiVersion'],mir3_username,mir3_password,mir3_soapVars['division'])
    
    
    response = queryMir3(mir3_payload, incomingMethodName='getScheduleNamesMir3', exitOnError=False, log_msg=log_msg)
    
    if response is not None:
        root = ET.fromstring(response)
        
        mir3_ns = '{http://www.mir3.com/ws}'
        
        #for child in root.iter('{}matchCount'.format(mir3_ns)):
        #    if child.tag == '{}matchCount'.format(mir3_ns):
        #        matchCount = child.text
        
        #for child in root.iter('{}returnCount'.format(mir3_ns)):
        #    if child.tag == '{}returnCount'.format(mir3_ns):
        #        returnCount = child.text
        
        #print('matchCount is {}'.format(matchCount))
        #print('returnCount is {}'.format(returnCount))
        
        
        scheduleNames = []
        
        for child in root.iter('{}recipientScheduleDetail'.format(mir3_ns)):
            scheduleName = child.find('{}scheduleName'.format(mir3_ns)).text
            scheduleNames.append(scheduleName)
            
        
        return scheduleNames

def generateEscalationsXml(scheduleDetail):

    if 'level1' in scheduleDetail.keys() and scheduleDetail['level1'] is not None:
        escalationsXml = ''' <ws:escalation>
                        <ws:maxResponseTime>3600</ws:maxResponseTime>
                        <ws:recipient>
                          <ws:userUUID>{}</ws:userUUID>
                        </ws:recipient>
                     </ws:escalation>
                     '''.format(scheduleDetail['level1'])
    if 'level2' in scheduleDetail.keys() and scheduleDetail['level2'] is not None:
        escalationsXml += ''' <ws:escalation>
                        <ws:maxResponseTime>3600</ws:maxResponseTime>
                        <ws:recipient>
                          <ws:userUUID>{}</ws:userUUID>
                        </ws:recipient>
                     </ws:escalation>
                     '''.format(scheduleDetail['level2'])
# V.Fanin 09/11/2020 - Removed Level 3 (group) from escalation path per request.
#     if 'level3' in scheduleDetail.keys() and scheduleDetail['level3'] is not None:
#        escalationsXml += ''' <ws:escalation>
#                        <ws:maxResponseTime>3600</ws:maxResponseTime>
#                        <ws:recipientGroup><![CDATA[{}]]></ws:recipientGroup>
#                     </ws:escalation>
#                     '''.format(scheduleDetail['level3'])
    if 'level4' in scheduleDetail.keys() and scheduleDetail['level4'] is not None:
        escalationsXml += ''' <ws:escalation>
                        <ws:maxResponseTime>3600</ws:maxResponseTime>
                        <ws:recipient>
                          <ws:userUUID>{}</ws:userUUID>
                        </ws:recipient>
                     </ws:escalation>
                     '''.format(scheduleDetail['level4'])    

    return escalationsXml

def generateRecipientScheduleXml(scheduleDetail):
    
    escalationsXml = generateEscalationsXml(scheduleDetail)
    
    payload = '''         <ws:recipientScheduleDetail>
            <ws:scheduleName><![CDATA[{}]]></ws:scheduleName>
            <ws:division>{}</ws:division>
            <ws:shifts>
               <ws:shiftName>On-Call</ws:shiftName>
               <ws:importedShift>false</ws:importedShift>
               <ws:rule>
                  <ws:ruleTimeZone>PACIFIC_USA</ws:ruleTimeZone>
                  <ws:ruleException>NON_EXCEPTION</ws:ruleException>
                  <ws:workOnHoliday>true</ws:workOnHoliday>
                  <ws:startTime>08:00:00</ws:startTime>
                  <ws:durationInMinutes>1440</ws:durationInMinutes>
                  <ws:startDate>2020-04-21</ws:startDate>
                  <ws:intervalRepeat>
                     <ws:every>1</ws:every>
                     <ws:timeUnit>DAY</ws:timeUnit>
                  </ws:intervalRepeat>
                  <ws:escalations>
                     {}
                  </ws:escalations>
               </ws:rule>
            </ws:shifts>
         </ws:recipientScheduleDetail>'''.format(scheduleDetail['scheduleName'],
                                                 mir3_soapVars['division'],
                                                 escalationsXml
                                                 )
    return payload


def createRecipientSchedulePayload(scheduleDetails, log_msg):
    payload = None
    for scheduleDetail in scheduleDetails:
        log_msg.debug('Creating Schedule named: {}'.format(scheduleDetail['scheduleName']))
        if payload == None:
            payload = generateRecipientScheduleXml(scheduleDetail)
        else:
            payload += '\n' + generateRecipientScheduleXml(scheduleDetail)
    
    mir3_payload = '''<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ws="http://www.mir3.com/ws">
   <soapenv:Header/>
   <soapenv:Body>
      <ws:addNewRecipientSchedules>
         <ws:apiVersion>{}</ws:apiVersion>
         <ws:authorization>
            <ws:username>{}</ws:username>
            <ws:password><![CDATA[{}]]></ws:password>
         </ws:authorization>
{}
      </ws:addNewRecipientSchedules>
   </soapenv:Body>
</soapenv:Envelope>'''.format(mir3_soapVars['apiVersion'],
                              mir3_username,
                              mir3_password,
                              payload
                              )
    return mir3_payload


def createMir3RecipientSchedules(scheduleDetails, log_msg):
    mir3_payload = createRecipientSchedulePayload(scheduleDetails, log_msg)
    response = queryMir3(mir3_payload, incomingMethodName='createMir3RecipientSchedules', exitOnError=False, log_msg=log_msg)
    return response

def generateUpdateMir3RecipientSchedulesXml(scheduleDetail):
    payload = '''         <ws:updateOneRecipientSchedule>
            <ws:recipientSchedule><![CDATA[{}]]></ws:recipientSchedule>
{}
         </ws:updateOneRecipientSchedule>'''.format(scheduleDetail['scheduleName'],generateRecipientScheduleXml(scheduleDetail))
    
    return payload

def generateUpdateMir3RecipientSchedulesPayload(scheduleDetails):
    payload = None
    for scheduleDetail in scheduleDetails:
        if payload == None:
            payload = generateUpdateMir3RecipientSchedulesXml(scheduleDetail)
        else:
            payload += '\n' + generateUpdateMir3RecipientSchedulesXml(scheduleDetail)
    
    mir3_payload = '''<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ws="http://www.mir3.com/ws">
   <soapenv:Header/>
   <soapenv:Body>
      <ws:updateRecipientSchedules>
         <ws:apiVersion>{}</ws:apiVersion>
         <ws:authorization>
            <ws:username><![CDATA[{}]]></ws:username>
            <ws:password><![CDATA[{}]]></ws:password>
         </ws:authorization>
{}
      </ws:updateRecipientSchedules>
   </soapenv:Body>
</soapenv:Envelope>'''.format(mir3_soapVars['apiVersion'],
                              mir3_username,
                              mir3_password,
                              payload
                              )
    return mir3_payload


def updateMir3RecipientSchedules(scheduleDetails, log_msg):
    mir3_payload = generateUpdateMir3RecipientSchedulesPayload(scheduleDetails)
    response = queryMir3(mir3_payload,incomingMethodName='updateMir3RecipientSchedules', exitOnError=False, log_msg=log_msg)
    return response

def generateDeleteMir3RecipientSchedulesXml(scheduleName):
    payload = '''         <ws:scheduleName><![CDATA[{}]]></ws:scheduleName>'''.format(scheduleName)
    
    return payload

def generateDeleteMir3RecipientSchedulesPayload(scheduleNames):
    payload = None
    for scheduleName in scheduleNames:
        if payload == None:
            payload = generateDeleteMir3RecipientSchedulesXml(scheduleName)
        else:
            payload += '\n' + generateDeleteMir3RecipientSchedulesXml(scheduleName)
    
    mir3_payload = '''<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ws="http://www.mir3.com/ws">
   <soapenv:Header/>
   <soapenv:Body>
      <ws:deleteRecipientSchedules>
         <ws:apiVersion>{}</ws:apiVersion>
         <ws:authorization>
            <ws:username>{}</ws:username>
            <ws:password><![CDATA[{}]]></ws:password>
         </ws:authorization>
{}
      </ws:deleteRecipientSchedules>
   </soapenv:Body>
</soapenv:Envelope>'''.format(mir3_soapVars['apiVersion'],
                              mir3_username,
                              mir3_password,
                              payload
                              )
    return mir3_payload


def deleteMir3RecipientSchedules(scheduleNames, log_msg):
    mir3_payload = generateDeleteMir3RecipientSchedulesPayload(scheduleNames)
    response = queryMir3(mir3_payload,incomingMethodName='deleteMir3RecipientSchedules',exitOnError=False, log_msg=log_msg)
    return response


# ========================================= Data Functions ========================================= #
def generateScheduleDetails(snowGroups,mir3Users, log_msg):
    scheduleDetails = []
    
    for snowGroup in snowGroups:        

        try:
#           scheduleName = 'KP Test {} On-Call'.format(snowGroup['name'])
            scheduleName = '{} On-Call'.format(snowGroup['name'])
            if '1.0' in snowGroup.keys():
                level1 = mir3Users[snowGroup['1.0']]
            else:
                level1 = None
                log_msg.warning('Error: Unknown Key: 1.0 while processing on-call schedule for ServiceNow Group {}.'\
                ' This most likely means that a ServiceNow user was not found in MIR3.'\
                ' Check log for such errors.'.format(snowGroup['name']))
            if '2.0' in snowGroup.keys():
                #mbk before doing this make sure roster is not SAME meaning bug in SNOW code to return entire team instead of just primary
                #   if they are the equal do not enter a level 2 to the map....
                if snowGroup['2.0-roster'] == snowGroup['1.0-roster']:
                  log_msg.info('Group has only 1 roster, not adding secondary for group: [{}]!'.format(snowGroup['name']))
                  level2 = None
                else:
                  level2 = mir3Users[snowGroup['2.0']]
            else:
                level2 = None
                log_msg.warning('Error: Unknown Key: 2.0 while processing on-call schedule for ServiceNow Group [{}].'\
                ' This most likely means that a ServiceNow user was not found in MIR3 OR the group only has a Primary Defined.'\
                ' Check log for such errors.'.format(snowGroup['name']))
            # V.Fanin 09/11/2020 - Removed Level 3 (group) from escalation path per request.
            # level3 = snowGroup['name']
            if 'manager' in snowGroup.keys():
                level4 = mir3Users[snowGroup['manager']]
            else:
                level4 = None
                log_msg.warning('Error: Unknown Key: manager while processing on-call schedule for ServiceNow Group [{}].'\
                ' This most likely means that a ServiceNow user was not found in MIR3.'\
                ' Check log for such errors.'.format(snowGroup['name']))
            
            scheduleDetail = {'scheduleName':scheduleName,
                            'level1':level1,
                            'level2':level2,
                            # V.Fanin 09/11/2020 - Removed Level 3 (group) from escalation path per request.
                            # 'level3':level3,
                            'level4':level4}
            
            scheduleDetails.append(scheduleDetail)
        except KeyError as keyException:
            log_msg.warning('Error: Unknown Key: {} while processing on-call schedule for ServiceNow Group [{}].'\
                ' This most likely means that a ServiceNow user was not found in MIR3.'\
                ' Check log for such errors.'.format(keyException, snowGroup['name']))
    
    return scheduleDetails

 
def addFakeDetails(scheduleDetails):
    randomInts = []
    for i in range(25):
        randomInts.append(random.randint(1,100))
    randomInts = list(set(randomInts))
    
    fakeScheduleDetails = []
    
    for scheduleDetail in scheduleDetails:
        fakeScheduleDetails.append(scheduleDetail)
        
        for randomInt in randomInts:
            tmp = scheduleDetail.copy()
            tmp['scheduleName'] = '{}_{}'.format(randomInt,tmp['scheduleName'])
            fakeScheduleDetails.append(tmp)
    
    return fakeScheduleDetails

def generateScheduleDetailsMap(scheduleDetails,existingSchedulesInMir3):
    scheduleDetailsMap = {'create': [],
                          'update': [],
                          'delete': []}
    
    scheduleNames = [scheduleDetail['scheduleName'] for scheduleDetail in scheduleDetails]
    
    # If in MIR3 and NOT in ServiceNow On-Call, then delete
    for existingSchedule in existingSchedulesInMir3:
        if existingSchedule not in scheduleNames:
            scheduleDetailsMap['delete'].append(existingSchedule)
    
    for scheduleDetail in scheduleDetails:
        if scheduleDetail['scheduleName'] in existingSchedulesInMir3:
            scheduleDetailsMap['update'].append(scheduleDetail)
        else:
            scheduleDetailsMap['create'].append(scheduleDetail)
    
    
    
    return scheduleDetailsMap

def syncMir3RecipientSchedules(scheduleDetailsMap, log_msg):
    cntCreate = len(scheduleDetailsMap['create'])
    cntDelete = len(scheduleDetailsMap['delete'])
    cntUpdate = len(scheduleDetailsMap['update'])
    
    if cntCreate != 0:
        plural = 's' if 1 < cntCreate else ''
        log_msg.info('    Creating {} recipient schedule{}'.format(cntCreate,plural))
        createMir3RecipientSchedules(scheduleDetailsMap['create'], log_msg=log_msg)
    else:
        log_msg.info('    There are no recipient schedules that need to be created.')
    
    
    if cntDelete != 0:
        plural = 's' if 1 < cntDelete else ''
        log_msg.info('    Deleting {} recipient schedule{}'.format(cntDelete,plural))
        deleteMir3RecipientSchedules(scheduleDetailsMap['delete'], log_msg=log_msg)
    else:
        log_msg.info('    There are no recipient schedules that need to be deleted.')
    
    
    if cntUpdate != 0:
        plural = 's' if 1 < cntUpdate else ''
        log_msg.info('    Updating {} recipient schedule{}'.format(cntUpdate,plural))
        updateMir3RecipientSchedules(scheduleDetailsMap['update'], log_msg=log_msg)
    else:
        log_msg.info('    There are no recipient schedules that need to be updated.')

def syncMir3RecipientSchedulesFake(scheduleDetailsMap, log_msg):
    cntCreate = len(scheduleDetailsMap['create'])
    cntDelete = len(scheduleDetailsMap['delete'])
    cntUpdate = len(scheduleDetailsMap['update'])
    
    if cntCreate != 0:
        plural = 's' if 1 < cntCreate else ''
        log_msg.info('    Creating {} recipient schedule{}'.format(cntCreate,plural))
        #createMir3RecipientSchedules(scheduleDetailsMap['create'])
    else:
        log_msg.info('    There are no recipient schedules that need to be created.')
    
    
    if cntDelete != 0:
        plural = 's' if 1 < cntDelete else ''
        log_msg.info('    Deleting {} recipient schedule{}'.format(cntDelete,plural))
        #deleteMir3RecipientSchedules(scheduleDetailsMap['delete'])
    else:
        log_msg.info('    There are no recipient schedules that need to be deleted.')
    
    
    if cntUpdate != 0:
        plural = 's' if 1 < cntUpdate else ''
        log_msg.info('    Updating {} recipient schedule{}'.format(cntUpdate,plural))
        #updateMir3RecipientSchedules(scheduleDetailsMap['update'])
    else:
        log_msg.info('    There are no recipient schedules that need to be updated.')

def initSetup(args):

    global sn_username, sn_password, mir3_username, mir3_password, mir3_soapVars, sn_instance

    try:
        #opts, args = getopt.getopt(sys.argv[1:], 'hl:e:', ['help', 'loglevel=', 'environment='])
        opts, args = getopt.getopt(args[1:], 'hl:e:', ['help', 'loglevel=', 'environment='])
    except getopt.GetoptError as err:
        print("exception in GETOPT with [%s]" % err)
        usage()
        sys.exit(2)
  
    # defaults.....
    loglevel = 'INFO'
    environment = '2015'
  
    validloglevel = [ 'DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL' ]
  
    for opt, arg in opts:
        if opt in ('--l', '--loglevel'):
            loglevel = arg.upper()
        elif opt in ('--e', '--environment'):
            environment = arg.upper()
        elif opt in ('--h', '--help'):
            usage()
            sys.exit(0)
        else:
            assert False, "unhandled option"

    currentscript = os.path.basename(os.path.splitext(__file__)[0])
    date_fmt = datetime.now().strftime('%Y%m%d-%H%M')
    LOGFILE = '%s/%s_%s.log' % (LOG_DIR, currentscript, date_fmt)

    if validloglevel.count(loglevel) < 1:
        usage()
        sys.exit(5)
    
  
    log_msg = log_message.get_file_logger(currentscript, loglevel, LOGFILE, currentscript, True)
    log_msg.info("Starting program running with LOG4J as [%s]" % loglevel)
    log_msg.info("Arguments for program {}".format(opts))

    try:

        #get config file information....
        cfgfile, config, sections = getConfigSections(log_msg, currentscript)
        if sections is None:
            log_msg.fatal("NO configuration file found, exiting!")
            sys.exit(3)
        else:
            log_msg.debug("Sections in configuration file [{}]".format(sections))
        
        if environment not in sections:
            log_msg.fatal("Provided Section [{}] does not exist in configuration file [{}], exiting!".format(environment,cfgfile))
            sys.exit(8)
      
        #get variables....    
        encryptKey = config.get(environment, 'encryptKey', fallback=None)
        sn_instance = config.get(environment, 'sn_instance', fallback=None)
        mir3_url = config.get(environment, 'mir3_url', fallback=None)
        mir3_username_encrypt = config.get(environment, 'mir3_username', fallback=None)
        sn_username_encrypt = config.get(environment, 'sn_username', fallback=None)
        sn_password_encrypt = config.get(environment, 'sn_password', fallback=None)
        mir3_password_encrypt = config.get(environment,'mir3_password', fallback=None)
        mir3_api_version = config.get('DEFAULT', 'mir3_api_version', fallback=None)
        mir3_division = config.get('DEFAULT', 'mir3_division', fallback=None)

        if mir3_division is None:
            log_msg.error("We must have a mir3_division value for MIR3, exiting!")
            sys.exit(3)
        else:
            mir3_soapVars['division'] = mir3_division
      
        if sn_instance is None:
            log_msg.error("We must have a ServiceNow instance to query against, exiting!")
            sys.exit(3)
        
        if mir3_api_version is None:
            log_msg.error("We must have a MIR3 API Version, exiting!")
            sys.exit(3)
        else:
            mir3_soapVars['apiVersion'] = mir3_api_version

        if encryptKey is None:
            log_msg.error("We must have a must have an encrypting key, exiting!")
            sys.exit(3)
    
        if mir3_url is None:
            log_msg.error("We must have a URL for MIR3, exiting!")
            sys.exit(3)

        if mir3_username_encrypt is None:
            log_msg.error("We must have a MIR3 username, exiting!")
            sys.exit(3)

        if mir3_password_encrypt is None:
            log_msg.error("We must have a MIR3 password, exiting!")
            sys.exit(3)

        if sn_username_encrypt is None:
            log_msg.error("We must have a ServiceNow username, exiting!")
            sys.exit(3)

        if sn_password_encrypt is None:
            log_msg.error("We must have a ServiceNow password, exiting!")
            sys.exit(3)
      
        log_msg.debug("Environment {} ServiceNow Instance {}".format(environment, sn_instance))
        log_msg.debug("encrypt key {}\n mir3_url {}\n mir3_username_encrypted {}\n mir3_password_encrypted {}\n sn_username_encrypted {}\n sn_password_encrypt {}"\
            .format(encryptKey, mir3_url, mir3_username_encrypt, mir3_password_encrypt, sn_username_encrypt, sn_password_encrypt))
    
    
        #use security functions to get username/password
        sn_username = decryptStringWithKey(log_msg, sn_username_encrypt, encryptKey)
        log_msg.debug("ServiceNow username [{}]".format(sn_username))
        sn_password = decryptStringWithKey(log_msg, sn_password_encrypt, encryptKey)
        log_msg.debug("ServiceNow password [{}]".format('XXXXXXXXXX'))
        mir3_username = decryptStringWithKey(log_msg, mir3_username_encrypt, encryptKey)
        log_msg.debug("MIR3 username [{}]".format(mir3_username))
        mir3_password = decryptStringWithKey(log_msg, mir3_password_encrypt, encryptKey)
        log_msg.debug("MIR3 password [{}]".format('XXXXXXXXXX'))

    except OSError as err:
        log_msg.error("OS error: {0}".format(err))
        log_msg.error(traceback.format_exc())
        raise
    except ValueError as err:
        log_msg.error("VALUE error: {0}".format(err))
        log_msg.error(traceback.format_exc())
        raise
    except KeyboardInterrupt:
        log_msg.error('You cancelled the operation.')
        log_msg.error(traceback.format_exc())
        raise
    except IOError as err:
        log_msg.error("IOError error: {0}".format(err))
        log_msg.error(traceback.format_exc())
        raise
    except EOFError as err:
        log_msg.error("EOFError error: {0}".format(err))
        log_msg.error(traceback.format_exc())
        raise
    except KeyError as err:
        log_msg.error("KeyError error: {0}".format(err))
        log_msg.error(traceback.format_exc())
        raise
    except Exception as err:
        log_msg.error("Unexpected error: {0}".format(err))
        log_msg.error(traceback.format_exc())
        raise
    
    return log_msg, sn_instance, mir3_url, sn_username, sn_password, mir3_username, mir3_password

def main():
      
    #setup the script
    log_msg, sn_instance, mir3_url, sn_username, sn_password, mir3_username, mir3_password = initSetup(sys.argv)
    
    liveRun = True # Change to True to actually update data
    log_msg.info('Starting Program')
    log_msg.info('Live Run is {}'.format(liveRun))

    header = '-------------------------------------------------------------------------------------------'
    header2 = '{}\n{}'.format(header,header)
    
    log_msg.info(header)
    log_msg.info('Querying list of on-call groups from ServiceNow')
    
    snowGroups = getOnCallScheduleSnow(log_msg=log_msg)
    log_msg.debug(snowGroups)
    
    log_msg.info(header2)
    
    log_msg.info('Generating unique list of ServiceNow users that are on-call')
    snowUsers = createListOfSnowUsers(snowGroups, log_msg=log_msg)
    log_msg.debug(snowUsers)
    
    log_msg.info(header2)
    
    log_msg.info('Querying MIR3 to get UUID for the on-call users')
    mir3Users = getMir3RecipientIds(snowUsers, log_msg=log_msg)
    log_msg.debug(mir3Users)
    
    log_msg.info(header2)
    
    log_msg.info('Querying MIR3 for existing recipient schedules in {}'.format(mir3_soapVars['division']))
    existingSchedulesInMir3 = getScheduleNamesMir3(log_msg=log_msg)
#    existingSchedulesInMir3.remove('IT Site Reliability Engineering (SRE) On-Call') # DELETE THIS LATER
    log_msg.debug(existingSchedulesInMir3)

    log_msg.info(header2)
    
    log_msg.info('Generating schedule details')
    scheduleDetails = generateScheduleDetails(snowGroups,mir3Users, log_msg=log_msg)
#    scheduleDetails = addFakeDetails(scheduleDetails) # DELETE THIS LATER
    log_msg.debug(scheduleDetails)
    
    log_msg.info(header2)
    
    log_msg.info('Generating schedule details map to determine action <create|update|delete>')
    scheduleDetailsMap = generateScheduleDetailsMap(scheduleDetails,existingSchedulesInMir3)
    log_msg.debug(scheduleDetailsMap)
    
    log_msg.info(header2)
    
    log_msg.info('Syncing MIR3 recipient schedules with ServiceNow')
    if liveRun:
        syncMir3RecipientSchedules(scheduleDetailsMap, log_msg=log_msg)
    else:
        syncMir3RecipientSchedulesFake(scheduleDetailsMap, log_msg=log_msg)
    
    log_msg.info('Ending Program')

if __name__=='__main__':
    main()

    
    
    