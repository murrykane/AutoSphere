#!/usr/bin/env python
'''
Murry Kane 
Version 1.0

 Updates
 Date       By             Reason
_________________________________________________________________________________________________
 04/07/2020 Murry Kane     Initial version
 11/04/2020 Murry Kane     Added logic to avoid case issues with Group Names
_________________________________________________________________________________________________
 Description
 This script will export all groups (group member) from ServiceNow via rest call, it will process each record 
 and gather specific fields for syncing with MIR3 notificaiton system. 


'''

import shlex, subprocess, sys, platform, os, log_message, getpass, getopt, ast, requests, json, base64, re, traceback, unicodedata
from datetime import datetime, timedelta
from SREConstants import *
from SREConfigParser import *
from SRESecurity import *
import xml.etree.ElementTree as ET

def usage():
  print("Usage: %s --environment=<PROD><DEV><QA><2015><TRAINING> (optional)--loglevel=<INFO><DEBUG><WARN><ERROR><FATAL> (optional)--help" % sys.argv[0])
  print("Usage: %s (optional)--e <PROD><DEV><QA><2015><TRAINING> (optional)--l <INFO><DEBUG><WARN><ERROR><FATAL> (optional)--h" % sys.argv[0])
  print("-------------------------------------------------------------------------------------------------------------------------------")

def strip_accents(string, accents=('COMBINING ACUTE ACCENT', 'COMBINING GRAVE ACCENT', 'COMBINING TILDE')):
  accents = set(map(unicodedata.lookup, accents))
  chars = [c for c in unicodedata.normalize('NFD', string) if c not in accents]
  normalized_chars = unicodedata.normalize('NFC', ''.join(chars))
  #lets fix en dash
  str1_chars = re.sub(u"\u2013", "-", normalized_chars)
  str2_chars = re.sub(u"\xa0", " ", str1_chars)
  return str2_chars
  
def getMIR3GroupData(log_msg, mir3_url, mir3_cntMaxCnt, mir3_username, mir3_password, mir3_api_version):

  #MIR3 variables
  mir3_auth_str = '%s:%s' % (mir3_username, mir3_password)
  mir3_b64_auth_str = base64.b64encode(mir3_auth_str.encode("utf-8"))
  cntPaginationCnt = 1
  mir3ContactData = {}
  mir3ContactIter = {}
  
  #payload = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://www.mir3.com/ws\">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <ws:searchRecipientGroups>\r\n         <ws:apiVersion>4.7</ws:apiVersion>\r\n         <ws:authorization>\r\n            <ws:username>mkane01</ws:username>\r\n            <ws:password>Skippy10!</ws:password>\r\n         </ws:authorization>\r\n         <ws:startIndex>1</ws:startIndex>\r\n         <ws:maxResults>500</ws:maxResults>\r\n         <ws:includeDetail>true</ws:includeDetail>\r\n         <ws:query>\r\n            <ws:not>\r\n            </ws:not>\r\n         </ws:query>\r\n      </ws:searchRecipientGroups>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>"
  payload = """<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://www.mir3.com/ws\">\r\n   
    <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <ws:searchRecipientGroups>\r\n         
    <ws:apiVersion>{apiversion}</ws:apiVersion>\r\n         <ws:authorization>\r\n            <ws:username>{username}</ws:username>\r\n            <ws:password>{password}</ws:password>\r\n         
    </ws:authorization>\r\n         <ws:startIndex>{startindex}</ws:startIndex>\r\n         <ws:maxResults>{maxresults}</ws:maxResults>\r\n         
    <ws:includeDetail>true</ws:includeDetail>\r\n         <ws:query>\r\n            <ws:not>\r\n            </ws:not>\r\n         </ws:query>\r\n      </ws:searchRecipientGroups>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>"""

  mir3_payloadGetTotal = payload.format(apiversion=mir3_api_version, username=mir3_username, password=mir3_password, startindex=1, maxresults=1 )
  mir3_payloadGetTotalLog = payload.format(apiversion=mir3_api_version, username='XXXXXXXXX', password='XXXXXXXXX', startindex=1, maxresults=1 )
  
  log_msg.debug("MIR3 Payload is: [{}]".format(mir3_payloadGetTotalLog))
  
  mir3_headers = {
    'Authorization': 'Basic {}'.format(mir3_b64_auth_str),
    'Content-Type': 'application/xml'
  }

  mir3_response = requests.request("POST", mir3_url, headers=mir3_headers, data = mir3_payloadGetTotal, verify=True)

  if mir3_response.status_code != 200: 
    log_msg.error("MIR3 Status [{}] Headers [{}] Error Response: [{}]".format(mir3_response.status_code, mir3_response.headers, mir3_response.text))
    exit(31)
  
  #return mir3_response      
  mir3ContactTotals = int(getMIR3ContactTotals(log_msg, mir3_response))
  log_msg.debug("Totals for MIR3 is [{}]".format(mir3ContactTotals))


  #now call MIR3 in loop to get all contacts into hashmap
  while cntPaginationCnt <= mir3ContactTotals:
  
    returnedGroupCnt = 0
    #setup pagination
    #mir3_payload = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://www.mir3.com/ws\" ws:nil=\"true\">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <ws:searchRecipients>\r\n         <ws:apiVersion>{}</ws:apiVersion>\r\n         <ws:authorization>\r\n            <ws:username>{}</ws:username>\r\n            <ws:password>{}</ws:password>\r\n         </ws:authorization>\r\n <ws:startIndex>{}</ws:startIndex>     \r\n          <ws:maxResults>{}</ws:maxResults> \r\n \t\t<ws:includeDetail>true</ws:includeDetail>\r\n         <ws:query>\r\n            <ws:and>\r\n               <ws:customField>\r\n                  <ws:name>snow_sysid</ws:name>\r\n                  <ws:value></ws:value>\r\n               </ws:customField>\r\n            </ws:and>\r\n         </ws:query>\r\n      </ws:searchRecipients>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>".format(mir3_api_version, mir3_username, mir3_password, cntPaginationCnt, mir3_cntMaxCnt)
    mir3_payload = payload.format(apiversion=mir3_api_version, username=mir3_username, password=mir3_password, startindex=cntPaginationCnt, maxresults=mir3_cntMaxCnt )
    mir3_payloadLog = payload.format(apiversion=mir3_api_version, username='XXXXXXXXX', password='XXXXXXXXX', startindex=cntPaginationCnt, maxresults=mir3_cntMaxCnt )
    log_msg.debug("MIR3 Payload is: [{}]".format(mir3_payloadLog))
    
    mir3_response = requests.request("POST", mir3_url, headers=mir3_headers, data = mir3_payload, verify=True)

    if mir3_response.status_code != 200: 
      log_msg.error("MIR3 Status [{}] Headers [{}] Error Response: [{}]".format(mir3_response.status_code, mir3_response.headers, mir3_response.text))
      exit(32) 
      
    #lookup up the group and get its data....
    returnedContactCnt, mir3ContactIter = getMIR3GroupRecord(log_msg, mir3_response)
    
    #append to full hashmap
    mir3ContactData = dict(list(mir3ContactData.items()) + list(mir3ContactIter.items()))
    #mir3ContactData += mir3GroupIter
    log_msg.debug("Added [{}] more MIR3 contacts to hashmap Total Count now [{}]".format(returnedContactCnt, len(mir3ContactData)))
    
    #to setup starting point for next loop....
    cntPaginationCnt += returnedContactCnt
    log_msg.debug("New Pagination counter is [{}]".format(cntPaginationCnt))
    

  #return hashmap 
  log_msg.debug("All done getting MIR3 contacts, size of hashmap is [{}]".format(len(mir3ContactData)))
  return mir3ContactData    

def getMIR3ContactTotals(log_msg, mir3_response):

  mir3ContactCnt = 0
  mir3_ns = ''  #mbk assign it to default before getting from elementTree
  foundIt = False
  
  root = ET.fromstring(mir3_response.content)
  for child in root.iter('*'):
    #log_msg.debug("Child Tag [{}] Child Attribute [{}] Child Text [{}]".format(child.tag, child.attrib, child.text))
    
    if len(re.findall('}response$', child.tag, flags=re.IGNORECASE)) > 0:
      mir3_ns = child.tag.split('}')[0] + '}'
      log_msg.debug("Response Found for getting namespace using the following: [{}]".format(mir3_ns))
    
    if len(re.findall('{}matchcount$'.format(mir3_ns), child.tag, flags=re.IGNORECASE)) > 0:
      log_msg.debug("Count of records found in MIR3 is: [{}]".format(child.text))
      mir3ContactCnt = child.text
      foundIt = True
    
    if mir3_ns is not None and foundIt:
      log_msg.debug("Found needed values for parsing elementTree...")
      break
  return mir3ContactCnt

def checkMIR3Group(log_msg, mir3_url, mir3_groupAttrs, mir3_contacts, sn_group, sn_contacts, mir3_username, mir3_password, mir3_api_version, mir3_division):

  action = None
  
  mir3_grpmemCnt = 0
  sn_grpmemCnt = 0
  mir3_grpUUIDs = ''
  
  #lets see if the group is in MIR3 
  if sn_group.lower() in (string.lower() for string in mir3_groupAttrs):
    #mbk need to get rid of case issues....
    if sn_group not in mir3_groupAttrs:
      #this means we have a case issues, lets update the group to get case fixed....
      log_msg.info("The case of the group is not matching, update needed for group [{}]".format(sn_group))
      action = 'update'
      return action   
    #get counts....
    mir3_grpmemCnt = len(mir3_groupAttrs[sn_group]['mir3_groupAttrs'].items())
    sn_grpmemCnt = len(sn_contacts.items())
    mir3_grpUUIDs = mir3_groupAttrs[sn_group]['mir3_groupAttrs']   
    log_msg.debug("MIR3 member count [{}] ServiceNow member count [{}] for group [{}]".format(mir3_grpmemCnt, sn_grpmemCnt, sn_group))
    log_msg.debug("MIR3 group members UUIDs [{}]".format(mir3_grpUUIDs))
   
    #check for update next....
    if mir3_grpmemCnt != sn_grpmemCnt:
      log_msg.debug("Count of records in MIR3 [{}] group don't match count of records in ServiceNow group [{}], update needed for group [{}]".format(mir3_grpmemCnt, sn_grpmemCnt, sn_group))
      action = 'update'
    else:
      #now check if each record matches.....
      for contact, sn_sysid in sn_contacts.items():
        log_msg.debug("Group Member [{}] with sys id [{}] for group [{}]".format(contact, sn_sysid, sn_group))
        #validate we can get mir3 uuid from sysid
        if sn_sysid in mir3_contacts:
          mir3_uuid = mir3_contacts[sn_sysid]['mir3_useruuid']
          log_msg.debug("Found sysid [{}] in MIR3 contacts with UUID [{}]".format(sn_sysid, mir3_uuid))
          #now see if we have the uuid in the returned web service call to MIR3
          if mir3_uuid in mir3_grpUUIDs:
            log_msg.debug("Found contact [{}] in MIR3 web service all for member of group [{}] with UUID [{}]".format(contact, sn_group, mir3_uuid))
          else:
            log_msg.debug("Didn't find contact [{}] in MIR3 web service call for member of group [{}] with UUID [{}], update needed for this group".format(contact, sn_group, mir3_uuid))
            action = 'update'
            break
        else:
          log_msg.warning("We could not find contact [{}] in MIR3 contacts, this is an issue!".format(contact))
          #MBK need to determine action or exit here!
  else:
    log_msg.debug("Insert is needed for this group [{}]".format(sn_group))
    action = 'insert'
    
  log_msg.debug("Action needed in MIR3 is [{}]".format(action))
  
  if action == 'update':
    #lets see if the divisions match....
    if mir3_division != mir3_groupAttrs[sn_group]['mir3_division']:
      log_msg.info("Group [{}] will get MIR3 DIVISION updated from [{}] to [{}]".format(sn_group, mir3_groupAttrs[sn_group]['mir3_division'], mir3_division))
          
  
  return action
  
def getMIR3ContactData(log_msg, mir3_response):

  mir3ContactCnt = 0
  contactTuple = {}
  mir3_ns = '' 
  mir3_workemail = ''
  mir3_personalemail = ''
  mir3_workphone = ''
  mir3_homephone = ''
  mir3_mobile = ''
  mir3_sms = ''
  mir3_homeemail = ''  
  mir3_jobcode = ''
  mir3_managerlevel = ''
  mir3_department = ''
  mir3_businessunit = ''
  mir3_datasource = ''
  mir3_middlename = ''
  mir3_supervisorid = ''
  mir3_snow_sysid = ''
  mir3_snow_userid = ''
      
  root = ET.fromstring(mir3_response.content)
  for child in root.iter('*'):
    #log_msg.debug("Child Tag [{}] Child Attribute [{}] Child Text [{}]".format(child.tag, child.attrib, child.text))
    
    if len(re.findall('}response$', child.tag, flags=re.IGNORECASE)) > 0:
      mir3_ns = child.tag.split('}')[0] + '}'
      log_msg.debug("Response Found for getting namespace using the following: [{}]".format(mir3_ns))
    
    if len(re.findall('{}matchcount$'.format(mir3_ns), child.tag, flags=re.IGNORECASE)) > 0:
      log_msg.debug("Count of records found in MIR3 is: [{}]".format(child.text))
      #contactTuple["mir3_matchcount"] = child.text
      #only care on what is returned so commented this out...
      #mir3ContactCnt = int(child.text)
      
    if len(re.findall('{}returncount$'.format(mir3_ns), child.tag, flags=re.IGNORECASE)) > 0:
      log_msg.debug("Count of matched records found in MIR3 is: [{}]".format(child.text))
      #contactTuple["mir3_returncount"] = child.text
      mir3ContactCnt = int(child.text)
    
    #if mir3_ns is not None and 'mir3_returncount' in contactTuple and 'mir3_matchcount' in contactTuple:
    if mir3_ns is not None and mir3ContactCnt > 0:
      log_msg.debug("Found needed values for parsing elementTree...")
      break
    
  for recipent in root.iter('{}recipientDetail'.format(mir3_ns)):
    log_msg.debug("Tag for this item is {}".format(recipent.tag))
    mir3_useruuid = recipent.find('{}userUUID'.format(mir3_ns)).text 
    mir3_pin = recipent.find('{}pin'.format(mir3_ns)).text
    mir3_telephonyid = recipent.find('{}telephonyId'.format(mir3_ns)).text
    mir3_firstname = recipent.find('{}firstName'.format(mir3_ns)).text
    mir3_lastname = recipent.find('{}lastName'.format(mir3_ns)).text
    mir3_locale = recipent.find('{}locale'.format(mir3_ns)).text
    mir3_division = recipent.find('{}division'.format(mir3_ns)).text
   
    if recipent.find('{}employeeId'.format(mir3_ns)) is None:
      mir3_employeeid = ''
    else:
      mir3_employeeid = recipent.find('{}employeeId'.format(mir3_ns)).text
      
    if recipent.find('{}company'.format(mir3_ns)) is None:
      mir3_company = ''
    else:
      mir3_company = recipent.find('{}company'.format(mir3_ns)).text
        
    if recipent.find('{}username'.format(mir3_ns)) is None:
      mir3_username = ''
    else:
      mir3_username = recipent.find('{}username'.format(mir3_ns)).text
       
    if recipent.find('{}jobTitle'.format(mir3_ns)) is None:
      mir3_jobtitle = ''
    else:
      mir3_jobtitle = recipent.find('{}jobTitle'.format(mir3_ns)).text

    if recipent.find('{}role'.format(mir3_ns)) is None:
      mir3_role = ''
    else:
      mir3_role = recipent.find('{}role'.format(mir3_ns)).text
     
    #now get devices...
    for devices in recipent.iter('{}devices'.format(mir3_ns)):
      #log_msg.debug("Tag for this item is {}".format(devices.tag))
      mir3_workemail = ''
      mir3_personalemail = ''
      mir3_workphone = ''
      mir3_homephone = ''
      mir3_mobile = ''
      mir3_sms = ''
      mir3_homeemail = ''
      
      for device in devices.iter('{}device'.format(mir3_ns)):
        #log_msg.debug("Tag for eachdevice is {}".format(device.tag))
        mir3_devicetype = device.find('{}deviceType'.format(mir3_ns)).text 
        mir3_deviceaddr = device.find('{}address'.format(mir3_ns)).text
        log_msg.debug("Name [{}] with address [{}]".format(mir3_devicetype, mir3_deviceaddr))
        
        if len(re.findall('work email', mir3_devicetype, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found work email....")
          mir3_workemail = mir3_deviceaddr
        if len(re.findall('personal email', mir3_devicetype, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found personal email....")
          mir3_personalemail = mir3_deviceaddr
        if len(re.findall('work phone', mir3_devicetype, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found work phone....")
          mir3_workphone = mir3_deviceaddr
        if len(re.findall('home phone', mir3_devicetype, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found home phone....")
          mir3_homephone = mir3_deviceaddr
        if len(re.findall('home mobile', mir3_devicetype, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found home mobile....")
          mir3_mobile = mir3_deviceaddr
        if len(re.findall('work mobile', mir3_devicetype, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found work mobile....")
          mir3_mobile = mir3_deviceaddr
        if len(re.findall('home sms', mir3_devicetype, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found home sms....")
          mir3_sms = mir3_deviceaddr
        if len(re.findall('work sms', mir3_devicetype, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found work sms....")
          mir3_sms = mir3_deviceaddr
          
        #MBK now sure on this one....
        if len(re.findall('home email', mir3_devicetype, flags=re.IGNORECASE)) > 0:
          log_msg.info("Found home email....")
          mir3_homeemail = mir3_deviceaddr          
 
    #now get custom attributes
    for customfields in recipent.iter('{}customFields'.format(mir3_ns)):
      #log_msg.debug("Tag for this item is {}".format(devices.tag))
      mir3_jobcode = ''
      mir3_managerlevel = ''
      mir3_department = ''
      mir3_businessunit = ''
      mir3_datasource = ''
      mir3_middlename = ''
      mir3_supervisorid = ''
      mir3_snow_sysid = ''
      mir3_snow_userid = ''
      
      for customfield in customfields.iter('{}customField'.format(mir3_ns)):
        #log_msg.debug("Tag for eachdevice is {}".format(customfield.tag))
        mir3_name = customfield.find('{}name'.format(mir3_ns)).text 
        mir3_value = customfield.find('{}value'.format(mir3_ns)).text
        log_msg.debug("Name [{}] with address [{}]".format(mir3_name, mir3_value))
        
        if len(re.findall('job code', mir3_name, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found job code....")
          mir3_jobcode = mir3_value
        if len(re.findall('manager level', mir3_name, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found manager level....")
          mir3_managerlevel = mir3_value
        if len(re.findall('department id', mir3_name, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found department id....")
          mir3_department = mir3_value
        if len(re.findall('business unit', mir3_name, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found business unit....")
          mir3_businessunit = mir3_value
        if len(re.findall('data source', mir3_name, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found data source....")
          mir3_datasource = mir3_value
        if len(re.findall('middle name', mir3_name, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found middle name....")
          mir3_middlename = mir3_value
        if len(re.findall('supervisor id', mir3_name, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found supervisor id....")
          mir3_supervisorid = mir3_value
        if len(re.findall('snow_sysid', mir3_name, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found ServiceNow sysid....")
          mir3_snow_sysid = mir3_value
        if len(re.findall('snow_userid', mir3_name, flags=re.IGNORECASE)) > 0:
          log_msg.debug("Found ServiceNow userid....")
          mir3_snow_userid = mir3_value          
        
    #if len(mir3_employeeid) < 1 or not mir3_employeeid.isdigit():
    if len(mir3_snow_sysid) < 1:
      log_msg.warning("INVALID ServiceNow sysid [{}] for MIR3 Contact UUID [{}]".format(mir3_snow_sysid, mir3_useruuid))
      log_msg.info("Invalid Contact Details: UUID is {} pin {} telephony {} firstname {} lastname {} locale {} employee ID {} company {} division {}".format(mir3_useruuid,mir3_pin,mir3_telephonyid,mir3_firstname,mir3_lastname,mir3_locale,mir3_employeeid,mir3_company,mir3_division))
    else:
      log_msg.debug("UUID is {} pin {} telephony {} firstname {} lastname {} locale {} employee ID {} company {} division {} username {} workemail {} personal email {} work phone {} home phone {} mobile {} sms {} home email {} mir3_jobcode {} mir3_managerlevel {} mir3_department {} mir3_department {} mir3_businessunit {} mir3_datasource {} mir3_middlename {} job_title {} supervisor id {} snow_sysid {} snow_userid {}".format(mir3_useruuid,mir3_pin,mir3_telephonyid,mir3_firstname,mir3_lastname,mir3_locale,mir3_employeeid,mir3_company,mir3_division, mir3_username, mir3_workemail, mir3_personalemail, mir3_workphone, mir3_homephone, mir3_mobile, mir3_sms, mir3_homeemail,mir3_jobcode, mir3_managerlevel, mir3_department, mir3_department, mir3_businessunit, mir3_datasource, mir3_middlename, mir3_jobtitle, mir3_role, mir3_supervisorid, mir3_snow_sysid, mir3_snow_userid ))
      #contactTuple[mir3_employeeid] = { 'mir3_pin' : mir3_pin, 'mir3_telephonyid' : mir3_telephonyid, 'mir3_firstname' : mir3_firstname, 'mir3_lastname' : mir3_lastname, 'mir3_locale' : mir3_locale, 'mir3_useruuid' : mir3_useruuid, 'mir3_company' : mir3_company, 'mir3_division' : mir3_division, 'mir3_username' : mir3_username, 'mir3_workemail' : mir3_workemail, 'mir3_personalemail' : mir3_personalemail, 'mir3_workphone' : mir3_workphone, 'mir3_homephone' : mir3_homephone, 'mir3_mobile' : mir3_mobile, 'mir3_sms' : mir3_sms, 'mir3_homeemail' : mir3_homeemail, 'mir3_jobcode' : mir3_jobcode, 'mir3_managerlevel' :  mir3_managerlevel, 'mir3_department' : mir3_department, 'mir3_businessunit' : mir3_businessunit, 'mir3_datasource' : mir3_datasource, 'mir3_middlename' : mir3_middlename, 'mir3_jobtitle' : mir3_jobtitle, 'mir3_role' : mir3_role, 'mir3_supervisorid' : mir3_supervisorid, 'mir3_snow_sysid' : mir3_snow_sysid, 'mir3_snow_userid' : mir3_snow_userid }
      #we will now load by key uuid...
      #mir3_useruuid
      contactTuple[mir3_snow_sysid] = { 'mir3_pin' : mir3_pin, 'mir3_telephonyid' : mir3_telephonyid, 'mir3_firstname' : mir3_firstname, 'mir3_lastname' : mir3_lastname, 'mir3_locale' : mir3_locale, 'mir3_useruuid' : mir3_useruuid, 'mir3_company' : mir3_company, 'mir3_division' : mir3_division, 'mir3_username' : mir3_username, 'mir3_workemail' : mir3_workemail, 'mir3_personalemail' : mir3_personalemail, 'mir3_workphone' : mir3_workphone, 'mir3_homephone' : mir3_homephone, 'mir3_mobile' : mir3_mobile, 'mir3_sms' : mir3_sms, 'mir3_homeemail' : mir3_homeemail, 'mir3_jobcode' : mir3_jobcode, 'mir3_managerlevel' :  mir3_managerlevel, 'mir3_department' : mir3_department, 'mir3_businessunit' : mir3_businessunit, 'mir3_datasource' : mir3_datasource, 'mir3_middlename' : mir3_middlename, 'mir3_jobtitle' : mir3_jobtitle, 'mir3_role' : mir3_role, 'mir3_supervisorid' : mir3_supervisorid, 'mir3_snow_sysid' : mir3_snow_sysid, 'mir3_snow_userid' : mir3_snow_userid }

    
  #return values needed for logic on insert...  
  return mir3ContactCnt, contactTuple

def getMIR3GroupRecord(log_msg, mir3_response):

  mir3GroupCnt = 0
  groupTuple = {}
  mir3_gorup = ''
  mir3_ns = ''  
  groupAttrs = {}
  
  root = ET.fromstring(mir3_response.content)
  for child in root.iter('*'):
    #log_msg.debug("Child Tag [{}] Child Attribute [{}] Child Text [{}]".format(child.tag, child.attrib, child.text))
    
    if len(re.findall('}response$', child.tag, flags=re.IGNORECASE)) > 0:
      mir3_ns = child.tag.split('}')[0] + '}'
      log_msg.debug("Response Found for getting namespace using the following: [{}]".format(mir3_ns))
    
    if len(re.findall('{}matchcount$'.format(mir3_ns), child.tag, flags=re.IGNORECASE)) > 0:
      log_msg.debug("Count of records found in MIR3 is: [{}]".format(child.text))
      #contactTuple["mir3_matchcount"] = child.text
      #only care on what is returned so commented this out...
      #mir3GroupCnt = int(child.text)
      
    if len(re.findall('{}returncount$'.format(mir3_ns), child.tag, flags=re.IGNORECASE)) > 0:
      log_msg.debug("Count of matched records found in MIR3 is: [{}]".format(child.text))
      #contactTuple["mir3_returncount"] = child.text
      mir3GroupCnt = int(child.text)
    
    #if mir3_ns is not None and 'mir3_returncount' in contactTuple and 'mir3_matchcount' in contactTuple:
    if mir3_ns is not None and mir3GroupCnt > 0:
      log_msg.debug("Found needed values for parsing elementTree...")
      break
  
  #lets build the dictionary for each group
  
  for recipent in root.iter('{}recipientGroupDetail'.format(mir3_ns)):
    log_msg.debug("Tag for this item is {}".format(recipent.tag))
    mir3_group = recipent.find('{}title'.format(mir3_ns)).text 
    mir3_division = recipent.find('{}division'.format(mir3_ns)).text
    mir3_dynamicGroup = recipent.find('{}dynamicGroup'.format(mir3_ns)).text

    #now get devices...
    for members in recipent.iter('{}members'.format(mir3_ns)):
      #log_msg.debug("Tag for this item is {}".format(devices.tag))
      groupAttrs = {}
      
      for member in members.iter('{}recipient'.format(mir3_ns)):
        #log_msg.debug("Tag for eachdevice is {}".format(device.tag))
        mir3_useruuid = member.find('{}userUUID'.format(mir3_ns)).text 
        mir3_firstname = member.find('{}firstName'.format(mir3_ns)).text
        mir3_lastname = member.find('{}lastName'.format(mir3_ns)).text
        
        log_msg.debug("First Name [{}] Last Name [{}] with uuid [{}]".format(mir3_firstname, mir3_lastname, mir3_useruuid))
        groupAttrs[mir3_useruuid] = { 'firstname' : mir3_firstname, 'lastname' : mir3_lastname }

    #if len(mir3_employeeid) < 1 or not mir3_employeeid.isdigit():
    if len(mir3_group) < 1:
      log_msg.warning("INVALID MIR3 group [{}] for MIR3 data [{}]".format(mir3_group, mir3_response))
    else:
      log_msg.debug("Group is [{}] division [{}] dynamic group [{}] contacts [{}]".format(mir3_group, mir3_division, mir3_dynamicGroup, groupAttrs))
      groupTuple[mir3_group] = { 'mir3_division' : mir3_division, 'mir3_dynamicGroup' : mir3_dynamicGroup, 'mir3_groupAttrs' : groupAttrs }

    
  #return values needed for logic on insert...  
  return mir3GroupCnt, groupTuple
  
def getSNowGroupData(log_msg, group):

  sn_user = ''
  sn_usersysid = ''
  sn_group = ''
  
  #log_msg.debug('Passed in group data [{}]'.format(group))
  for key, val in group.items():
    if(key.lower() == "user"):
      if val is None:
        sn_user = ''
      else:
        #sn_user = val
        #now get the value....  
        sn_usersysid = strip_accents(val['value'])
        sn_user = strip_accents(val['display_value'])
        if sn_user is None or sn_usersysid is None:
          sn_user = ''
          sn_usersysid = ''
      #log_msg.debug('   User is: [{}] SysID [{}]'.format(sn_user, sn_usersysid))
 
    if(key.lower() == "group"):
      if val is None:
        sn_group = ''
      else:
        #sn_user = val
        #now get the value....
        sn_group = strip_accents(val['display_value'].strip())
        if sn_group is None:
          sn_group = ''
        #mbk lets determine if ascii...
        try:
          sn_group.encode('ascii')
        except UnicodeEncodeError as err:
          log_msg.warning("Exception group name is NOT ASCII [{}] with error [{}]".format(sn_group, err))
          sn_group = ''
          
      #log_msg.debug('   Group is: {}'.format(sn_group))
  
  log_msg.debug('   User is: [{}] SysID [{}] for Group [{}]'.format(sn_user, sn_usersysid, sn_group))
  
  return sn_user, sn_usersysid, sn_group

def insertMIR3Group(log_msg, mir3_url, mir3_contacts, sn_group, sn_contacts, mir3_username, mir3_password, mir3_api_version, mir3_division):

  #MIR3 variables
  mir3_auth_str = '%s:%s' % (mir3_username, mir3_password)
  mir3_b64_auth_str = base64.b64encode(mir3_auth_str.encode("utf-8"))
  
  #payload = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://www.mir3.com/ws\">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <ws:addNewRecipientGroups>\r\n         <ws:apiVersion>4.7</ws:apiVersion>\r\n         <ws:authorization>\r\n            <ws:username>mkane01</ws:username>\r\n            <ws:password>Skippy10!</ws:password>\r\n         </ws:authorization>\r\n         <ws:recipientGroupDetail>\r\n            <ws:title>IT Site Reliability Engineering (SRE)</ws:title>\r\n            <ws:division>/IT/ServiceNow</ws:division>\r\n            <ws:group>IT Site Reliability Engineering (SRE)</ws:group>\r\n            <ws:dynamicGroup>false</ws:dynamicGroup>\r\n            <ws:members>\r\n               <ws:recipient>\r\n                  <ws:userUUID>1af84f52-0001-3000-80c0-fceb55463ffe</ws:userUUID>\r\n               </ws:recipient>\r\n               <ws:recipient>\r\n                  <ws:userUUID>1a405133-0001-3000-80c0-fceb55463ffe</ws:userUUID>\r\n               </ws:recipient>\r\n            </ws:members>\r\n         </ws:recipientGroupDetail>\r\n      </ws:addNewRecipientGroups>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>"
  payload_start = """<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://www.mir3.com/ws\">\r\n   
    <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <ws:addNewRecipientGroups>\r\n         <ws:apiVersion>{apiversion}</ws:apiVersion>\r\n         
    <ws:authorization>\r\n            <ws:username>{username}</ws:username>\r\n            <ws:password>{password}</ws:password>\r\n
    </ws:authorization>\r\n         <ws:recipientGroupDetail>\r\n            <ws:title><![CDATA[{group}]]></ws:title>\r\n
    <ws:division>{division}</ws:division>\r\n            <ws:group><![CDATA[{group}]]></ws:group>\r\n            
    <ws:dynamicGroup>false</ws:dynamicGroup>\r\n            <ws:members>\r\n           """
    
  payload_user = """      <ws:recipient>\r\n                  <ws:userUUID>{uuid}</ws:userUUID>\r\n               </ws:recipient>\r\n               """

  payload_end = """            </ws:members>\r\n         </ws:recipientGroupDetail>\r\n      </ws:addNewRecipientGroups>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>"""
  
  #lots of checks for empty values and it not empty append to payload string
  payload_append = payload_start

  #for loop for each contact needed in the group....
  for contact, sn_sysid in sn_contacts.items():
    log_msg.debug("Group Member [{}] with sys id [{}] for group [{}]".format(contact, sn_sysid, sn_group))
    #validate we can get mir3 uuid from sysid
    if sn_sysid in mir3_contacts:
      mir3_uuid = mir3_contacts[sn_sysid]['mir3_useruuid']
      log_msg.debug("Found sysid [{}] in MIR3 contacts with UUID [{}]".format(sn_sysid, mir3_uuid))
      #add the row to soap call
      payload_append = payload_append + payload_user.format(uuid=mir3_uuid)
    else:
      log_msg.error("We could not find contact [{}] in MIR3 contacts for group [{}], this is an issue exiting!".format(contact, sn_group))    
      #MBK for now
      #exit(47)
      
  #append trailer records
  payload_append = payload_append + payload_end

  #update to the needed values....
  mir3_payload_upd = payload_append.format(apiversion=mir3_api_version, username=mir3_username, password=mir3_password, group=sn_group, division=mir3_division)
  mir3_payload_log = payload_append.format(apiversion=mir3_api_version, username='XXXXXXXXXX', password='XXXXXXXXXX', group=sn_group, division=mir3_division)
  
  #MBK for now
  log_msg.debug("Updated payload: [{}]".format(mir3_payload_log))
  #log_msg.info("Updated payload: [{}]".format(mir3_payload_log))
  
  mir3_headers = {
    'Authorization': 'Basic {}'.format(mir3_b64_auth_str),
    'Content-Type': 'application/xml'
  }

  
  mir3_response = requests.request("POST", mir3_url, headers=mir3_headers, data = mir3_payload_upd, verify=True)

  if mir3_response.status_code != 200: 
    log_msg.error("MIR3 Status [{}] Headers [{}] Error Response: [{}]".format(mir3_response.status_code, mir3_response.headers, mir3_response.text))
    exit(21)

  #lets validate we got 'success' = 'true' from the response....
  log_msg.debug("headers [{}] text [{}]".format(mir3_response.headers, mir3_response.text))
  successValue = re.search("<success>.*</success>", mir3_response.text, flags=re.IGNORECASE)
  responseCode = successValue.group(0).split('>')[1].split('</')[0]
  if len(responseCode) > 0:
    log_msg.debug("Success boolean from MIR3 response is [{}]".format(responseCode))
    if responseCode.lower() == 'false':
      log_msg.error("Failed to insert group [{}], exiting from program!".format(sn_group))
      log_msg.error("Received: [{}]".format(mir3_response.text))
      exit(22)
    else:
      log_msg.debug("Received: [{}] from insert call into MIR3 for group [{}]".format(responseCode, sn_group))
  else:
    log_msg.warning("Could not find <success> in the response from MIR3, for group [{}]".format(sn_group))
    log_msg.warning("Received: [{}]".format(mir3_response.text))
    
  #check for non-critical errors....
  errorStr = re.search("<errorcode>.*</errorcode>", mir3_response.text, flags=re.IGNORECASE)
  if errorStr is not None:
    errorNum = errorStr.group(0).split('>')[1].split('</')[0]
    if len(errorNum) > 0:
      log_msg.warning("Received none-critical error message: [{}] for group [{}]".format(errorNum, sn_group))
      errorMsgStr = re.search("<errormessage>.*</errormessage>", mir3_response.text, flags=re.IGNORECASE)
      errorMsg = errorMsgStr.group(0).split('>')[1].split('</')[0]
      log_msg.warning("Non-Critical Message received: [{}] for group [{}]".format(errorMsg, sn_group))
    else:
      log_msg.debug("No non-critical error received for group [{}]".format(sn_group))
        
  log_msg.info("Successfully inserted group [{}]".format(sn_group))
  

def callMIR3(log_msg, mir3_url, mir3_cntMaxCnt, mir3_username, mir3_password, mir3_api_version):

  #MIR3 variables
  mir3_auth_str = '%s:%s' % (mir3_username, mir3_password)
  mir3_b64_auth_str = base64.b64encode(mir3_auth_str.encode("utf-8"))
  cntPaginationCnt = 1
  mir3ContactData = {}
  mir3ContactIter = {}
  #mir3_payloadGetTotal = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://www.mir3.com/ws\">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <ws:searchRecipients>\r\n         <ws:apiVersion>{}</ws:apiVersion>\r\n         <ws:authorization>\r\n            <ws:username>{}</ws:username>\r\n            <ws:password>{}</ws:password>\r\n         </ws:authorization>\r\n  \r\n         <ws:startIndex>{}</ws:startIndex>     \r\n          <ws:maxResults>{}</ws:maxResults>\r\n \t\t<ws:includeDetail>true</ws:includeDetail>\r\n         <ws:query>\r\n            <ws:not>\r\n            </ws:not>\r\n         </ws:query>\r\n      </ws:searchRecipients>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>".format(mir3_api_version, mir3_username, mir3_password, 1, 1)
  #mir3_payloadGetTotal = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://www.mir3.com/ws\" ws:nil=\"true\">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <ws:searchRecipients>\r\n         <ws:apiVersion>{}</ws:apiVersion>\r\n         <ws:authorization>\r\n            <ws:username>{}</ws:username>\r\n            <ws:password>{}</ws:password>\r\n         </ws:authorization>\r\n <ws:startIndex>{}</ws:startIndex>     \r\n          <ws:maxResults>{}</ws:maxResults> \r\n \t\t<ws:includeDetail>true</ws:includeDetail>\r\n         <ws:query>\r\n            <ws:and>\r\n               <ws:customField>\r\n                  <ws:name>snow_sysid</ws:name>\r\n                  <ws:value></ws:value>\r\n               </ws:customField>\r\n            </ws:and>\r\n         </ws:query>\r\n      </ws:searchRecipients>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>".format(mir3_api_version, mir3_username, mir3_password, 1, 1)
  mir3_payloadGetTtl = """ <soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://www.mir3.com/ws\" ws:nil=\"true\">\r\n   
          <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <ws:searchRecipients>\r\n         <ws:apiVersion>{}</ws:apiVersion>\r\n         <ws:authorization>\r\n            
          <ws:username>{}</ws:username>\r\n            <ws:password>{}</ws:password>\r\n         </ws:authorization>\r\n <ws:startIndex>{}</ws:startIndex>     \r\n          
          <ws:maxResults>{}</ws:maxResults> \r\n \t\t<ws:includeDetail>true</ws:includeDetail>\r\n         <ws:query>\r\n            <ws:and>\r\n               
          <ws:customField>\r\n                  <ws:name>snow_sysid</ws:name>\r\n                  <ws:value></ws:value>\r\n               </ws:customField>\r\n            
          </ws:and>\r\n         </ws:query>\r\n      </ws:searchRecipients>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>"""

  mir3_payloadGetTotal = mir3_payloadGetTtl.format(mir3_api_version, mir3_username, mir3_password, 1, 1)
  mir3_payloadGetTotalLog = mir3_payloadGetTtl.format(mir3_api_version, 'XXXXXXXXXX', 'XXXXXXXXXX', 1, 1)
  
  log_msg.debug("MIR3 Payload is: [{}]".format(mir3_payloadGetTotalLog))
  
  mir3_headers = {
    'Authorization': 'Basic {}'.format(mir3_b64_auth_str),
    'Content-Type': 'application/xml'
  }

  mir3_response = requests.request("POST", mir3_url, headers=mir3_headers, data = mir3_payloadGetTotal, verify=True)

  if mir3_response.status_code != 200: 
    log_msg.error("MIR3 Status [{}] Headers [{}] Error Response: [{}]".format(mir3_response.status_code, mir3_response.headers, mir3_response.text))
    exit(19)
  
  #return mir3_response      
  mir3ContactTotals = int(getMIR3ContactTotals(log_msg, mir3_response))
  log_msg.info("Total contacts from MIR3 is [{}]".format(mir3ContactTotals))


  #now call MIR3 in loop to get all contacts into hashmap
  while cntPaginationCnt <= mir3ContactTotals:
  
    returnedGroupCnt = 0
    #setup pagination
    #mir3_payload = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://www.mir3.com/ws\">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <ws:searchRecipients>\r\n         <ws:apiVersion>{}</ws:apiVersion>\r\n         <ws:authorization>\r\n            <ws:username>{}</ws:username>\r\n            <ws:password>{}</ws:password>\r\n         </ws:authorization>\r\n  \r\n         <ws:startIndex>{}</ws:startIndex>     \r\n          <ws:maxResults>{}</ws:maxResults>\r\n \t\t<ws:includeDetail>true</ws:includeDetail>\r\n         <ws:query>\r\n            <ws:not>\r\n            </ws:not>\r\n         </ws:query>\r\n      </ws:searchRecipients>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>".format(mir3_api_version, mir3_username, mir3_password, cntPaginationCnt, mir3_cntMaxCnt)
    #mir3_payload = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://www.mir3.com/ws\" ws:nil=\"true\">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <ws:searchRecipients>\r\n         <ws:apiVersion>{}</ws:apiVersion>\r\n         <ws:authorization>\r\n            <ws:username>{}</ws:username>\r\n            <ws:password>{}</ws:password>\r\n         </ws:authorization>\r\n <ws:startIndex>{}</ws:startIndex>     \r\n          <ws:maxResults>{}</ws:maxResults> \r\n \t\t<ws:includeDetail>true</ws:includeDetail>\r\n         <ws:query>\r\n            <ws:and>\r\n               <ws:customField>\r\n                  <ws:name>snow_sysid</ws:name>\r\n                  <ws:value></ws:value>\r\n               </ws:customField>\r\n            </ws:and>\r\n         </ws:query>\r\n      </ws:searchRecipients>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>".format(mir3_api_version, mir3_username, mir3_password, cntPaginationCnt, mir3_cntMaxCnt)
    mir3_payload_str = """<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://www.mir3.com/ws\" ws:nil=\"true\">\r\n   
            <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <ws:searchRecipients>\r\n         <ws:apiVersion>{}</ws:apiVersion>\r\n         <ws:authorization>\r\n            
            <ws:username>{}</ws:username>\r\n            <ws:password>{}</ws:password>\r\n         </ws:authorization>\r\n <ws:startIndex>{}</ws:startIndex>     \r\n          
            <ws:maxResults>{}</ws:maxResults> \r\n \t\t<ws:includeDetail>true</ws:includeDetail>\r\n         <ws:query>\r\n            
            <ws:and>\r\n               <ws:customField>\r\n                  <ws:name>snow_sysid</ws:name>\r\n                  <ws:value></ws:value>\r\n               
            </ws:customField>\r\n            </ws:and>\r\n         </ws:query>\r\n      </ws:searchRecipients>\r\n   
            </soapenv:Body>\r\n</soapenv:Envelope>""" 
            
    mir3_payload = mir3_payload_str.format(mir3_api_version, mir3_username, mir3_password, cntPaginationCnt, mir3_cntMaxCnt)
    mir3_payloadLog = mir3_payload_str.format(mir3_api_version, 'XXXXXXXXX', 'XXXXXXXXX', cntPaginationCnt, mir3_cntMaxCnt)
    log_msg.debug("MIR3 Payload is: [{}]".format(mir3_payloadLog))
    
    mir3_response = requests.request("POST", mir3_url, headers=mir3_headers, data = mir3_payload, verify=True)

    if mir3_response.status_code != 200: 
      log_msg.error("MIR3 Status [{}] Headers [{}] Error Response: [{}]".format(mir3_response.status_code, mir3_response.headers, mir3_response.text))
      exit(20)    
    
    returnedContactCnt, mir3ContactIter = getMIR3ContactData(log_msg, mir3_response)
    
    #append to full hashmap
    mir3ContactData = dict(list(mir3ContactData.items()) + list(mir3ContactIter.items()))
    #mir3ContactData += mir3GroupIter
    log_msg.debug("Added [{}] more MIR3 contacts to hashmap Total Count now [{}]".format(returnedContactCnt, len(mir3ContactData)))
    
    #to setup starting point for next loop....
    cntPaginationCnt += returnedContactCnt
    log_msg.debug("New Pagination counter is [{}]".format(cntPaginationCnt))
    

  #return hashmap 
  log_msg.debug("All done getting MIR3 contacts, size of hashmap is [{}]".format(len(mir3ContactData)))
  return mir3ContactData
  
def updateMIR3Group(log_msg, mir3_url, mir3_contacts, sn_group, sn_contacts, mir3_username, mir3_password, mir3_api_version, mir3_division):

  #MIR3 variables
  mir3_auth_str = '%s:%s' % (mir3_username, mir3_password)
  mir3_b64_auth_str = base64.b64encode(mir3_auth_str.encode("utf-8"))
  
  payload_start = """<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://www.mir3.com/ws\">\r\n  
    <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <ws:updateRecipientGroups>\r\n         <ws:apiVersion>{apiversion}</ws:apiVersion>\r\n         
    <ws:authorization>\r\n            <ws:username>{username}</ws:username>\r\n            <ws:password>{password}</ws:password>\r\n         </ws:authorization>\r\n 
    <ws:createIfNotFound>false</ws:createIfNotFound>\r\n         <ws:updateOneRecipientGroup>\r\n            
    <ws:recipientGroup><![CDATA[{group}]]></ws:recipientGroup>\r\n            <ws:recipientGroupDetail>\r\n               
    <ws:title><![CDATA[{group}]]></ws:title>\r\n               <ws:division>{division}</ws:division>\r\n               
    <ws:members>\r\n """
               
  payload_end = """  </ws:members>\r\n            </ws:recipientGroupDetail>\r\n                        </ws:updateOneRecipientGroup>\r\n      </ws:updateRecipientGroups>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>""" 
    
  payload_user = """              <ws:recipient>\r\n   <ws:userUUID>{uuid}</ws:userUUID>\r\n      </ws:recipient>\r\n   """
                  
    
  #lots of checks for empty values and it not empty append to payload string
  payload_append = payload_start
  
  #for loop for each contact needed in the group....
  for contact, sn_sysid in sn_contacts.items():
    log_msg.debug("Group Member [{}] with sys id [{}] for group [{}]".format(contact, sn_sysid, sn_group))
    #validate we can get mir3 uuid from sysid
    if sn_sysid in mir3_contacts:
      mir3_uuid = mir3_contacts[sn_sysid]['mir3_useruuid']
      log_msg.debug("Found sysid [{}] in MIR3 contacts with UUID [{}]".format(sn_sysid, mir3_uuid))
      #add the row to soap call
      payload_append = payload_append + payload_user.format(uuid=mir3_uuid)
    else:
      log_msg.error("We could not find contact [{}] in MIR3 contacts for group [{}], this is an issue exiting!".format(contact, sn_group))    
      #MBK for now we will continue....
      #exit(46)
          
          
  #append trailer records
  payload_append = payload_append + payload_end
  
  #update to the needed values....
  mir3_payload_upd = payload_append.format(apiversion=mir3_api_version, username=mir3_username, password=mir3_password, group=sn_group, division=mir3_division)
  mir3_payload_log = payload_append.format(apiversion=mir3_api_version, username='XXXXXXXXX', password='XXXXXXXXX', group=sn_group, division=mir3_division)

  log_msg.debug("Updated payload: [{}]".format(mir3_payload_log))

  mir3_headers = {
    'Authorization': 'Basic {}'.format(mir3_b64_auth_str),
    'Content-Type': 'application/xml'
  }

  mir3_response = requests.request("POST", mir3_url, headers=mir3_headers, data = mir3_payload_upd, verify=True)

  if mir3_response.status_code != 200: 
    log_msg.error("MIR3 Status [{}] Headers [{}] Error Response: [{}]".format(mir3_response.status_code, mir3_response.headers, mir3_response.text))
    exit(23)

  #lets validate we got 'success' = 'true' from the response....
  log_msg.debug("headers [{}] text [{}]".format(mir3_response.headers, mir3_response.text))
  successValue = re.search("<success>.*</success>", mir3_response.text, flags=re.IGNORECASE)
  responseCode = successValue.group(0).split('>')[1].split('</')[0]
  if len(responseCode) > 0:
    log_msg.debug("Success boolean from MIR3 response is [{}]".format(responseCode))
    if responseCode.lower() == 'false':
      log_msg.error("Failed to update group [{}], exiting from program!".format(sn_group))
      log_msg.error("Received: [{}]".format(mir3_response.text))
      exit(24)
    else:
      log_msg.debug("Received: [{}] from update call into MIR3 for group [{}]".format(responseCode, sn_group))
  else:
    log_msg.warning("Could not find <success> in the response from MIR3, for group [{}]".format(sn_group))
    log_msg.warning("Received: [{}]".format(mir3_response.text))
    
  #check for non-critical errors....
  errorStr = re.search("<errorcode>.*</errorcode>", mir3_response.text, flags=re.IGNORECASE)
  if errorStr is not None:
    errorNum = errorStr.group(0).split('>')[1].split('</')[0]
    if len(errorNum) > 0:
      log_msg.warning("Received none-critical error message: [{}] for group [{}]".format(errorNum, sn_group))
      errorMsgStr = re.search("<errormessage>.*</errormessage>", mir3_response.text, flags=re.IGNORECASE)
      errorMsg = errorMsgStr.group(0).split('>')[1].split('</')[0]
      log_msg.warning("Non-Critical Message received: [{}] for group [{}]".format(errorMsg, sn_group))
    else:
      log_msg.debug("No non-critical error received for group [{}]".format(sn_group))
        
  log_msg.info("Successfully updated group [{}]".format(sn_group))
 
def removeMIR3Group(log_msg, mir3_url, sn_group, mir3_username, mir3_password, mir3_api_version):


  #MIR3 variables
  mir3_auth_str = '%s:%s' % (mir3_username, mir3_password)
  mir3_b64_auth_str = base64.b64encode(mir3_auth_str.encode("utf-8"))
  
  #payload = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://www.mir3.com/ws\">\r\n   <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <ws:deleteRecipientGroups>\r\n         <ws:apiVersion>4.7</ws:apiVersion>\r\n         <ws:authorization>\r\n            <ws:username>mkane01</ws:username>\r\n            <ws:password>Skippy10!</ws:password>\r\n         </ws:authorization>\r\n         <ws:recipientGroup>IT Site Reliability Engineering (SRE)</ws:recipientGroup>\r\n      </ws:deleteRecipientGroups>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>"
  payload = """<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://www.mir3.com/ws\">\r\n   
    <soapenv:Header/>\r\n   <soapenv:Body>\r\n      <ws:deleteRecipientGroups>\r\n         <ws:apiVersion>{apiversion}</ws:apiVersion>\r\n         
    <ws:authorization>\r\n            <ws:username>{username}</ws:username>\r\n            <ws:password>{password}</ws:password>\r\n         
    </ws:authorization>\r\n         <ws:recipientGroup><![CDATA[{group}]]></ws:recipientGroup>\r\n      </ws:deleteRecipientGroups>\r\n   </soapenv:Body>\r\n</soapenv:Envelope>"""
  
  mir3_payload_upd = payload.format(apiversion=mir3_api_version, username=mir3_username, password=mir3_password, group=sn_group )
  mir3_payload_log = payload.format(apiversion=mir3_api_version, username='XXXXXXXXX', password='XXXXXXXXX', group=sn_group )
  
  log_msg.debug("Updated payload: [{}]".format(mir3_payload_log))

  mir3_headers = {
    'Authorization': 'Basic {}'.format(mir3_b64_auth_str),
    'Content-Type': 'application/xml'
  }

  mir3_response = requests.request("POST", mir3_url, headers=mir3_headers, data = mir3_payload_upd, verify=True)

  if mir3_response.status_code != 200: 
    log_msg.error("MIR3 Status [{}] Headers [{}] Error Response: [{}]".format(mir3_response.status_code, mir3_response.headers, mir3_response.text))
    exit(25)
  
  #lets validate we got 'success' = 'true' from the response....
  log_msg.debug("headers [{}] text [{}]".format(mir3_response.headers, mir3_response.text))
  successValue = re.search("<success>.*</success>", mir3_response.text, flags=re.IGNORECASE)
  responseCode = successValue.group(0).split('>')[1].split('</')[0]
  if len(responseCode) > 0:
    log_msg.debug("Success boolean from MIR3 response is [{}]".format(responseCode))
    if responseCode.lower() == 'false':
      log_msg.error("Failed to delete group [{}], exiting from program!".format(sn_group))
      log_msg.error("Received: [{}]".format(mir3_response.text))
      exit(26)
    else:
      log_msg.debug("Received: [{}] from delete call into MIR3 for group [{}]".format(responseCode, sn_group))
  else:
    log_msg.warning("Could not find <success> in the response from MIR3, for group [{}]".format(sn_group))
    log_msg.warning("Received: [{}]".format(mir3_response.text))
    
  #check for non-critical errors....
  errorStr = re.search("<errorcode>.*</errorcode>", mir3_response.text, flags=re.IGNORECASE)
  if errorStr is not None:
    errorNum = errorStr.group(0).split('>')[1].split('</')[0]
    if len(errorNum) > 0:
      log_msg.warning("Received none-critical error message: [{}] for group [{}]".format(errorNum, sn_group))
      errorMsgStr = re.search("<errormessage>.*</errormessage>", mir3_response.text, flags=re.IGNORECASE)
      errorMsg = errorMsgStr.group(0).split('>')[1].split('</')[0]
      log_msg.warning("Non-Critical Message received: [{}] for group [{}]".format(errorMsg, sn_group))
    else:
      log_msg.debug("No non-critical error received for group [{}]".format(sn_group))
        
  log_msg.info("Successfully deleted group [{}]".format(sn_group))

def determineMIR3GroupRemoval(log_msg, mir3_groupAttrs, sn_groupAttrs, mir3_url, mir3_username, mir3_password, mir3_api_version, removeGroupCnt, mir3_division):
  log_msg.debug("Working on group removal logic")
  #need to iterate all groups defined in MIR3 and see if any are not in ServiceNow, if true then delete them..
  #    Notes: the group in MIR3 should be only non-dynamic groups if its dynamic skip it!
  
  # MBK - lets make it case-insensitive 
  for mir3_group in mir3_groupAttrs:
    log_msg.debug("Working on group [{}] for delete check".format(mir3_group))
    #if mir3_group in sn_groupAttrs:
    if mir3_group.lower() in (string.lower() for string in sn_groupAttrs):
      log_msg.debug("Group [{}] found, no deletion needed".format(mir3_group))
    else:
      #validate its not a dynamic group before deleting...
      log_msg.debug("Dynamic Group flag is [{}] division is [{}]".format(mir3_groupAttrs[mir3_group]['mir3_dynamicGroup'], mir3_groupAttrs[mir3_group]['mir3_division']))
      
      if mir3_groupAttrs[mir3_group]['mir3_dynamicGroup'] == 'true' or mir3_groupAttrs[mir3_group]['mir3_division'] != mir3_division :
        log_msg.debug("Skipping delete on group [{}] as its not eligable".format(mir3_group))
      else:
        log_msg.debug("Performing delete on group [{}] as it no longer exists in ServiceNow".format(mir3_group))
        removeMIR3Group(log_msg, mir3_url, mir3_group, mir3_username, mir3_password, mir3_api_version)
        removeGroupCnt += 1
  
  return removeGroupCnt

def initSetup(args):

  try:
    #opts, args = getopt.getopt(sys.argv[1:], 'hl:e:', ['help', 'loglevel=', 'environment='])
    opts, args = getopt.getopt(args[1:], 'hl:e:', ['help', 'loglevel=', 'environment='])
  except getopt.GetoptError as err:
    print("exception in GETOPT with [%s]" % err)
    usage()
    sys.exit(2)
  
  # defaults.....
  loglevel = 'INFO'
  environment = 'QA'
  
  validloglevel = [ 'DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL' ]
  
  for opt, arg in opts:
    if opt in ('--l', '--loglevel'):
      loglevel = arg.upper()
    elif opt in ('--e', '--environment'):
      environment = arg.upper()
    elif opt in ('--h', '--help'):
      usage()
      sys.exit(0)
    else:
      assert False, "unhandled option"

  pathname = os.path.dirname(sys.argv[0])        
  pathdir = os.path.abspath(pathname)
  currentscript = os.path.basename(os.path.splitext(__file__)[0])
  date_fmt = datetime.now().strftime('%Y%m%d-%H%M')
  LOGFILE = '%s/%s_%s.log' % (LOG_DIR, currentscript, date_fmt)

  if validloglevel.count(loglevel) < 1:
    usage()
    sys.exit(5)
    
  
  log_msg = log_message.get_file_logger(currentscript, loglevel, LOGFILE, currentscript, True)
  log_msg.info("Starting program running with LOG4J as [%s]" % loglevel)

  try:
  
    #get config file information....
    cfgfile, config, sections = getConfigSections(log_msg, currentscript)
    if sections is None:
      log_msg.fatal("NO configuration file found, exiting!")
      sys.exit(3)
    else:
      log_msg.debug("Sections in configuration file [{}]".format(sections))
    
    if environment not in sections:
      log_msg.fatal("Provided Section [{}] does not exist in configuration file [{}], exiting!".format(environment,cfgfile))
      sys.exit(8)
      
    #get variables....    
    sn_maxResultCnt = config.getint('DEFAULT', 'sn_maxResultCnt', fallback=None)
    mir3_cntMaxCnt = config.getint('DEFAULT', 'mir3_cntMaxCnt', fallback=None)
    encryptKey = config.get(environment, 'encryptKey', fallback=None)
    sn_instance = config.get(environment, 'sn_instance', fallback=None)
    mir3_url = config.get(environment, 'mir3_url', fallback=None)
    mir3_username_encrypt = config.get(environment, 'mir3_username', fallback=None)
    sn_username_encrypt = config.get(environment, 'sn_username', fallback=None)
    sn_password_encrypt = config.get(environment, 'sn_password', fallback=None)
    mir3_password_encrypt = config.get(environment,'mir3_password', fallback=None)
    mir3_api_version = config.get('DEFAULT', 'mir3_api_version', fallback=None)
    sn_getGroups = config.get(environment, 'sn_getGroups', fallback=None)
    mir3_division = config.get('DEFAULT', 'mir3_division', fallback=None)

    if mir3_division is None:
      log_msg.error("We must have a MIR3 Divsion value to add to MIR3 Groups, exiting!")
      sys.exit(3)
      
    if sn_getGroups is None:
      log_msg.error("We must have a Query lookup for Groups in ServiceNow, exiting!")
      sys.exit(3)
      
    if sn_instance is None:
      log_msg.error("We must have a ServiceNow instance to query against, exiting!")
      sys.exit(3)
      
    if mir3_api_version is None:
      log_msg.error("We must have a MIR3 API Version, exiting!")
      sys.exit(3)

    if encryptKey is None:
      log_msg.error("We must have a must have an encrypting key, exiting!")
      sys.exit(3)
    
    if mir3_cntMaxCnt is None:
      log_msg.error("We must have a MIR3 Max Return count of contacts, exiting!")
      sys.exit(3)
    
    if sn_maxResultCnt is None:
      log_msg.error("We must have a ServiceNow Max Return count of contacts, exiting!")
      sys.exit(3)
 
    if mir3_url is None:
      log_msg.error("We must have a URL for MIR3, exiting!")
      sys.exit(3)

    if mir3_username_encrypt is None:
      log_msg.error("We must have a MIR3 username, exiting!")
      sys.exit(3)

    if mir3_password_encrypt is None:
      log_msg.error("We must have a MIR3 password, exiting!")
      sys.exit(3)

    if sn_username_encrypt is None:
      log_msg.error("We must have a ServiceNow username, exiting!")
      sys.exit(3)

    if sn_password_encrypt is None:
      log_msg.error("We must have a ServiceNow password, exiting!")
      sys.exit(3)
      
    log_msg.debug("sn_maxResultCnt is {} Environment {} ServiceNow Instance {}".format(sn_maxResultCnt, environment, sn_instance))
    log_msg.debug("encrypt key {} mir3_cntmaxcnt {} mir3_url {} mir3_username_encrypted {} mir3_password_encrypted {} sn_username_encrypted {} sn_password_encrypt {}".format(encryptKey, mir3_cntMaxCnt, mir3_url, mir3_username_encrypt, mir3_password_encrypt, sn_username_encrypt, sn_password_encrypt))
    
    
    #use security functions to get username/password
    sn_username = decryptStringWithKey(log_msg, sn_username_encrypt, encryptKey)
    log_msg.debug("ServiceNow username [{}]".format(sn_username))
    sn_password = decryptStringWithKey(log_msg, sn_password_encrypt, encryptKey)
    log_msg.debug("ServiceNow password [{}]".format('XXXXXXXXXX'))
    mir3_username = decryptStringWithKey(log_msg, mir3_username_encrypt, encryptKey)
    log_msg.debug("MIR3 username [{}]".format(mir3_username))
    mir3_password = decryptStringWithKey(log_msg, mir3_password_encrypt, encryptKey)
    log_msg.debug("MIR3 password [{}]".format('XXXXXXXXXX'))

  except OSError as err:
    log_msg.error("OS error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except ValueError as err:
    log_msg.error("VALUE error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except KeyboardInterrupt:
    log_msg.error('You cancelled the operation.')
    log_msg.error(traceback.format_exc())
    raise
  except IOError as err:
    log_msg.error("IOError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except EOFError as err:
    log_msg.error("EOFError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except KeyError as err:
    log_msg.error("KeyError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except Exception as err:
    log_msg.error("Unexpected error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
    
  
  return log_msg, sn_maxResultCnt, mir3_cntMaxCnt, encryptKey, sn_instance, mir3_url, mir3_api_version, sn_username, sn_password, mir3_username, mir3_password, sn_getGroups, mir3_division
 
def getGroupRecords(log_msg, sn_getGroups, sn_username, sn_password, sn_paginationCnt, sn_maxResultCnt, sn_groupCnt, sn_instance):

  sn_groupAttrs = {}
  
  # we will just get the first record, to get the total count of records....
  #url = '{}/api/now/table/sys_user_grmember?sysparm_query=group.nameSTARTSWITHIT Site Reliability Engineering (SRE)^group.typeLIKE09a29c916f468940608a0302be3ee4ad^group.active=true^user.active=true&sysparm_display_value=all&sysparm_exclude_reference_link=true&sysparm_limit={}&sysparm_offset={}'.format(sn_instance, 1, sn_paginationCnt)
  url = sn_getGroups.format(sn_instance, 1,1)

  resp = requests.get(url, auth=(sn_username, sn_password)) 
  log_msg.debug("HTTP REST call received: %s" % resp.status_code)
  
  if resp.status_code != 200:
    # This means something went wrong.
    log_msg.error("ServiceNow Status [{}] Headers [{}] Error Response: [{}]".format(resp.status_code, resp.headers, resp.text))
    sys.exit(14)
  
  #log the headers
  log_msg.debug("Headers are: [{}]".format(resp.headers))
  totalCnt = int(resp.headers['X-Total-Count'])
  
  log_msg.info("Total Count of Group Members to process in ServiceNow is [{}]".format(totalCnt))
  
  #hard-coding total records for testing...
  #totalCnt = 101
  
  #While loop to get all groups from ServiceNow
  while sn_paginationCnt <= totalCnt:   

    resp = None
    json_objs = None
    groups = None
    group = None
    key = None
    
    log_msg.info("Pagination is now [{}]".format(sn_paginationCnt))
    #url = '{}/api/now/table/sys_user_grmember?sysparm_query=group.nameSTARTSWITHIT Site Reliability Engineering (SRE)^group.typeLIKE09a29c916f468940608a0302be3ee4ad^group.active=true^user.active=true&sysparm_display_value=all&sysparm_exclude_reference_link=true&sysparm_limit={}&sysparm_offset={}'.format(sn_instance, sn_maxResultCnt, sn_paginationCnt)
    url = sn_getGroups.format(sn_instance, sn_maxResultCnt, sn_paginationCnt) 
   
    log_msg.debug("Making REST call: [{}]".format(url))
    
    resp = requests.get(url, auth=(sn_username, sn_password)) 
    log_msg.debug("HTTP REST call received: %s" % resp.status_code)
    
    if resp.status_code != 200:
      # This means something went wrong.
      log_msg.error("ServiceNow Status [{}] Headers [{}] Error Response: [{}]".format(resp.status_code, resp.headers, resp.text))
      sys.exit(15)
     
    json_objs=resp.json()
    for keyvalue in json_objs.items():
      key, groups = keyvalue[0], keyvalue[1]
    
    #groups will now be all rows returned
    
    for group in groups:
      #counter....
      sn_groupCnt += 1
      
      if sn_groupCnt > totalCnt:
        log_msg.info("Reached are last record....")
        sn_groupCnt = sn_groupCnt -1
        break
      
      sn_userid = ''
      sn_usersysid = ''
      sn_group = ''
      
      log_msg.debug('Working on ServiceNow group [{}]'.format(group))
      #process the record 
      sn_user, sn_usersysid, sn_group = getSNowGroupData(log_msg, group)
      skipFlag = False
      
      if sn_user and sn_usersysid and sn_group:
        #update sn_groupAttrs
        if sn_group in sn_groupAttrs:
          #update the existing one...
          sn_groupAttrs[sn_group].update({ sn_user : sn_usersysid })
          log_msg.debug("Updating existing group: [{}]".format(sn_group))
        else:
          sn_groupAttrs[sn_group] = { sn_user : sn_usersysid }
          log_msg.debug("Creating new group: [{}]".format(sn_group))
      else:
        #log_msg.warning("invalid data for this record...")
        log_msg.warning("Could not find data needed in MIR3 for group [{}]".format(group['group']['display_value']))

    #last thing is to increment counter
    sn_paginationCnt += sn_maxResultCnt

  return sn_groupAttrs, sn_groupCnt
      
  
def main():

  #counters
  updateGroupCnt = 0
  insertGroupCnt = 0
  removeGroupCnt = 0
  skipGroupCnt = 0
  sn_recordCnt = 0
  sn_paginationCnt = 0
  noactionGroupCnt = 0
  sn_groupCnt = 0
  
  
  #setup the script
  log_msg, sn_maxResultCnt, mir3_cntMaxCnt, encryptKey, sn_instance, mir3_url, mir3_api_version, sn_username, sn_password, mir3_username, mir3_password, sn_getGroups, mir3_division = initSetup(sys.argv)
    
  try:
    
    
    #call MIR3  MBK Need a Work around for this....
    mir3_contacts = callMIR3(log_msg, mir3_url, mir3_cntMaxCnt, mir3_username, mir3_password, mir3_api_version)
    
    '''
    cntjson = json.dumps(mir3_contacts)
    f = open('D:/temp\grpsysid.json', 'w')
    f.write(cntjson)
    f.close()
    
   
    
    #since I have created the json file above.... just read in the file for speed of testing
    with open('D:/temp\grpsysid.json') as f:
      mir3_contacts = json.load(f)
    
    '''
    #now get group data....
    mir3_groupAttrs = getMIR3GroupData(log_msg, mir3_url, mir3_cntMaxCnt, mir3_username, mir3_password, mir3_api_version)  
    log_msg.debug("Group data is [{}]".format(mir3_groupAttrs))

    '''
    grpjson = json.dumps(mir3_groupAttrs)
    f = open('D:/temp\mir3grpattrs.json', 'w')
    f.write(grpjson)
    f.close()
    
    
    with open('D:/temp\mir3grpattrs.json') as f:
      mir3_groupAttrs = json.load(f)   
    '''      
    
    #call get groups from ServiceNow..
    sn_groupAttrs, sn_groupCnt = getGroupRecords(log_msg, sn_getGroups, sn_username, sn_password, sn_paginationCnt, sn_maxResultCnt, sn_groupCnt, sn_instance)
    log_msg.debug("Returned with Group Count of [{}]".format(sn_groupCnt))
    
    '''
    #now lets write the groups file...
    grpjson = json.dumps(sn_groupAttrs)
    f = open('D:/temp\sn_grp_recs.json', 'w')
    f.write(grpjson)
    f.close()
    
    
    with open('D:/temp\sn_grp_recs.json') as f:
      sn_groupAttrs = json.load(f)
    '''
    
    log_msg.info("Final count of groups members processed is: [{}] Total size of Group Dictionary is [{}]".format(sn_groupCnt, len(sn_groupAttrs)))    
    log_msg.debug("Final Groups defined in SNOW as dictionary is: [{}]".format(sn_groupAttrs))

    #need a loop for each group returned from service now to see if exists in MIR3 
    for sn_group in sn_groupAttrs:
      log_msg.debug("Working on dictionary group [{}]".format(sn_group))  
      sn_recordCnt += 1
      
      action = checkMIR3Group(log_msg, mir3_url, mir3_groupAttrs, mir3_contacts, sn_group, sn_groupAttrs[sn_group], mir3_username, mir3_password, mir3_api_version, mir3_division)
      if action is None:
        log_msg.info("No action needed for group [{}]".format(sn_group))
        noactionGroupCnt += 1
      elif action == 'insert':
        log_msg.info("Insert needed for group [{}]".format(sn_group))
        insertMIR3Group(log_msg, mir3_url, mir3_contacts, sn_group, sn_groupAttrs[sn_group], mir3_username, mir3_password, mir3_api_version, mir3_division)
        insertGroupCnt += 1
      elif action == 'update':
        log_msg.info("Update needed for group [{}]".format(sn_group))
        updateMIR3Group(log_msg, mir3_url, mir3_contacts, sn_group, sn_groupAttrs[sn_group], mir3_username, mir3_password, mir3_api_version, mir3_division)
        updateGroupCnt += 1  
      else:
        log_msg.warning("UNKNOWN action for group [{}]".format(sn_group))
        skipGroupCnt += 1
  
    #MBK need to do remove groups still....
    removeGroupCnt = determineMIR3GroupRemoval(log_msg, mir3_groupAttrs, sn_groupAttrs, mir3_url, mir3_username, mir3_password, mir3_api_version,removeGroupCnt, mir3_division)
    
  except OSError as err:
    log_msg.error("OS error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except ValueError as err:
    log_msg.error("VALUE error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except KeyboardInterrupt:
    log_msg.error('You cancelled the operation.')
    log_msg.error(traceback.format_exc())
    raise
  except IOError as err:
    log_msg.error("IOError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except EOFError as err:
    log_msg.error("EOFError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except KeyError as err:
    log_msg.error("KeyError error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  except Exception as err:
    log_msg.error("Unexpected error: {0}".format(err))
    log_msg.error(traceback.format_exc())
    raise
  finally:
    log_msg.info("---------------------------------------------------------------------------------------------------------")
    log_msg.info("Counts: Inserts [{}] Updates [{}] Deletes [{}] Skips [{}] No Action [{}] Total Processed [{}]".format(insertGroupCnt, updateGroupCnt, removeGroupCnt, skipGroupCnt, noactionGroupCnt, sn_recordCnt))
    log_msg.info("---------------------------------------------------------------------------------------------------------")

  
  log_msg.info("Completed program successfully")
  sys.exit(0)
   
if __name__ == "__main__":
  main()
