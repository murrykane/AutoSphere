# -*- coding: utf-8 -*-
"""
Created on Fri Oct  2 15:05:45 2020

@author: kparro01
"""
import pandas as pd
import os
import shutil
from datetime import datetime


def updateRxInfo(file):
    # Load EAF File Data
    df_eaf_orig = pd.read_csv(file, sep='\t', dtype=str)

    # Create 2020 BIN / PCN Map
    df_lookup = pd.DataFrame({'CONTRACTID' : ['H0504','H4937','S2468','H5928'],
                              'RXBIN2020' : ['012353','012353','012353','012353'],
                              'RXPCN2020' : ['01920000','01920000','03510000','07800000']
                             })

    # Join EAF Data and Map
    df_eaf = pd.merge(df_eaf_orig, df_lookup, on='CONTRACTID', how='left')

    # Update RXBIN and RXPCN (only for effective date of 2020)
    df_eaf['EFFECTIVEDATEYEAR'] = df_eaf['EFFECTIVEDATE'].astype(str).str[-4:]
    df_eaf['RXBIN'] = df_eaf.apply(lambda x: x['RXBIN2020'] if x['EFFECTIVEDATEYEAR'] == '2020' else x['RXBIN'], axis=1)
    df_eaf['RXPCN'] = df_eaf.apply(lambda x: x['RXPCN2020'] if x['EFFECTIVEDATEYEAR'] == '2020' else x['RXPCN'], axis=1)

    # Drop Unneeded Columns
    df_eaf = df_eaf.drop(['RXBIN2020','RXPCN2020','EFFECTIVEDATEYEAR'],axis=1)

    # Rename column to original
    df_eaf = df_eaf.rename(columns = {'PCPPROVIDERID.1' : 'PCPPROVIDERID'})

    # Save File
    df_eaf.to_csv(file,index=False,sep='\t')
    
    
def main():
    header = '------------------------------------------------------------------------------------------------------'
    eaf_file_path = '//bsc/FACP02/Core/Facets/RIS/Output/MAM/EAF/tidaltransit/'
    eaf_archive_path = '//bsc/FACP02/Core/Facets/RIS/Output/MAM/EAF/Archive_OriginalEAF/'
    
    # Set Archive Time
    archive_time = datetime.now().strftime('%Y%m%d.%H%M%S')

    # Get EAF Files
    print('Searching for EAF files in [{}]'.format(eaf_file_path))
    print('')
    files = os.listdir(eaf_file_path)
    files = [f for f in files if f.startswith('EAF_') and f.endswith('.txt')]
    
    # Iterate Through Files and Process
    if len(files) > 0:
        for file in files:
            print(header)
            print('Working on {}...'.format(file))
            
            # Set Fully Qualified Names
            eaf_file = eaf_file_path + file
            archive_file = eaf_archive_path + archive_time + '_' + file

            # Archive a Copy
            print('Archiving {} as [{}]...'.format(file,archive_file))
            shutil.copy(eaf_file,archive_file)

            # Update EAF File RX Info
            print('Updating RX BIN and PCN data for {}...'.format(file))
            updateRxInfo(eaf_file)
            print(header)
            print('')
    else:
        print('No EAF files found!')
            
if __name__ == '__main__':
    main()