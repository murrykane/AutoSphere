import pickle
from java.lang import System

class apmVariables:
    def __init__(self):
        self.Cellname = AdminControl.getCell()
        self.dmgrNode = AdminControl.getNode()
        self._userSysPath = System.getProperty("user.install.root")
        self._wasSysPath = System.getProperty("was.install.root")
        self.port = AdminControl.getPort()
        self.Type = AdminControl.getType()

    def gatherInfo(self, HashLib1={}):
        HashLib1["cell"] = self.Cellname
        HashLib1["DmgrNode"] = self.dmgrNode
        HashLib1["userPath"] = self._userSysPath
        HashLib1["wasPath"] = self._wasSysPath
        HashLib1["dmPort"] = self.port
        HashLib1["connType"] = self.Type
        print "[Dictionary created] ",HashLib1
        FILE = open("/tmp/HashLib1.txt","wb")
        pickle.dump(HashLib1, FILE)
        FILE.close() 
        

if __name__ == "__main__":
    wApm = apmVariables()
    wApm.gatherInfo()

         
