import pickle
import sys

def unvealNode(MNode):
        contain = {}
        hostname = None
        info = None
        servername = None
        serverID = AdminConfig.getid("/Node:%s/Server:/" % MNode).splitlines()
        nodeID = AdminConfig.getid("/Node:%s" % MNode)
        for srvAsItem in serverID:
            # discard nodeagent string (Incase)
            if srvAsItem.find("nodeagent") == -1:
                srvVer = srvAsItem
        info = AdminConfig.showAttribute(srvVer, 'serverType') #servertype
        
        hostname = AdminConfig.showAttribute(nodeID, "hostName") #hostName
        try:
            nodeBean = AdminConfig.getObjectName(srvVer)
            if nodeBean == '':
                SRVname = AdminConfig.showAttribute(srvVer, 'name') #servername
            else:
                SRVname = AdminControl.getAttribute(nodeBean, 'name') #servername
        except:
            SRVname = AdminConfig.showAttribute(srvVer, 'name') #servername
        
        contain["hostName"] = hostname
        contain["Info"] = info
        contain["ServerName"] = SRVname
        print "[Dictionary returned] ",contain
        hs =  open("/tmp/HashLib2.txt","w")
        pickle.dump(contain, hs)
        hs.close()
        

if __name__=="__main__":
    if len(sys.argv) == 1:
        theNode = sys.argv[0]
    else:
        print "Usage: wsadmin_unveal.py [args#1]"
        print "argument(1) required [Node name]"
        print "invoke by wsadmin.sh"
        sys.exit(0)
    # STARTS
    unvealNode(theNode)
#----------------------------------

