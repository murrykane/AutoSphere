#--------------------------------------------------
# Name: apmEngine.py
# Role: Contain child class that inherent attributes
#       from its parent class. The workhorse of this package.
# Author: Jeffrey Apiado (IT_NPO_WEB_TEAM)
#---------------------------------------------------
import ConfigParser
import apmLIB as lib
import os, pickle, sys 
#---------------------------------------------------
class Engine(lib.UTILITY, lib.SOURCE, lib.APMAUTH):
    def __init__(self):
        self.scrtpath = os.path.dirname(os.path.abspath(__file__))
        self.parse = ConfigParser.SafeConfigParser()
        self.parse.read("apmConfig.ini")
        lib.UTILITY.__init__(self, self.parse)
        self.sproc = lib.SOURCE()
        self.agentInstallFN = "/tmp/custom_silent_install.txt"
        self.wimResponsefile = "/tmp/wimresponse_config.txt"
        self.environ = self.sproc.verifyEnvToRun()

    def parseEng(self):
        selection = lib.UTILITY.apmConfigSelect(self)
        opt_D = lib.UTILITY.DmgrAgent(self)
        opt_W = lib.UTILITY.WebAgent(self)
        opt_A = lib.UTILITY.AppAgent(self)
        dmgr = [select for select in selection if select in opt_D]
        websrv = [select for select in selection if select in opt_W]
        appsrv = [select for select in selection if select in opt_A]
        return (dmgr, websrv, appsrv)
    
    def parseReq(self):
        shell = lib.UTILITY.wsadminPath(self)
        variable = lib.UTILITY.wsadminVar(self)
        allnode = lib.UTILITY.wsadminNode(self)
        unveal = lib.UTILITY.wsadminVeal(self)
        return (shell, variable, allnode, unveal)


    def runWSAdminVariable(self, shell, var):
        (adm, pwd) = lib.UTILITY.credentialDefault(self)
	if self.environ:
            init_adm = adm[0]
            init_pwd = pwd[0]
        else:
            init_adm = adm[1]
            init_pwd = pwd[1]

        self.admin = init_adm
        self.pasword = init_pwd

        path = self.scrtpath + var
        command = "{0} -lang jython -f {1} -user {2} -password {3}".format(shell, path, self.admin, self.pasword)
        print command
        self.sproc.simpleProc(command)
        result = self.sproc.DEserialized("/tmp/HashLib1.txt")
        return result

    def getCredentials(self, cellname, upath):
        sdirname = upath + "/config/cells/" + cellname + "/"
        lib.APMAUTH.__init__(self, sdirname)
        sITEM = lib.APMAUTH.searchEng(self)
        if sITEM != "":
            xmlAdminId, xmlBindPasword = lib.APMAUTH.search_LookUp(self, sITEM)
            if xmlAdminId == "default" or len(xmlAdminId) < 10:
                print "[Used default admin id]"
                defAdmin = self.admin
            else:
                print "[Assigned]"
                defAdmin = xmlAdminId[1:-1]
            # - - - - - - - - - - - - - - - - 
            if xmlBindPasword == "default" or len(xmlBindPasword) < 10:
                print "[Used default admin pwd]"
                defPwd = self.pasword
            else:
                print "[Decrypt]"
                defPwd = lib.APMAUTH.decrypt(self, xmlBindPasword)
        else:
            print "[used default credentials from .ini file]"
            defAdmin = self.admin
            defPwd = self.pasword

        #------------------------
        self.admin = defAdmin
        self.pasword = defPwd
        # -----------------------
        self.CELL = cellname
        print "======================="
        print "CELL: ",self.CELL
        print "ADMINID: ",self.admin
        print "ADMINPwd: ",self.pasword
        print "========================"

    def environPrep(self, userPath):
        xtart = 1
        prof, apname = self.sproc.getProfile(userPath)
        tarfile = lib.UTILITY.getTarfilename(self)
        self.tarfile = tarfile
        print self.tarfile
        extrloc = lib.UTILITY.getAPMshell(self)
        self.extrloc = extrloc
        print self.extrloc
        if not self.environ:
            dirPath = "/apps/%s/apm/agent" % apname
        else:
            dirPath = "/opt/IBM/WebSphere/apm/agent" 
        print dirPath
        fpath = "/tmp/{0}".format(self.tarfile)
        if os.path.isfile(fpath):
            r = self.sproc.chkDirExists(dirPath)
            if r == "Created":
                print "[new directory created] > %s" % dirPath
            s = self.sproc.chkDirExists("/tmp/APM")
            if s == "Created":
               print "[new directory created] > /tmp/APM"
            if os.path.isfile(extrloc):
                xtart = 0
        else:
           print "[IPM_APM TAR FILES need to be copied to /tmp directory before commencing]"
           print "                [Terminate script process]                               " 
           sys.exit(0)

        if xtart:
            self.xtractTar()
            if os.path.isfile(extrloc) == False:
                return False
        return True
        #-----------------------------------------------------
    def xtractTar(self):
        thiscmd = "tar -pxvf /tmp/%s -C /tmp/APM" % self.tarfile
        self.sproc.simpleProc(thiscmd)

    def runWSUnveal(self, shell, unveal, node):
        path = self.scrtpath + unveal
        command = "{0} -lang jython -f {1} {2} -user {3} -password {4}".format(shell, path, node, self.admin, self.pasword)
        print command
        self.sproc.simpleProc(command)
        result = self.sproc.DEserialized("/tmp/HashLib2.txt")
        return result

    def runWSAdminAllnode(self, shell, alln):
        path = self.scrtpath + alln
        command = "{0} -lang jython -f {1} -user {2} -password {3}".format(shell, path, self.admin, self.pasword)
        print command
        self.sproc.simpleProc(command)
        result = self.sproc.DEserialized("/tmp/HashLib3.txt")
        return result

    def DMGRproc(self, connHost, servName, upath):
        self.userPath = upath
        print "userPath: ",self.userPath
        profile, appname = self.sproc.getProfile(self.userPath)
        self.profile = profile
        self.appname = appname
        print "application name: ",self.appname
        self.servName = servName
        self.connHost = connHost
        self.sproc.DMGRDisplay(self.connHost, self.CELL)
        
    def wimFunction(self, upath, agent="wim"):
        response = self.sproc.checkInstance(self.appname, "wim-agent.sh", self.environ)
        if response == "Install":
            self.sproc.installBUILD(agent, self.appname, self.agentInstallFN, self.environ)
            self.sproc.silentEngine(self.extrloc)
        else:
            print "\t[wim-agent.sh instance found] [%s]" % response
        response = self.sproc.chkwimInstance(self.appname, self.environ)
        if response == "Config":
            self.sproc.wimConfig(self.appname, self.profile, self.admin, self.pasword, self.wimResponsefile, self.environ)
            self.sproc.wimConfigEngine(self.appname, self.connHost, self.environ)

            self.sproc.createSYMLINK(self.appname, self.profile, self.environ, upath)

            cert = lib.UTILITY.getCerts(self)
            if self.environ: # Portal
                 self.sproc.rebuildCerts(cert, upath)
            else:
                self.sproc.verifyCerts(self.appname, self.profile, cert)
            self.sproc.startAgent(self.appname, "wim", self.environ)
        else:
            print "\t[wim agent already configured]"

        #self.sproc.startAgent(self.appname, "wim", self.environ)
        return "WIM"
        
    def httpFunction(self, httpList, shell, wsscript, agent="http_server", frt=0):
        for webnode in httpList:
             data = self.runWSUnveal(shell, wsscript, webnode)
             appn = self.appBuildname(data['hostName'])
             self.sproc.setdisplay(data['hostName'],data['ServerName'],data['Info'], webnode, self.CELL, appn)
             output = self.sproc.sshCheckpoint(data['hostName'])
             if output == "noposs":
                 print "[SSH connection failed to established]"
             else:
                 self.sproc.checkHTTPDstatus(data['hostName'], self.environ)
                 r = self.sproc.checkInstance(appn, 'http_server-agent.sh', self.environ, connectTo=data['hostName'])
                 if r == "Install":
                     self.sproc.setUP(data['hostName'], appn, self.environ)
                     if frt:
                         self.sproc.installBUILD(agent, appn, self.agentInstallFN, self.environ, rt=1)
                     else:
                         self.sproc.installBUILD(agent, appn, self.agentInstallFN, self.environ)
                     self.sproc.Rsync(data['hostName'], fg=0, cfile=self.agentInstallFN)
                     self.sproc.silentEngine(self.extrloc, connectTo=data['hostName'])
                     # ------------- for IHS -----ext=1 start only -------
                     self.sproc.apacheSTOPSTART(data['hostName'], self.environ, "red")
                     # --------------------------------------------------
                     self.sproc.addKhutoHTTPD(appn, data['hostName'], self.environ)
                     # ------------- AGENT -----------------------------
                     self.sproc.startHTTPAgent(appn, "http_server", data['hostName'], self.environ)
                     # ------------- APACHE ------ext=0 stop and start ------- 
                     self.sproc.apacheSTOPSTART(data['hostName'], self.environ, "green")
                     # --------------Don't leave apache down ----------------
                     print "[Verify IHS process [if not running, START it.]"
                     self.sproc.checkHTTPDstatus(data['hostName'], self.environ)
                 else:
                     print "\t[{0} already installed]".format(agent)
        return "WEB"

    def wasFunction(self, wasList, shell, wsscript, port, conntype, waspath, agent="was"):
        for appnode in wasList:
            data = self.runWSUnveal(shell, wsscript, appnode)
            appn = self.appBuildname(data['hostName'])
            self.sproc.setdisplay(data['hostName'],data['ServerName'],data['Info'], appnode, self.CELL, appn)
            output = self.sproc.sshCheckpoint(data['hostName'])
            if output == "noposs": 
                print "[SSH connection failed to established]"
            else:
                r = self.sproc.checkInstance(appn, 'was-agent.sh', self.environ, connectTo=data['hostName'])
                if r == "Install":
                     self.sproc.setUP(data['hostName'], appn, self.environ)
                     self.sproc.installBUILD(agent, appn, self.agentInstallFN, self.environ)
                     self.sproc.Rsync(data['hostName'], fg=0, cfile=self.agentInstallFN)
                     self.sproc.silentEngine(self.extrloc, connectTo=data['hostName'])
                else:
                     print "\t[{0} already installed]".format(agent)
                wcon = self.sproc.yndchome(appn, data['hostName'], self.environ)
                if wcon == "Skip":
                   print "\t[{0} already configured in this App Server]".format(agent)
                else:
                   if not self.environ:
                       hn = data['hostName'] + ".blueshieldcloud.net"
                       defaultSection = [hn, conntype, port, self.admin, self.pasword, "False",  appnode, waspath, self.CELL, appnode]
                   else:
                       hn = data['hostName']
                       #profileName = self.getPortalProfile(data['hostName'])
                       defaultSection = [hn, conntype, port, self.admin, self.pasword, "False",  "wp_profile", waspath, self.CELL, appnode]
                   serverSection = [data['ServerName'], data['ServerName']]
                   self.sproc.wasconfigBuild(defaultSection, serverSection)
                   self.sproc.Rsync(data['hostName'], fg=0, cfile="/tmp/custom_silent_config.txt")
                   self.wasConfigEngine(data['hostName'], appn, wcon, self.environ)   
                   self.sproc.wasRestart(appn, self.environ, connectTo=data['hostName'])
                
        return "WAS"

        
        
        

#-------------------
#eng = Engine()
