import pickle

class allNodes:
    def __init__(self):
        self.anode = AdminTask.listNodes().splitlines()

    def setTYPE(self, HashLib={}):
        applist = []
        weblist = []
        for nodeNAME in self.anode:
            getid = AdminConfig.getid("/Node:%s/Server:/" % nodeNAME).splitlines()
            req = [srv for srv in getid if srv.find("nodeagent") == -1]
            getType = AdminConfig.showAttribute(req[0], 'serverType')
            if getType == "APPLICATION_SERVER":
                applist.append(nodeNAME)
            elif getType == "WEB_SERVER":
                weblist.append(nodeNAME)
        HashLib["web"] = weblist
        HashLib["apps"] = applist 
        tfile = open("/tmp/HashLib3.txt", "wb")
        pickle.dump(HashLib, tfile)
        tfile.close()   

if __name__ == "__main__":
    wall = allNodes()
    wall.setTYPE()

         
