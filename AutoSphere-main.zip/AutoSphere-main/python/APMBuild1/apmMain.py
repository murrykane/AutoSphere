#-------------------------------------------
# Name: apmMain.py
# Role: Main execution script for installing 
#       and configuring the APM agent.
# Author: Jeffrey Apiado (IT_NPO_WEB_TEAM)
#--------------------------------------------
import subf.apmEngine as engage
import os, sys
#--------------------------------------------

def main():
    # Work with selected agent type to installed
    engine = engage.Engine()
    (dmgr, websrv, appsrv) = engine.parseEng()
    (shell, var, alln, unveal) = engine.parseReq()
    inENV = engine.environ # only 0 legacy and 1 rebuild
    if inENV: rpath = shell[0]
    else: rpath = shell[1]
    print "rpath >",rpath
    hashCont = engine.runWSAdminVariable(rpath, var)
    engine.getCredentials(hashCont['cell'],hashCont['userPath'])
    stat = engine.environPrep(hashCont['userPath'])
    if stat is False: 
          print "[Tar_file extraction error][unsuccesfull]"
          print "[Check Tar_File permisssion]"
          sys.exit(0)
    #-----------------------------------------------------------------------------
    # Description: Determine if there is a task for agent installation
    #              in the DMGR.
    #              Also verify if there is a module for defined agent to installed.
    #------------------------------------------------------------------------------

    if dmgr != []:
        print "[INSTALLING AGENT in [dmgr]"
        dmgrAttrib = engine.runWSUnveal(rpath, unveal, hashCont['DmgrNode'])
        print "dmgrAttrib", dmgrAttrib
        engine.DMGRproc(dmgrAttrib['hostName'],dmgrAttrib['ServerName'],hashCont['userPath'])
        #---------------FOR WIM ----------------------------
        lookup = [agent for agent in dmgr if agent == "wim"]
        if lookup != []: 
            testOutput = engine.wimFunction(hashCont['userPath'])
        print "{0} installation and configuration [EXIT]".format(testOutput)
        #---------------ADD HERE ---------------------------

    #------------------------------------------------------------------
    # Description: Get all nodes that managed by the DMGR and sort them
    #               by type 'WEB' or 'APP'.
    #------------------------------------------------------------------
    newDict = engine.runWSAdminAllnode(rpath, alln) 

    #-----------------------------------------------------------------------------
    # Description: Determine if there is a task for agent installation
    #              in the IHS server.
    #              Also verify if there is a module for defined agent to installed.
    #------------------------------------------------------------------------------

    if websrv != []:
        print websrv
        #--------------FOR HTTP_SERVER ---------------------
        lookup = [agent for agent in websrv if agent == "http_server"]
        lookRT = [agent for agent in websrv if agent == "rt"]
        if lookup != [] and newDict['web'] != []:
            if lookRT != []:
                testOutput = engine.httpFunction(newDict['web'], rpath, unveal, frt=1)
            else:
                testOutput = engine.httpFunction(newDict['web'], rpath, unveal)
        print "{0} installation and configuration [EXIT]".format(testOutput)
        #----------------ADD HERE -------------------------------------

    #-----------------------------------------------------------------------------
    # Description: Determine if there is a task for agent installation
    #              in the Portal server.
    #              Also verify if there is a module for defined agent to installed.
    #------------------------------------------------------------------------------

    if appsrv != []:
        print appsrv
        #------------- FOR WAS ------------------------------
        lookup = [agent for agent in appsrv if agent == "was"]
        if lookup != [] and newDict['apps'] != []:
            testOutput = engine.wasFunction(newDict['apps'], rpath, unveal, hashCont['dmPort'], hashCont['connType'], hashCont['wasPath'])
        print "{0} installation and configuration [EXIT]".format(testOutput)
        #----------------ADD HERE -------------------------------------

if __name__ == "__main__":
    main()
