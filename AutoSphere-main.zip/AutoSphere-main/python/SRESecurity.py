#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 03/24/2020 Murry Kane     Initial version - used for configuration files
#                           Strings are always passed into functions and strings are always returned
#_________________________________________________________________________________________________
#

from cryptography.fernet import Fernet

def getSecureKey():
  key = Fernet.generate_key().decode()
  #print(key)
  return key

def encryptStringWithKey(log_msg, theString, key = None):
  if key is None:
    key = getSecureKey()
    key = key.encode()
    #print("key is being generated...")
  else:
    if type(key) is not bytes:
      key = key.encode()
      #print("converted to bytes...")
      
  cipher_suite = Fernet(key)
  ciphered_text = cipher_suite.encrypt(theString.encode())   
  #print(ciphered_text) 
  encrypted_string = ciphered_text.decode()
  return key.decode(),encrypted_string
  
def decryptStringWithKey(log_msg, theString, key):
  if key is not bytes:
    key = key.encode()
  if theString is not bytes:
    theString = theString.encode()
  cipher_suite = Fernet(key)
  unciphered_text = (cipher_suite.decrypt(theString))
  #print(unciphered_text)
  return unciphered_text.decode()


  
  