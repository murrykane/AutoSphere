#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 09/12/2019 Murry Kane     Initial version - This will issue a terminate against 1 Application 
#                           Server within a IBM WebSphere Cluster
#_________________________________________________________________________________________________
#

import shlex, subprocess, sys, platform, ConfigParser, os, log_message, getpass, getopt
from datetime import datetime
from constants import *
from init_websphere import *

def usage():
  print "Usage: %s --appserver=<xyz> (optional)--terminate (optional)--immidiate (optional)--help" % sys.argv[0]
  print "       %s -a=<xyz> (optional)-t (optional)-i (optional)-h" % sys.argv[0]
  print "Example: python %s --appserver=PIMSP01AM01 --terminate" % sys.argv[0]
  print "  The above example will stop the one application server PIMSP01AM01 with terminate option"
  print "  Default for optional flags is --immidiate without terminate"

if os.name != 'nt' and getpass.getuser() != 'websphr':
  print "You must run this as the effective user 'websphr', please try again as that user, exiting!"
  sys.exit(1)

def main():

  try:
    opts, args = getopt.getopt(sys.argv[1:], 'itha:', ['immidiate', 'terminate', 'help', 'appserver='])
  except getopt.GetoptError, err:
    print "exception in GETOPT with [%s]" % err
    usage()
    sys.exit(2)
  
  # defaults.....
  immidiate=True
  terminate=False  
  appserver=''  
  
  for opt, arg in opts:
    if opt in ( '-a', '--appserver'):
      appserver = arg
    elif opt in ('-h', '--help'):
      usage()
      sys.exit(0)
    elif opt in ('-i', '--immidiate'):
      #print "Setting immidiate flag to true"
      immidiate = True
    elif opt in ('-t', '--terminate'):
      #print "Setting terminate flag to true"
      terminate = True
    else:
      usage()
      sys.exit(0)

  if not appserver:
    print "AppServer was NOT passed!!"
    usage()
    sys.exit(4)      
  
  if terminate:
    #set immidiate to false then 
    #print "Since terminate is set, we will set immidiate to false...."
    immidiate = False
  #else:
  #  print "Terminate is false..... with [%s]" % terminate
  
  sleepTimeBetweenServers = 1
  stopWaitTimeoutAppServers = 30
  pathname = os.path.dirname(sys.argv[0])        
  pathdir = os.path.abspath(pathname)
  localhost = platform.node().upper()
  currentscript = os.path.basename(os.path.splitext(__file__)[0])
  localhost = platform.node().upper()
  loglevel = 'DEBUG'
  date_fmt = datetime.now().strftime('%Y%m%d-%H%M')
  LOGFILE = '%s/%s_%s.log' % (LOG_DIR, currentscript, date_fmt)
  ignoreNodeList = ''
  
  log_msg = log_message.get_file_logger(currentscript, loglevel, LOGFILE, currentscript, True)
  log_msg.info("Starting program")
  log_msg.info("ingore node list is %s" % ignoreNodeList)
  ignoreNodeList = "/".join(ignoreNodeList)
  log_msg.debug("ignore list as string is: %s" % ignoreNodeList)
  if len(ignoreNodeList) == 0:
    ignoreNodeList = '/'
    log_msg.debug("ignore node modified due to empty, list as string is: %s" % ignoreNodeList)
  
  log_msg.info("Flags for stop application server [%s] are immidiate=[%i] TERMINATE [%i]" % (appserver, immidiate, terminate))
    
  # use manageprofiles.sh to get the WebSphere profiles on this server
  if getProfiles(profilesFile, log_msg):
    log_msg.info("Successfully got profiles for server")
  else:
    log_msg.error("ERROR: We could not get the profiles for this server, exiting!")
    sys.exit(14)
  
  #get the DMGR from the output above....
  xmlStr = ''
  aStr = ''
  temp = open(profilesFile,'r').readlines()
  for line in temp:   # there should only be 1 line....
    aStr = line.strip('\n\r[]') 
  log_msg.info("List of Profiles on server is [%s]" % aStr)
  if not aStr:
    #could not determine profiles on this system....
    log_msg.error("ERROR: We could not determine the WebSphere Profiles on this server, exiting!")
    sys.exit(15)
  
  #server may have one or more profiles, loop through them....
  profileList = aStr.split()
  for profile in profileList:
    if re.search('dmgr', profile, re.IGNORECASE):
      log_msg.info("Profile [%s] is a DMGR" % profile)
      startStr = " ".join(re.findall("[a-zA-Z]+", aStr)).split()[0]
      startNum = " ".join(re.findall("[0-9]+", aStr)).split()[0]
      xmlStr = '%s%s' % (startStr, startNum)
      if len(xmlStr) < 5:
        log_msg.warn("The XML Search String [%s] is very small, which may lead to bad results!" % xmlStr)
          
  if not xmlStr:    
    log_msg.error("We could not determine if this server is a DMGR, exiting!")
    sys.exit(15)
    
  #xmlStr = serverStatusQuery('Starting tool with the ', 0, log_msg)
  log_msg.info("XML String to find files with is [%s]" % xmlStr)
  xmlString = "%s*.xml" % xmlStr
  jythonscript = '%s/%s.py' % (JYTHON_DIR, currentscript)
  
  XMLFile, username, encrypted_password, password, wsadminpath = getXMLFile(xmlString, log_msg) 
  #wsadminfile = '%s/bin/wsadmin.sh' % wsadminpath 
  wsadminfile = os.path.join(wsadminpath + os.sep, 'bin' + os.sep, 'wsadmin' + ext_name).replace("\\", "/")
  
  # lets validate all variables are defined
  #------------------------------------------
  if os.path.isfile(wsadminfile):
    log_msg.debug("Found the WSAdmin.sh with: [%s]" % wsadminfile)
  else:
    log_msg.error("Unable to find the WSAdmin script with: [%s], exiting!" % wsadminfile)
    sys.exit(10)    
  if os.path.isfile(jythonscript):
    log_msg.debug("Found the python script with: [%s]" % jythonscript)
  else:
    log_msg.error("Unable to find the jython script with: [%s], exiting!" % jythonscript)
    sys.exit(10)
  if os.path.isfile(XMLFile):
    log_msg.debug("Found the XML Property File with: [%s]" % XMLFile)
  else:
    log_msg.error("Unable to find the XML Property File with: [%s], exiting!" % XMLFile)
    sys.exit(10)
  if username:
    log_msg.debug("Found the user name to use with WSAdmin script with: [%s]" % username)
  else:
    log_msg.error("Unable to find the user name for WSAdmin script with: [%s], exiting!" % username)
    sys.exit(10)
  if encrypted_password:
    log_msg.debug("Obtained the encrypted password for WSAdmin script with: [%s]" % encrypted_password)
  else:
    log_msg.error("Unable to find the encrypted password for WSAdmin script with: [%s], exiting!" % encrypted_password)
    sys.exit(10)
  if password:
    log_msg.debug("Obtained the password for WSAdmin script with: [%s]" % 'XXXXXXXXXX')
  else:
    log_msg.error("Unable to find the password for WSAdmin script with: [%s], exiting!" % password)
    sys.exit(10) 
  ################################################################################################
  # lets check if IBM security is set on this environment.....
  #
  IBMSecuritySet = False
  IBMSecuritySet = securityEnabledCheck(log_msg, wsadminpath)
  if IBMSecuritySet:
    if serverStatusWithNoPass(serverStatusOutFile, log_msg, wsadminpath):
      log_msg.debug("Successfully created the server status output file")
    else:
      log_msg.error("Could not determine status of the DMGR, exiting!")
      sys.exit(99) 
  else:      
    #make sure we are on a running DMGR to proceed....
    if serverStatusWithPass(serverStatusOutFile, username, password, log_msg, wsadminpath):
      log_msg.debug("Successfully created the server status output file")
    else:
      log_msg.error("Could not determine status of the DMGR, exiting!")
      sys.exit(99)
  
  #lets read the serverStatus output now....
  dFlag = False
  sfile = file(serverStatusOutFile)
  for line in sfile:
    if 'The Deployment Manager' in line:
      log_msg.debug("Found the following line in the ServerStatus output: [%s]" % line.strip())
      dFlag = True
      #get the last value to check if its 'STARTED'
      if line.rsplit(None, 1)[-1] == 'STARTED':
        log_msg.info("DMGR is running on this server, continue with script.....")
      else:
        log_msg.error("DMGR is NOT running, we can not continue with this script, please start the DMGR and run again!")
        sys.exit(45)
  # make sure its a DMGR
  if not dFlag:
    log_msg.error("This is not a DMGR server, and we can not run on this server, exiting!")
    sys.exit(55)

  if IBMSecuritySet:
    logging_cmd = '%s -lang jython -conntype SOAP -javaoption "-Dpython.path=%s" -f %s %s %s %s %i %i' % ( wsadminfile, PYTHONPATH, jythonscript, ignoreNodeList, appserver, stopWaitTimeoutAppServers, immidiate, terminate )
    cmd = '%s -lang jython -conntype SOAP -javaoption "-Dpython.path=%s" -f %s %s %s %s %i %i' % ( wsadminfile, PYTHONPATH, jythonscript, ignoreNodeList, appserver, stopWaitTimeoutAppServers, immidiate, terminate )
  else:
    logging_cmd = '%s -lang jython -conntype SOAP -user %s -password %s -javaoption "-Dpython.path=%s" -f %s %s %s %s %i %i' % ( wsadminfile, username, 'XXXXXXXXX', PYTHONPATH, jythonscript, ignoreNodeList, appserver, stopWaitTimeoutAppServers, immidiate, terminate )
    cmd = '%s -lang jython -conntype SOAP -user %s -password %s -javaoption "-Dpython.path=%s" -f %s %s %s %s %i %i' % ( wsadminfile, username, password, PYTHONPATH, jythonscript, ignoreNodeList, appserver, stopWaitTimeoutAppServers, immidiate, terminate )
  log_msg.info("Issueing: [%s]" % logging_cmd)
  
  if os.name != 'nt':
    args = shlex.split(cmd)
  else:
    args = cmd
    #log_msg.debug("Windows special with ARGS: [%s]" % args)  
    
  process = subprocess.Popen(args,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
  
  # Poll process for new output until finished
  while True:
    nextline = process.stdout.readline().rstrip()
    if nextline == '' and process.poll() is not None:
      break
    if nextline and (not nextline.isspace()):
      log_msg.info(nextline)
      sys.stdout.flush()
    
  output, error = process.communicate()
  exit_code = process.wait()

  if exit_code > 0:
    #print "ERROR: [%s], exiting" % error
    if output:
      log_msg.error("Received STDOUT: %s" % output)
    if error:
      #lets see if its just the 'ulimit:' open files error received all the time
      for line in error.split(os.linesep):
        if line.find('ulimit:') > 0:
          log_msg.debug("Ignoring the ULIMIT: error from stderr...")
        else:
          log_msg.error(line)
    log_msg.error("ERROR: Exiting program!")
    sys.exit(exit_code)
  else:
    if output:
      log_msg.info("Received STDOUT: %s" % output)
    log_msg.info("Success on executing [%s]" % jythonscript)

  log_msg.info("Completed program successfully")
    
if __name__ == "__main__":
  main()

