#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 05/10/2017 Murry Kane     Initial version
# 12/04/2017 Murry Kane     Wrote to work on Windows
# 03/18/2018 Murry Kane     Added logic to call new method to deterine if username/password needs
#                           to be sent to all IBM scripts based on IBM Security Enabled or not
#
#_________________________________________________________________________________________________
#

import shlex, subprocess, sys, platform, ConfigParser, os, log_message, getpass, getopt, ast
from datetime import datetime
from constants import *
from init_websphere import *


def usage():
  print "Usage: %s --newcertsList=<value> --oldcertalias=<value> --CellDefaultTrustStore=<value> --CustomKeyStore=<value> --personalcertlocation=<value> --keyfilepass=<value> --certificateAliasFromKeyFile=<value> --removePersonalCertAlias=<value> --certificateAlias=<value> --scpkeystorelocation=<value> --exchangekeystores=<value> --localCustomKeyStoreFile=<value) --ClientDefaultTrustStore=<value>" % sys.argv[0]
  print 'Example: %s --newcertsList=\'("BSCISSUECA2","/home/websphr/pam/BSCISSUECA2.cer"),("BSCROOTCA2","/home/websphr/pam/BSCROOTCA2.cer")\'  --oldcertalias=\'["bscissue01ca","bscrootca", "google-internet-authority", "www.google.com", "www3.onlinefinancialdocs.com", "edhc01wex02", "california.prs.vitals.com", "bscpolicyca"]\'  --CellDefaultTrustStore=CellDefaultTrustStore  --CustomKeyStore=WEBN208Keystore  --personalcertlocation=/home/websphr/npe-web-dp-ssl.bsc.bscal.com.pfx  --keyfilepass=Webops123  --certificateAliasFromKeyFile=npe-web-dp-ssl.bsc.bscal.com  --removePersonalCertAlias=webp02.basc.bscal.com.pfx  --certificateAlias=npe-web-dp-ssl.bsc.bscal.com  --scpkeystorelocation=/apps/WEBN208-common/certs  --exchangekeystores=\'["CellDefaultTrustStore", "WEBN08Keystore"]\'  --localCustomKeyStoreFile=/apps/WEBN208-common/certs/WEBN208Keystore.p12 --ClientDefaultTrustStore=ClientDefaultTrustStore' % sys.argv[0]

if os.name != 'nt' and getpass.getuser() != 'websphr':
  print "You must run this as the effective user 'websphr', please try again as that user, exiting!"
  sys.exit(1)
  
def main():

  #newcertsList=('BSCISSUECA2','/home/websphr/pam/BSCISSUECA2.cer'),('BSCROOTCA2','/home/websphr/pam/BSCROOTCA2.cer')
  #oldcertalias=['bscissue01ca','bscrootca', 'google-internet-authority', 'www.google.com', 'www3.onlinefinancialdocs.com', 'edhc01wex02', 'california.prs.vitals.com', 'bscpolicyca']
  #CellDefaultTrustStore=CellDefaultTrustStore
  #CustomKeyStore=WEBN208Keystore
  #personalcertlocation=/home/websphr/npe-web-dp-ssl.bsc.bscal.com.pfx
  #keyfilepass=Webops123
  #certificateAliasFromKeyFile=npe-web-dp-ssl.bsc.bscal.com
  #removePersonalCertAlias=webp02.basc.bscal.com.pfx
  #certificateAlias=npe-web-dp-ssl.bsc.bscal.com
  #scpkeystorelocation=/apps/WEBN208-common/certs
  #exchangekeystores=['CellDefaultTrustStore','WEBN08Keystore']
  #localCustomKeyStoreFile=/apps/WEBN208-common/certs/WEBN208Keystore.p12
  # ClientDefaultTrustStore   # needed for the nodes to for retriveSigners.sh
  
  newcertsList = ''
  oldcertalias = ''
  CellDefaultTrustStore = ''
  CustomKeyStore = ''
  personalcertlocation = ''
  keyfilepass = ''
  certificateAliasFromKeyFile = ''
  removePersonalCertAlias = ''
  certificateAlias = ''
  scpkeystorelocation = ''
  exchangekeystores = '' 
  localCustomKeyStoreFile = ''
  ClientDefaultTrustStore = ''

  #NodeDefaultSSLSettings = ''
  #CellDefaultTrustStore = ''
  #CustomKeyStore = ''
  #certificateAliasFromKeyFile = ''
  #certificateAlias = ''
  
  try:
    opts, args = getopt.getopt(sys.argv[1:], 'n:o:d:c:l:k:f:r:a:s:x:p:z', ['newcertsList=', 'oldcertalias=', 'CellDefaultTrustStore=', 'CustomKeyStore=', 'personalcertlocation=', 'keyfilepass=', 'certificateAliasFromKeyFile=', 'removePersonalCertAlias=','certificateAlias=','scpkeystorelocation=','exchangekeystores=','localCustomKeyStoreFile=', 'ClientDefaultTrustStore='])
  except getopt.GetoptError, err:
    print "exception in GETOPT with [%s]" % err
    usage()
    sys.exit(2)

  for opt, arg in opts:
    if opt in ( '-n', '--newcertsList'):
      newcertsList = arg
    elif opt in ('-o', '--oldcertalias'):
      oldcertalias = arg
    elif opt in ('-d', '--CellDefaultTrustStore'):
      CellDefaultTrustStore = arg
    elif opt in ('-c', '--CustomKeyStore'):
      CustomKeyStore = arg
    elif opt in ('-l', '--personalcertlocation'):
      personalcertlocation = arg
    elif opt in ('-k', '--keyfilepass'):
      keyfilepass = arg
    elif opt in ('-f', '--certificateAliasFromKeyFile'):
      certificateAliasFromKeyFile = arg
    elif opt in ('-r', '--removePersonalCertAlias'):
      removePersonalCertAlias = arg
    elif opt in ('-a', '--certificateAlias'):
      certificateAlias = arg
    elif opt in ('-s', '--scpkeystorelocation'):
      scpkeystorelocation = arg
    elif opt in ('-x', '--exchangekeystores'):
      exchangekeystores = arg
    elif opt in ('-p', '--localCustomKeyStoreFile'):
      localCustomKeyStoreFile = arg    
    elif opt in ('-z', '--ClientDefaultTrustStore'):
      ClientDefaultTrustStore = arg    
    else:
      usage
      sys.exit(3)
  
  #validate args passed in are defined...
  if not newcertsList:
    print "newcertsList NOT passed"
    usage()
    sys.exit(4)
  if not oldcertalias:
    print "oldcertalias NOT passed"
    usage()
    sys.exit(5)
  if not CellDefaultTrustStore:
    print "CellDefaultTrustStore NOT passed"
    usage()
    sys.exit(6)
  if not CustomKeyStore:
    print "CustomKeyStore NOT passed"
    usage()
    sys.exit(7)
  if not personalcertlocation:
    print "personalcertlocation NOT passed"
    usage()
  if not keyfilepass:
    print "keyfilepass NOT passed"
    usage()
    sys.exit(8)
  if not certificateAliasFromKeyFile:
    print "certificateAliasFromKeyFile NOT passed"
    usage()
    sys.exit(9)
  if not removePersonalCertAlias:
    print "removePersonalCertAlias NOT passed"
    usage()
    sys.exit(10)
  if not certificateAlias:
    print "certificateAlias NOT passed"
    usage()
    sys.exit(11)
  if not scpkeystorelocation:
    print "scpkeystorelocation NOT passed"
    usage()
  if not exchangekeystores:
    print "exchangekeystores NOT passed"
    usage()
    sys.exit(12)
  if not localCustomKeyStoreFile:
    print "localCustomKeyStoreFile NOT passed"
    usage()
    sys.exit(13)
  if not ClientDefaultTrustStore:
    print "ClientDefaultTrustStore NOT passed"
    usage()
    sys.exit(14)

  #print "node %s cell %s keystore %s alias from file %s alias %s" % ( NodeDefaultSSLSettings, CellDefaultTrustStore, CustomKeyStore, certificateAliasFromKeyFile, certificateAlias )
  
  #sleepTimeBetweenServers = 1
  #stopWaitTimeoutAppServers = 300
  pathname = os.path.dirname(sys.argv[0])        
  pathdir = os.path.abspath(pathname)
  localhost = platform.node().upper()
  currentscript = os.path.basename(os.path.splitext(__file__)[0])
  localhost = platform.node().upper()
  loglevel = 'DEBUG'
  date_fmt = datetime.now().strftime('%Y%m%d-%H%M')
  LOGFILE = '%s/%s_%s.log' % (LOG_DIR, currentscript, date_fmt)
  ignoreNodeList = ''
    
  log_msg = log_message.get_file_logger(currentscript, loglevel, LOGFILE, currentscript, True)
  log_msg.info("Starting program")
  #log_msg.info("node [%s] cell [%s] keystore [%s] alias from file [%s] alias [%s]" % ( NodeDefaultSSLSettings, CellDefaultTrustStore, CustomKeyStore, certificateAliasFromKeyFile, certificateAlias ))
  log_msg.info("ingore node list is %s" % ignoreNodeList)
  ignoreNodeList = "/".join(ignoreNodeList)
  log_msg.debug("ignore list as string is: %s" % ignoreNodeList)
  if len(ignoreNodeList) == 0:
    ignoreNodeList = '/'
    log_msg.debug("ignore node modified due to empty, list as string is: %s" % ignoreNodeList)
  thenodelist = ''   
  

  #lets eval it....
  newcertsList = ast.literal_eval(newcertsList)
  exchangekeystores = ast.literal_eval(exchangekeystores)
  oldcertalias = ast.literal_eval(oldcertalias)

  log_msg.info("Old Singer Certificates list is %s" % oldcertalias)
  oldcertalias = "/".join(oldcertalias)
  log_msg.debug("Old Signer Certificates list as string is: %s" % oldcertalias)
  
  if len(oldcertalias) == 0:
    #oldcertalias = '/'
    log_msg.error("There is no old singer certificates to remove, please validate and run again, exiting!")
    sys.exit(6)
    
  if len(newcertsList) == 0:
    log_msg.error("ERROR: New CERT list is empty, exiting!" % newcertsList)
    sys.exit(5)
  else:
    if len(newcertsList) > 2:
      log_msg.error("ERROR: New CERT list [%s] is greator than 2 with [%s], exiting!" % (newcertsList, len(newcertsList)))
      sys.exit(5)

  counter=0
  for args in newcertsList:
    if counter==0:
      newcert1 = args[0]
      newcertPath1 = args[1]
    else:
      newcert2 = args[0]
      newcertPath2 = args[1]
    counter=counter+1

  log_msg.debug("New Cert 1 [%s] location [%s] Cert 2 [%s] location [%s]" % (newcert1, newcertPath1, newcert2, newcertPath2))

  log_msg.info("Exchange Signers list is %s" % exchangekeystores)
  exchangekeystores = "/".join(exchangekeystores)
  log_msg.debug("Exchange Signers list as string is: %s" % exchangekeystores)
  if len(exchangekeystores) == 0:
    exchangekeystores = '/'
    log_msg.debug("Exchange Signers modified due to empty, list as string is: %s" % exchangekeystores)
      
  
  # use manageprofiles.sh to get the WebSphere profiles on this server
  if getProfiles(profilesFile, log_msg):
    log_msg.info("Successfully got profiles for server")
  else:
    log_msg.error("ERROR: We could not get the profiles for this server, exiting!")
    sys.exit(14)
  
  #get the DMGR from the output above....
  xmlStr = ''
  aStr = ''
  temp = open(profilesFile,'r').readlines()
  for line in temp:   # there should only be 1 line....
    aStr = line.strip('\n\r[]') 
  log_msg.info("List of Profiles on server is [%s]" % aStr)
  if not aStr:
    #could not determine profiles on this system....
    log_msg.error("ERROR: We could not determine the WebSphere Profiles on this server, exiting!")
    sys.exit(15)
  
  #server may have one or more profiles, loop through them....
  profileList = aStr.split()
  for profile in profileList:
    if re.search('dmgr', profile, re.IGNORECASE):
      log_msg.info("Profile [%s] is a DMGR" % profile)
      startStr = " ".join(re.findall("[a-zA-Z]+", aStr)).split()[0]
      startNum = " ".join(re.findall("[0-9]+", aStr)).split()[0]
      xmlStr = '%s%s' % (startStr, startNum)
      if len(xmlStr) < 5:
        log_msg.warn("The XML Search String [%s] is very small, which may lead to bad results!" % xmlStr)
      
  if not xmlStr:    
    log_msg.error("We could not determine if this server is a DMGR, exiting!")
    sys.exit(15)
    
  #xmlStr = serverStatusQuery('Starting tool with the ', 0, log_msg)
  log_msg.info("XML String to find files with is [%s]" % xmlStr)
  xmlString = "%s*.xml" % xmlStr
  jythonscript = '%s/%s.py' % (JYTHON_DIR, currentscript)
  
  XMLFile, username, encrypted_password, password, wsadminpath = getXMLFile(xmlString, log_msg) 
  wsadminfile = os.path.join(wsadminpath + os.sep, 'bin' + os.sep, 'wsadmin' + ext_name).replace("\\", "/")
  
  # lets validate all variables are defined
  #------------------------------------------
  if os.path.isfile(wsadminfile):
    log_msg.debug("Found the WSAdmin.sh with: [%s]" % wsadminfile)
  else:
    log_msg.error("Unable to find the WSAdmin script with: [%s], exiting!" % wsadminfile)
    sys.exit(10)    
  if os.path.isfile(jythonscript):
    log_msg.debug("Found the python script with: [%s]" % jythonscript)
  else:
    log_msg.error("Unable to find the jython script with: [%s], exiting!" % jythonscript)
    sys.exit(10)
  if os.path.isfile(XMLFile):
    log_msg.debug("Found the XML Property File with: [%s]" % XMLFile)
  else:
    log_msg.error("Unable to find the XML Property File with: [%s], exiting!" % XMLFile)
    sys.exit(10)
  if username:
    log_msg.debug("Found the user name to use with WSAdmin script with: [%s]" % username)
  else:
    log_msg.error("Unable to find the user name for WSAdmin script with: [%s], exiting!" % username)
    sys.exit(10)
  if encrypted_password:
    log_msg.debug("Obtained the encrypted password for WSAdmin script with: [%s]" % encrypted_password)
  else:
    log_msg.error("Unable to find the encrypted password for WSAdmin script with: [%s], exiting!" % encrypted_password)
    sys.exit(10)
  if password:
    log_msg.debug("Obtained the password for WSAdmin script with: [%s]" % 'XXXXXXXXXX')
  else:
    log_msg.error("Unable to find the password for WSAdmin script with: [%s], exiting!" % password)
    sys.exit(10) 
  ################################################################################################
  
  ################################################################################################
  # lets check if IBM security is set on this environment.....
  #
  IBMSecuritySet = False
  IBMSecuritySet = securityEnabledCheck(log_msg, wsadminpath)
  if IBMSecuritySet:
    if serverStatusWithNoPass(serverStatusOutFile, log_msg, wsadminpath):
      log_msg.debug("Successfully created the server status output file")
    else:
      log_msg.error("Could not determine status of the DMGR, exiting!")
      sys.exit(99) 
  else:      
    #make sure we are on a running DMGR to proceed....
    if serverStatusWithPass(serverStatusOutFile, username, password, log_msg, wsadminpath):
      log_msg.debug("Successfully created the server status output file")
    else:
      log_msg.error("Could not determine status of the DMGR, exiting!")
      sys.exit(99)
  
  #lets read the serverStatus output now....
  dFlag = False
  sfile = file(serverStatusOutFile)
  for line in sfile:
    if 'The Deployment Manager' in line:
      log_msg.debug("Found the following line in the ServerStatus output: [%s]" % line.strip())
      dFlag = True
      #get the last value to check if its 'STARTED'
      if line.rsplit(None, 1)[-1] == 'STARTED':
        log_msg.info("DMGR is running on this server, continue with script.....")
      else:
        log_msg.error("DMGR is NOT running, we can not continue with this script, please start the DMGR and run again!")
        sys.exit(45)
  # make sure its a DMGR
  if not dFlag:
    log_msg.error("This is not a DMGR server, and we can not run on this server, exiting!")
    sys.exit(55)

  result = []  
  # oldcertalias[0], oldcertalias[1], personalcertlocation, certificateAlias, keyfilepass, certificateAliasFromKeyFile, certificateAlias, removePersonalCertAlias, exchangekeystores
  log_msg.debug("wsadminpath %s" % wsadminpath)
  log_msg.debug("username %s" % username)
  #log_msg.debug("pass %s" % password )  
  log_msg.debug("jythonscript %s" % jythonscript)
  log_msg.debug("CellDefaultTrustStore %s" % CellDefaultTrustStore)
  #log_msg.debug("CustomKeyStore %s" % CustomKeyStore)
  log_msg.debug("newcert1 %s" % newcert1 )
  log_msg.debug("newcertPath1 %s" % newcertPath1)
  log_msg.debug("newcert2 %s" % newcert2)
  log_msg.debug("newcertPath2 %s" % newcertPath2)
  log_msg.debug("oldcertalias %s" % oldcertalias)
  #log_msg.debug("oldcertalias[1] %s" % oldcertalias[1])
  log_msg.debug("personalcertlocation %s" % personalcertlocation)
  #log_msg.debug("cetificate alias %s" % certificateAlias)
  #log_msg.debug("keyfilepass %s" % keyfilepass)
  log_msg.debug("certificateAliasFromFile %s" % certificateAliasFromKeyFile)
  log_msg.debug("certificateAlias %s" % certificateAlias)
  log_msg.debug("removePersonalCertAlias %s" % removePersonalCertAlias)
  log_msg.debug("exchangekeystores %s" % exchangekeystores) 
  log_msg.debug("Personal Certificate Custom Keystore %s" % CustomKeyStore)
  log_msg.debug("localCustomKeyStoreFile is %s" % localCustomKeyStoreFile)
  
  if IBMSecuritySet:
    logging_cmd = '%s -lang jython -conntype SOAP -javaoption "-Dpython.path=%s" -f %s %s %s %s %s %s %s %s %s %s %s %s %s %s' % ( wsadminfile, PYTHONPATH, jythonscript, CellDefaultTrustStore, newcert1, newcertPath1, newcert2, newcertPath2, oldcertalias, personalcertlocation, certificateAlias, 'XXXXXXXXX', certificateAliasFromKeyFile, removePersonalCertAlias, exchangekeystores, CustomKeyStore)
    cmd = '%s -lang jython -conntype SOAP -javaoption "-Dpython.path=%s" -f %s %s %s %s %s %s %s %s %s %s %s %s %s %s' % ( wsadminfile, PYTHONPATH, jythonscript, CellDefaultTrustStore, newcert1, newcertPath1, newcert2, newcertPath2, oldcertalias, personalcertlocation, certificateAlias, keyfilepass, certificateAliasFromKeyFile, removePersonalCertAlias, exchangekeystores, CustomKeyStore)
  else:
    logging_cmd = '%s -lang jython -conntype SOAP -user %s -password %s -javaoption "-Dpython.path=%s" -f %s %s %s %s %s %s %s %s %s %s %s %s %s %s' % ( wsadminfile, username, 'XXXXXXXXX', PYTHONPATH, jythonscript, CellDefaultTrustStore, newcert1, newcertPath1, newcert2, newcertPath2, oldcertalias, personalcertlocation, certificateAlias, 'XXXXXXXXX', certificateAliasFromKeyFile, removePersonalCertAlias, exchangekeystores, CustomKeyStore)
    cmd = '%s -lang jython -conntype SOAP -user %s -password %s -javaoption "-Dpython.path=%s" -f %s %s %s %s %s %s %s %s %s %s %s %s %s %s' % ( wsadminfile, username, password, PYTHONPATH, jythonscript, CellDefaultTrustStore, newcert1, newcertPath1, newcert2, newcertPath2, oldcertalias, personalcertlocation, certificateAlias, keyfilepass, certificateAliasFromKeyFile, removePersonalCertAlias, exchangekeystores, CustomKeyStore)
  log_msg.info("Issueing: [%s]" % logging_cmd)
  
  if os.name != 'nt':
    args = shlex.split(cmd)
  else:
    args = cmd
    #log_msg.debug("Windows special with ARGS: [%s]" % args)
  process = subprocess.Popen(args,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
  
  # Poll process for new output until finished
  while True:
    nextline = process.stdout.readline().rstrip()
    if nextline == '' and process.poll() is not None:
      break
    if nextline and (not nextline.isspace()):
      log_msg.info(nextline)
      if 'Nodes to SCP updated P12 file too: ' in nextline:
        key, value = nextline.split('Nodes to SCP updated P12 file too: ')
        result = eval(value.strip())
      sys.stdout.flush()
    
  output, error = process.communicate()
  exit_code = process.wait()

  if exit_code > 0:
    #print "ERROR: [%s], exiting" % error
    if output:
      log_msg.error("Received STDOUT: %s" % output)
    if error:
      #lets see if its just the 'ulimit:' open files error received all the time
      for line in error.split(os.linesep):
        if line.find('ulimit:') > 0:
          log_msg.debug("Ignoring the ULIMIT: error from stderr...")
        else:
          log_msg.error(line)
    log_msg.error("ERROR: Exiting program!")
    sys.exit(exit_code)
  else:
    if output:
      log_msg.info("Received STDOUT: %s" % output)
    log_msg.info("Success on executing [%s]" % jythonscript)

  if os.name == 'nt':
    log_msg.info("_____________________________________________________________________________________________________") 
    log_msg.error("Windows logic HAS NOT BEEN COMPLETED, skipping logic to update web servers and node agents in this cluster!!!!!")
    log_msg.info("_____________________________________________________________________________________________________") 
  else:
    if result.count > 0: 
        for nodename, hostname, binPath, port, dmgrHost in result:
          # ./retrieveSigners.sh WEBN208Keystore ClientDefaultTrustStore -host dm1.webn208 -port 10010 -conntype SOAP -autoAcceptBootstrapSigner
          log_msg.info("_____________________________________________________________________________________________________")
          log_msg.info("NodeName %s HostName %s Path %s Port %s DMGR Host %s Working on SCP..." % (nodename, hostname, binPath, port, dmgrHost))
          ssherror, sshCmd, sshargs, sshprocess, sshoutput = ('','','','','')
          # lets determine if its local host or not
          #nodenameHost = os.popen('nslookup %s' % hostname ).read().splitlines()[4].split("\t")[1].split(".")[0].upper()
          nodenameHost = os.popen('nslookup %s' % hostname ).read().split("Name:")[1].split("\t")[1].split(".")[0].upper()
          if nodenameHost == localhost:
            log_msg.info("Ignoring local host %s" % localhost)
          else:
            sshCmd = 'scp %s %s:%s' % (localCustomKeyStoreFile, hostname, scpkeystorelocation)  
          log_msg.debug("Issueing the following: [%s]" % sshCmd)
          sshexit_code = 0
          sshCmd_logging = ''
          sshargs = shlex.split(sshCmd)
          sshprocess = subprocess.Popen(sshargs,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
          sshoutput, ssherror = sshprocess.communicate()
          sshexit_code = sshprocess.wait()
          if sshexit_code > 0:
            if sshoutput:
              log_msg.error("ERROR OUTPUT: \n[%s]" % sshoutput)
              log_msg.error("ERROR: SCP command received rc: %s error message:(IGNORE ulimit line)\n[%s]" % (sshexit_code, ssherror))
              sys.exit(sshexit_code)
          if sshoutput:
            log_msg.info("Output from SCP on %s is:\n[%s]" % (hostname, sshoutput))
          else:
            log_msg.info("Susccesfully submitted command for %s" % hostname)
          
          # now the retriveSigners command
          if nodenameHost == localhost:
            log_msg.info("Ignoring local host %s" % localhost)
          else:
            sshCmd = 'ssh %s nohup %s/bin/retrieveSigners.sh %s %s -host %s -port %s -conntype SOAP -autoAcceptBootstrapSigner -username %s -password \'%s\' >> %s/logs/retrieveSigners.log 2>&1 & disown' % (hostname, binPath, CustomKeyStore, ClientDefaultTrustStore, dmgrHost, port, username, password, binPath)  
            sshCmd_logging = 'ssh %s nohup %s/bin/retrieveSigners.sh %s %s -host %s -port %s -conntype SOAP -autoAcceptBootstrapSigner -username %s -password \'%s\' >> %s/logs/retrieveSigners.log 2>&1 & disown' % (hostname, binPath, CustomKeyStore, ClientDefaultTrustStore, dmgrHost, port, username, 'XXXXXXXX', binPath)  
          log_msg.debug("Issueing the following: [%s]" % sshCmd_logging)
          sshexit_code = 0
          sshargs = shlex.split(sshCmd)
          sshprocess = subprocess.Popen(sshargs,stdout = subprocess.PIPE, stderr= subprocess.PIPE)
          sshoutput, ssherror = sshprocess.communicate()
          sshexit_code = sshprocess.wait()
          if sshexit_code > 0:
            if sshoutput:
              log_msg.error("ERROR OUTPUT: \n[%s]" % sshoutput)
              log_msg.error("ERROR: SSH command received rc: %s error message:(IGNORE ulimit line)\n[%s]" % (sshexit_code, ssherror))
              sys.exit(sshexit_code)
          if sshoutput:
            log_msg.info("Output from SSH on %s is:\n[%s]" % (hostname, sshoutput))
          else:
            log_msg.info("Susccesfully submitted command for %s" % hostname)
    else:
      log_msg.info("No nodes to do!")
    
    if result.count > 0:
      log_msg.info("_____________________________________________________________________________________________________") 
      
   
  log_msg.info("Completed program successfully")
    
if __name__ == "__main__":
  main()

