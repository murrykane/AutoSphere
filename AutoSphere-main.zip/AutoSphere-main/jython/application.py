import sys, re
import javaos as os
import java.io
import Xparser
import XPathCount
import base, time

#--------------------------------------------------------------
# initialize global websphere classes from the base lib
#--------------------------------------------------------------
base.setAdminRefs((AdminConfig, AdminControl, AdminTask, AdminApp, AdminUtilities))
#global AdminConfig
#global AdminControl
#global AdminApp
#global AdminControl
#global AdminTask

#**************************************************************************
# uninstall target:
# 1) checks for the existance of the application
# 2) uninstalls application
#**************************************************************************
def uninstall(appXML, applicationName):
	
	appList = AdminApp.list().splitlines()	
	
	for currName in appList:
		if (currName == applicationName):
                	print " --> found: " + applicationName + " uninstaling ..."
                	print " "
                	AdminApp.uninstall(applicationName)
        	        AdminConfig.save()
		#endIf
	#endFor
#endDef

def disableApp(serverXML, appXMLPath, deployPath):
    appXMLVal = "application/disableapp.xml"
    appXML = (appXMLPath+appXMLVal)
    appCount = XPathCount.getCount(appXML, "//application/name/*", "")
    x = 1
    while x < appCount+1:
          disAppNum = ("disApp"+str(x))
          disAppName = Xparser.xFind(appXML, "//application/name/"+disAppNum+"/@name")
          AppId = AdminConfig.getid('/Deployment:'+disAppName+'/')
          AppObj = AdminConfig.showAttribute(AppId, 'deployedObject')
          AppTargetMap = AdminConfig.showAttribute(AppObj, 'targetMappings')
          AppTargetMap = AppTargetMap[1:len(AppTargetMap)-1].split(" ")
          for AppMapping in AppTargetMap:
              print "Disabling  "+disAppName+"   Application"
              AdminConfig.modify(AppMapping, [["enable", "false"]])
              AdminConfig.save()
          x = x+1
#endDef

#**************************************************************************
# checkIfAppExists target:
# 1) checks for the existance of the application
#**************************************************************************
def nodeSync(nodeName):
	print " "
	print " --> performing node sync"
	base.syncNode(nodeName)
	print " "
	time.sleep(90)
	print " --> waiting 90 seconds for node sync to complete"


#**************************************************************************
# checkIfAppExists target:
# 1) checks for the existance of the application
#**************************************************************************
def checkIfAppExists(applicationName):
	
	appExists = "true"
	application = AdminConfig.getid("/Deployment:"+applicationName+"/").strip()
	if (len(application) == 0):
		appExists = "false"
	#endIf 
	return appExists
	
#endDef
#**************************************************************************
# Map WEB modules to virtual hosts
#**************************************************************************
def mapWebModulesVhost(vHostName):

	vhostMapping = "[ '.*' '.*.war,.*' "+vHostName+"]"
	return vhostMapping
#endDef	
#**************************************************************************
# Map WEB modules to servers in the cell the mapping will be set at 
# time of depoloyment
#**************************************************************************
def mapWebModulesToServers(serverXML, cellName, nodeName, serverName):
        
        
	wsCount = XPathCount.getCount(serverXML, "//websphere/webservers/*", "")
	webMapping = ""

	if wsCount > 0:
		ws = 1
		wsMapping = ""
		while ws < wsCount+1:
			wsNum = ("webserver"+str(ws)) 
			wsCheckName = len(Xparser.xFind(serverXML, "//websphere/webservers/"+wsNum+"/@name"))
			if wsCheckName > 0:
				
				webNodeName = Xparser.xFind(serverXML, "//websphere/webservers/"+wsNum+"/@nodeName")
				webServerName = Xparser.xFind(serverXML, "//websphere/webservers/"+wsNum+"/@name") 
			                
				wsMap = "+WebSphere:cell="+cellName+",node="+webNodeName+",server="+webServerName
			               
				wsMapping += wsMap
				ws= ws+1
		         
			else:
				print "web server: not defined"
				ws= ws+1
				
	webMap = "[ '.*' '.*.*,.*' WebSphere:" + "cell=" + cellName + ",node=" + nodeName + ",server=" + serverName + "]"
	webMapping += webMap
	return webMapping

#**************************************************************************
# Map WEB modules to servers in the cell the mapping will be set at 
# time of depoloyment
#**************************************************************************
def mapWebModulesToCluster(serverXML, cellName, clusterName):

		wsCount = XPathCount.getCount(serverXML, "//websphere/webservers/*", "")
			
		webMapping = ""
	
		if wsCount > 0:
			ws = 1
			wsMapping = ""
			while ws < wsCount+1:
				wsNum = ("webserver"+str(ws))
				wsCheckName = len(Xparser.xFind(serverXML, "//websphere/webservers/"+wsNum+"/@name"))
				if wsCheckName > 0:
					webNodeName = Xparser.xFind(serverXML, "//websphere/webservers/"+wsNum+"/@nodeName")
					webServerName = Xparser.xFind(serverXML, "//websphere/webservers/"+wsNum+"/@name")
					wsMap = "+WebSphere:cell="+cellName+",node="+webNodeName+",server="+webServerName
					wsMapping += wsMap
					ws= ws+1
				else:
					print "web server:not defined"
					ws=ws+1
		webMap =  "[ '.*' '.*.*,.*' WebSphere:cell="+cellName+",cluster="+clusterName+""+ wsMapping +"]"
		webMapping += webMap
		return webMapping
              
#**************************************************************************
# Map EJB modules to servers in the cell the mapping will be set at 
# time of depoloyment
#**************************************************************************
def mapEjbModulesToServers(appXML, cellName, nodeName, serverName):

        ejbVal = (Xparser.xFind(appXML, "//application/ejbModules/ejb1/@module"))
        checkVal = len(ejbVal)
        
        if (checkVal < 1):
        	print "ejb mapping: not defined"
                x = 0
                return ""
        else:
		ejbCount = XPathCount.getCount(appXML, "//application/ejbModules/*", "")
		x = 1
	#endIf
		
	ejbMapping = ""
	while x < ejbCount+1:
	
		ejbNum = ("ejb"+str(x))
		ejbModulePath = "//application/ejbModules/"+ejbNum+"/@module"
		ejbUriPath = "//application/ejbModules/"+ejbNum+"/@uri"
		ejbModule = Xparser.xFind(appXML, ejbModulePath)
		ejbUri = Xparser.xFind(appXML, ejbUriPath)
		ejbMap = "[" + "\"" + ejbModule + "\"" + " " + ejbUri + " " + "WebSphere:" + "cell=" + cellName + ",node=" + nodeName + ",server=" + serverName + "]"
		ejbMapping += ejbMap
		x= x+1
	#endWhile
	
	return ejbMapping
#endDef

#**************************************************************************
# Map EJB modules to servers in the cell the mapping will be set at 
# time of depoloyment
#**************************************************************************
def mapEjbModulesToCluster(appXML, cellName, clusterName):
	
	ejbVal = (Xparser.xFind(appXML, "//application/ejbModules/ejb1/@module"))
        checkVal = len(ejbVal)
        
        if (checkVal < 1):
        	print "ejb modules: not defined"
                x = 0
                return ""
        else:
		ejbCount = XPathCount.getCount(appXML, "//application/ejbModules/*", "")
		x = 1
	#endIf
	
	ejbMapping = ""
	while x < ejbCount+1:
	
		ejbNum = ("ejb"+str(x))
		ejbModulePath = "//application/ejbModules/"+ejbNum+"/@module"
		ejbUriPath = "//application/ejbModules/"+ejbNum+"/@uri"
		ejbModule = Xparser.xFind(appXML, ejbModulePath)
		ejbUri = Xparser.xFind(appXML, ejbUriPath)
		ejbMap = "[" + "\"" + ejbModule + "\"" + " " + ejbUri + " " + "WebSphere:" + "cell=" + cellName + ",cluster=" + clusterName +"]"
		ejbMapping += ejbMap
		x= x+1
	#endWhile
	
	return ejbMapping
#endDef

#**************************************************************************
# Application Shared Library references 
# 
#**************************************************************************
def appSharedLibRefs(applicationName, appXML):

	appCount = XPathCount.getCount(appXML, "//application/sharedLibRefs/*", "")
	
	if appCount > 0:
		app = 1
		while app < appCount+1:
			appNum = ("app"+str(app))
			appName = Xparser.xFind(appXML, "//application/sharedLibRefs/"+appNum+"/@application")
			uri = Xparser.xFind(appXML, "//application/sharedLibRefs/"+appNum+"/@uri")
			sharedLib = Xparser.xFind(appXML, "//application/sharedLibRefs/"+appNum+"/@sharedLib")

			print "Updating application shared library references"
			
			#AdminApp.edit('KonyMiddleware', '[ -MapSharedLibForMod [[ "Kony Middleware" middleware.war,WEB-INF/web.xml middleware-common-library ]]]' )	
			AdminApp.edit(applicationName, '[ -MapSharedLibForMod [[ "'+appName+'" '+uri+' '+sharedLib+']]]')
			AdminConfig.save()
			app= app+1
		#endWhile
	#endIf
#endDef

#**************************************************************************
# Application Class Loader
# 
#**************************************************************************
def appclassLoader(applicationName, appXML):

	appCount = XPathCount.getCount(appXML, "//application/classLoader/*", "")
	
	if appCount > 0:
		cl = 1
		while cl < appCount+1:
			clNum = ("classLoader"+str(cl))
			clmode = Xparser.xFind(appXML, "//application/classLoader/"+clNum+"/@mode")

			dep = AdminConfig.getid('/Deployment:"'+applicationName+'"/')
			depObject = AdminConfig.showAttribute(dep, 'deployedObject')
			classldr = AdminConfig.showAttribute(depObject, 'classloader')

			print "Updating application classloader"
			print clmode
			AdminConfig.modify(classldr, [['mode', clmode]])
			#print AdminConfig.showall(classldr)

			AdminConfig.save()
			cl= cl+1
		#endWhile
	#endIf
#endDef



#**************************************************************************

#**************************************************************************
# Configure Context Root for web modules at time of deployment
#
#**************************************************************************
def ctxRootForWebMod(appXML):
	
	webVal = (Xparser.xFind(appXML, "//application/webModules/web1/@module"))
        checkVal = len(webVal)
        
        if (checkVal < 1):
        	print " no web modules defined ... skip context root for web mouldes"
                i = 0
                return ""
        else:
		webCount = XPathCount.getCount(appXML, "//application/webModules/*", "")
		i = 1
		
	ctxRootWebMod = ""

	while i < webCount+1:
	
		webNum = ("web"+str(i))
		webModulePath = "//application/webModules/"+webNum+"/@module"
		webUriPath = "//application/webModules/"+webNum+"/@uri"
		webCtxRoot = "//application/webModules/"+webNum+"/@ctxroot"
		webModule = Xparser.xFind(appXML, webModulePath)
		webUri = Xparser.xFind(appXML, webUriPath)
		webCtxRoot = Xparser.xFind(appXML, webCtxRoot)
		
		ctxRootVal = len(webCtxRoot)

		if (ctxRootVal < 1):			
        		print " no context root defined ... skip contxt root for web module"
                else:
			# define context root
			webCtx = "[" + "\"" + webModule + "\"" + " " + webUri + " " + webCtxRoot +"]"
	        
	        	ctxRootWebMod += webCtx
	        i= i+1
	#endWhile
	return ctxRootWebMod
#endDef
#**************************************************************************
# map resource reference to modules
#
#**************************************************************************
def MapResRefToMod(appXML):
	
	resRefVal = (Xparser.xFind(appXML, "//application/resRefs/res1/@uri"))
	
	checkVal = len(resRefVal)
	if (checkVal < 1):
		i = 0
		return ""
	else:
		resCount = XPathCount.getCount(appXML, "//application/resRefs/*", "")
		i = 1

		resRefMapping = ""
		while i < resCount+1:
	
			resNum = ("res"+str(i))
			resMod = "//application/resRefs/"+resNum+"/@module"
			resEjb = "//application/resRefs/"+resNum+"/@ejb"
			resUri = "//application/resRefs/"+resNum+"/@uri"
			resBind = "//application/resRefs/"+resNum+"/@refBinding"
			resJndi = "//application/resRefs/"+resNum+"/@jndi"
			resType = "//application/resRefs/"+resNum+"/@resource"
			resRefModule = Xparser.xFind(appXML, resMod)
			resRefEjb = Xparser.xFind(appXML, resEjb)
			resRefUri = Xparser.xFind(appXML, resUri)
			resRefBind = Xparser.xFind(appXML, resBind)
			resRefJndi = Xparser.xFind(appXML, resJndi)
			resRefType = Xparser.xFind(appXML, resType)
		
			resRefMap = "[ " + "\""+resRefModule+"\"" + " \""+resRefEjb+"\"" + " \""+resRefUri+"\"" + " \""+resRefBind+"\"" + " \""+resRefType+"\"" + " \""+resRefJndi+"\"" +" ]"
			resRefMapping += resRefMap
			i = i + 1
		
	#endWhile
		return resRefMapping
#endDef	

def MapMessageDestinationRefToEJB(appXML):
	
	resRefVal1 = (Xparser.xFind(appXML, "//application/mesgDestRef/res1/@uri"))
	checkVal1 = len(resRefVal1)
	if (checkVal1 < 1):
		i = 0
		return ""
	else:
		resCount = XPathCount.getCount(appXML, "//application/mesgDestRef/*", "")
		i = 1

		resRefMsgMapping = ""
		while i < resCount+1:
			resNum = ("res"+str(i))
			resMod = "//application/mesgDestRef/"+resNum+"/@module"
			resEjb = "//application/mesgDestRef/"+resNum+"/@ejb"
			resUri = "//application/mesgDestRef/"+resNum+"/@uri"
			resBind = "//application/mesgDestRef/"+resNum+"/@refBinding"
			resJndi = "//application/mesgDestRef/"+resNum+"/@jndi"
			resRefModule = Xparser.xFind(appXML, resMod)
			resRefEjb = Xparser.xFind(appXML, resEjb)
			resRefUri = Xparser.xFind(appXML, resUri)
			resRefBind = Xparser.xFind(appXML, resBind)
			resRefJndi = Xparser.xFind(appXML, resJndi)
			
			resMsgDestRefEJBMap = "[ " + "\""+resRefModule+"\"" + " \""+resRefEjb+"\"" + " \""+resRefUri+"\"" + " \""+resRefBind+"\"" + " \""+resRefJndi+"\"" +" ]"
			resRefMsgMapping += resMsgDestRefEJBMap
			i = i + 1
		print resRefMsgMapping
		#endWhile
		return resRefMsgMapping
#endDef
def MapRolesToUsers (serverXML, deployUnit):
 	appCount = XPathCount.getCount(serverXML, "//websphere/applications/*", "")
 	j=1
 	while j < appCount+1:
 		appNum = ("app"+str(j))
		artifact = (Xparser.xFind(serverXML,"//websphere/applications/"+appNum+"/@deployUnit"))
		
		if ( artifact.lower() == deployUnit.lower() ):
			userRoleVal = (Xparser.xFind(serverXML, "//websphere/applications/"+appNum+"/userRoles/role1/@role"))
	
       			checkVal = len(userRoleVal)
        
        		if (checkVal < 1):
             	   		i = 0
                		return ""
        		else:
				roleCount = XPathCount.getCount(serverXML, "//websphere/applications/"+appNum+"/userRoles/*", "")
				i = 1
			#endIf
		
			userRoleMapping = ""
			while i < roleCount+1:		
				roleNum = ("role"+str(i))
				
				role = "//websphere/applications/"+appNum+"/userRoles/"+roleNum+"/@role"	
				everyone = "//websphere/applications/"+appNum+"/userRoles/"+roleNum+"/@everyone"
				allAuth = "//websphere/applications/"+appNum+"/userRoles/"+roleNum+"/@allAuth"
				users = "//websphere/applications/"+appNum+"/userRoles/"+roleNum+"/@users"
				groups = "//websphere/applications/"+appNum+"/userRoles/"+roleNum+"/@groups"
			
				userRolesRole= Xparser.xFind(serverXML, role)	
				userRolesEveryone = Xparser.xFind(serverXML, everyone)
				userRolesAllAuth = Xparser.xFind(serverXML, allAuth)			
				userRolesUsers = Xparser.xFind(serverXML, users)
				userRolesGroups = Xparser.xFind(serverXML, groups)
				
				userRoleMap = "[ "+userRolesRole+" "+userRolesEveryone+" "+userRolesAllAuth+" \""+userRolesUsers+"\"" + " \""+userRolesGroups+"\"" +" ]"
								
				userRoleMapping += userRoleMap
				i= i+1
			#endWhile
			break
		#endIf
		j = j+1
	#endWhile
	return userRoleMapping	
#endDef
#**************************************************************************
# deploy target: 
# 1) stop server
# 2) uninstall application if it exists
# 3) deploy application
# 4) start server
# 5) check application status 
#**************************************************************************

# update handle multi deploy -jc
#def deploy(serverXML, appXML, deployPath):
def deploy(serverXML, appXMLPath, deployPath, nodeName, serverName):
	
	# ********************** variables ************************ # 	
	cellName = AdminControl.getCell()
	#serverName = (Xparser.xFind(serverXML, "//websphere/server/@name"))
	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
	clusterLen = (len(clusterName))
	vHostName = ""
	vHostName = Xparser.xFind(serverXML, "//websphere/server/environment/vhosts/vhost/@name")
	if ( len(vHostName) == 0):
		vHostName = Xparser.xFind(serverXML, "//websphere/server/environment/vhosts/vhost1/@name")
        
        #print clusterName
	# update handle multi deploy -jc
	#deployWs = Xparser.xFind(appXML, "//application/deploy/@webServices")
	#preCompileJsp = Xparser.xFind(appXML, "//application/deploy/@preCompileJsp")
	#contextRoot = Xparser.xFind(appXML, "//application/context/@root")
        # ********************** end variables ********************* # 	 
        

	
	deployUnit = os.path.basename(deployPath)
		
        
 	appCount = XPathCount.getCount(serverXML, "//websphere/applications/*", "")
 	i=1
 	app="false"
 	while i < appCount+1:
 		appNum = ("app"+str(i))
		artifact = (Xparser.xFind(serverXML,"//websphere/applications/"+appNum+"/@deployUnit"))
		# update handle multi deploy -jc
		
		
		if ( artifact.lower() == deployUnit.lower() ):
			applicationName = (Xparser.xFind(serverXML,"//websphere/applications/"+appNum+"/@name"))
			# set path to applicatinon xml for current app number
			appXMLVal= (Xparser.xFind(serverXML,"//websphere/applications/"+appNum+"/@appXML"))
			#print " --> debug: appXMLPath = ", appXMLPath
			appXML= (appXMLPath+appXMLVal)
			# check existance
			if ( os.path.exists(appXML) == 0):
				print "Fail: File "+appXML+" does not exists.  Please check the application conf file."
				print " "
				sys.exit(1)
			#print " --> debug: appXML = ", appXML 
			# pull application values
			deployWs = Xparser.xFind(appXML, "//application/deploy/@webServices")
			preCompileJsp = Xparser.xFind(appXML, "//application/deploy/@preCompileJsp")
			contextRoot = Xparser.xFind(appXML, "//application/context/@root")
			
			app="true"
			break
		#endIf
		
		i = i+1
	#endWhile
        
        print "--> deploying application", applicationName
        
        # stop server(s)
        if ( clusterLen > 0 ):

		clusterId = AdminConfig.getid("/ServerCluster:" + clusterName + "/")
		clusterMembersId = AdminConfig.showAttribute(clusterId, "members")
		clusterMembersId = clusterMembersId[1:-1]
        	#clusterMembers = AdminConfig.list("ClusterMember", clusterId ).splitlines()
        	
        	for clusterMemberId in clusterMembersId.split():
			nodeName = AdminConfig.showAttribute( clusterMemberId, "nodeName" )
			serverName = AdminConfig.showAttribute( clusterMemberId, "memberName" )
			
			print " --> stopping server: ", serverName
			base.stopServer(nodeName, serverName)
		#endFor
	else:
		print " --> stopping server: ", serverName
		base.stopServer(nodeName, serverName)
        #endIf
        
        
        
        # uninstall application if it exists
       	# uninstall(appXML, applicationName)
       	appExists = checkIfAppExists(applicationName)
       	
  	vHostMapping = (mapWebModulesVhost(vHostName))
	#ctxRootWebMod = (ctxRootForWebMod(appXML))
	resRefMapping = (MapResRefToMod(appXML))
	resRefMsgMapping = (MapMessageDestinationRefToEJB(appXML))
	userRolesMapping = (MapRolesToUsers(serverXML, deployUnit))
	# deploy application
	if ( clusterLen > 0 ):
		print " --> starting: cluster installation"
		print "server: " + serverName + " is part of cluster: " + clusterName
		
		appTarget = clusterName
		
		# application mapping
		webMapping = (mapWebModulesToCluster(serverXML, cellName, clusterName))
		ejbMapping = (mapEjbModulesToCluster(appXML, cellName, clusterName))
		scope = "-cluster "+clusterName
		
	else:
		print " --> starting: single server server installation"
		appTarget = serverName
		
		appTarget = serverName
		
		# application mapping
		webMapping = (mapWebModulesToServers(serverXML, cellName, nodeName, serverName))
		ejbMapping = (mapEjbModulesToServers(appXML, cellName, nodeName, serverName))
		scope = "-server "+serverName
	#endIf
	
	print "deploying application: "
	print "---------------------- " 
	print "application name: " + applicationName 
	print "application target: " + appTarget
	print "deployment unit: " + deployUnit
	print "deployment path (defined in server xml): " + deployPath				
               
		
	if (webMapping != ""):
		print "web mapping:", webMapping
	#endIf
	if (ejbMapping != ""):
		print "ejbMapping:", ejbMapping
	#endIf
		
	ctxArg = ""
	#if (ctxRootWebMod != ""):	
		#print "context root for web modules:", ctxRootWebMod
		#ctxArg = '-CtxRootForWebMod ['+ctxRootWebMod+']'
	#endIf

	contextArg = ""
	if (contextRoot != ""):	
		print "context root:", contextRoot
		contextArg = '-contextroot '+contextRoot
	#endIf		
		
	resRefArg = ""
	if (resRefMapping != ""):	
		print "resource ref for ejb modules:", resRefMapping
		resRefArg = '-MapResRefToEJB ['+resRefMapping+']'
	#endIf
	resMsgDestArg = ""
	if (resRefMsgMapping != ""):
		print "resource message destination ref for ejb modules:", resRefMsgMapping
		resMsgDestArg = '-MapMessageDestinationRefToEJB ['+resRefMsgMapping+']'
	#endIf
	
	userRolesArg = ""
	if (userRolesMapping != ""):	
		print "security role mapping:", userRolesMapping	
		userRolesArg = '-MapRolesToUsers ['+userRolesMapping+']'
	#endIf		
	if (deployWs == "true"):
		deploywsOption='-deployws'
	else:
		deploywsOption='-nodeployws'
	#endIf
	
	
	if (preCompileJsp == "true"):
		preCompileJspOption='-preCompileJSPs'
	else:
		preCompileJspOption=""
	#endIf
	
	print " "
	        
	if (appExists == "true"):
		print "--> start: updating application"
		print " "
		
		AdminApp.update(applicationName, 'app', '[ -operation update -contents '+deployPath+' '+deploywsOption+' -MapModulesToServers ['+ejbMapping+' '+webMapping+'] '+contextArg+' '+ctxArg+' '+userRolesArg+' '+preCompileJspOption+' '+resRefArg+' -MapWebModToVH ['+vHostMapping+']'+resMsgDestArg+']') 
	
		appSharedLibRefs(applicationName,appXML)
		appclassLoader(applicationName, appXML)   

		print " --> complete: updating application"
		AdminConfig.save()
		nodeSync(nodeName)
	else:
		print " --> start: installing deployment"
		print " "
		
		AdminApp.install(deployPath, '['+scope+' -appname '+applicationName+' '+deploywsOption+' -MapModulesToServers ['+ejbMapping+' '+webMapping+'] '+contextArg+' '+preCompileJspOption+' '+ctxArg+' '+userRolesArg+' '+resRefArg+' -MapWebModToVH ['+vHostMapping+'] '+resMsgDestArg+']')

		appSharedLibRefs(applicationName,appXML)
		appclassLoader(applicationName, appXML)
        
		
		print " "
		print " --> complete: deployment"
		AdminConfig.save()
		nodeSync(nodeName)
	#endIf
	if ( clusterLen > 0 ):
		for clusterMemberId in clusterMembersId.split():
			nodeName = AdminConfig.showAttribute( clusterMemberId, "nodeName" )
			serverName = AdminConfig.showAttribute( clusterMemberId, "memberName" )
			print " "
			print " --> starting server: ", serverName
			base.startServer(nodeName, serverName)
		#endFor
	else:
		print " --> starting server: ", serverName
		base.startServer(nodeName, serverName)
	
	time.sleep(35)
	appStatus = base.checkApplicationRunning(nodeName, serverName, applicationName)
	
	if ( appStatus == 0):
		base.startApplication(nodeName, serverName, applicationName)
	#endIf
	
#endDef
def deploy_app_only(serverXML, deployPath, nodeName, serverName):

        # ********************** variables ************************ #
        cellName = AdminControl.getCell()
        serverName = (Xparser.xFind(serverXML, "//websphere/server/@name"))
        nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
        clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
        clusterLen = (len(clusterName))
        vHostName = ""
        vHostName = Xparser.xFind(serverXML, "//websphere/server/environment/vhosts/vhost/@name")
        if ( len(vHostName) == 0):
                vHostName = Xparser.xFind(serverXML, "//websphere/server/environment/vhosts/vhost1/@name")


        deployUnit = os.path.basename(deployPath)
        applicationName = re.sub("(.ear|.war)", "", deployUnit)
        appExists = checkIfAppExists(applicationName)

        if ( clusterLen > 0 ):
                print " --> starting: cluster installation"
                print "server: " + serverName + " is part of cluster: " + clusterName

                appTarget = clusterName
                webMapping = (mapWebModulesToCluster(serverXML, cellName, clusterName))
                scope = "-cluster "+clusterName

        else:
                print " --> starting: single server server installation"
                appTarget = serverName
                webMapping = (mapWebModulesToServer(serverXML, cellName, serverName))
                scope = "-server "+serverName
        #endIf

        print "deploying application: "
        print "---------------------- "
        print "application name: " + applicationName
        print "application target: " + appTarget
        print "deployment unit: " + deployUnit
        print "deployment path: " + deployPath

        if (appExists == "true"):
                print "--> start: updating application"
                print " "

                AdminApp.update(applicationName, 'app', '[ -operation update -contents '+deployPath+' -MapModulesToServers ['+webMapping+']]')
                AdminConfig.save()

                print " "
                print " --> complete: deployment"
        else:
                print " --> start: installing deployment"
                print " "

                vHostMapping = (mapWebModulesVhost(vHostName))
                AdminApp.install(deployPath, '['+scope+' -appname '+applicationName+' -MapModulesToServers ['+webMapping+'] -MapWebModToVH ['+vHostMapping+']]')
                AdminConfig.save()

                print " "
                print " --> complete: deployment"
        #endIf

        base.syncNode(nodeName)
        base.startApplication(nodeName, serverName, applicationName)
#endDef


def deploy_rollout(serverXML, appXMLPath, deployPath, nodeName, serverName):
# ********************** variables ************************ # 	
	cellName = AdminControl.getCell()
	#serverName = (Xparser.xFind(serverXML, "//websphere/server/@name"))
	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
	clusterLen = (len(clusterName))
	vHostName = ""
	vHostName = Xparser.xFind(serverXML, "//websphere/server/environment/vhosts/vhost/@name")
	if ( len(vHostName) == 0):
		vHostName = Xparser.xFind(serverXML, "//websphere/server/environment/vhosts/vhost1/@name")
		
	deployUnit = os.path.basename(deployPath)
	appCount = XPathCount.getCount(serverXML, "//websphere/applications/*", "")
	i=1
 	app="false"
	while i < appCount+1:
 		appNum = ("app"+str(i))
		artifact = (Xparser.xFind(serverXML,"//websphere/applications/"+appNum+"/@deployUnit"))
		# update handle multi deploy -jc
		
		
		if ( artifact == deployUnit ):
			applicationName = (Xparser.xFind(serverXML,"//websphere/applications/"+appNum+"/@name"))
			# set path to applicatinon xml for current app number
			appXMLVal= (Xparser.xFind(serverXML,"//websphere/applications/"+appNum+"/@appXML"))
			#print " --> debug: appXMLPath = ", appXMLPath
			appXML= (appXMLPath+appXMLVal)
			# check existance
			if ( os.path.exists(appXML) == 0):
				print "Fail: File "+appXML+" does not exists.  Please check the application conf file."
				print " "
				sys.exit(1)
			#print " --> debug: appXML = ", appXML 
			# pull application values
			deployWs = Xparser.xFind(appXML, "//application/deploy/@webServices")
			preCompileJsp = Xparser.xFind(appXML, "//application/deploy/@preCompileJsp")
			contextRoot = Xparser.xFind(appXML, "//application/context/@root")
			
			app="true"
			break
		#endIf
		
		i = i+1
	#endWhile
	if ( clusterLen > 0 ):
		clusterId = AdminConfig.getid("/ServerCluster:" + clusterName + "/")
		clusterMembersId = AdminConfig.showAttribute(clusterId, "members")
		clusterMembersId = clusterMembersId[1:-1]
		NodesList = []
		for clusterMemberId in clusterMembersId.split():
			nodeName = AdminConfig.showAttribute( clusterMemberId, "nodeName" )
			serverName = AdminConfig.showAttribute( clusterMemberId, "memberName" )
			if len(NodesList) == 0 :
				NodesList.append(nodeName)
				
			else:
				matchfound = 'false'
				for node in NodesList:
					if (node == nodeName):
						matchfound = 'true'
				if ( matchfound == 'false'):
					NodesList.append(nodeName)
		print "Nodes identified are:" , NodesList
		for node in NodesList:
			naId = AdminConfig.getid("/Node:" +node+ "/Server:nodeagent/")
			syncId = AdminConfig.list('ConfigSynchronizationService',naId)
			AdminConfig.modify(syncId,'[[autoSynchEnabled "false"]]')
			AdminConfig.modify(syncId,'[[synchOnServerStartup "false"]]')
			AdminConfig.save()
			nodeSync = AdminControl.completeObjectName('type=NodeSync,node='+node+',*')
			AdminControl.invoke(nodeSync,'sync')
			print " --> Diasabled Automatic Synchronization on "+node
			agent = AdminControl.completeObjectName('type=NodeAgent,node='+node+',process=nodeagent,*')
			AdminControl.invoke(agent,'restart','false false')
			time.sleep(120)
	print "Deploying Application" , applicationName
	# Application check
	appExists = checkIfAppExists(applicationName)
	# Virtual Host Mapping
	vHostMapping = (mapWebModulesVhost(vHostName))
	# Resource Reference Mapping
	resRefMapping = (MapResRefToMod(appXML))
	# Message Destination Mapping
	resRefMsgMapping = (MapMessageDestinationRefToEJB(appXML))
	userRolesMapping = (MapRolesToUsers(serverXML, deployUnit))
	
	if ( clusterLen > 0 ):
		print " --> starting: cluster installation"
		print "server: " + serverName + " is part of cluster: " + clusterName
		
		appTarget = clusterName
		
		# application mapping
		webMapping = (mapWebModulesToCluster(serverXML, cellName, clusterName))
		ejbMapping = (mapEjbModulesToCluster(appXML, cellName, clusterName))
		scope = "-cluster "+clusterName
	if (webMapping != ""):
		print "web mapping:", webMapping
	#endIf
	if (ejbMapping != ""):
		print "ejbMapping:", ejbMapping
	#endIf
	ctxArg = ""
	#if (ctxRootWebMod != ""):	
		#print "context root for web modules:", ctxRootWebMod
		#ctxArg = '-CtxRootForWebMod ['+ctxRootWebMod+']'
	#endIf
	contextArg = ""
	if (contextRoot != ""):	
		print "context root:", contextRoot
		contextArg = '-contextroot '+contextRoot
	#endIf		
		
	resRefArg = ""
	if (resRefMapping != ""):	
		print "resource ref for ejb modules:", resRefMapping
		resRefArg = '-MapResRefToEJB ['+resRefMapping+']'
	#endIf
	resMsgDestArg = ""
	if (resRefMsgMapping != ""):
		print "resource message destination ref for ejb modules:", resRefMsgMapping
		resMsgDestArg = '-MapMessageDestinationRefToEJB ['+resRefMsgMapping+']'
	
	userRolesArg = ""
	if (userRolesMapping != ""):	
		print "security role mapping:", userRolesMapping	
		userRolesArg = '-MapRolesToUsers ['+userRolesMapping+']'
	#endIf	
		
	if (deployWs == "true"):
		deploywsOption='-deployws'
	else:
		deploywsOption='-nodeployws'
	#endIf
	
	
	if (preCompileJsp == "true"):
		preCompileJspOption='-preCompileJSPs'
	else:
		preCompileJspOption=""
	#endIf
	if (appExists == "true"):
		print "--> start: updating application"
		print " "
		
		AdminApp.update(applicationName, 'app', '[ -operation update -contents '+deployPath+' '+deploywsOption+' -MapModulesToServers ['+ejbMapping+' '+webMapping+'] '+contextArg+' '+ctxArg+' '+userRolesArg+' '+preCompileJspOption+' '+resRefArg+' '+resMsgDestArg+' -MapWebModToVH ['+vHostMapping+']') 
	
		appSharedLibRefs(applicationName,appXML)
	
		print " --> complete: updating application"
		AdminConfig.save()
	
	# Node sync

	
	clusterId = AdminConfig.getid("/ServerCluster:" + clusterName + "/")
	clusterMembersId = AdminConfig.showAttribute(clusterId, "members")
	clusterMembersId = clusterMembersId[1:-1]
	if len(NodesList) < 2:
		time.sleep(120)
	for node in NodesList:
		#checking to see if nodeagent is avaliable if not wait 2 minutes
		stpServerList = []
		# Stopping instance on Node.
		for clusterMemberId in clusterMembersId.split():
			nodeName = AdminConfig.showAttribute( clusterMemberId, "nodeName" )
			serverName = AdminConfig.showAttribute( clusterMemberId, "memberName" )
			if (node == nodeName):
				runServer = AdminControl.completeObjectName("type=Server,node=" + nodeName + ",process=" + serverName + ",*")
				if len(runServer) > 0:
					print "stopping server"+ serverName
					base.stopServer(nodeName, serverName)
				else:
					stpServerList.append(serverName)
		naId = AdminConfig.getid("/Node:" +node+ "/Server:nodeagent/")
		syncId = AdminConfig.list('ConfigSynchronizationService',naId)
		AdminConfig.modify(syncId,'[[synchInterval "2"] [exclusions ""] [enable "true"] [synchOnServerStartup "true"] [autoSynchEnabled "true"]]')
		AdminConfig.save()
		nodeSync = AdminControl.completeObjectName('type=NodeSync,node='+node+',*')
		AdminControl.invoke(nodeSync,'sync')
		print "Synchronized Node "+node
		for clusterMemberId in clusterMembersId.split():
			nodeName = AdminConfig.showAttribute( clusterMemberId, "nodeName" )
			serverName = AdminConfig.showAttribute( clusterMemberId, "memberName" )
			if (node == nodeName):
				
				stopped = "false"
				for serv in stpServerList:
					if ( serv == serverName ):
						print " Server "+serverName+" was stopped before deployment it will not be started"
						stopped="true"
				if (stopped == "false"):
					base.startServer(nodeName, serverName)
		agent = AdminControl.completeObjectName('type=NodeAgent,node='+node+',process=nodeagent,*')
		AdminControl.invoke(agent,'restart','true false')
	print "Application has rollout to all nodes"
	#End def
	
	

def deploy_stop(serverXML, appXMLPath, deployPath, nodeName, serverName):
	
	# ********************** variables ************************ # 	
	cellName = AdminControl.getCell()
	#serverName = (Xparser.xFind(serverXML, "//websphere/server/@name"))
	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
	clusterLen = (len(clusterName))
	vHostName = ""
	vHostName = Xparser.xFind(serverXML, "//websphere/server/environment/vhosts/vhost/@name")
	if ( len(vHostName) == 0 ):
		vHostName = Xparser.xFind(serverXML, "//websphere/server/environment/vhosts/vhost1/@name")
        
        #print clusterName
	# update handle multi deploy -jc
	#deployWs = Xparser.xFind(appXML, "//application/deploy/@webServices")
	#preCompileJsp = Xparser.xFind(appXML, "//application/deploy/@preCompileJsp")
	#contextRoot = Xparser.xFind(appXML, "//application/context/@root")
        # ********************** end variables ********************* # 	 
        

	
	deployUnit = os.path.basename(deployPath)
		
        
 	appCount = XPathCount.getCount(serverXML, "//websphere/applications/*", "")
 	i=1
 	app="false"
 	while i < appCount+1:
 		appNum = ("app"+str(i))
		artifact = (Xparser.xFind(serverXML,"//websphere/applications/"+appNum+"/@deployUnit"))
		# update handle multi deploy -jc
		
		
		if ( artifact == deployUnit ):
			applicationName = (Xparser.xFind(serverXML,"//websphere/applications/"+appNum+"/@name"))
			# set path to applicatinon xml for current app number
			appXMLVal= (Xparser.xFind(serverXML,"//websphere/applications/"+appNum+"/@appXML"))
			#print " --> debug: appXMLPath = ", appXMLPath
			appXML= (appXMLPath+appXMLVal)
			# check existance
			if ( os.path.exists(appXML) == 0):
				print "Fail: File "+appXML+" does not exists.  Please check the application conf file."
				print " "
				sys.exit(1)
			#print " --> debug: appXML = ", appXML 
			# pull application values
			deployWs = Xparser.xFind(appXML, "//application/deploy/@webServices")
			preCompileJsp = Xparser.xFind(appXML, "//application/deploy/@preCompileJsp")
			contextRoot = Xparser.xFind(appXML, "//application/context/@root")
			
			app="true"
			break
		#endIf
		
		i = i+1
	#endWhile
        
        print "--> deploying application", applicationName
        
        # stop server(s)
        if ( clusterLen > 0 ):

		clusterId = AdminConfig.getid("/ServerCluster:" + clusterName + "/")
		clusterMembersId = AdminConfig.showAttribute(clusterId, "members")
		clusterMembersId = clusterMembersId[1:-1]
        	#clusterMembers = AdminConfig.list("ClusterMember", clusterId ).splitlines()
        	
        	for clusterMemberId in clusterMembersId.split():
			nodeName = AdminConfig.showAttribute( clusterMemberId, "nodeName" )
			serverName = AdminConfig.showAttribute( clusterMemberId, "memberName" )
			
			print " --> stopping server: ", serverName
			base.stopServer(nodeName, serverName)
		#endFor
	else:
		print " --> stopping server: ", serverName
		base.stopServer(nodeName, serverName)
        #endIf
        
        
        
        # uninstall application if it exists
       	# uninstall(appXML, applicationName)
       	appExists = checkIfAppExists(applicationName)
       	
  	vHostMapping = (mapWebModulesVhost(vHostName))
	#ctxRootWebMod = (ctxRootForWebMod(appXML))
	resRefMapping = (MapResRefToMod(appXML))
	resMsgDestRefMapping = (MapMessageDestinationRefToEJB(appXML))
	userRolesMapping = (MapRolesToUsers(serverXML, deployUnit))
	
	# deploy application		
	if ( clusterLen > 0 ):
		print " --> starting: cluster installation"
		print "server: " + serverName + " is part of cluster: " + clusterName
		
		appTarget = clusterName
		
		# application mapping
		webMapping = (mapWebModulesToCluster(serverXML, cellName, clusterName))
		ejbMapping = (mapEjbModulesToCluster(appXML, cellName, clusterName))
		scope = "-cluster "+clusterName
		
	else:
		print " --> starting: single server server installation"
		appTarget = serverName
		
		appTarget = serverName
		
		# application mapping
		webMapping = (mapWebModulesToServers(serverXML, cellName, nodeName, serverName))
		ejbMapping = (mapEjbModulesToServers(appXML, cellName, nodeName, serverName))
		scope = "-server "+serverName
	#endIf
	
	print "deploying application: "
	print "---------------------- " 
	print "application name: " + applicationName 
	print "application target: " + appTarget
	print "deployment unit: " + deployUnit
	print "deployment path (defined in server xml): " + deployPath				
               
		
	if (webMapping != ""):
		print "web mapping:", webMapping
	#endIf
	if (ejbMapping != ""):
		print "ejbMapping:", ejbMapping
	#endIf
		
	ctxArg = ""
	#if (ctxRootWebMod != ""):	
		#print "context root for web modules:", ctxRootWebMod
		#ctxArg = '-CtxRootForWebMod ['+ctxRootWebMod+']'
	#endIf

	contextArg = ""
	if (contextRoot != ""):	
		print "context root:", contextRoot
		contextArg = '-contextroot '+contextRoot
	#endIf		
		
	resRefArg = ""
	if (resRefMapping != ""):	
		print "resource ref for ejb modules:", resRefMapping
		resRefArg = '-MapResRefToEJB ['+resRefMapping+']'
	#endIf
	resMsgRefArg = ""
	if (resMsgDestRefMapping != ""):	
		print "resource message destinations ref for ejb modules:", resMsgDestRefMapping
		resMsgRefArg = '-MapMessageDestinationRefToEJB ['+resMsgDestRefMapping+']'
	#endIf
	
	userRolesArg = ""
	if (userRolesMapping != ""):	
		print "security role mapping:", userRolesMapping	
		userRolesArg = '-MapRolesToUsers ['+userRolesMapping+']'
	#endIf	
	
	if (deployWs == "true"):
		deploywsOption='-deployws'
	else:
		deploywsOption='-nodeployws'
	#endIf
	
	
	if (preCompileJsp == "true"):
		preCompileJspOption='-preCompileJSPs'
	else:
		preCompileJspOption=""
	#endIf
	
	print " "
	        
	if (appExists == "true"):
		print "--> start: updating application"
		print " "
		
		AdminApp.update(applicationName, 'app', '[ -operation update -contents '+deployPath+' '+deploywsOption+' -MapModulesToServers ['+ejbMapping+' '+webMapping+'] '+contextArg+' '+ctxArg+' '+userRolesArg+' '+preCompileJspOption+' '+resRefArg+' '+resMsgRefArg+' -MapWebModToVH ['+vHostMapping+']') 
	
		appSharedLibRefs(applicationName,appXML)
	
		print " --> complete: updating application"
		AdminConfig.save()
		nodeSync(nodeName)
	else:
		print " --> start: installing deployment"
		print " "
		
		AdminApp.install(deployPath, '['+scope+' -appname '+applicationName+' '+deploywsOption+' -MapModulesToServers ['+ejbMapping+' '+webMapping+'] '+contextArg+' '+preCompileJspOption+' '+ctxArg+' '+userRolesArg+' '+resRefArg+' '+resMsgRefArg+' -MapWebModToVH ['+vHostMapping+']')
	
		appSharedLibRefs(applicationName,appXML)
	
		print " "
		print " --> complete: deployment"
		AdminConfig.save()
		nodeSync(nodeName)
	#endIf
	
	print " "
	
	if ( clusterLen > 0 ):
		for clusterMemberId in clusterMembersId.split():
			nodeName = AdminConfig.showAttribute( clusterMemberId, "nodeName" )
			serverName = AdminConfig.showAttribute( clusterMemberId, "memberName" )
			print " --> application server not started: ", serverName
			#base.startServer(nodeName, serverName)
		#endFor
	else:
		print " --> application server not started: ", serverName
	
def deploy_only_app_edition(serverXML, deployPath, nodeName, serverName):

        # ********************** variables ************************ #
        cellName = AdminControl.getCell()
        serverName = (Xparser.xFind(serverXML, "//websphere/server/@name"))
        nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
        clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
        clusterLen = (len(clusterName))
        vHostName = ""
        vHostName = Xparser.xFind(serverXML, "//websphere/server/environment/vhosts/vhost/@name")
        if ( len(vHostName) == 0):
                vHostName = Xparser.xFind(serverXML, "//websphere/server/environment/vhosts/vhost1/@name")
        print "testing01"
	appCount = XPathCount.getCount(serverXML, "//websphere/applications/*", "") 
        print appCount
	if appCount > 0:
		app = 1
		while app < appCount+1:
			appNum = ("app"+str(app))
			editionNumber = (Xparser.xFind(serverXML,"//websphere/applications/"+appNum+"/@edition"))
			applicationName = (Xparser.xFind(serverXML,"//websphere/applications/"+appNum+"/@name"))
			print applicationName
			print editionNumber
			break
		app=app+1
	deployUnit = os.path.basename(deployPath)
#        applicationName = re.sub("(.ear|.war)", "", deployUnit)
        appExists = checkIfAppExists(applicationName)
	print appExists
        if ( clusterLen > 0 ):
                print " --> starting: cluster installation"
                print "server: " + serverName + " is part of cluster: " + clusterName

                appTarget = clusterName
                webMapping = (mapWebModulesToCluster(serverXML, cellName, clusterName))
                scope = "-cluster "+clusterName

        else:
                print " --> starting: single server server installation"
                appTarget = serverName
                webMapping = (mapWebModulesToServer(serverXML, cellName, serverName))
                scope = "-server "+serverName
        #endIf

        print "deploying application: "
        print "---------------------- "
        print "application name: " + applicationName
        print "application target: " + appTarget
        print "deployment unit: " + deployUnit
        print "deployment path: " + deployPath

#        if (appExists == "true"):
        print " --> start: installing app edition deployment"
        print " "

        vHostMapping = (mapWebModulesVhost(vHostName))
#        AdminApp.install(deployPath, '['+scope+' -appname '+applicationName+' -edition '+editionNumber+' -MapModulesToServers ['+webMapping+'] -MapWebModToVH ['+vHostMapping+']]')
 	AdminApp.install(deployPath, '['+scope+' -appname '+applicationName+' -edition '+editionNumber+' -MapWebModToVH ['+vHostMapping+']]')
        AdminConfig.save()

        print " "
        print " --> complete: App edition deployment"                
#        else:
#                print " --> stopped: installing deployment"
#                print " "
#                print " --> Warning: Base App edition not installed"
        #endIf

        base.syncNode(nodeName)

	#endIf	
#endDef
#********************************************************
# script usage: 
#********************************************************

def usage():
	print " "
        print " "
        print " usage: python application.py [environment type] [instance] [option]"
        print " example: python application.py nxsa dev01_nx deploy"
        print " "
        print " current options:"
        print " ----------------"
        print " 1) deploy [steps: stop application, update/install, map modules, map virutal hosts]"
        print " 2) uninstall [steps: stop application, uninstall application]"
        print " "
        print " " 
      
#endDef
  		
#********************************************************
# main: 
#********************************************************

def main():
        
	print " "
	print " "
	
	# check arguments
	if len(sys.argv) < 5:
		usage()
		sys.exit(1)
	# expected input

	shieldHome = sys.argv[0]
	envType = sys.argv[1]
	instance = sys.argv[2]
	task = sys.argv[3]
	deployPath = sys.argv[4]        
			   
	# variables
	xmlBasePath = (shieldHome+"/xml/")

	# get appName
	Temp = os.path.basename(deployPath)	

	appName = re.sub("(.ear|.war)", "", Temp)

	#xml path        
	serverXML = (xmlBasePath+envType+"/"+instance+".xml")
	appXMLPath = (xmlBasePath+envType+"/")
	xmlNodeConfig = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	nodeName = base.matchNodeVal(xmlNodeConfig)
	serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	
	
	if (task == "deploy"):
		# testing multi app solution - jc
		deploy(serverXML, appXMLPath, deployPath, nodeName, serverName)
	elif (task == "deploy_app_only"):
		deploy_app_only(serverXML, deployPath, nodeName, serverName)
	elif (task == "deploy_rollout"):
		deploy_rollout(serverXML, appXMLPath, deployPath, nodeName, serverName)
	elif (task == "disableApp"):
		disableApp(serverXML, appXMLPath, deployPath)
	elif (task == "uninstall"):
		uninstall(appXML)
	elif (task == "deploy_stop"):
		deploy_stop(serverXML, appXMLPath, deployPath, nodeName, serverName)
	elif (task == "deploy_only_app_edition"):
		deploy_only_app_edition(serverXML, deployPath, nodeName, serverName)
	else:
		print "deployment option: " + task + " not found"
		usage() 

#endDef

        
# call main	        
main()   
