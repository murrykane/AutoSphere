#--------------------------------------------------------------
# initialize global websphere classes
#--------------------------------------------------------------
import sys, time
AdminConfig = sys._getframe(1).f_locals['AdminConfig']
AdminApp = sys._getframe(1).f_locals['AdminApp']
AdminControl = sys._getframe(1).f_locals['AdminControl']
AdminTask = sys._getframe(1).f_locals['AdminTask']
Help = sys._getframe(1).f_locals['Help']


#************************************************************
# setAminRefs: allows an api execution of the base functions 
#************************************************************
def setAdminRefs(adminTuple):
	global AdminConfig, AdminControl
	global AdminTask, AdminApp
	global AdminUtilities
	#(AdminConfig, AdminControl, AdminTask, AdminApp, AdminUtilities) = adminTuple

#********************************************************
# startServer: 
#********************************************************
def startServer(nodeName, serverName):
	
	
	#--------------------------------------------------------------
        #     -- is a server by this name already running on the node? 
        #--------------------------------------------------------------
        print "checking to see if server " + serverName + " is running on node " + nodeName
        runningServer = AdminControl.completeObjectName("type=Server,node=" + nodeName + ",process=" + serverName + ",*")
   		
   	if len(runningServer) > 0:
      		print "server " + serverName + " is running on node " + nodeName
	else: 
      		print "server is not running"
      		print " " 
      		print "starting server " + serverName + "..."
                rc = AdminControl.startServer(serverName, nodeName)
                print " "
                print rc
                                
        return 


#********************************************************
#jvmJavaCore 
#********************************************************
def jvmJavaCore(nodeName, serverName):


        #--------------------------------------------------------------
        #     -- is a server by this name already running on the node?
        #--------------------------------------------------------------
        jvm = AdminControl.completeObjectName('type=JVM,process='+serverName+',*')
        objName = AdminControl.makeObjectName (jvm)
        AdminControl.invoke(jvm, 'dumpThreads')

#********************************************************
#jvmHeapDump
#********************************************************
def jvmHeapDump(nodeName, serverName):


        #--------------------------------------------------------------
        #     -- is a server by this name already running on the node?
        #--------------------------------------------------------------
        jvm = AdminControl.completeObjectName('type=JVM,process='+serverName+',*')
        objName = AdminControl.makeObjectName (jvm)
        AdminControl.invoke(jvm, 'generateHeapDump')



#********************************************************
# stopServer: 
#********************************************************
def stopServer(nodeName, serverName):
	
	
	#--------------------------------------------------------------
        #     -- is a server by this name already running on the node? 
        #--------------------------------------------------------------
	print "checking to see if server " + serverName + " is running on node " + nodeName
	runningServer = AdminControl.completeObjectName("type=Server,node=" + nodeName + ",process=" + serverName + ",*")
	print "running server" + runningServer
   		
	if len(runningServer) > 0:
		print "server " + serverName + " is running on node " + nodeName
		print "stopping server " + serverName + "..."
		print " "
		try:
			_excp_ = 0		
			rc = AdminControl.stopServer(serverName, nodeName)
			_excp_ = 0 #reset (in case of nested exceptions)

		except:
			_type_, _value_, _tbck_ = sys.exc_info()
			_excp_ = 1
			
		temp = _excp_
		if (temp > 0):
			print "stopping server: exception trying to stop "+serverName+" on "+ nodeName
			return 
		else:
			if (len(rc) > 0):
				print " "
				print rc
			#endIf 
		#endElse 						
	else:
		print "server " + serverName + " is already stopped on node " + nodeName
		return 


#********************************************************
# startCluster: 
#********************************************************
def startCluster(cellName, clusterName):

        cluster = AdminControl.completeObjectName("type=Cluster,cell=" + cellName + ",name=" + clusterName + ",*")
   		
   	if len(cluster) > 0:
      		print "starting cluster " + clusterName + "..."
                #rc = AdminControl.invoke(clusterName, 'start')
                #print " "
                #print rc

		clusterId = AdminConfig.getid("/ServerCluster:" + clusterName + "/")
		clusterMembersId = AdminConfig.showAttribute(clusterId, "members")
		clusterMembersId = clusterMembersId[1:-1]
                
                for clusterMemberId in clusterMembersId.split():
                	nodeName = AdminConfig.showAttribute( clusterMemberId, "nodeName")
                	serverName = AdminConfig.showAttribute( clusterMemberId, "memberName")
                	print " "
                	print " --> starting server: ", serverName
                        startServer(nodeName, serverName)
                #endfor
        return 

#********************************************************
# stopCluster: 
#********************************************************
def stopCluster(cellName, clusterName):
        cluster = AdminControl.completeObjectName("type=Cluster,cell=" + cellName + ",name=" + clusterName + ",*")
   		
   	if len(cluster) > 0:
      		print "stopping cluster " + clusterName + "..."
                #rc = AdminControl.invoke(cluster, 'stop')
                #print " "
                #print rc
                
                clusterId = AdminConfig.getid("/ServerCluster:" + clusterName + "/")
                clusterMembersId = AdminConfig.showAttribute(clusterId, "members")
                clusterMembersId = clusterMembersId[1:-1]
                
                for clusterMemberId in clusterMembersId.split():
                	nodeName = AdminConfig.showAttribute( clusterMemberId, "nodeName" )
                	serverName = AdminConfig.showAttribute( clusterMemberId, "memberName" )
                	print " --> stopping server: ", serverName
                	stopServer(nodeName, serverName)
                #endFor
                                                
        return 
#********************************************************
# rippleStart
#********************************************************
def rippleStart(cellName, clusterName):

        cluster = AdminControl.completeObjectName("type=Cluster,cell=" + cellName + ",name=" + clusterName + ",*")

        if len(cluster) > 0:
                print " ------------ ripple starting cluster: " + clusterName + " -----------------------"
                print " ---------------------------------------------------------------------------"
                clusterId = AdminConfig.getid("/ServerCluster:" + clusterName + "/")
                clusterMembersId = AdminConfig.showAttribute(clusterId, "members")
                clusterMembersId = clusterMembersId[1:-1]

                for clusterMemberId in clusterMembersId.split():
                        nodeName = AdminConfig.showAttribute( clusterMemberId, "nodeName")
                        serverName = AdminConfig.showAttribute( clusterMemberId, "memberName")
                        print " "
                        print " --> stopping server: ", serverName
                        stopServer(nodeName, serverName)

                        print " "
                        print " "
                        print " --> starting server: ", serverName
                        startServer(nodeName, serverName)
                #endfor

        print " ------------ ripple starting cluster: " + clusterName + " -----------------------"
        print " ---------------------------------------------------------------------------"
        return
#def
#********************************************************
# checkApplicationRunning: 
#********************************************************
def checkApplicationRunning(nodeName, serverName, appName):

	print "checkApplicationRunning: "+nodeName+" "+serverName+" "+appName
	appID = ""
	
	try:
		_excp_ = 0
		appID = AdminControl.completeObjectName("type=Application,node="+nodeName+",Server="+serverName+",name="+appName+",*" )
		_excp_ = 0 #reset (in case of nested exceptions)
	except:
		_type_, _value_, _tbck_ = sys.exc_info()
		_excp_ = 1
	#endTry
	temp = _excp_
	length = len(appID)
	print "checkApplicationRunning: appID.length="+str(length)
	
	retries = 0
	while (( retries < 20 )  and ( length == 0 ) ):
		retries = retries+1
		
		try:
			_excp_ = 0
			time.sleep(15)
			appID = AdminControl.completeObjectName("type=Application,node="+nodeName+",Server="+serverName+",name="+appName+",*" )
			_excp_ = 0 #reset (in case of nested exceptions)
			
		except:
			_type_, _value_, _tbck_ = sys.exc_info()
			_excp_ = 1
		#endTry 
		temp = _excp_
		
		#if (temp > 0):
			#print "checkApplicationRunning: Exception trying to getID for "+appName+" "+nodeName+" "+serverName
		#endIf 
		
		length = len(appID)
		
	#endWhile 
	
	if (length > 0):
		print "checkApplicationRunning: "+appName+" is STARTED."
	else:
		print "checkApplicationRunning: "+appName+" "+nodeName+" "+serverName+" DID NOT START."
	#endElse
	
	return length
#********************************************************
# startApplication:
#********************************************************
def startApplication(nodeName, serverName, appName):
	print "StartApplication: appName="+appName+" nodeName="+nodeName+" serverName="+serverName+" ..."
	appMgrID = AdminControl.queryNames("type=ApplicationManager,node="+nodeName+",process="+serverName+",*" )
	length = len(appMgrID)
	print "StartApplication: appMgrID.length="+str(length)+" appMgrID="+appMgrID
	if (length >= 1):
		print "startApplication: starting "+appName+"  ..."
		try:
			_excp_ = 0
			started = AdminControl.invoke(appMgrID, "startApplication", appName )
			_excp_ = 0 #reset (in case of nested exceptions)
		except:
			_type_, _value_, _tbck_ = sys.exc_info()
			_excp_ = 1
		#endTry 
		temp = _excp_
		if (temp > 0):
			print "startApplication: Exception trying to start "+appName+" "+nodeName+" "+serverName
			return 
		else:
			if (len(started) > 0):
				print started
			#endIf 
		#endElse 
	else:
		print "startApplication: appMgr ERROR, NOT ACCESSABLE, cannot start "+appName
		sys.exit(1)
	#endElse 
	checkApplicationRunning(nodeName, serverName, appName )
	
	

#********************************************************
# stopApplication: TODO
#********************************************************
#def stopApplication(): 


#********************************************************
# syncNode: 
#********************************************************
def syncNode(nodeName):

	print "--> start: synchronizing node"
	syncNode = AdminControl.completeObjectName('type=NodeSync,node='+nodeName+',*')
	status = AdminControl.invoke(syncNode, 'sync')
	
	if (status == "true"):
		print "--> complete: synchronizing node"
	else:
		retries = 0
		while (( retries < 10 )  and ( status != "true" ) ):
			retries = retries+1
		
			try:
				_excp_ = 0
				time.sleep(5)
				print "--> waiting 5 seconds on node"
				status = AdminControl.invoke(syncNode, 'sync')
				_excp_ = 0 #reset (in case of nested exceptions)
			
			except:
				_type_, _value_, _tbck_ = sys.exc_info()
				_excp_ = 1
			#endTry 
			
			temp = _excp_		
		#endWhile 	
		
		if (status == "true"):
			print "--> complete: synchronizing node, retries = "+retries
		#endIf
	#endIf	
#def

#********************************************************
# updateJvmPorts: 
#********************************************************
def portProcessor(serverName, nodeName, host, endPointName, endPoint):
	print "--> updating " + endPointName + ":", endPoint, host
	AdminTask.modifyServerPort (''+serverName+'', '[-nodeName '+nodeName+' -endPointName '+endPointName+' -host '+host+' -port '+endPoint+']')
	AdminConfig.save()
#endDef
        
def portProcessorShared(serverName, nodeName, host, endPointName, endPoint):
	print "--> updating shared " + endPointName + ":", endPoint, host
	AdminTask.modifyServerPort (''+serverName+'', '[-nodeName '+nodeName+' -endPointName '+endPointName+' -host '+host+' -port '+endPoint+' -modifyShared]')
	AdminConfig.save()
#endDef

def getNodeServerVal():
	import  java.lang.System  as  sys  
	lineSeparator = sys.getProperty('line.separator')

	list = []
	cells = AdminConfig.list('Cell').split()
	for cell in cells:
		nodes = AdminConfig.list('Node', cell).split()
		for node in nodes:
			cname = AdminConfig.showAttribute(cell, 'name')
			nname = AdminConfig.showAttribute(node, 'name')
			servs = AdminControl.queryNames('type=Server,cell=' + cname +',node=' + nname + ',*').split()
			for server in servs:
				serverName = AdminControl.getAttribute(server, 'name')
				list.append(nname+', '+serverName)
				return list
				print "inside function sending ->", list
			#endFor
		#endFor
	#endFor
#endDef

def matchNodeVal(nodeIn):
	print "finding match for node -->", nodeIn
	cells = AdminConfig.list('Cell').split()
	for cell in cells:
		nodes = AdminConfig.list('Node', cell).split()
		for node in nodes:
			cname = AdminConfig.showAttribute(cell, 'name')
			nname = AdminConfig.showAttribute(node, 'name')
			print "nodeName --> ", nname
			if nname.find(nodeIn) == 0:
				print "found node --", nname
				return nname
			#endIf
		#endFor
	#endFor
#endDef
