#********************************************************
# purpose: websphere re-usable administrative scripts
# author: jcanepa
# version: 1.0
#********************************************************
 

#import
import sys
sys.path.append("C:\\Documents and Settings\\jcanep01\\AST\\workspace\\admin\\jython")
import java.io
import Xparser
import XPathCount 

#--------------------------------------------------------------
# initialize global websphere classes
#--------------------------------------------------------------
global AdminConfig
global AdminControl
global AdminApp
global AdminControl
global AdminTask


def portProcessor(serverName, nodeName, host, endPointName, endPoint):
        print " updating " + endPointName + ":", endPoint, host
        AdminTask.modifyServerPort (''+serverName+'', '[-nodeName '+nodeName+' -endPointName '+endPointName+' -host '+host+' -port '+endPoint+']')
        AdminConfig.save()

def portProcessorShared(serverName, nodeName, host, endPointName, endPoint):
        print " updating shared " + endPointName + ":", endPoint, host
        AdminTask.modifyServerPort (''+serverName+'', '[-nodeName '+nodeName+' -endPointName '+endPointName+' -host '+host+' -port '+endPoint+' -modifyShared]')
        AdminConfig.save()

#********************************************************
# updateJvmPorts: 
#********************************************************
def updatePorts(serverName, nodeName, serverConfigPath):
	
	
	#--------------------------------------------------------------
        #     -- additional variables
        #--------------------------------------------------------------
	host = Xparser.xFind(serverConfigPath, "//websphere/server/@host")
        server = AdminConfig.getid('/Server:'+serverName+'/')
        ns = AdminConfig.list('NameServer', ''+server+'')

	http = Xparser.xFind(serverConfigPath, "//websphere/server/jvmPorts/@http")
	jmsSec = Xparser.xFind(serverConfigPath, "//websphere/server/jvmPorts/@jmsSec")
	ipcPort = Xparser.xFind(serverConfigPath, "//websphere/server/jvmPorts/@ipcPort")

        
	#--------------------------------------------------------------
        #     -- process ports based on build sheet 
        #--------------------------------------------------------------
        print "configuring server:", serverName
        print "start: update ports"
        
        # HTTP - Web Container
        #print "updating WEB_CONTAINER:"
        
        # BOOTSTRAP_ADDRESS
        portProcessor(serverName, nodeName, host, "BOOTSTRAP_ADDRESS", (Xparser.xFind(serverConfigPath, "//websphere/server/jvmPorts/@bootstrap")))
        # SOAP
        portProcessor(serverName, nodeName, host, "SOAP_CONNECTOR_ADDRESS", (Xparser.xFind(serverConfigPath, "//websphere/server/jvmPorts/@soap")))   
        # SAS_SSL_SERVERAUTH_LISTENER_ADDRESS
        portProcessor(serverName, nodeName, host, "SAS_SSL_SERVERAUTH_LISTENER_ADDRESS", (Xparser.xFind(serverConfigPath, "//websphere/server/jvmPorts/@sasSsl")))
        # CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS
        portProcessor(serverName, nodeName, host, "CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS", (Xparser.xFind(serverConfigPath, "//websphere/server/jvmPorts/@csiv2ServerAuth")))
        # CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS
        portProcessor(serverName, nodeName, host, "CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS", (Xparser.xFind(serverConfigPath, "//websphere/server/jvmPorts/@csiv2MutualAuth")))
        # DCS_UNICAST_ADDRESS -modifiedShared paramater needs to be specified
        portProcessorShared(serverName, nodeName, host, "DCS_UNICAST_ADDRESS", (Xparser.xFind(serverConfigPath, "//websphere/server/jvmPorts/@uniAddress")))
        # SIP_DEFAULTHOST
        portProcessorShared(serverName, nodeName, host, "SIP_DEFAULTHOST", (Xparser.xFind(serverConfigPath, "//websphere/server/jvmPorts/@sip")))
        #SIP_DEFAULTHOST_SECURE -modifiedShared paramater needs to be specified
        portProcessorShared(serverName, nodeName, host, "SIP_DEFAULTHOST_SECURE", (Xparser.xFind(serverConfigPath, "//websphere/server/jvmPorts/@sipSec")))
        # SIB_ENDPOINT_ADDRESS -modifiedShared paramater needs to be specified
        portProcessorShared(serverName, nodeName, host, "SIB_ENDPOINT_ADDRESS", (Xparser.xFind(serverConfigPath, "//websphere/server/jvmPorts/@sib")))
        # SIB_MQ_ENDPOINT_ADDRESS
        portProcessor(serverName, nodeName, host, "SIB_MQ_ENDPOINT_ADDRESS", (Xparser.xFind(serverConfigPath, "//websphere/server/jvmPorts/@mqEndpoint")))
        # SIB_MQ_ENDPOINT_SECURE_ADDRESS
        portProcessor(serverName, nodeName, host, "SIB_MQ_ENDPOINT_SECURE_ADDRESS", (Xparser.xFind(serverConfigPath, "//websphere/server/jvmPorts/@mqEndpointSec")))
        # ORB_LISTENER_ADDRESS
        portProcessor(serverName, nodeName, host, "ORB_LISTENER_ADDRESS", (Xparser.xFind(serverConfigPath, "//websphere/server/jvmPorts/@orb")))
        
        
        #--------------------------------------------------------------
        #     -- save the configuration
        #--------------------------------------------------------------
        AdminConfig.save()
        print "end: update ports"    

#********************************************************
# startServer: 
#********************************************************
def startServer(nodeName, serverName):
	
	
	#--------------------------------------------------------------
        #     -- is a server by this name already running on the node? 
        #--------------------------------------------------------------
        print "checking to see if server " + serverName + " is running on node " + nodeName
        runningServer = AdminControl.completeObjectName("type=Server,node=" + nodeName + ",process=" + serverName + ",*")
   		
   	if len(runningServer) > 0:
      		print "server " + serverName + " is running on node " + nodeName
	else: 
      		print "server is not running"
      		print " " 
      		print "starting server " + serverName + "..."
                rc = AdminControl.startServer(serverName, nodeName)
                print " "
                print rc
                                
        return 

#********************************************************
# stopServer: 
#********************************************************
def stopServer(nodeName, serverName):
	
	
	#--------------------------------------------------------------
        #     -- is a server by this name already running on the node? 
        #--------------------------------------------------------------
	print "checking to see if server " + serverName + " is running on node " + nodeName
	runningServer = AdminControl.completeObjectName("type=Server,node=" + nodeName + ",process=" + serverName + ",*")
	print "running server" + runningServer
   		
	if len(runningServer) > 0:
		print "server " + serverName + " is running on node " + nodeName
		print "stopping server " + serverName + "..."
		print " "
		rc = AdminControl.stopServer(serverName, nodeName)
		print " "
		print rc
	else:
		print "server " + serverName + " is already stopped on node " + nodeName
		return 

#********************************************************
# getServerSpecs: 
#********************************************************
def getServerSpecs(envTarget):
	
	serverConfigPath = envTarget+".xml"
	#applicationConfigPath = open("c:/Documents and Settings/jcanep01/AST/workspace/admin/xml/application/application.xml", "r")
	
	count = XPathCount.getCount(serverConfigPath, "//websphere/server/@name") 
	
	if count > 0:
		#print "there is only one server:"
		serverName = Xparser.xFind(serverConfigPath, "//websphere/server/@name")
	        nodeName = Xparser.xFind(serverConfigPath, "//websphere/server/@nodeName")
	        
	else: 
		print "there is more than one value"
	
	updatePorts(serverName, nodeName, serverConfigPath)
	
	
#********************************************************
# main: 
#********************************************************

def main():

	rootPath = "c:/Documents and Settings/jcanep01/AST/workspace/admin/xml/"
	environmentType = sys.argv[0]
	environment = sys.argv[1]
	
	
	getServerSpecs(rootPath+environmentType+"/"+environment)
	#deployApplication(envDoc)
        
        
main()	 