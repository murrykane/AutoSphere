import sys
import java.io
import Xparser
import XPathCount
from com.ibm.ISecurityUtilityImpl import PasswordUtil

#********************************************************
#  configure SIBus 
#********************************************************
def configureSIBus(serverXML, taskName, AdminControl, AdminConfig, AdminTask):

        #check if required configuration
        configure = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/@configure")
	if (configure == "false"):
		print "--> configure set to false ... skipping"
		return 0	
	
	cellName = AdminControl.getCell()
	
	#Get SIBus List 
	sibCount = XPathCount.getCount(serverXML, "//websphere/server/resources/sibs/*", "")

	i = 1
	sib = ""
	while i < sibCount+1:
		sibNum = ("sib"+str(i))

		sibName = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/@name")
		sibId = AdminConfig.getid('/SIBus:'+sibName+'/')

		if (taskName == "createSIB"):			 
			if (sibId == ""):	
				print "--> start: create sibus"
				print "-->   creating sibus:", sibName 

				#create sibus 
				AdminTask.createSIBus('[-bus '+sibName+' -busSecurity false]')
				AdminConfig.save()

				print "--> end: create sibus"
				print ""
			else:
				print "--> skip sibus creation, bus already exists:", sibName
				print ""
			#endIf
	
		elif (taskName == "updateSIB"):
			if  (sibId != ""):
				print "--> start: update sibus"
				print "-->   updating sibus:", sibName 

				#update sibus 
				AdminTask.modifySIBus('[-bus '+sibName+' -busSecurity false]')
				AdminConfig.save()

				print "--> end: update sibus"
				print ""
			else:
				print "--> skip sibus update, bus does not exists:", sibName
			#endIf
		
		else:
			if  (sibId != ""):
				print "--> start: delete sibus"
				print "-->   deleting sibus:", sibName 

				#create sibus 
				AdminTask.deleteSIBus('[-bus '+sibName+']')
				AdminConfig.save()

				print "--> end: delete sibus"
				print ""
			else:
				print "--> skip sibus deletion, bus does not exists:", sibName
				print ""
			#endIf

		#endIf

		i = i+1
	#endWhile
#endDef

#********************************************************
#  configure sibus members 
#********************************************************
def configureSIBmembers(serverXML, taskName, AdminControl, AdminConfig, AdminTask, nodeName, serverName):
       
	#check if required configuration
        configure = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/@configure")
	if (configure == "false"):
		print "--> configure set to false ... skipping"
		return 0
		
	#Get SIBus List 
	sibCount = XPathCount.getCount(serverXML, "//websphere/server/resources/sibs/*", "")

	i = 1
	sib = ""
	while i < sibCount+1:
		sibNum = ("sib"+str(i))

		sibName = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/@name")
		sibId = AdminConfig.getid('/SIBus:'+sibName+'/')
		memCount = XPathCount.getCount(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/members/*", "")

		if (sibId != ""):

			x = 1
			mem = ""

			while x < memCount+1:

				memNum = ("mem"+str(x))

				memType = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/members/"+memNum+"/@type")
				policy = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/members/"+memNum+"/@policy")
				storeType = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/members/"+memNum+"/@storeType")
				filestoreDir = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/members/"+memNum+"/@fileStoreDir")
				jndi = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/members/"+memNum+"/@jndi")
				schema = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/members/"+memNum+"/@schema")
				auth = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/members/"+memNum+"/@auth")
				#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
				#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
				clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")

                                logSize = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/members/"+memNum+"/@logSize")
                                logDirectory = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/members/"+memNum+"/@logDirectory")
                                minPermanentStoreSize = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/members/"+memNum+"/@minPermanentStoreSize")
                                maxPermanentStoreSize = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/members/"+memNum+"/@maxPermanentStoreSize")
                                permanentStoreDirectory = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/members/"+memNum+"/@permanentStoreDirectory")
                                minTemporaryStoreSize = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/members/"+memNum+"/@minTemporaryStoreSize") 
                                maxTemporaryStoreSize = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/members/"+memNum+"/@maxTemporaryStoreSize")
                                temporaryStoreDirectory = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/members/"+memNum+"/@temporaryStoreDirectory")
                                print "min perm store size :" + minPermanentStoreSize
                                print "max perm store size :" + maxPermanentStoreSize

				if (memType == "server"):
					member = serverName
					memargs = ' -node '+nodeName+' -server '+serverName
					if (storeType == "filestore"):
						args = '[-bus '+sibName +memargs+' -fileStore -permanentStoreDirectory '+permanentStoreDirectory+'' 
						args +=' -temporaryStoreDirectory '+temporaryStoreDirectory+' -logDirectory '+logDirectory+'' 
						args +='-logSize '+logSize+' -minPermanentStoreSize '+minPermanentStoreSize+' -maxPermanentStoreSize '+maxPermanentStoreSize+' -unlimitedPermanentStoreSize false '
						args +='-minTemporaryStoreSize '+minTemporaryStoreSize+' -maxTemporaryStoreSize '+maxTemporaryStoreSize+' -unlimitedTemporaryStoreSize false]'
					else:
						args = '[-bus '+sibName +memargs+' -dataStore -datasourceJndiName '+jndi+']'
						args +=' -schemaName '+schema+' -authAlias '+auth+']'

					#endIf

				elif (memType =="cluster"):
					member = clusterName
					memargs = ' -cluster '+clusterName
					if (storeType == "filestore"):
						args = '[-bus '+sibName +memargs+' -fileStore -permanentStoreDirectory '+permanentStoreDirectory+'' 
						args +=' -temporaryStoreDirectory '+temporaryStoreDirectory+' -logDirectory '+logDirectory+''
						args +=' -logSize '+logSize+' -minPermanentStoreSize '+minPermanentStoreSize+' -maxPermanentStoreSize '+maxPermanentStoreSize+' -unlimitedPermanentStoreSize false '
						args +='-minTemporaryStoreSize '+minTemporaryStoreSize+' -maxTemporaryStoreSize '+maxTemporaryStoreSize+' -unlimitedTemporaryStoreSize false]'

					else:
						args ='[-bus '+sibName +memargs+'  -dataStore -datasourceJndiName '+jndi
						args +=' -schemaName '+schema+' -authAlias '+auth+']'
					#endIf
				else:
					print "--> MQ Type is not a supported member by the framework"

				#endIf
			
				memList = AdminTask.listSIBusMembers('[-bus '+sibName+']').splitlines()

				memberExists = "false"

				for mem in memList:
					if (memType == "server"):
						memberName = AdminConfig.showAttribute(mem, "server")
						if (memberName == serverName):
							memberExists = "true"
						#endIf
					else:
						memberName = AdminConfig.showAttribute(mem, "cluster")
						if (memberName == clusterName):
							memberExists = "true"
						#endIf

					#endIf
					
				#endFor

				if (taskName == "addMember"):
					if (memberExists == "false"):
						print "--> start: add sibus member"   
						print "--> 	adding sibus member: sibus="+sibName+", member="+member 

						AdminTask.addSIBusMember(args)
						AdminConfig.save()

						print "--> end: add sibus member: sibus"
					else:
						print "--> skip: sibus member already exists: sibus="+sibName+", member="+member

				elif (taskName == "removeMember"):
					if (memberExists == "true"):
						print "--> start: delete sibus member"   
						print "--> 	deleting sibus member: sibus="+sibName+", member="+member 

						AdminTask.removeSIBusMember('[-bus '+sibName +memargs+']')
						AdminConfig.save()

						print "--> end: delete sibus member: sibus"
					else:
						print "--> skip: sibus member doesn't exists: sibus="+sibName+", member="+member
				#endIf
				x = x+1
			#endWhile
		#endIf
		i =i+1
	#endWhile
#endDef


#********************************************************
#  configure sibus destinations 
#********************************************************
def configureSIBDestinations(serverXML, taskName, AdminControl, AdminConfig, AdminTask, nodeName, serverName):

        #check if required configuration
        configure = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/@configure")
	if (configure == "false"):
		print "--> configure set to false ... skipping"
		return 0

	#Get SIBus List 
	sibCount = XPathCount.getCount(serverXML, "//websphere/server/resources/sibs/*", "")

	i = 1
	sib = ""
	while i < sibCount+1:
		sibNum = ("sib"+str(i))

		sibName = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/@name")
		sibId = AdminConfig.getid('/SIBus:'+sibName+'/')
		desCount = XPathCount.getCount(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/destinations/*", "")

		if (sibId != ""):

			x = 1
			dest = ""

			while x < desCount+1:

				desNum = ("dest"+str(x))

				name = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/destinations/"+desNum+"/@name")
				type = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/destinations/"+desNum+"/@type")
				scope = Xparser.xFind(serverXML, "//websphere/server/resources/sibs/"+sibNum+"/destinations/"+desNum+"/@scope")

				#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
				#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
				clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")

				desList = AdminTask.listSIBDestinations('[-bus '+sibName+' -type '+type+']').splitlines()
				destExists = "false"

				args = '[-bus '+sibName+' -name '+name
				
				if (scope == "server"):
					args += ' -node '+nodeName+' -server '+serverName
				else:
					args += ' -cluster '+clusterName 

				for item in desList:
					if (type == "Queue"):
						destName = AdminConfig.showAttribute(item, "identifier")
						if (destName == name):
							destExists = "true"
						#endIf
					else:
						print "--> skip: destination creations, type not supported" 

					#endIf
					
				#endFor

				if (type == "Queue"):
					args += ' -type QUEUE ]'
				elif (type == "Foregin"):
					args += ' -type Foregin ]'
				elif (type == "TopicSpace"):
					args += ' -type TopicSpace ]'


				if (taskName == "createDestination"):
					if (destExists == "false"):
						print "--> start: create sibus destination"   
						print "--> 	creating sibus destination", name

						AdminTask.createSIBDestination(args)
						AdminConfig.save()

						print "--> end: create sibus destination"  
					else:
						print "--> skip: sib destination already exists", name
				elif (taskName == "deleteDestination"):
					if (destExists == "true"):
						print "--> start: delete sibus destination"   
						print "--> 	deleting sibus destination", name

						AdminTask.deleteSIBDestination('[-bus '+sibName+' -name '+name+']')
						AdminConfig.save()

						print "--> end: delete sibus destination"  
					else:
						print "--> skip: sib destination doesn't exists", name

				#endIf
				x = x+1
			#endWhile
		#endIf
		i =i+1
	#endWhile
#endDef


#********************************************************
# script usage: 
#********************************************************

def usage():
	print " "
        print " "
        print " usage: python sibus.py [option] [environment type] [instance]"
        print " example: python sibus.py createJAAS nxsa dev01_nx"
        print " "
        print " current options:"
        print " ----------------"
        print " 1) createSIB [steps: creates sibus]"
        print " 2) updateSIB [steps: updates sibus]"
        print " 3) deleteSIB [steps: deletes sibus]"
        print " " 
#endDef
        
#********************************************************
# main: 
#********************************************************

def main():
        
	print " "
	print " "
        

	# check arguments
	if len(sys.argv) < 3:
		usage()
		sys.exit(1)
	#endIf
	

        # expected input	
        shieldHome = sys.argv[0]
        envType = sys.argv[1] 
        instance = sys.argv[2]
        task = sys.argv[3]


        # variables
	xmlBasePath = (shieldHome+"/xml/")
        
        #xml path
	serverXML = (xmlBasePath+envType+"/"+instance+".xml")


	if (task == "createSIB"):
		configureSIBus(serverXML, "createSIB", nodeName, serverName)
	elif (task == "updateSIB"):
		configureSIBus(serverXML, "updateSIB", nodeName, serverName)
	elif (task == "deleteSIB"):
		configureSIBus(serverXML, "deleteSIB", nodeName, serverName)
	elif (task == "addSIBmember"):
		configureSIBmembers(serverXML, "addMember", nodeName, serverName)
	elif (task == "removeSIBmember"):
		configureSIBmembers(serverXML, "removeMember", nodeName, serverName)
	elif (task == "createSIBdestination"):
		configureSIBDestinations(serverXML, "createDestination", nodeName, serverName)
	elif (task == "deleteSIBdestination"):
		configureSIBDestinations(serverXML, "deleteDestination", nodeName, serverName)
	else:
		print "option: " + task + " not found"
		usage()
	#endIf 
        
#endDef
# call main
#main()   
        
