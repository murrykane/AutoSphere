import sys, os
from java.lang import System
import StringIO
from java.lang import ProcessBuilder
from java.io import InputStreamReader
from java.io import BufferedReader
from java.io import File

class wasManaged:
    def __init__(self, ARGS):
        self.args = ARGS
        self.userPath = System.getProperty("user.install.root") # in apm/agent*
        self.ManagedNodes = AdminTask.listManagedNodes().splitlines()

    def wasTask(self):
        for MNode in self.ManagedNodes:
            hname, info, srvname = self.unvealNode(MNode)
            if hname == None and info == None and srvName == None:
                continue 
            else:
                connection = self.wasSSHCheckpoint(hname)
                if connection: 
                    continue
                else:
                    app = self.appsBuild(hname)
                    subcmd = "find /apps/%s/apm/agent -type f -name was-agent.sh" % app
                    jcmd = ["ssh", hname, subcmd]
                    #print "[command list] > ",jcmd
                    result = self.processBuild(jcmd)
                    if result.find("was-agent.sh") == -1 or result == "": 
                        print "[Skipped] was-agent not installed in this app_Server [%s]" % hname
                        # meaning was agent in not installed or uninstalled
                        continue 
            remapp = app
            #--------------------------------------------------------------- 
            print ""
            print "             [Application Server]        "
            print "[HOSTNAME] . . . . . . . . . . . . . [%s]" % hname
            print "[TYPE] . . . . . . . . . . . . . . . [%s]" % info
            print "[SERVER] . . . . . . . . . . . . . . [%s]" % srvname
            print "[NODENAME] . . . . . . . . . . . . . [%s]" % MNode
            print "[COMMAND] . . . . . . . . . . . . .  [%s]" % self.args
            print ""
            if self.args == "start":
                 self.wasSTART(hname,remapp)
            elif self.args == "stop":
                 self.wasSTOP(hname,remapp)
            else:
                 sys.stdout.write("[Invalid option received] start or stop\n")
                 sys.exit(0)

            print ""
	    print "= " * 30

        print ""
        print "[end of line] . . . . . . . .[fin]"
        

    def wasSTART(self, startHNAME, remAPP):
        z = self.wasSTATUS(startHNAME, remAPP)
        if not z:
            print "[Agent was already started]"
            print "[successfull] APM_WAS START for %s . . . . done" % startHNAME
        else:
            print "Starting Agent"
            print "invoke ws-agent.sh start"    
            starCMD = "/apps/%s/apm/agent/bin/was-agent.sh start" % remAPP
            cmdOP = ["ssh",startHNAME,starCMD]
            #print "[command in list] >>> %s" % cmdOP
            result = self.processBuild(cmdOP)
            if result != "":
                if result.find("started") != -1:
                    print result[result.find("started")]
                else:
                   print "[sucessfull] APM_WAS START for %s . . . . done" % stopHNAME
            else:
                print "[Attempt to START apm_agent for %s . . . . [Failed]]" % stopHNAME

    def wasSTOP(self,stopHNAME, remAPP):
        s = self.wasSTATUS(stopHNAME, remAPP)
        if not s:
            print "Stopping Agent"
            print "invoke ws-agent.sh stop"
            stopCMD = "/apps/%s/apm/agent/bin/was-agent.sh stop" % remAPP
            cmdOP = ["ssh",stopHNAME,stopCMD]
            #print "[command in list] >>> %s" % cmdOP
            result = self.processBuild(cmdOP)
            if result != "":
                if result.find("gracefully") != -1:
                    print result[result.find("gracefully")]
                elif result.find("force") != -1:
                    print result[result.find("force")]
                else:
                   print "[sucessfull] APM_WAS STOPPED for %s . . . . done" % stopHNAME 
            else:
                print "[Attempt to STOP apm_agent for %s . . . . [Failed]]" % stopHNAME  
            
        else:
            print "[Agent was already stopped]"
            print "[successfull] APM_WAS STOPPED for %s . . . . done" % stopHNAME




    def wasSTATUS(self,statHNAME,remAPP):
        print "Checking Agent Status"
        print "invoke ws-agent.sh status"
        subCMD = "/apps/%s/apm/agent/bin/was-agent.sh status" % remAPP
        wasStat = ["ssh",statHNAME,subCMD]
        #print "[command in list] >>> %s" % wasStat
        result = self.processBuild(wasStat)
        stat = 0
        if result != "":
            if result.find("Agent is running") != -1:
                print result[result.find("Agent is running")]
            elif result.find("Connected") != -1:
                print result[result.find("Connected")]
            elif result.find("Connecting") != -1:
                print result[result.find("Connecting")]
            else:
                stat = 1
        else:
            stat = 1

        return stat

    def unvealNode(self, MNode):
        hostname = None
        info = None
        servername = None
        serverID = AdminConfig.getid("/Node:%s/Server:/" % MNode).splitlines()
        nodeID = AdminConfig.getid("/Node:%s" % MNode)
        for srvAsItem in serverID: 
            # discard nodeagent string (Incase)
            if srvAsItem.find("nodeagent") == -1:
                srvVer = srvAsItem
        info = AdminConfig.showAttribute(srvVer, 'serverType') #servertype
        if info != "WEB_SERVER":
            hostname = AdminConfig.showAttribute(nodeID, "hostName") #hostName
            try:
                nodeBean = AdminConfig.getObjectName(srvVer)
                SRVname = AdminControl.getAttribute(nodeBean, 'name') #servername
            except:
                SRVname = AdminConfig.showAttribute(srvVer, 'name') #servername
            return hostname, info, SRVname 
        else:
            # None, None, None
            return hostname, info, servername

    def wasSSHCheckpoint(self, host):
        sshcmd = "ssh -q -o BatchMode=yes -o ConnectTimeout=10 %s exit" % host
        #print "[exec] %s" % sshcmd
        connect = os.system(sshcmd)
        if connect > 0:
                return 1
        else:
                return 0
    
    def processBuild(self, jcmd):
        SIOS = StringIO.StringIO()
        proc = ProcessBuilder(jcmd)
        proc.directory(File(self.userPath))
        proc.redirectErrorStream()
        outputStream = proc.start()
	br = BufferedReader(InputStreamReader(outputStream.getInputStream()))
        line = br.readLine()
        while line != None:
            SIOS.write(line + "\n")
            line = br.readLine()
        try:
            outStr = SIOS.getvalue()
        except:
            outStr = ""
        outputStream.waitFor()
        br.close()
        SIOS.flush()
        SIOS.close()
        return outStr

            
    def appsBuild(self, finalForm):
          k, l = finalForm.split(".", 1)
          h = l.upper()
          apps = "%s-%s" % (h, k)
          return apps
    

if __name__ == "__main__":
    if len(sys.argv) == 1:
        if sys.argv[0] == "start":
            ARGS = sys.argv[0]
        elif sys.argv[0] == "stop":
            ARGS = sys.argv[0]
        else:
            print "================================="
            print "Invalid Option [UNKNOWN]         "
            print "Choose either['start', or 'stop']"
            print "================================ "
            sys.exit(0)
    else:
        print "================================================="
        print "[USAGE]:        invoke by wsadmin.sh             "
        print "             wasAPM_managed.py [arguments]       "
        print "[REQUIRED] Argument type STR ['start', or 'stop']"
        print "================================================="     
        sys.exit(0)

    wasa = wasManaged(ARGS)
    wasa.wasTask()