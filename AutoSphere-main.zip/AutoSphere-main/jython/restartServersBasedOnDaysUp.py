#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 02/06/2017 Murry Kane     Initial version
# 02/27/2018 Murry Kane     Added logic to skip selective nodes
#                           Added logic to select selective application servers like 'csadmin'
# 08/07/2018 Murry Kane     Added logic for wait time to be passed into script default is 900 seconds
#_________________________________________________________________________________________________
#
import os, sys
from constants import *

if os.path.isfile('%s/wsadminlib.py' % JYTHON_DIR):
  execfile('%s/wsadminlib.py' % JYTHON_DIR)
else:
  print "Needed library wsadminlib.py NOT Found, exiting!"
  sys.exit(1)

enableDebugMessages()
m="restartServersOnDaysUp:"
searchAppServers = ''
waitTime = 900

def usage():
  print "Usage: %s 'String of Exclude Nodes' 'Days to Determine Recycle of Application Server' '(Optional) Applicaiton Server search string'" % m
  print "Example %s WEBP02EPresentBatch02/WEBP02ESS01 6 CSAdmin" % m
  
if ( len(sys.argv) not in [2,3,4]):
  usage()
  sys.exit(1)
elif (len(sys.argv) == 4):
  ignoreNodeList = sys.argv[0]
  daysToRecycle = int(sys.argv[1])
  waitTime = int(sys.argv[2])
  searchAppServers = sys.argv[3]
elif (len(sys.argv) == 3):
  ignoreNodeList = sys.argv[0]
  daysToRecycle = int(sys.argv[1])
  waitTime = int(sys.argv[2])
elif (len(sys.argv) == 2):
  ignoreNodeList = sys.argv[0]
  daysToRecycle = int(sys.argv[1])
  waitTime = 900

ignorelist = ignoreNodeList.split("/")
sop(m,"Ignore NODE List is %s" % ignorelist)
sop(m,"Max wait time for recycles is [%d]" % waitTime)

if searchAppServers:
  sop(m, "Running with selective search for Nodes to recycle based on uptime, with value [%s]" % searchAppServers)
  
#lets validate we are on a DMGR!
if whatEnv() == 'nd':
  sop(m, "Running on DMGR, continueing...")
else:
  sop(m, "ERROR: You must run this script on the DMGR!, exiting!")
  sys.exit(2)
  
Running_Nodes=AdminControl.queryNames('*:type=Server,name=nodeagent,*').split(java.lang.System.getProperty("line.separator"))
ignoretype=['dmgr','nodeagent']
sop(m, "-----------------------------------------------------------------------------------------------------------------")

for nod in Running_Nodes:
  NodeName=AdminControl.invoke(nod ,"getNodeName()")
  Running_JVMS=AdminControl.queryNames('*:type=Server,node='+NodeName+',*').split(java.lang.System.getProperty("line.separator"))
  sop (m,"NODENAME:%s" % NodeName)
  if NodeName.lower() in ignorelist:
    sop(m,"NODENAME:%s being skipped since its in the ignore node list!" % NodeName)
  else:
    for JVM in Running_JVMS:
      ServerName=AdminControl.invoke(JVM ,"getName()")
      if ServerName.lower() not in ignoretype:
        JVMName=AdminControl.completeObjectName('type=JVM,process='+ServerName+',*')
        JVMObject=AdminControl.makeObjectName(JVMName)
        perf=AdminControl.completeObjectName('type=Perf,process='+ServerName+',*')
        perfObject=AdminControl.makeObjectName(perf)
        Obj=AdminControl.invoke_jmx(perfObject,"getStatsObject",[JVMObject,java.lang.Boolean('false')],['javax.management.ObjectName','java.lang.Boolean'])
        current=Obj.getStatistic('HeapSize').getCurrent()
        used=Obj.getStatistic('UsedMemory').getCount()
        usage=float(used)/float(current)*100
        uptime=float(Obj.getStatistic('UpTime').getCount())/60/60/24
        uptimeseconds=Obj.getStatistic('UpTime').getCount()
        sop(m, "ServerName      :%s" % ServerName )
        sop(m, "Uptime Seconds  :%d" % int(uptimeseconds) )
        sop(m, "Uptime(in days) :%d" % int(uptime) )
        sop(m, "CurrentUsage    :%s" % current )
        sop(m, "UsedMemory      :%s" % used )
        sop(m, "Usage in Percent:%d" % int(usage) )
        
        #resetflag for skip node logic
        skipFlag = 0
        
        if searchAppServers:
          sop(m, "Checking if ServerName '%s' matches with substring '%s'" % (ServerName.lower(), searchAppServers))
          #jython 2.1 version causes error 'TypeError: string member test needs char left operand' for the below..... upgrade IBM!
          #if searchAppServers in ServerName.lower():
          if ServerName.lower().find(searchAppServers) >= 0:
            sop(m, "The substring [%s] matches this node [%s], checking runtime days next..." % (searchAppServers, ServerName) )
          else:
            sop(m, "The substring [%s] DOES NOT match this node [%s], skipping this node..." % (searchAppServers, ServerName) )
            skipFlag = 1
        
        #sop(m,"Skip Flag is [%s] for Server [%s]" % (skipFlag, ServerName))
        
        #lets see if its in the include list
        if skipFlag == 0 and uptime > daysToRecycle:
          sop(m,"Up for more than %s days, starting recycle logic." % daysToRecycle)
          isRunning, stopOccurred = restartServer(NodeName, ServerName, waitTime)  # wait waitTime minutes max for restart
          sop(m, "restartServer returned with running [%s] with stop occurred [%s]" % (isRunning, stopOccurred))
          if stopOccurred == 1 and isRunning == 1:
            sop(m, "Sleeping before moving onto another Application Server for 30 seconds")
            time.sleep(30) 
          else:
            #this is an issue!
            sop(m, "FATAL: The server [%s] did not restart successfully!, exiting script!!!" % (ServerName))
            sys.exit(99)
        else:
          if uptime < daysToRecycle and skipFlag == 0:
            sop(m, "NOT up for %s or more days, skipping recycle for this Application Server [%s]" % (daysToRecycle,ServerName))
          #if skipFlag:
          #  sop(m, "The substring [%s] DOES NOT match this node [%s], skipping this node..." % (searchAppServers, ServerName) )
      # can't show none running nodes, since it might be a nodeagent/dmgr node too.....
      #else:
        #if ServerName.lower() not in ignoretype:
      #  sop(m, "Server is NOT running or wrong type(nodeagent/dmgr), skipping this node...")    
    
  sop(m, "-----------------------------------------------------------------------------------------------------------------")
"""
        else:
          #lets check if we need to exclude
          sop(m, "Checking if ServerName '%s' matches with substring '%s'" % (ServerName.lower(), searchAppServers))
          #jython 2.1 version causes error 'TypeError: string member test needs char left operand' for the below..... upgrade IBM!
          #if searchAppServers in ServerName.lower():
          if ServerName.lower().find(searchAppServers) >= 0:
            sop(m, "The substring [%s] matches this node [%s], checking runtime days..." % (searchAppServers, ServerName) )
            if uptime > daysToRecycle:
              sop(m,"Up for more than %s days, starting recycle logic." % daysToRecycle)
              restartServer(NodeName, ServerName, 900)  # wait 15 minutes max for restart
              sop(m, "Sleeping before moving onto another Application Server for 30 seconds")
              time.sleep(30) 
            else:
              sop(m, "NOT up for %s or more days, skipping recycle for this Application Server [%s]" % (daysToRecycle, ServerName))           
          else:
            sop(m, "This server is being skipped since it does not match the search substring [%s] with server [%s]" % (searchAppServers, ServerName.lower()))
        sop(m, "--------------------------------------------")
        """
sop(m, "All Done")
sop(m, "=====================================================================")
