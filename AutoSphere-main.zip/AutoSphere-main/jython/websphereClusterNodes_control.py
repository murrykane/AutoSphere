#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 02/06/2017 Murry Kane     Initial version
#
#_________________________________________________________________________________________________
#
import os, sys
from constants import *

if os.path.isfile('%s/wsadminlib.py' % JYTHON_DIR):
  execfile('%s/wsadminlib.py' % JYTHON_DIR)
else:
  print "Needed library wsadminlib.py NOT Found, exiting!"
  sys.exit(1)

enableDebugMessages()
m="websphereClusterNodes_control"

#lets validate we are on a DMGR!
if whatEnv() == 'nd':
  sop(m, "Running on DMGR, continueing...")
else:
  sop(m, "ERROR: You must run this script on the DMGR!, exiting!")
  sys.exit(2)

def usage():
  print "Usage: %s <restart|stop> 'String of Exclude Nodes'" % m
  print "Example %s stop 'WEBP02EPresentBatch02/WEBP02ESS01'" % m
  
if ( len(sys.argv) != 2):
  usage()
  sys.exit(1)
else:
  action = sys.argv[0].lower()
  ignoreNodeList = sys.argv[1]

ignorelist = ignoreNodeList.split("/")
sop(m,"Ignore NODE List is %s" % ignorelist)

dmgr_node = getDmgrNodeName()
cellname = getCellName()

if dmgr_node == '':
  sop(m,"ERROR: We must find a DMGR to complete this script!, exiting!")
  sys.exit(6)

if cellname == '':
  sop(m,"ERROR: We must find a Cell Name to complete this script!, exiting!")
  sys.exit(7)
  
sop(m,"DMGR Node is: [%s] for Cell [%s]" % (dmgr_node, cellname))

dmgr_bean = AdminControl.queryNames('WebSphere:name=DeploymentManager,process=dmgr,platform=common,node=%s,diagnosticProvider=*,version=*,type=DeploymentManager,mbeanIdentifier=DeploymentManager,cell=%s,spec=*' % (dmgr_node,cellname))

if dmgr_bean == '':
  sop(m,"ERROR: We must find the MBEAN for the DMGR, we can not continue the script, exiting!")
  sys.exit(7)

sop(m,"Found the DMGR bean with [%s]" % dmgr_bean)

nodes = _splitlines(AdminConfig.list( 'Node' ))
for node_id in nodes:
  nodename = getNodeName(node_id)
  hostname = getNodeHostname(nodename)
  platform = getNodePlatformOS(nodename)
  if nodeIsDmgr(nodename):
    sop(m,"NODE %s on %s (%s)" % (nodename,hostname,platform))
  else:
    sop(m,"NODE %s on %s (%s)" % (nodename,hostname,platform))
    #if ignorelist.find(nodename) != -1:
    if nodename in ignorelist:
      sop(m,"NODE is being skipped since its in the ignore list")
    else:
      serverEntries = _splitlines(AdminConfig.list( 'ServerEntry', node_id ))
      for serverEntry in serverEntries:
        sName = AdminConfig.showAttribute( serverEntry, "serverName" )
        sType = AdminConfig.showAttribute( serverEntry, "serverType" )
        isRunning = isServerRunning(nodename,sName)
        if isRunning:
          na = AdminControl.queryNames('type=NodeAgent,node=%s,*' % nodename)
          if action == 'restart':
            AdminControl.invoke(na, 'restart', 'true false')
          elif action == 'stop':
            #AdminControl.invoke(na, 'stopNode')
            #AdminControl.invoke('WebSphere:name=DeploymentManager,process=dmgr,platform=common,node=WEBN208Dmgr01,diagnosticProvider=true,version=7.0.0.41,type=DeploymentManager,mbeanIdentifier=DeploymentManager,cell=WEBN208Cell,spec=1.0', 'stopNodeAgent', '[WEBN208ConsumerBatchNode02]', '[java.lang.String]')
            #AdminControl.invoke(na, 'stopNodeAgent', '[WEBN208ConsumerBatchNode02]', '[java.lang.String]'
            AdminControl.invoke(dmgr_bean, 'stopNodeAgent', '[%s]' % nodename, '[java.lang.String]' )
          else:
            sop(m, "ERROR: Invalid option[%s] sent to program!, exiting!" % action)
            sys.exit(10)
        else: 
          sop(m, "Node/AppServer is NOT Running, skipping this node %s" % nodename)
    
sop(m, "All Done")
