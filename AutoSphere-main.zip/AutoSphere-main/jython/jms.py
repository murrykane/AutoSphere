#import
import sys
import java.io
import Xparser
import XPathCount

#********************************************************
# configure SIBus JMS
#********************************************************
def configureSIBJMS(serverXML, jmsType, task, AdminControl, AdminConfig, AdminTask, nodeName, serverName):

# ********************** variables ************************ #
	cellName = AdminControl.getCell()
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")

	if (jmsType == "activationSpec"):
		#check if required configuration
		configure = Xparser.xFind(serverXML, "//websphere/server/resources/activationSpec/@configure")
		if (configure == "false"):
			print "--> configure set to false ... skipping"
			return 0
		else:
			jmsCount = XPathCount.getCount(serverXML, "//websphere/server/resources/activationSpec/*", "")
			listTask = AdminTask.listSIBJMSActivationSpecs
			createTask = AdminTask.createSIBJMSActivationSpec
			deleteTask = AdminTask.deleteSIBJMSActivationSpec
			modifyTask = AdminTask.modifySIBJMSActivationSpec
	elif (jmsType == "connectionFactories"):
		#check if required configuration
		configure = Xparser.xFind(serverXML, "//websphere/server/resources/connectionFactories/@configure")
		if (configure == "false"):
			print "--> configure set to false ... skipping"
			return 0
		else:
			jmsCount = XPathCount.getCount(serverXML, "//websphere/server/resources/connectionFactories/*", "")
			listTask = AdminTask.listSIBJMSConnectionFactories
			createTask = AdminTask.createSIBJMSConnectionFactory
			deleteTask = AdminTask.deleteSIBJMSConnectionFactory
			modifyTask = AdminTask.modifySIBJMSConnectionFactory
	elif (jmsType == "queues"):
		#check if required configuration
		configure = Xparser.xFind(serverXML, "//websphere/server/resources/queues/@configure")
		if (configure == "false"):
			print "--> configure set to false ... skipping"
			return 0
		else:
			jmsCount = XPathCount.getCount(serverXML, "//websphere/server/resources/queues/*", "")
			listTask = AdminTask.listSIBJMSQueues
			createTask = AdminTask.createSIBJMSQueue
			deleteTask = AdminTask.deleteSIBJMSQueue
			modifyTask = AdminTask.modifySIBJMSQueue
	elif (jmsType == "topics"):
		#check if required configuration
		configure = Xparser.xFind(serverXML, "//websphere/server/resources/topics/@configure")
		if (configure == "false"):
			print "--> configure set to false ... skipping"
			return 0
		else:
			jmsCount = XPathCount.getCount(serverXML, "//websphere/server/resources/topics/*", "")
			listTask = AdminTask.listSIBJMSTopics
			createTask = AdminTask.createSIBJMSTopic
			deleteTask = AdminTask.deleteSIBJMSTopic
			modifyTask = AdminTask.modifySIBJMSTopic

	else:
		print "--> JMS type is not supported"
	#endIf

        i = 1
	jms = ""
	while i < jmsCount+1:

		jmsNum = ("jms"+str(i))
		# added to script to check if values exist else skip
		scope = Xparser.xFind(serverXML, "//websphere/server/resources/"+jmsType+"/"+jmsNum+"/@scope")
		checkVal = len(scope)
		if (checkVal < 1):
			print " no values defined ... skipping"
			i = 0
			return ""
		else:
			scope = Xparser.xFind(serverXML, "//websphere/server/resources/"+jmsType+"/"+jmsNum+"/@scope")
			providerName = Xparser.xFind(serverXML, "//websphere/server/resources/"+jmsType+"/"+jmsNum+"/@provider")
			jmsName = Xparser.xFind(serverXML, "//websphere/server/resources/"+jmsType+"/"+jmsNum+"/@name")
			jndi = Xparser.xFind(serverXML, "//websphere/server/resources/"+jmsType+"/"+jmsNum+"/@jndi")
			bus = Xparser.xFind(serverXML, "//websphere/server/resources/"+jmsType+"/"+jmsNum+"/@bus")
                        tChain = Xparser.xFind(serverXML, "//websphere/server/resources/"+jmsType+"/"+jmsNum+"/@tChain")
			hostName = Xparser.xFind(serverXML, "//websphere/server/@host")
			sibPort = Xparser.xFind(serverXML, "//websphere/server/ports/@sib")
	
		args = '-name "'+jmsName+'" -jndiName '+jndi+' -busName '+bus

		# get scope - TODO create base lib to do this
		if (scope == "server"):
			scopePath = '/Node:'+nodeName+'/Server:'+serverName+'/'
			scopeAttribute =' -node '+nodeName+' -server '+serverName 
			scopeName = serverName
		if (scope == "node"):
			scopePath = '/Cell:'+cellName+'/Node:'+nodeName+'/'
			scopeAttribute =' -node '+nodeName 
			scopeName = nodeName
	 	if (scope == "cell"):
			scopePath = '/Cell:'+cellName+'/'
			scopeAttribute =' -cell '+cellName 
			scopeName = cellName 
		if (scope == "cluster"):
			scopePath = '/Cell:'+cellName+'/ServerCluster:'+clusterName+'/'
			scopeAttribute =' -cluster '+clusterName 
			scopeName = clusterName 

		if (jmsType == "activationSpec"):
			desType = Xparser.xFind(serverXML, "//websphere/server/resources/activationSpec/"+jmsNum+"/@desType")
			desJndi = Xparser.xFind(serverXML, "//websphere/server/resources/activationSpec/"+jmsNum+"/@desJndi")
			args +=' -destinationJndiName '+desJndi+' -destinationType '+desType
		if (jmsType == "connectionFactories"):
			type = Xparser.xFind(serverXML, "//websphere/server/resources/connectionFactories/"+jmsNum+"/@type")
			if (type == ""):
				args +=' -providerEndPoints '+hostName+':'+sibPort+':BootstrapBasicMessaging '
			else:
				args +=' -providerEndPoints '+hostName+':'+sibPort+':BootstrapBasicMessaging -type '+type+' -targetTransportChain '+tChain
		if (jmsType == "queues"):
			queueName = Xparser.xFind(serverXML, "//websphere/server/resources/queues//"+jmsNum+"/@queueName")
			args +=' -queueName '+queueName
		if (jmsType == "topics"):
			topicName = Xparser.xFind(serverXML, "//websphere/server/resources/topics/"+jmsNum+"/@topicName")
			topicSpace = Xparser.xFind(serverXML, "//websphere/server/resources/topics/"+jmsNum+"/@topicSpace")
			deliveryMode = Xparser.xFind(serverXML, "//websphere/server/resources/topics/"+jmsNum+"/@deliveryMode")
			readAhead = Xparser.xFind(serverXML, "//websphere/server/resources/topics/"+jmsNum+"/@readAhead")
			args +=' -topicName '+topicName+' -topicSpace '+topicSpace+' -deliveryMode '+deliveryMode+' -readAhead '+readAhead


		jmsId = AdminConfig.getid(scopePath)
		jmsExists = "false"
		jmsList = listTask(jmsId).splitlines()

		busList = AdminTask.listSIBusMembers('[-bus '+bus+']').splitlines()
		for busItem in busList:
			if (busItem != ""):
                 		scope = "cluster"
				scopeA = AdminConfig.showAttribute(busItem, scope)
				if (scopeA == scopeName):
					engList = AdminTask.listSIBEngines('[-bus '+bus+ scopeAttribute+']')
					engName = AdminConfig.showAttribute(engList, 'name')
					if (jmsType == "activationSpec" or jmsType =="connectionFactories"):
						args +=' -durableSubscriptionHome '+engName 
				#endIf
			#endIf
		#endFor

		for item in jmsList:
			if (item != ""):
				attributeName = AdminConfig.showAttribute(item, "name")
				if (jmsName == attributeName):
					jmsExists = "true"
					break
				#endIf
			#endIf
		#endFor

		if (task == "create" and jmsExists == "false"):
			print "--> start: create SIB JMS "+jmsType
			print "-->    creating SIB JMS "+jmsType+": " +jmsName

			createTask(jmsId, '['+args+']')
			AdminConfig.save()

			print "--> end: create SIB JMS "+jmsType
			print ""
		elif (task == "delete" and jmsExists == "true"):
			print "--> start: delete SIB JMS "+jmsType
			print "-->    deleting SIB JMS "+jmsType+": " +jmsName
			
			deleteTask(item)
			AdminConfig.save()
			print "--> end: create SIB JMS "+jmsType
			print ""
		elif (task == "update" and jmsExists == "true"):
			print "--> start: update SIB JMS "+jmsType
			print "-->    updating SIB JMS "+jmsType+": " +jmsName

			modifyTask(item, '['+args+']')
			AdminConfig.save()
			print "--> end: update SIB JMS "+jmsType
			print ""
		else:
			print "--> skip: "+task+" SIB JMS "+jmsType
		#endIf	
		
		i =i+1

#endDef
#********************************************************
# main: 
#********************************************************

def main():
        
	print " "
	print " "


	# check arguments
	if len(sys.argv) < 5:
		usage()
		sys.exit(1)
	#endIf

        # expected input	
        shieldHome = sys.argv[0]
        envType = sys.argv[1] 
        instance = sys.argv[2]
        task = sys.argv[3]
        jmsType = sys.argv[4]



        # variables
	xmlBasePath = (shieldHome+"/xml/")
        
        #xml path
	serverXML = (xmlBasePath+envType+"/"+instance+".xml")

	configureSIBJMS(serverXML, jmsType, task, AdminControl, AdminConfig, AdminTask)
        
#endDef
# call main
#main()   
