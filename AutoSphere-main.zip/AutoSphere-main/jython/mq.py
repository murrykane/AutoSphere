#import
import sys
import java.io
import Xparser
import XPathCount
import base

#********************************************************
# configure MQ Queues and QCF
#********************************************************

def deleteMqQCF(serverXML,AdminConfig,AdminControl, nodeName, serverName):
    print "in the Delete Mq QCF function"
    cellName = AdminControl.getCell()
    #serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
    #nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
    clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")

    configure = Xparser.xFind(serverXML, "//websphere/server/resources/mq/qcfs/@configure")
    if (configure == "false"):
           print "--> configure set to false ... skipping"
           return 0

    qcfsCount = XPathCount.getCount(serverXML, "//websphere/server/resources/mq/qcfs/*", "")
    i = 1
    while i < qcfsCount+1:
         qcfNum = ("qcf"+str(i))
         qcfName = Xparser.xFind(serverXML, "//websphere/server/resources/mq/qcfs/"+qcfNum+"/@name")
         qcfScope = Xparser.xFind(serverXML, "//websphere/server/resources/mq/qcfs/"+qcfNum+"/@scope")

         if (qcfScope == "server"):
              scopePath = '/Node:'+nodeName+'/Server:'+serverName+'/'
         elif (qcfScope == "node"):
              scopePath = '/Cell:'+cellName+'/Node:'+nodeName+'/'
         elif (qcfScope == "cell"):
              scopePath = '/Cell:'+cellName+'/'
         elif (qcfScope == "cluster"):
              scopePath = '/Cell:'+cellName+'/ServerCluster:'+clusterName+'/'
         else:
              print "Select Correct Scope"
              return 0

         qcfId = AdminConfig.getid(scopePath)
         qcfList = AdminConfig.list( 'MQQueueConnectionFactory', qcfId).splitlines()

         isQCFExists = "false"
         delqcfId=""
         for item in qcfList:
            if (item != ""):
                   attributeName = AdminConfig.showAttribute(item, "name")
                   if ( attributeName == qcfName ):
                          isQCFExists = "true"
                          delqcfId=item
            #endIf
         #endFor

         if ( isQCFExists == "true" ):
             delqcf=AdminConfig.showAttribute(delqcfId, "name")
             print "Deleting QCF  "+delqcf
             AdminTask.deleteWMQConnectionFactory(delqcfId)
             AdminConfig.save()
             print "QCF "+delqcf+" Has been deleted"
         else:
             print "MQ Queue Connection Factory "+qcfName+"  doesn't existed ..skipping.. "
         #endIf

         i=i+1
#endDef

def createMqQCF(serverXML,AdminConfig,AdminControl, AdminTask, nodeName, serverName):
    cellName = AdminControl.getCell()
    #serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
    #nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
    clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")

    configure = Xparser.xFind(serverXML, "//websphere/server/resources/mq/qcfs/@configure")
    if (configure == "false"):
           print "--> configure set to false ... skipping"
           return 0

    qcfsCount = XPathCount.getCount(serverXML, "//websphere/server/resources/mq/qcfs/*", "")
    i = 1 
    while i < qcfsCount+1:
         qcfNum = ("qcf"+str(i))
         qcfName = Xparser.xFind(serverXML, "//websphere/server/resources/mq/qcfs/"+qcfNum+"/@name")
         qcfJNIDName = Xparser.xFind(serverXML, "//websphere/server/resources/mq/qcfs/"+qcfNum+"/@jndiName")
         qcfQmgrName = Xparser.xFind(serverXML, "//websphere/server/resources/mq/qcfs/"+qcfNum+"/@qmgrName") 
         qcfType = Xparser.xFind(serverXML, "//websphere/server/resources/mq/qcfs/"+qcfNum+"/@type")
         qcfQmgrHostName = Xparser.xFind(serverXML, "//websphere/server/resources/mq/qcfs/"+qcfNum+"/@qmgrHostName")
         qcfPort = Xparser.xFind(serverXML, "//websphere/server/resources/mq/qcfs/"+qcfNum+"/@port")
         qcfChannel = Xparser.xFind(serverXML, "//websphere/server/resources/mq/qcfs/"+qcfNum+"/@channel")
         qcfScope = Xparser.xFind(serverXML, "//websphere/server/resources/mq/qcfs/"+qcfNum+"/@scope")
         qcfType2 = "QCF"

         args = '-name "'+qcfName+'" -jndiName '+qcfJNIDName+' -qmgrName '+qcfQmgrName+' -wmqTransportType '+qcfType+' -qmgrHostname '+qcfQmgrHostName+' -qmgrPortNumber '+qcfPort+' -qmgrSvrconnChannel '+qcfChannel+' -type '+qcfType2

         if (qcfScope == "server"):
              scopePath = '/Node:'+nodeName+'/Server:'+serverName+'/'
         elif (qcfScope == "node"):
              scopePath = '/Cell:'+cellName+'/Node:'+nodeName+'/'
         elif (qcfScope == "cell"):
              scopePath = '/Cell:'+cellName+'/'
         elif (qcfScope == "cluster"):
              scopePath = '/Cell:'+cellName+'/ServerCluster:'+clusterName+'/'
         else:
              print "Select Correct Scope"
              return 0
      
         qcfId = AdminConfig.getid(scopePath)
         qcfList = AdminConfig.list( 'MQQueueConnectionFactory', qcfId).splitlines()

         isQCFExists = "false"
         for item in qcfList:
            if (item != ""):
                   attributeName = AdminConfig.showAttribute(item, "name")
                   if ( attributeName == qcfName ):
                          isQCFExists = "true"
            #endIf
         #endFor

         if ( isQCFExists == "true" ):
             print "MQ Queue Connection Factory "+qcfName+" is  Exists ...skipping ....."
         else:
             print "creating  "+qcfName
             AdminTask.createWMQConnectionFactory(qcfId, '['+args+']')
             AdminConfig.save()
             print "MQ Queue Connection Factory "+qcfName+"  has been created"
         #endIf

         i=i+1
    #endWhile
#endIf


def deleteMqQueue(serverXML,AdminConfig,AdminControl, nodeName, serverName):
       cellName = AdminControl.getCell()
       #serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
       #nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
       clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
       qCount = XPathCount.getCount(serverXML, "//websphere/server/resources/mq/queues/*", "")

       i = 1
       while i < qCount+1:
          qNum = ("q"+str(i))
          queueName = Xparser.xFind(serverXML, "//websphere/server/resources/mq/queues/"+qNum+"/@name")
          scope = Xparser.xFind(serverXML, "//websphere/server/resources/mq/queues/"+qNum+"/@scope")
          if (scope == "server"):
              scopePath = '/Node:'+nodeName+'/Server:'+serverName+'/'
          elif (scope == "node"):
              scopePath = '/Cell:'+cellName+'/Node:'+nodeName+'/'
          elif (scope == "cell"):
              scopePath = '/Cell:'+cellName+'/'
          elif (scope == "cluster"):
              scopePath = '/Cell:'+cellName+'/ServerCluster:'+clusterName+'/'
          else:
              print "Select Correct Scope"
              return 0

          mqId = AdminConfig.getid(scopePath)
          mqList = AdminConfig.list( 'MQQueue', mqId).splitlines()

          isQueueExists = "false"
          delId=""
          for item in mqList:
              if (item != ""):
                  attributeName = AdminConfig.showAttribute(item, "name")
                  if ( attributeName == queueName ):
                      isQueueExists = "true"
                      delId=item
              #endIf
          #endFor

          if ( isQueueExists == "true" ):
             delQueueNqme=AdminConfig.showAttribute(delId, "name")
             print "Deleting Mq Queue :"+delQueueNqme
             AdminTask.deleteWMQQueue(delId)
             AdminConfig.save()
             print "Mq Queue "+delQueueNqme+" Has been deleted"
          else:
             print "MQ Queue "+queueName+"  doesn't not existed ... skipping"
          #endIf

          i=i+1
#endDef

def createMqQueues(serverXML,AdminConfig,AdminControl, AdminTask, nodeName, serverName):
    configure = Xparser.xFind(serverXML, "//websphere/server/resources/mq/queues/@configure")
    if (configure == "false"):
           print "--> configure set to false ... skipping"
           return 0
    cellName = AdminControl.getCell()
    #serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
    #nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
    clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
    qCount = XPathCount.getCount(serverXML, "//websphere/server/resources/mq/queues/*", "")

    i = 1 
    while i < qCount+1:
        qNum = ("q"+str(i))
        queueName = Xparser.xFind(serverXML, "//websphere/server/resources/mq/queues/"+qNum+"/@name")
        queueJNDI = Xparser.xFind(serverXML, "//websphere/server/resources/mq/queues/"+qNum+"/@jndiName")
        queue = Xparser.xFind(serverXML, "//websphere/server/resources/mq/queues/"+qNum+"/@queue")
        scope = Xparser.xFind(serverXML, "//websphere/server/resources/mq/queues/"+qNum+"/@scope")
        qmgrHost=Xparser.xFind(serverXML, "//websphere/server/resources/mq/queues/"+qNum+"/@qmgrHost")
        qmgrPort=Xparser.xFind(serverXML, "//websphere/server/resources/mq/queues/"+qNum+"/@qmgrPort")
        sccName=Xparser.xFind(serverXML, "//websphere/server/resources/mq/queues/"+qNum+"/@sccName")
        id=Xparser.xFind(serverXML, "//websphere/server/resources/mq/queues/"+qNum+"/@id")
        password=Xparser.xFind(serverXML, "//websphere/server/resources/mq/queues/"+qNum+"/@password")

        qmgrHost_attr = [ 'queueManagerHost', qmgrHost ]
        qmgrPort_attr = [ 'queueManagerPort', qmgrPort ]
        sccName_attr  = [ 'serverConnectionChannelName', sccName ]
        id_attr = [ 'userName', id ]
        password_attr = [ 'password', password ]
        attrs = [ qmgrHost_attr, qmgrPort_attr, sccName_attr, id_attr, password_attr ]

        args = '-name "'+queueName+'" -jndiName '+queueJNDI+' -queueName '+queue
        
        if (scope == "server"):
              scopePath = '/Node:'+nodeName+'/Server:'+serverName+'/'
        elif (scope == "node"):
              scopePath = '/Cell:'+cellName+'/Node:'+nodeName+'/'
        elif (scope == "cell"):
              scopePath = '/Cell:'+cellName+'/'
        elif (scope == "cluster"):
              scopePath = '/Cell:'+cellName+'/ServerCluster:'+clusterName+'/'
        else:
              print "Select Correct Scope"
              return 0
  
        mqId = AdminConfig.getid(scopePath)
        mqList = AdminConfig.list( 'MQQueue', mqId).splitlines()
        
        isQueueExists = "false"
        for item in mqList:
            if (item != ""):
                  attributeName = AdminConfig.showAttribute(item, "name")
                  if ( attributeName == queueName ):
                      isQueueExists = "true"
            #endIf
        #endFor

        if ( isQueueExists == "true" ):
             print "MQ Queue "+queueName+"  is Exists...skipping...."
        else:
             print "creating  "+queueName
             nqId = AdminTask.createWMQQueue(mqId, '['+args+']')
             AdminConfig.modify(nqId, attrs )
             AdminConfig.save()
             print "MQ Queue  "+queueName+"  has been created"

        i = i+1
    #endDef
#endDef
