#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 02/06/2017 Murry Kane     Initial version
#
#_________________________________________________________________________________________________
#
import os, sys
from constants import *

if os.path.isfile('%s/wsadminlib.py' % JYTHON_DIR):
  execfile('%s/wsadminlib.py' % JYTHON_DIR)
else:
  print "Needed library wsadminlib.py NOT Found, exiting!"
  sys.exit(1)

enableDebugMessages()
m="updateSSLKeystore:"

#lets validate we are on a DMGR!
if whatEnv() == 'nd':
  sop(m, "Running on DMGR, continueing...")
else:
  sop(m, "ERROR: You must run this script on the DMGR!, exiting!")
  sys.exit(2)

def usage():
  print "Usage: %s CellDefaultTrustStore, newcert1, newcertPath1, newcert2, newcertPath2, oldcertalias, personalcertlocation, certificateAlias, keyfilepass, certificateAliasFromKeyFile, removePersonalCertAlias, exchangekeystores, personalCertKeyStore" % m
  #print "Example %s 'WEBP02EPresentBatch02/WEBP02ESS01'" % m
  
if ( len(sys.argv) != 13):
  usage()
  sys.exit(1)
else:
  CellDefaultTrustStore = sys.argv[0]
  certAlias1 = sys.argv[1]
  certPath1 = sys.argv[2]
  certAlias2 = sys.argv[3]
  certPath2 = sys.argv[4]
  removeCertAliasList = sys.argv[5]
  #removeCertAlias2 = sys.argv[6]
  personalCertPath = sys.argv[6]
  personalCertAlias = sys.argv[7]
  personalCertPass = sys.argv[8]
  personalCertAliasInFile = sys.argv[9]
  deletePersonalCertAlias = sys.argv[10]
  trustStoreNames = sys.argv[11]
  personalCertKeyStore = sys.argv[12]

removeCertAliasList = removeCertAliasList.split("/")
sop(m,"Remove Signer CERT Alias Array is %s" % removeCertAliasList)

cellName = getCellName()  
serverIDList = []
keyStoreType = 'PKCS12'  
# this is hard-coded as it should never change!

#sop(m,"wsadminpath %s" % wsadminpath)
#sop(m,"username %s" % username)
#sop(m,"pass %s" % password ) 
#sop(m,"jythonscript %s" % jythonscript)
sop(m,"CellDefaultTrustStore %s" % CellDefaultTrustStore)
sop(m,"certAlias1 %s" % certAlias1 )
sop(m,"certPath1 %s" % certPath1)
sop(m,"certAlias2 %s" % certAlias2)
sop(m,"Path2 %s" % certPath2)
sop(m,"oldcertalias list %s" % removeCertAliasList)
#sop(m,"oldcertalias[1] %s" % removeCertAlias2)
sop(m,"personalcertlocation %s" % personalCertPath)
sop(m,"personal cetificate alias %s" % personalCertAlias)
#sop(m,"keyfilepass %s" % personalCertPass)
sop(m,"certificateAliasFromFile %s" % personalCertAliasInFile)
sop(m,"deletePersonalCertAlias %s" % deletePersonalCertAlias)
sop(m,"exchangekeystores %s" % trustStoreNames) 
sop(m,"Personal Certificate KeyStore %s" % personalCertKeyStore)
  
trustStoreNames = trustStoreNames.split("/")
sop(m,"Trust Store Names List is %s" % trustStoreNames)


#remove old certs
for removeSingerCert in removeCertAliasList:
  sop(m,"Attempting to remove OLD Signer Cert [%s] in Keystore [%s]" % (removeSingerCert,CellDefaultTrustStore))
  if checkCert(CellDefaultTrustStore, removeSingerCert) == 0:
    sop(m,"The following Certificate [%s] exists and we will proceed to remove it" % removeSingerCert)
    removeCert(CellDefaultTrustStore, removeSingerCert)
  else:
    sop(m,"WARNING: The certificate [%s] does not exist, therefore can't remove it!" % removeSingerCert)

sop(m,"Complete with deletes, moving into insert personal certificate....")    
 
#import new certs
if checkCert(CellDefaultTrustStore, certAlias1) == 0:
  sop(m,"WARNING: The following Certificate [%s] exists already, skipping insert!" % certAlias1)
else:
  sop(m,"Attempting to insert certificate [%s] into keystore [%s] with path [%s]" % (certAlias1, CellDefaultTrustStore, certPath1))
  if importCertNoNode(CellDefaultTrustStore, certAlias1, certPath1) == 0:
    sop(m,"Import was successfull")
  else:
    sop(m,"ERROR: Failed to import signer certificate into keystore, exiting!")

if checkCert(CellDefaultTrustStore, certAlias2) == 0:
  sop(m, "WARNING: The following Certificate [%s] exists already, skipping insert!" % certAlias2)
else:
  sop(m,"Attempting to insert certificate [%s] into keystore [%s] with path [%s]" % (certAlias2, CellDefaultTrustStore, certPath2))
  if importCertNoNode(CellDefaultTrustStore, certAlias2, certPath2) == 0:
    sop(m,"Import was successfull")
  else:
    sop(m,"ERROR: Failed to import signer certificate into keystore, exiting!") 
    #mbk -missing return?

sop(m,"Complete with inserts, moving into delete personal certificates....")

#lets check if the personalCert Exists first
sop(m,"Complete with deletes, moving into delete personal certificate....")

#lets delete the old one...
if checkPersonalCert(personalCertKeyStore, deletePersonalCertAlias) == 0:
  sop(m,"Attempting deletion of the personal certificate [%s]" % deletePersonalCertAlias)
  if deletePersonalCert(personalCertKeyStore, deletePersonalCertAlias) == 0:
    sop(m,"Successfully deleted [%s]" % deletePersonalCertAlias)
  else:
    sop(m,"FATAL: could not delete personal certificate with Alias [%s]" % deletePersonalCertAlias)
    sys.exit(7)
else:
  sop(m,"WARNING: CAN NOT delete old personal certificate [%s] as it does not exist!" % deletePersonalCertAlias)

sop(m,"Complete with delete personal certificates, moving into insert Personal Cert....") 

if checkPersonalCert(personalCertKeyStore, personalCertAlias) == 0:
  sop(m,"WARNING: The personal certificate [%s] already exists, therefore can't insert it!" % personalCertAlias)
else:
  #sop(m,"we are here....")
  #sop(m,"Attempting insert of the personal certificate [%s] KeyStore [%s] Path [%s] Pass [%s] Type [%s] File Alias [%s]" % (personalCertAlias, CellDefaultTrustStore, personalCertPath, personalCertPass, keyStoreType, personalCertAliasInFile))
  sop(m,"Attempting insert of the personal certificate [%s] KeyStore [%s] Path [%s] Pass [%s] Type [%s] File Alias [%s]" % (personalCertAlias, CellDefaultTrustStore, personalCertPath, 'XXXXXXXX', keyStoreType, personalCertAliasInFile))
  #sop(m,"attempting import personal cert......")
  if importPersonalCert(personalCertKeyStore, personalCertPath, personalCertPass, keyStoreType, personalCertAliasInFile, personalCertAlias) == 0:
    sop(m,"Successfully imported [%s]" % personalCertAlias)
  else:
    sop(m,"FATAL: could not import personal certificate with Alias [%s]" % personalCertAlias)
    sys.exit(6)

sop(m,"Complete with insert, moving into exchange new signer certificates........")

# def exchangeCert(keyStoreName1, keyStoreScope1, keyStoreName2, keyStoreScope2, certAliasList1)
signerCertList = "%s:%s" % (certAlias1,certAlias2)
sop(m,"Using singer certificate alias list [%s]" % signerCertList)
if exchangeCert(CellDefaultTrustStore, cellName, personalCertKeyStore, cellName, signerCertList) == 0:
  sop(m,"Successfully exchanged %s and %s with Signers Certificate list [%s]" % (CellDefaultTrustStore, personalCertKeyStore, signerCertList))
else:
  sop(m,"ERROR: Failed to exchange %s and %s with Signers Certificate list [%s]" % (CellDefaultTrustStore, personalCertKeyStore, signerCertList))
  sys.exit(10)

#modSSLConfig(alias, scopeName, nodeName, personalCertKeyStore, keyStoreScopeName, trustStoreName, trustStoreScopeName, serverKeyAlias, clientKeyAlias )
# now lets get nodes to scp the p12 files too.... 
NodeList = []
nodesToGetInfo = listAppServerNodesNoIHS()
#dmgrNode = getDmgrNode()
#dmgrHost = getNodeHostname(node)
SoapInfo = []
SoapInfo = getServerNamedEndPoint('dmgr', 'SOAP_CONNECTOR_ADDRESS')
sop(m,"Getting DMGR End Point returned: [%s]" % SoapInfo)
dmgrHost = SoapInfo[0]
port = SoapInfo[1]
if not dmgrHost:
  sop(m,"ERROR: We could not determine the DMGR Host, exiting!")
  sys.exit(11)
if not port:
  sop(m,"ERROR: We could not determine the SOAP PORT!, exiting!")
  sys.exit(12)
  
#wsadmin>array = getServerNamedEndPoint('dmgr', 'SOAP_CONNECTOR_ADDRESS')
#getServerNamedEndPoint: Attempt to get value of SOAP_CONNECTOR_ADDRESS for server dmgr
#wsadmin>array
#['dm1.webn208', '10010']

for node in nodesToGetInfo:
  sop(m,"Getting information for node %s" % node)
  hostname = getNodeHostname(node)
  binPath = getWasProfileRoot(node)
  NodeList.append((node.encode('ascii', 'ignore'), hostname.encode('ascii', 'ignore'), binPath.encode('ascii', 'ignore'), port.encode('ascii', 'ignore'), dmgrHost.encode('ascii', 'ignore')))
     
sop(m,"Nodes to SCP updated P12 file too: %s" % NodeList) 

# lets clean up and save everything
saveAndSync()
sop(m,"Completed Successfully")
