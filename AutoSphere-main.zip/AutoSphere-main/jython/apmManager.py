#--------------------------------------------------------------------
# Name: apmManager.py
# Role: apm agent startup and shutdown [for was, http_server and wim]
# Author: Jeffrey Apiado (IT_NPO_WEB_TEAM)
# Release: Aug 4, 2017
# Property of: Blue Shield of California (EDR)
#--------------------------------------------------------------------
import sys, os, re
from java.lang import System
import StringIO
from java.lang import ProcessBuilder
from java.io import InputStreamReader
from java.io import BufferedReader
from java.io import File
#------------------------------------------------------------------
class apmManager:
    def __init__(self, A_args, B_args):
        self.arg1 = A_args  # agent
        self.arg2 = B_args  # action
        self.userPath = System.getProperty("user.install.root") # in apm/agent*
        self.ManagedNodes = AdminTask.listNodes().splitlines()
        self.dmgrNode = AdminControl.getNode()

    def websphrEnv(self):
        deter = [item for item in os.listdir("/opt/IBM") if item != "ITM"]
        if os.listdir("/apps") != [] and len(deter) == 0:
            print "( Legacy )"
            return 0
        else:
            print "( Rebuild )"
            return 1

    def sortNode(self):
        HashLib = {}
        applist = []
        weblist = []
        for nodeNAME in self.ManagedNodes:
            getid = AdminConfig.getid("/Node:%s/Server:/" % nodeNAME).splitlines()
            req = [srv for srv in getid if srv.find("nodeagent") == -1]
            getType = AdminConfig.showAttribute(req[0], 'serverType')
            if getType == "APPLICATION_SERVER":
                applist.append(nodeNAME)
            elif getType == "WEB_SERVER":
                weblist.append(nodeNAME)
        HashLib["web"] = weblist
        HashLib["apps"] = applist
        return HashLib

    #-------------------------
    # Module: TaskManager
    # Desc: Accept no argument 
    #-------------------------     
    def TaskManager(self):
        envir = self.websphrEnv()
        #---------------------
        # Agent: WIM
        #--------------------
        if self.arg1 == "wim":
            agent = "wim-agent.sh"
            hostN, infO, serverN = self.unvealNode(self.dmgrNode)
            if hostN != "" and infO != "" and serverN != "":
                if not envir: # Legacy
                    appname = self.defineAppName(hostN) 
                else:
                    appname = "default"
                out = self.chkInstance(agent, envir, appname)
                if out == "Skip":
                    print "[No %s installed in this Server [skip]" % agent
                else:
                    inst = self.getInstance(envir, appname)
                    if inst == "nothing":
                        print "[No instance installed in this Server [skip]" 
                    else:
                        print "[instance name][%s]" % inst
                        self.apmDisplay(hostN, infO, serverN, self.dmgrNode, self.arg2, self.arg1)
                        self.apmExec(self.arg2, agent, envir, appname, inst=inst)                      
        else:
           container = self.sortNode()
           #----------------------
           # Agent: http_server
           #---------------------
           if self.arg1 == "http":
               agent = "http_server-agent.sh"
               for srvN in container['web']:
                   hostN, infO, serverN = self.unvealNode(srvN)
                   if hostN != "" and infO != "" and serverN != "":
                       if not envir:
                           appname = self.defineAppName(hostN) 
                       else:
                           appname = "default"
                       connection = self.SSHCheckpoint(hostN)
                       if not connection:
                           out = self.chkInstance(agent, envir, appname, remSrv=hostN)
                           if out == "Skip":
                               print "[No %s installed in this Server" % agent
                           else:
                              self.apmDisplay(hostN, infO, serverN, srvN, self.arg2, self.arg1)
                              self.apmExec(self.arg2, agent, envir, appname, remSrv=hostN)                      
                       else:
                           print "[unable to connect remotely]"
           #---------------------
           # Agent: was
           #---------------------
           if self.arg1 == "was":
               agent = "was-agent.sh"
               for srvN in container['apps']:
                   hostN, infO, serverN = self.unvealNode(srvN)
                   if hostN != "" and infO != "" and serverN != "":
                       if not envir:
                           appname = self.defineAppName(hostN) 
                       else:
                           appname = "default"
                       connection = self.SSHCheckpoint(hostN)
                       if not connection:
                           out = self.chkInstance(agent, envir, appname,remSrv=hostN)
                           if out == "Skip":
                               print "[No %s installed in this Server" % agent
                           else:
                              self.apmDisplay(hostN, infO, serverN, srvN, self.arg2, self.arg1)
                              self.apmExec(self.arg2, agent, envir, appname, remSrv=hostN)                      
                       else:
                           print "[unable to connect remotely]"

    def apmDisplay(self, hname, info, srvname, MNode, arg2, agent):
            #--------------------------------------------------------------- 
            print ""
            print "             [AGENT %s]          " % agent
            print "[HOSTNAME] . . . . . . . . . . . . . [%s]" % hname
            print "[TYPE] . . . . . . . . . . . . . . . [%s]" % info
            print "[SERVER] . . . . . . . . . . . . . . [%s]" % srvname
            print "[NODENAME] . . . . . . . . . . . . . [%s]" % MNode
            print "[COMMAND] . . . . . . . . . . . . .  [%s]" % arg2
            print ""

    def apmExec(self, arg2, agentName, env, appn, inst="default", remSrv="local"): 
            if arg2 == "start":
                 if remSrv == "local":
                     self.agentSTART(env, agentName, appn, instance=inst)
                 else:
                     self.agentSTART(env, agentName, appn, remote=remSrv)
            elif arg2 == "stop":
                 if remSrv == "local":
                     self.agentSTOP(env, agentName, appn, instance=inst)
                 else:
                     self.agentSTOP(env , agentName, appn, remote=remSrv)
            else:
                 print "[Invalid option received] start or stop only!"
                 sys.exit(0)

        
    def chkInstance(self, agent, env, appn, remSrv="local"):
        if not env:
            if remSrv == "local":
                pre = "find /apps/%s/apm/agent/bin -type f -name %s" % (appn,agent)
                command = ["/bin/bash","-c", pre]
            else:
                pre = "find /apps/%s/apm/agent/bin -type f -name %s" % (appn,agent)
                command = ["ssh",remSrv, pre]
        else:
            if remSrv == "local":
                pre = "find /opt/IBM/WebSphere/apm/agent/bin -type f -name %s" % agent
                command = ["/bin/bash","-c", pre]
            else:
                pre = "find /opt/IBM/WebSphere/apm/agent/bin -type f -name %s" %  agent
                command = ["ssh",remSrv, pre]
        print "[command] %s" % command
        result = self.processBuild(command)
        print "result: > ",result
	if result.find(agent) == -1 or result == "":
            return "Skip"
        else:
            return "Proceed"

    def agentSTART(self, env, agentName, appnn, instance=None, remote="local"):
        if remote != "local": # not local machine
            z = self.agentSTATUS(env, agentName, appnn, rem=remote)
        else:
            z = self.agentSTATUS(env, agentName, appnn)

        if not z:
            print "[Agent was already started]"
            print "[successfull] APM_agent START . . . . done" 
        else:
            print "Starting Agent"
            print "invoke %s start" % agentName    
            if not env:
                if remote != "local":
                   starCMD = "/apps/%s/apm/agent/bin/%s start" % (appnn, agentName)
                   cmdOP = ["ssh", remote, starCMD]
                else:
                   starCMD = "/apps/%s/apm/agent/bin/%s start %s" % (appnn, agentName, instance)
                   cmdOP = ["/bin/bash","-c",starCMD]
            else:
                if remote != "local":
                    startCMD = "/opt/IBM/WebSphere/apm/agent/bin/%s start" % agentName
                    cmdOP = ["ssh", remote, startCMD]
                else: # local
                    startCMD = "/opt/IBM/WebSphere/apm/agent/bin/%s start %s" % (agentName, instance)
		    cmdOP = ["/bin/bash","-c",startCMD]
            print "[command] %s" % cmdOP
            result = self.processBuild(cmdOP)
            if result != "":
                if result.find("started") != -1:
                    print result[result.find("started")]
                else:
                   print "[sucessfull] APM_agent START . . . . done" 
            else:
                print "[Attempt to START apm_agent  . . . [Failed]]" 


    def agentSTOP(self, env, agentName, appnn, instance=None, remote="local"):
        if remote != "local": # not local machine
            s = self.agentSTATUS(env, agentName, appnn, rem=remote)
        else:
            s = self.agentSTATUS(env, agentName, appnn)

        if not s:
            print "Stopping Agent"
            print "invoke %s stop" % agentName
            if not env: #-----------------------------------------------------------------Legacy
                if remote != "local": #----------------------------------------------------------remote
                    stopCMD = "/apps/%s/apm/agent/bin/%s stop" % (appnn, agentName)
                    cmdOP = ["ssh", remote, stopCMD]
                else: # ----------------------------------------------------------------------local
                    stopCMD = "/apps/%s/apm/agent/bin/%s stop %s" % (appnn, agentName, instance)
		    cmdOP = ["/bin/bash","-c",stopCMD]
            else: #------------------------------------------------------------------------Rebuild
                if remote != "local": #---------------------------------------------------------remote
                    stopCMD = "/opt/IBM/WebSphere/apm/agent/bin/%s stop" % agentName
                    cmdOP = ["ssh", remote, stopCMD]
                else: # ----------------------------------------------------------------------local
                    stopCMD = "/opt/IBM/WebSphere/apm/agent/bin/%s stop %s" % (agentName, instance)
		    cmdOP = ["/bin/bash","-c", stopCMD]
            print "[command] %s" % cmdOP
            result = self.processBuild(cmdOP)
            if result != "":
                if result.find("gracefully") != -1:
                    print result[result.find("gracefully")]
                elif result.find("force") != -1:
                    print result[result.find("force")]
                else:
                   print "[sucessfull] APM_agent STOPPED . . . . done"  
            else:
                print "[Attempt to STOP apm_agent . . . . [Failed]]"   
            
        else:
            print "[Agent was already stopped]"
            print "[successfull] APM_WAS STOPPED . . . . done" 

    def getInstance(self, env, appn):
        if not env:
            print "[retrieve instance] [if present or else return nothing]"
            execc = "/apps/%s/apm/agent/bin/wim-agent.sh status" % appn
        else:
            execc = "/opt/IBM/WebSphere/apm/agent/bin/wim-agent.sh status"
        command = ["/bin/bash","-c", execc]
        result = self.processBuild(command)
        if result.find("No instance") > -1:
             return "nothing"
        else:
             ptt = re.compile(r'status:\s*(\w.*?)\sis', re.I)
             match = ptt.search(result)
             if match:
                return match.group(1)
                
    def defineAppName(self, hostname):
        a, b = hostname.split(".")
        getb = b.upper()
        appname = "%s-%s" % (getb, a)
        return appname

    def agentSTATUS(self, env, agentProc, apname, rem="local"):
        print "Checking Agent Status"
        print "invoke %s " % agentProc
        if not env:
            if rem == "local":
                subCMD = "/apps/%s/apm/agent/bin/%s status" % (apname, agentProc)
                wasStat = ["/bin/bash","-c", subCMD]
            else:
                subCMD = "/apps/%s/apm/agent/bin/%s status" % (apname, agentProc)
                wasStat = ["ssh", rem, subCMD]
        else:
            if rem == "local":
                subCMD = "/opt/IBM/WebSphere/apm/agent/bin/%s status" % agentProc
                wasStat = ["/bin/bash","-c", subCMD]
            else: 
                subCMD = "/opt/IBM/WebSphere/apm/agent/bin/%s status" % agentProc
                wasStat = ["ssh", rem, subCMD]
        print "[command] %s" % subCMD
        result = self.processBuild(wasStat)
        stat = 0
        if result != "":
            if result.find("Agent is running") != -1:
                print result[result.find("Agent is running")]
            elif result.find("Connected") != -1:
                print result[result.find("Connected")]
            elif result.find("Connecting") != -1:
                print result[result.find("Connecting")]
            else:
                stat = 1
        else:
            stat = 1
        # stat 0 means up (need stopped) , stat 1 means down (need started)
        return stat

    def unvealNode(self, MNode):
        hostname = ""
        info = ""
        servername = ""
        serverID = AdminConfig.getid("/Node:%s/Server:/" % MNode).splitlines()
        nodeID = AdminConfig.getid("/Node:%s" % MNode)
        for srvAsItem in serverID:
            # discard nodeagent string (Incase)
            if srvAsItem.find("nodeagent") == -1:
                srvVer = srvAsItem
        info = AdminConfig.showAttribute(srvVer, 'serverType') #servertype

        hostname = AdminConfig.showAttribute(nodeID, "hostName") #hostName
        try:
            nodeBean = AdminConfig.getObjectName(srvVer)
            if nodeBean != '':
                SRVname = AdminControl.getAttribute(nodeBean, 'name') #servername
            else:
                SRVname = AdminConfig.showAttribute(srvVer, 'name') #servername
        except:
            SRVname = AdminConfig.showAttribute(srvVer, 'name') #servername

        return hostname, info, SRVname

    def SSHCheckpoint(self, host):
        print "[verify ssh connection for %s]" % host
        sshcmd = "ssh -q -o BatchMode=yes -o ConnectTimeout=10 %s exit" % host
        #print "[exec] %s" % sshcmd
        connect = os.system(sshcmd)
        if connect > 256:
                return 1
        else:
                return 0
    
    def processBuild(self, jcmd):
        SIOS = StringIO.StringIO()
        proc = ProcessBuilder(jcmd)
        proc.directory(File(self.userPath))
        proc.redirectErrorStream()
        outputStream = proc.start()
	br = BufferedReader(InputStreamReader(outputStream.getInputStream()))
        line = br.readLine()
        while line != None:
            SIOS.write(line + "\n")
            line = br.readLine()
        try:
            outStr = SIOS.getvalue()
        except:
            outStr = ""
        outputStream.waitFor()
        br.close()
        SIOS.flush()
        SIOS.close()
        return outStr

            

if __name__ == "__main__":
    if len(sys.argv) == 2:
        # ----------AGENT ----------
        if sys.argv[0] == "wim":
            print "[agent WIM]"
        elif sys.argv[0] == "http":
           print "[agent http_server]"
        elif sys.argv[0] == "was":
           print "[agent was]"
        else:
            print "============================================"
            print "Invalid Option [UNKNOWN]                    "
            print "Acceptable argument ['wim', 'http' or 'was']"
            print "============================================"
            sys.exit(0)
    
        arg1 = sys.argv[0]
        # -------- ACTION ------------
        if sys.argv[1] == "start":
            print "[starting agent]"
        elif sys.argv[1] == "stop":
            print "[stopping agent]"
        else:
            print "========================================"
            print "Invalid Option [UNKNOWN]                "
            print "Acceptable argument ['start', or 'stop']"
            print "========================================"
            sys.exit(0)

        arg2 = sys.argv[1]
    else:
        print "=================================================="
        print "[USAGE]:        invoke by wsadmin.sh              "
        print "             apmManager.py [argument1] [argument2]"
        print "[REQUIRED] argument1 ['was', 'http', or 'wim']    "
        print "[REQUIRED] argument2 ['start', or 'stop']         "
        print "=================================================="     
        sys.exit(0)
    # ---------- PROCESS ------------ 
    apm = apmManager(arg1, arg2)
    apm.TaskManager()

