#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 09/19/2017 Murry Kane     Initial version
#
#_________________________________________________________________________________________________
#
import os, sys
from constants import *

if os.path.isfile('%s/wsadminlib.py' % JYTHON_DIR):
  execfile('%s/wsadminlib.py' % JYTHON_DIR)
else:
  print "Needed library wsadminlib.py NOT Found, exiting!"
  sys.exit(1)

enableDebugMessages()
m="websphereRetrieveSigners:"

#lets validate we are on a DMGR!
if whatEnv() == 'nd':
  sop(m, "Running on DMGR, continueing...")
else:
  sop(m, "ERROR: You must run this script on the DMGR!, exiting!")
  sys.exit(2)

def usage():
  print "Usage: %s " % m
  
if ( len(sys.argv) != 0):
  usage()
  sys.exit(1)

# now lets get nodes in cluster....
#NodeList = []
#nodesToGetInfo = listAppServerNodesNoIHS()
SoapInfo = []
SoapInfo = getServerNamedEndPoint('dmgr', 'SOAP_CONNECTOR_ADDRESS')
sop(m,"Getting DMGR End Point returned: [%s]" % SoapInfo)
dmgrHost = SoapInfo[0]
port = SoapInfo[1]
if not dmgrHost:
  sop(m,"ERROR: We could not determine the DMGR Host, exiting!")
  sys.exit(11)
if not port:
  sop(m,"ERROR: We could not determine the SOAP PORT!, exiting!")
  sys.exit(12)

NodeList = []
nodes = _splitlines(AdminConfig.list( 'Node' ))
for node_id in nodes:
  nodename = getNodeName(node_id)
  hostname = getNodeHostname(nodename)
  platform = getNodePlatformOS(nodename)
  if not nodeIsDmgr(nodename):
    #sop(m,"NODE %s on %s (%s)" % (nodename,hostname,platform))
    userroot = getWasProfileRoot(nodename)
    serverEntries = _splitlines(AdminConfig.list( 'ServerEntry', node_id ))
    for serverEntry in serverEntries:
      sName = AdminConfig.showAttribute( serverEntry, "serverName" )
      sType = AdminConfig.showAttribute( serverEntry, "serverType" )
      sop(m,"NODE %s on %s (%s) Name %s Type %s" % (nodename,hostname,platform, sName, sType))
      if sType == "NODE_AGENT":
        sop(m,"Adding %s to array for Retrieve Signers" % (nodename))
        NodeList.append((nodename.encode('ascii', 'ignore'), hostname.encode('ascii', 'ignore'), userroot.encode('ascii', 'ignore'), port.encode('ascii', 'ignore'), dmgrHost.encode('ascii', 'ignore')))
        
#for node in nodesToGetInfo:
#  sop(m,"Getting information for node %s" % node)
#  hostname = getNodeHostname(node)
#  binPath = getWasProfileRoot(node)
#  NodeList.append((node, hostname, binPath, port, dmgrHost))
     
sop(m,"Nodes to RetrieveSigners on: %s" % NodeList) 

sop(m,"Completed Successfully")
