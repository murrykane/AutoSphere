#import
import sys
import java.io
import Xparser
import XPathCount
import base
import os

AdminConfig = sys._getframe(1).f_locals['AdminConfig']
AdminApp = sys._getframe(1).f_locals['AdminApp']
AdminControl = sys._getframe(1).f_locals['AdminControl']
AdminTask = sys._getframe(1).f_locals['AdminTask']
Help = sys._getframe(1).f_locals['Help']

#********************************************************
# create URL Provider
#********************************************************
def createUrls(serverXML, AdminConfig, AdminControl, nodeName, serverName):
	
        #check if required configuration
        configure = Xparser.xFind(serverXML, "//websphere/server/resources/urls/@configure")
	if (configure == "false"):
		print "--> configure set to false ... skipping"
		return 0	


        # ********************** variables ************************ # 	
	cellName = AdminControl.getCell()
        #serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
        #nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
        clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
        urlCount = XPathCount.getCount(serverXML, "//websphere/server/resources/urls/*", "")
        
                
        i = 1
	url = ""
	while i < urlCount+1:
	        
	        urlNum = ("url"+str(i))
    
        	scope = Xparser.xFind(serverXML, "//websphere/server/resources/urls/"+urlNum+"/@scope")
        
	         #get scope - TODO create base lib to do this
	        if (scope == "server"):
				currScope = AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'')
				scopePath = '/Node:'+nodeName+'/Server:'+serverName+'/' 	
	        if (scope == "node"):
				currScope = AdminConfig.getid('/Cell:'+cellName+'/Node:'+nodeName+'')
				scopePath = '/Cell:'+cellName+'/Node:'+nodeName+'/'
		if (scope == "cell"):
				currScope = AdminConfig.getid('/Cell:'+cellName+'')
				scopePath = '/Cell:'+cellName+'/'
		if (scope == "cluster"):
			scopePath = '/Cell:'+cellName+'/ServerCluster:'+clusterName+'/'
		        currScope = AdminConfig.getid('/Cell:'+cellName+'/ServerCluster:'+clusterName+'')
		
	        
		# set attributes
		urlName = Xparser.xFind(serverXML, "//websphere/server/resources/urls/"+urlNum+"/@name")
		name = ['name', (Xparser.xFind(serverXML, "//websphere/server/resources/urls/"+urlNum+"/@name"))]
		jndiName = ['jndiName', (Xparser.xFind(serverXML, "//websphere/server/resources/urls/"+urlNum+"/@jndiName"))]
	        spec = ['spec', (Xparser.xFind(serverXML, "//websphere/server/resources/urls/"+urlNum+"/@specification"))]
	    	urlProvider = Xparser.xFind(serverXML, "//websphere/server/resources/urls/"+urlNum+"/@urlProvider")
	            
	        ids = AdminConfig.getid(''+scopePath+'URLProvider:'+urlProvider+'/URL:/')
	        urlExist = len(ids)
	    
	        if (urlExist > 0):
	        	urls = ids.splitlines()
		        for varProvider in urls:
		            	getUrlName = AdminConfig.showAttribute(varProvider, "name")
		            	if (getUrlName == urlName):
		           		print "--> URL " +urlName+ " exists ... removing"
		                        AdminConfig.remove(varProvider)
		                        AdminConfig.save()
		# creating URL	   
		urlAttrs = [name, jndiName, spec]
	        print "--> creating url: ", urlName
	        #create url
	        AdminConfig.create('URL', AdminConfig.getid(''+scopePath+'URLProvider:'+urlProvider+'/'), urlAttrs)      
        
                AdminConfig.save()
	        i= i+1
                
            
#********************************************************
# create URL Provider
#********************************************************
def createUrlProvider(serverXML, AdminConfig, AdminControl, nodeName, serverName):
	
        #check if required configuration
        configure = Xparser.xFind(serverXML, "//websphere/server/resources/urlProviders/@configure")
	if (configure == "false"):
		print "--> configure set to false ... skipping"
		return 0	


        # ********************** variables ************************ # 	
	cellName = AdminControl.getCell()
        #serverName = (Xparser.xFind(serverXML, "//websphere/server/@name"))
        #nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
        clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
        urlProviderCount = XPathCount.getCount(serverXML, "//websphere/server/resources/urlProviders/*", "")
        
        i = 1
	urlProvider = ""
	while i < urlProviderCount+1:
	        
	        urlNum = ("urlProvider"+str(i))
		scope = Xparser.xFind(serverXML, "//websphere/server/resources/urlProviders/"+urlNum+"/@scope")
	        
	        # get scope - TODO create base lib to do this
	        if (scope == "server"):
	        	currScope = AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'') 	
 		if (scope == "node"):
	        	currScope = AdminConfig.getid('/Cell:'+cellName+'/Node:'+nodeName+'')
 		if (scope == "cell"):
		         currScope = AdminConfig.getid('/Cell:'+cellName+'')
		if (scope == "cluster"):
		         currScope = AdminConfig.getid('/Cell:'+cellName+'/ServerCluster:'+clusterName+'')
		         
		# set attributes
		name = ['name', (Xparser.xFind(serverXML, "//websphere/server/resources/urlProviders/"+urlNum+"/@name"))]
	        description = ['description', (Xparser.xFind(serverXML, "//websphere/server/resources/urlProviders/"+urlNum+"/@description"))]
                className = ['streamHandlerClassName', (Xparser.xFind(serverXML, "//websphere/server/resources/urlProviders/"+urlNum+"/@className"))]  
                protocol = ['protocol', (Xparser.xFind(serverXML, "//websphere/server/resources/urlProviders/"+urlNum+"/@protocol"))]
                
                urlProviderAttrs = [name, description, className, protocol]
                
                AdminConfig.create('URLProvider', currScope, urlProviderAttrs)
                AdminConfig.save()
                i = i+1


#********************************************************
# create JDBC Provider 
#********************************************************
def createJdbcProvider(serverXML, AdminConfig, AdminControl, nodeName, serverName):
	#check if required configuration
	configure = Xparser.xFind(serverXML, "//websphere/server/resources/jdbcProviders/@configure")
	if (configure == "false"):
		print "--> configure set to false ... skipping"
		return 0
	
	
	
	# ********************** variables ************************ # 	
	cellName = AdminControl.getCell()
	#serverName = (Xparser.xFind(serverXML, "//websphere/server/@name"))
	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
	jdbcProviderCount = XPathCount.getCount(serverXML, "//websphere/server/resources/jdbcProviders/*", "")
	
	i = 1
	jdbcProvider = ""
	while i < jdbcProviderCount+1:
		
		jdbcNum = ("jdbcProvider"+str(i))
		scope = Xparser.xFind(serverXML, "//websphere/server/resources/jdbcProviders/"+jdbcNum+"/@scope")
		
		
		# get scope - TODO create base lib to do this
		if (scope == "server"):
			currScope = AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'')
			scopePath = '/Node:'+nodeName+'/Server:'+serverName+'' 	
 		if (scope == "node"):
			currScope = AdminConfig.getid('/Cell:'+cellName+'/Node:'+nodeName+'')
 		if (scope == "cell"):
			currScope = AdminConfig.getid('/Cell:'+cellName+'')
			scopePath = '/Cell:'+cellName
		if (scope == "cluster"):
			scopePath = '/Cell:'+cellName+'/ServerCluster:'+clusterName+'/'
			currScope = AdminConfig.getid('/Cell:'+cellName+'/ServerCluster:'+clusterName+'')
	
	
		# set attributes
		jdbcProviderName = Xparser.xFind(serverXML, "//websphere/server/resources/jdbcProviders/"+jdbcNum+"/@name")
		name = ['name', (Xparser.xFind(serverXML, "//websphere/server/resources/jdbcProviders/"+jdbcNum+"/@name"))]
		description = ['description', (Xparser.xFind(serverXML, "//websphere/server/resources/jdbcProviders/"+jdbcNum+"/@description"))]
		providerType = ['providerType', (Xparser.xFind(serverXML, "//websphere/server/resources/jdbcProviders/"+jdbcNum+"/@providerType"))]
		implClass = ['implementationClassName', (Xparser.xFind(serverXML, "//websphere/server/resources/jdbcProviders/"+jdbcNum+"/@implementationClassName"))]
		classpath = ['classpath', (Xparser.xFind(serverXML, "//websphere/server/resources/jdbcProviders/"+jdbcNum+"/@classPath"))]
		
		varProviders = []
		currProviders = AdminConfig.list('JDBCProvider', AdminConfig.getid(''+scopePath+'')).splitlines()
		# checking for existing JDBC Provider
		jdbcExists = "false"
		for varProvider in currProviders:
			getProviderName = AdminConfig.showAttribute(varProvider, "name")
			# remove if JDBC Provider Exists
			if (getProviderName == jdbcProviderName):
				print "--> JDBC Provider exists ... skipping"
				#AdminConfig.remove(varProvider)
				#AdminConfig.save()
				jdbcExists = "true"
				break
		if ( jdbcExists == "true"):
			i = i+1
			continue
		# creating JDBC Provider
		jdbcAttrs = [name, providerType, implClass, classpath, description]
		print "creating jdbc provider: ", name
		# create jdbc provider      
		AdminConfig.create('JDBCProvider', currScope, jdbcAttrs)
		
		AdminConfig.save()
		i= i+1
	

	

#********************************************************
# create Datasources
#********************************************************
def createDatasource(serverXML, AdminConfig, AdminControl, AdminUtilities, nodeName, serverName):
	#check if required configuration
	configure = Xparser.xFind(serverXML, "//websphere/server/resources/datasources/@configure")
	if (configure == "false"):
		print "--> configure set to false ... skipping"
		return 0


	# ********************** variables ************************ #
	cellName = AdminControl.getCell()
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
	
	datasourceCount = XPathCount.getCount(serverXML, "//websphere/server/resources/datasources/*", "")
	i = 1
	datasource = ""
	while i < datasourceCount+1:
		
		dsNum = ("datasource"+str(i))
		scope = Xparser.xFind(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/@scope")
		
		# get scope - TODO create base lib to do this
		if (scope == "server"):
			scopePath = '/Node:'+nodeName+'/Server:'+serverName+'/' 	
		if (scope == "node"):
			scopePath = '/Cell:'+cellName+'/Node:'+nodeName+'/'
	 	if (scope == "cell"):
			scopePath = '/Cell:'+cellName+'/'
		if (scope == "cluster"):
			scopePath = '/Cell:'+cellName+'/ServerCluster:'+clusterName+'/'	        
			
		jdbcProviderName = Xparser.xFind(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/@provider")
		
		# check if values exist  
		
		dataSourceName = Xparser.xFind(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/@name")
		jdbcProvider = AdminConfig.getid(''+scopePath+'JDBCProvider:'+jdbcProviderName+'/') 
		datasourceExists = AdminConfig.getid(''+scopePath+'JDBCProvider:'+jdbcProviderName+'/DataSource:'+dataSourceName+'/')
		if (len(datasourceExists) > 0):
			print " "
			print "--> " +dataSourceName+ " exists ... skipping"
			i = i+1
			continue
			#AdminConfig.remove(datasourceExists)
			#AdminConfig.save()
		
		
			# set attributes
		name = dataSourceName
		jndi = (Xparser.xFind(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/@jndi"))
		description = (Xparser.xFind(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/@description"))
		helperClass = (Xparser.xFind(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/@helperClass"))
		componentManagedAuthAlias = (Xparser.xFind(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/@componentManagedAuthAlias"))
		containerManagedAuthAlias =(Xparser.xFind(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/@containerManagedAuthAlias"))
		statementCacheSize = (Xparser.xFind(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/@statementCacheSize"))
		customPropCount = XPathCount.getCount(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/customProperties/*", "")

		x = 1
		customProperties = ""
		cProperties = ""

		while x < customPropCount+1:
			# custom properties
			cPropNum = ("customProperty"+str(x))
			cName = Xparser.xFind(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/customProperties/"+cPropNum+"/@name")
			cValue = Xparser.xFind(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/customProperties/"+cPropNum+"/@value")

			if (cName == "portNumber" or cName == "driverType"):
				javaType = "java.lang.Integer"
			else:
				javaType = "java.lang.String"
			#endif
			
			
			props = "[" +cName+ " " +javaType+ " " +cValue+ "] "
			cProperties = cProperties + props 
			
			x = x+1
		
		cProperties = "["+cProperties+"]"

		print "creating datasource: ", name
		# create datasource
		ds = AdminTask.createDatasource(jdbcProvider, ['-name', name, '-jndiName', jndi, '-dataStoreHelperClassName', helperClass, '-componentManagedAuthenticationAlias', componentManagedAuthAlias, '-configureResourceProperties', cProperties])
		AdminConfig.save()

		ds = AdminConfig.getid(''+scopePath+'JDBCProvider:'+jdbcProviderName+'/DataSource:'+dataSourceName+'/')
		if (containerManagedAuthAlias != ""):
			containerAttrb = "[[authDataAlias " +containerManagedAuthAlias+ "] [mappingConfigAlias \"\"]]"
			AdminConfig.create('MappingModule', ds, containerAttrb)
			AdminConfig.save()

		connectionPoolconfigure = Xparser.xFind(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/connectionPool/@configure")
		if (connectionPoolconfigure == "false"):
			print "--> datasource connection pool configure set to false ... skipping"
		else:
		
			connectionPoolCount = XPathCount.getCount(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/connectionPool/*", "")
			print " "
			print "--> configuring connection pool:"
			y = 1
			connectionPool = ""
			while y < connectionPoolCount+1:
				# connection pool
				
				varNum = ("poolValue"+str(y))
				varName = Xparser.xFind(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/connectionPool/"+varNum+"/@name")
				varValue = Xparser.xFind(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/connectionPool/"+varNum+"/@value")
				
				attrs = '[['+varName+' '+varValue+' ]]'
				
				print " "
				
				print "-->  name: ", varName
				print "--> value: ", varValue
				ds = AdminConfig.getid(''+scopePath+'JDBCProvider:'+jdbcProviderName+'/DataSource:'+dataSourceName+'/')
				pool = AdminConfig.showAttribute(ds, 'connectionPool')
				AdminConfig.modify( pool, attrs )
				
				AdminConfig.save()
				y = y+1
		#endIf

		j2eeResources = Xparser.xFind(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/j2eeResources/@configure")
		if (j2eeResources == "false"):
			print "--> datasource J2EE Resource Properties configure set to false ... skipping"
		else:
			j2eeReCount = XPathCount.getCount(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/j2eeResources/*", "")
			print " "
			print "--> configuring datasource j2ee resource custom properties:"
			z = 1
			j2eeResource = ""
			
			while z < j2eeReCount+1:
				j2eeNum = ("customProperty"+str(z))
				j2eeName = Xparser.xFind(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/j2eeResources/"+j2eeNum+"/@name")
				j2eeValue =  Xparser.xFind(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/j2eeResources/"+j2eeNum+"/@value")
				j2eeValueAttr = "[[value " +j2eeValue+ "]]"
				#j2eeNameAttr = "[[name " +j2eeName+ "]]"
				
				
				print " "
				print "-->  name: ", j2eeName
				print "--> value: ", j2eeValue

				ds = AdminConfig.getid(''+scopePath+'JDBCProvider:'+jdbcProviderName+'/DataSource:'+dataSourceName+'/')
				properties = AdminConfig.list('J2EEResourceProperty', ds)
				props = AdminUtilities.convertToList(properties)

				for prop in props:
					propName = AdminConfig.showAttribute(prop, 'name')
					if (propName == j2eeName):
						AdminConfig.modify(prop, j2eeValueAttr)
						AdminConfig.save()
				z = z+1
		i= i+1
#endDef

def deleteDatasources (serverXML, AdminConfig, AdminControl, nodeName, serverName):
	cellName = AdminControl.getCell()
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
	
	datasourceCount = XPathCount.getCount(serverXML, "//websphere/server/resources/datasources/*", "")
	i = 1
	datasource = ""
	while i < datasourceCount+1:
		
		dsNum = ("datasource"+str(i))
		scope = Xparser.xFind(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/@scope")
		
		# get scope - TODO create base lib to do this
		if (scope == "server"):
			scopePath = '/Node:'+nodeName+'/Server:'+serverName+'/' 	
		if (scope == "node"):
			scopePath = '/Cell:'+cellName+'/Node:'+nodeName+'/'
	 	if (scope == "cell"):
			scopePath = '/Cell:'+cellName+'/'
		if (scope == "cluster"):
			scopePath = '/Cell:'+cellName+'/ServerCluster:'+clusterName+'/'	        
			
		jdbcProviderName = Xparser.xFind(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/@provider")
		
		# check if values exist  
		
		dataSourceName = Xparser.xFind(serverXML, "//websphere/server/resources/datasources/"+dsNum+"/@name")
		jdbcProvider = AdminConfig.getid(''+scopePath+'JDBCProvider:'+jdbcProviderName+'/') 
		datasourceExists = AdminConfig.getid(''+scopePath+'JDBCProvider:'+jdbcProviderName+'/DataSource:'+dataSourceName+'/')
		if (len(datasourceExists) > 0):
			print " "
			print "--> " +dataSourceName+ " exists ...removing"
			AdminConfig.remove(datasourceExists)
			AdminConfig.save()
		i = i + 1
#enddef
def createSecurityDomains(serverXML,AdminConfig,AdminContorl,AdminTask):
	configure = Xparser.xFind(serverXML, "//websphere/security/securitydomain/@configure")
	if (configure == "false"):
		print "--> Skipped: configure set to false"
		os._exit(0)
	elif (configure == None):
		print "---> Skipped: skipping security domain"
		os._exit(0)
	# get variables:
	domainCount = XPathCount.getCount(serverXML, "//websphere/security/securitydomain/*", "")
	i = 1
	while ( i < domainCount + 1 ):
		
		domainlist = AdminTask.listSecurityDomains().splitlines()
		domainNum = ("domain"+str(i))
		sdomainName = Xparser.xFind(serverXML,"//websphere/security/securitydomain/"+domainNum+"/@name")
		clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")

		for domain in domainlist:
			
			if ( domain == sdomainName ):
				print "Domain exists :"+ domain
				mapped = AdminTask.listResourcesInSecurityDomain('-securityDomainName '+domain)
				print mapped
				if not mapped:
					print "Mapping cluster to Security Domain"
					AdminTask.mapResourceToSecurityDomain('[-securityDomainName '+sdomainName+' -resourceName Cell=:ServerCluster='+clusterName+']')
					AdminConfig.save()
					return

				else:
					print "---> Skipped: skipping security domain already mapped"
					return

		regType = Xparser.xFind(serverXML,"//websphere/security/securitydomain/"+domainNum+"/userRegistry/@type")
		if ( regType == "CustomUserRegistry"):
			descpt = Xparser.xFind(serverXML,"//websphere/security/securitydomain/"+domainNum+"/@description")
			regClass = Xparser.xFind(serverXML,"//websphere/security/securitydomain/"+domainNum+"/userRegistry/@customRegClass")
			realmName = Xparser.xFind(serverXML,"//websphere/security/securitydomain/"+domainNum+"/userRegistry/@realmName")
			customPropCount = XPathCount.getCount(serverXML, "//websphere/security/securitydomain/"+domainNum+"/customProperties/*", "")
			properties = ""
			x = 1
			while ( x < customPropCount + 1):
				propNum = ("prop"+str(x))
				propName = Xparser.xFind(serverXML,"//websphere/security/securitydomain/"+domainNum+"/customProperties/"+propNum+"/@name")
				propValue = Xparser.xFind(serverXML,"//websphere/security/securitydomain/"+domainNum+"/customProperties/"+propNum+"/@value")
				property = "\""+propName+"="+propValue+"\""
				properties = properties + property
				if (x < customPropCount):
					properties = properties + ","
				x = x + 1
			print properties
			AdminTask.createSecurityDomain('[-securityDomainName '+sdomainName+' -securityDomainDescription "'+descpt+'"]')
			AdminTask.configureAppCustomUserRegistry('[-customRegClass '+regClass+' -customProperties ['+properties+'] -securityDomainName '+sdomainName+' -realmName '+realmName+' -ignoreCase false -verifyRegistry false ]')
			AdminTask.setAppActiveSecuritySettings('[-securityDomainName '+sdomainName+' -activeUserRegistry CustomUserRegistry]')
			AdminTask.setAppActiveSecuritySettings('[-securityDomainName '+sdomainName+' -appSecurityEnabled true]')
			AdminTask.configureAppCustomUserRegistry('[-securityDomainName '+sdomainName+' -verifyRegistry true ]')
			AdminTask.mapResourceToSecurityDomain('[-securityDomainName '+sdomainName+' -resourceName Cell=:ServerCluster='+clusterName+']')
			print "Domain configured" +sdomainName
			AdminConfig.save()
		elif(regType == "LDAPUserRegistry"):
			descpt = Xparser.xFind(serverXML,"//websphere/security/securitydomain/"+domainNum+"/@description")
			ldapHost = Xparser.xFind(serverXML,"//websphere/security/securitydomain/"+domainNum+"/userRegistry/@host")
			port = Xparser.xFind(serverXML,"//websphere/security/securitydomain/"+domainNum+"/userRegistry/@port")
			sslValue = Xparser.xFind(serverXML,"//websphere/security/securitydomain/"+domainNum+"/userRegistry/@sslEnabled")
			ldapType = Xparser.xFind(serverXML,"//websphere/security/securitydomain/"+domainNum+"/userRegistry/@ldapType")
			baseDN = Xparser.xFind(serverXML,"//websphere/security/securitydomain/"+domainNum+"/userRegistry/@baseDN")
			bindDN = Xparser.xFind(serverXML,"//websphere/security/securitydomain/"+domainNum+"/userRegistry/@bindDN")
			bindPassword = Xparser.xFind(serverXML,"//websphere/security/securitydomain/"+domainNum+"/userRegistry/@bindPassword")

			if ( sslValue != "true"):
				sslValue = "false"

			AdminTask.createSecurityDomain('[-securityDomainName '+sdomainName+' -securityDomainDescription "'+descpt+'"]')
			AdminTask.configureAppLDAPUserRegistry('[-securityDomainName '+sdomainName+' -ldapHost '+ldapHost+' -ldapPort '+port+' -ldapServerType '+ldapType+' -baseDN '+baseDN+' -bindDN '+bindDN+' -bindPassword '+bindPassword+' -searchTimeout 120 -reuseConnection true -sslEnabled '+sslValue+' -sslConfig -ignoreCase true -customProperties ["com.ibm.websphere.security.ldap.recursiveSearch=true"] -verifyRegistry false ]')
			AdminTask.configureAppLDAPUserRegistry('[-securityDomainName '+sdomainName+' -userFilter (&(sAMAccountName=%v)(objectClass=user)) -groupFilter (&(cn=%v)(objectClass=group)) -userIdMap user:sAMAccountName -groupIdMap *:cn -groupMemberIdMap memberof:member -certificateFilter -certificateMapMode EXACT_DN -customProperties ["com.ibm.websphere.security.ldap.recursiveSearch=true"] -verifyRegistry false ]')
			AdminTask.setAppActiveSecuritySettings('[-securityDomainName '+sdomainName+' -activeUserRegistry LDAPUserRegistry]')
			AdminTask.setAppActiveSecuritySettings('[-securityDomainName '+sdomainName+' -appSecurityEnabled true]')
			AdminTask.mapResourceToSecurityDomain('[-securityDomainName '+sdomainName+' -resourceName Cell=:ServerCluster='+clusterName+']')
			print "Domain configured " +sdomainName
			AdminConfig.save()
		i = i + 1
	#End While
#End def


#***********************************************************************
# create/update resource environment providers, REP custom properties, REP referenceable
#***********************************************************************
def resourceEnvironmentProviders(serverXML, AdminConfig, nodeName, serverName):
	#check if required configuration
	configure = Xparser.xFind(serverXML, "//websphere/server/resources/reProviders/@configure")
	
	if (configure == "false"):
		print "--> configure set to false ... skipping"
		return 0

	# ********************** variables ************************ #
	cellName = AdminControl.getCell()
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
	
	repCount = XPathCount.getCount(serverXML, "//websphere/server/resources/reProviders/*", "")
	i = 1
	rep = ""
	while i < repCount+1:
	
		repNum = ("rep"+str(i))
		scope = Xparser.xFind(serverXML, "//websphere/server/resources/reProviders/"+repNum+"/@scope")
		
		# get scope - TODO create base lib to do this
		if (scope == "server"):
			scopePath = '/Node:'+nodeName+'/Server:'+serverName+'/'			 	
		if (scope == "node"):
			scopePath = '/Cell:'+cellName+'/Node:'+nodeName+'/'
	 	if (scope == "cell"):
			scopePath = '/Cell:'+cellName+'/'
		if (scope == "cluster"):
			scopePath = '/Cell:'+cellName+'/ServerCluster:'+clusterName+'/'	        
						
		# check if resource environment provider exists
		repName = Xparser.xFind(serverXML, "//websphere/server/resources/reProviders/"+repNum+"/@name")
		repDes = Xparser.xFind(serverXML, "//websphere/server/resources/reProviders/"+repNum+"/@description")
		repId = AdminConfig.getid('/ResourceEnvironmentProvider:'+repName+'/')
		scopeId = AdminConfig.getid(scopePath)
		
		print "debug: scopeId --> ", scopeId
		if (len(repId) > 0):
			print " "
			print "--> resource environment provider:" +repName+ " exists. skipping ..."		
		else:
			#create the new resource environment provider
			print "--> creating resource environment provider: " +repName+ "..."
			AdminConfig.create('ResourceEnvironmentProvider', scopeId, '[[classpath ""] [name "'+repName+'"] [isolatedClassLoader "false"] [nativepath ""] [description "'+repDes+'"]]')
			AdminConfig.save()
		#endIf	
		newRepId = AdminConfig.getid('/ResourceEnvironmentProvider:'+repName+'/')
		print "debug: newRepId --> ", newRepId
		propSet = AdminConfig.showAttribute(newRepId, 'propertySet')
		print "debug: propSet -->", propSet
		if propSet == None:
			propSet = AdminConfig.create('J2EEResourcePropertySet',newRepId,[])
			AdminConfig.save()
		
		
		# REP custom properties
		repCustomPropCount = XPathCount.getCount(serverXML, "//websphere/server/resources/reProviders/"+repNum+"/customProperties/*", "")
		x = 1
		print "debug: repCustomPropCount --> ", repCustomPropCount
		while x < repCustomPropCount+1:
			# custom properties
			cPropNum = ("customProperty"+str(x))
			cName = Xparser.xFind(serverXML, "//websphere/server/resources/reProviders/"+repNum+"/customProperties/"+cPropNum+"/@name")
			cValue = Xparser.xFind(serverXML, "//websphere/server/resources/reProviders/"+repNum+"/customProperties/"+cPropNum+"/@value")			
				
			# Get the J2EE resource property set:
			resourceProperties = AdminConfig.list("J2EEResourceProperty", propSet).splitlines()
			print "debug: resourceProperties --> ", resourceProperties 
			found = 0
			for resourceProperty in resourceProperties:
				if (AdminConfig.showAttribute(resourceProperty, "name") == cName): 
					# Modify if values are different
					if (AdminConfig.showAttribute(resourceProperty, "value") != cValue): 
						print "----> update REP existing custom property: ", cName
						AdminConfig.modify(resourceProperty, [['value', cValue]])
						AdminConfig.save()
					else:
						print "----> found REP custom property, identical value.  did not modify: ", cName
					#endIf
					found = 1
					break
				#endIf
			#endFor
			
			if found == 0:
				# Add to the property set
				print "----> creating REP new custom property: ", cName, "  value:", cValue
				AdminConfig.create('J2EEResourceProperty', propSet, [["name", cName], ["value", cValue]])
				AdminConfig.save()
			#endIf
			x = x+1
		#endWhile

		i= i+1		
	#endWhile
#endDef

#***********************************************************************
# create/update resource environment entries
#***********************************************************************
def resourceEnvironmentEntries(serverXML, AdminConfig, nodeName, serverName):
	#check if required configuration
	configure = Xparser.xFind(serverXML, "//websphere/server/resources/reProviders/@configure")
	
	if (configure == "false"):
		print "--> configure set to false ... skipping"
		return 0

	# ********************** variables ************************ #
	cellName = AdminControl.getCell()
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
	

	# check if resource environment provider exists, create if doesnt.
	resourceEnvironmentProviders(serverXML, AdminConfig, nodeName, serverName)
	
	repCount = XPathCount.getCount(serverXML, "//websphere/server/resources/reProviders/*", "")
	a = 1
	rep = ""
	while a < repCount+1:
	
		repNum = ("rep"+str(a))
		scope = Xparser.xFind(serverXML, "//websphere/server/resources/reProviders/"+repNum+"/@scope")
		
		# get scope - TODO create base lib to do this
		if (scope == "server"):
			scopePath = '/Node:'+nodeName+'/Server:'+serverName+'/'			 	
		if (scope == "node"):
			scopePath = '/Cell:'+cellName+'/Node:'+nodeName+'/'
	 	if (scope == "cell"):
			scopePath = '/Cell:'+cellName+'/'
		if (scope == "cluster"):
			scopePath = '/Cell:'+cellName+'/ServerCluster:'+clusterName+'/'	        
						
		
		repName = Xparser.xFind(serverXML, "//websphere/server/resources/reProviders/"+repNum+"/@name")		
		repId = AdminConfig.getid(scopePath+'ResourceEnvironmentProvider:'+repName+'/')
		scopeId = AdminConfig.getid(scopePath)
		
		# get the number of ree
		reeCount = XPathCount.getCount(serverXML, "//websphere/server/resources/reProviders/"+repNum+"/reEntries/*", "")
		b = 1
		while b < reeCount+1:
			# get ree attributes form xml file
			reeNum = ("reEntry"+str(b))
			reeName = Xparser.xFind(serverXML, "//websphere/server/resources/reProviders/"+repNum+"/reEntries/"+reeNum+"/@name")
			reeJndi = Xparser.xFind(serverXML, "//websphere/server/resources/reProviders/"+repNum+"/reEntries/"+reeNum+"/@jndi")			
			reeDesc = Xparser.xFind(serverXML, "//websphere/server/resources/reProviders/"+repNum+"/reEntries/"+reeNum+"/@description")			

                        factoryClassName = Xparser.xFind(serverXML, "//websphere/server/resources/reProviders/"+repNum+"/reEntries/"+reeNum+"/@factoryClassName")
                        className = Xparser.xFind(serverXML, "//websphere/server/resources/reProviders/"+repNum+"/reEntries/"+reeNum+"/@className")

                        print "factoryClassName:"+factoryClassName
                        print "className:"+className
                        print "Creating ref:" 
                        locate = 0

                        refList = AdminConfig.list("Referenceable").splitlines()    
                        refereId = ""

                        for refItem in refList:
                                refItemFCValue = AdminConfig.showAttribute(refItem, "factoryClassname")
                                if (refItemFCValue == factoryClassName):
                                        # Modify if class name are different
                                        if (AdminConfig.showAttribute(refItem, "classname") != className):
                                                print "----> update REP existing referenceable factory class: ", factoryClassName
                                                AdminConfig.modify(refItem, [['classname', className]])
                                                AdminConfig.save()
                                        else:
                                                print "----> found REP referenceable factory class, identical class name value.  did not modify: ", factoryClassName
                                        #endIf
                                        locate = 1
                                        refereId = refItem
                                        break
                                #endIf
                        #endFor

                        if locate == 0:
                                # create new referenceable
                                print "----> creating REP referenceable: ", factoryClassName, "  classname:", className
                                refereId=AdminConfig.create('Referenceable', repId, [["factoryClassname", factoryClassName], ["classname", className]])
                                AdminConfig.save()
                                print "refereId"+refereId
                        #endIf
                        print "Ref has been created:"
			
			# get ree id
			reePath = scopePath+'ResourceEnvironmentProvider:'+repName+'/'
			reeId = AdminConfig.getid(reePath+'ResourceEnvEntry:'+reeName+'/')
			if (len(reeId) > 0):
				print " "
				print "--> resource environment entries: " +reeName+ " exists. skipping ..."		
			else:
				#create the new resource environment provider
				print "----> creating resource environment entries: " +reeName+ "..."
				AdminConfig.create('ResourceEnvEntry', repId, '[[name "'+reeName+'"] [jndiName "'+reeJndi+'" ] [referenceable "'+refereId+'" ] [description "'+reeDesc+'"]]')
				AdminConfig.save()
			#endIf	
			
			newReeId = AdminConfig.getid(reePath+'ResourceEnvEntry:'+reeName+'/')
			reePropSet = AdminConfig.showAttribute(newReeId, 'propertySet')

			if reePropSet == None:
				reePropSet = AdminConfig.create('J2EEResourcePropertySet',newReeId,[])
				AdminConfig.save()


			# REE custom properties
			reeCustomPropCount = XPathCount.getCount(serverXML, "//websphere/server/resources/reProviders/"+repNum+"/reEntries/"+reeNum+"/customProperties/*", "")
			c = 1

			while c < reeCustomPropCount+1:
				# custom properties
				reeCPnum = ("customProperty"+str(c))
				reeCPname = Xparser.xFind(serverXML, "//websphere/server/resources/reProviders/"+repNum+"/reEntries/"+reeNum+"/customProperties/"+reeCPnum+"/@name")
				reeCPvalue = Xparser.xFind(serverXML, "//websphere/server/resources/reProviders/"+repNum+"/reEntries/"+reeNum+"/customProperties/"+reeCPnum+"/@value")			
				
				# Get the J2EE resource property set:
				reeResourceProperties = AdminConfig.list("J2EEResourceProperty", reePropSet).splitlines()
	
				temp = 0
				for reeSourceProperty in reeResourceProperties:
					if (AdminConfig.showAttribute(reeSourceProperty, "name") == reeCPname): 
						# Modify if values are different
						if (AdminConfig.showAttribute(reeSourceProperty, "value") != reeCPvalue): 
							print "----> update REE existing custom property: ", reeCPname
							AdminConfig.modify(reeSourceProperty, [['value', reeCPvalue]])
							AdminConfig.save()
						else:
							print "----> found REE custom property, identical value.  did not modify: ", reeCPname
						#endIf
						temp = 1
						break
					#endIf
				#endFor
			
				if temp == 0:
					# Add to the property set
					print "----> creating REE new custom property: ", reeCPname, "  value:", reeCPvalue
					AdminConfig.create('J2EEResourceProperty', reePropSet, [["name", reeCPname], ["value", reeCPvalue]])
					AdminConfig.save()
				#endIf
				c = c+1				
			#endWhile
			b = b+1
		#endWhile
		
		a = a+1		
	#endWhile
#endDef



#***********************************************************************
# create/update cache object cache instance
#***********************************************************************
def objectCacheInstances(serverXML, AdminConfig, AdminTask, nodeName, serverName):
	#check if required configuration
	configure = Xparser.xFind(serverXML, "//websphere/server/resources/cacheInstances/@configure")
	
	if (configure == "false"):
		print "--> cache instance configure set to false ... skipping"
		return 0

	# ********************** variables ************************ #
	cellName = AdminControl.getCell()
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")

	objectCacheCount = XPathCount.getCount(serverXML, "//websphere/server/resources/cacheInstances/objectCacheInstances/*", "")

	x = 1
	while x < objectCacheCount+1:
	
		ociNum = ("oci"+str(x))
		
		ociName = Xparser.xFind(serverXML, "//websphere/server/resources/cacheInstances/objectCacheInstances/"+ociNum+"/@name")		
		ociJndi = Xparser.xFind(serverXML, "//websphere/server/resources/cacheInstances/objectCacheInstances/"+ociNum+"/@jndi")		
                ociType = Xparser.xFind(serverXML, "//websphere/server/resources/cacheInstances/objectCacheInstances/"+ociNum+"/@type")
                ociEnable = Xparser.xFind(serverXML, "//websphere/server/resources/cacheInstances/objectCacheInstances/"+ociNum+"/@enable")
		scope = Xparser.xFind(serverXML, "//websphere/server/resources/cacheInstances/objectCacheInstances/"+ociNum+"/@scope")

		# get scope - TODO create base lib to do this
		if (scope == "server"):
			scopePath = '/Node:'+nodeName+'/Server:'+serverName+'/'			 	
		if (scope == "node"):
			scopePath = '/Cell:'+cellName+'/Node:'+nodeName+'/'
		if (scope == "cell"):
			scopePath = '/Cell:'+cellName+'/'
		if (scope == "cluster"):
			scopePath = '/Cell:'+cellName+'/ServerCluster:'+clusterName+'/'	        

		cellScopePath = '/Cell:'+cellName+'/'
		cellScopeId = AdminConfig.getid(cellScopePath)
		scopeId = AdminConfig.getid(scopePath)
		cacheProviderId = AdminConfig.getid(''+scopePath+'CacheProvider:CacheProvider/')

		# Get  cache instance list
		ciList = AdminConfig.list('CacheInstance', cellScopeId).splitlines()
		
		locate = 0
		for ciItem in ciList:
			cacheInstanceName = AdminConfig.showAttribute(ciItem, "name")
			if (cacheInstanceName == ociName): 
				# Modify if class name are different
				if (AdminConfig.showAttribute(ciItem, "jndiName") != ociJndi): 
					print "--> update object cache instance existing jndi value: ", ociName
					AdminConfig.modify(ciItem, [['jndiName', ociJndi]])
					AdminConfig.save()
				else:
					print "--> found object cache instance , identical jndi name value.  did not modify: ", ociJndi
				#endIf
				locate = 1
				break
			#endIf
		#endFor
			
		if locate == 0:
			# create new object cache instance
			print "--> creating object cache instance: ", ociName, "  jndi name:", ociJndi
			obj1 = AdminTask.createObjectCacheInstance(cacheProviderId, ['-name', ociName, '-jndiName', ociJndi])
                        if ( len(ociEnable) > 0 ):
                              if ( len(ociType) > 0):
                                  AdminConfig.modify(obj1, '[[enableCacheReplication '+ociEnable+'] [replicationType '+ociType+']]')
                              else:
                                  AdminConfig.modify(obj1, '[[enableCacheReplication '+ociEnable+']]')

			AdminConfig.save()
		#endIf

		x = x+1
	#endWhile
#endDef


#***********************************************************************
# Generate Plugin
#***********************************************************************
def resourceGeneratePlugin(serverXML, AdminConfig, AdminControl, nodeName, serverName):
        print " --> hello "
        cellName = AdminControl.getCell()
        #serverName = Xparser.xFind(serverXML, "//websphere/webservers/webserver1/@name")
        #nodeName = Xparser.xFind(serverXML, "//websphere/webservers/webserver1/@nodeName")
        versionNo =  Xparser.xFind(serverXML, "//websphere/installation/was/@version")
        dmConfig = Xparser.xFind(serverXML, "//websphere/webservers/webserver1/@dmgrConfig")
        rootProfile = "/opt/IBM/WebSphere/Profiles/Dmgr01"
        generator = AdminControl.completeObjectName('type=PluginCfgGenerator,*')
        print " --> cell Name: ", cellName
        print " --> server name:", serverName
        print " --> node name:", nodeName
        print " --> dmgr config:", dmConfig
       #AdminControl.invoke(generator, 'generate', " dmConfig + " " + cellName + " " + nodeName + " " + serverName + " " true")
        print " --> generating the global plugin "
        AdminControl.invoke(generator, 'generate', rootProfile + " " + dmConfig + " " + cellName + " null null plugin-cfg.xml")
        print " --> propogating the global plugin "
        AdminControl.invoke(generator, 'propagate', "" + dmConfig + " " + cellName + " " + nodeName + " webserver1")
       #AdminControl.invoke(generator, 'generate', "/opt/IBM/WebSphere/Profiles/Dmgr01/config DefaultDmgrCell_1 ihsvmNode_3 webserver1 true")

#endDef
