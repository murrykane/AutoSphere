# *********************************************************
# Created by: Jeffrey Apiado
# Owned by: IT NPE WEB Team
# Role: Class for parsing XML in AutoSphere/xml directory
#        no intention to replace Xparser java class, use this
#        to extend parsing capability. 
# *********************************************************
# Modified:
#   Version1.0               July 17, 2019          Jeffrey
#
#
# *********************************************************
import xml.etree.ElementTree as ET

class parse:
     def __init__(self, xmlfile):
          self.root = ET.parse(xmlfile).getroot()

     def getRep_count_all(self):
          getrep_all = []
          for cp in self.root.findall("./server/resources/reProviders"):
                for rep in cp:
                   for xxx in rep:
                       getrep_all.append(rep.tag)
          if getrep_all:
              return (len(getrep_all), getrep_all)
          else:
              return (None, None)
                        
     def getRep_count_withEntry(self):
          getrep_with_entries = []
          for cp in self.root.findall("./server/resources/reProviders"):
                for rep in cp:
                   for xxx in rep:
                       if xxx.tag == 'reEntries':
                           getrep_with_entries.append(rep.tag)        
          if getrep_with_entries:
              return (len(getrep_with_entries), getrep_with_entries)
          else:
              return (None, None)

     def getRep_count_withoutEntry(self):
         entrybox = []
         for np in self.root.findall("./server/resources/reProviders"):
                for rep in np:
                   for yyy in rep:
                        if yyy.tag == 'customProperties':
                           entrybox.append(rep.tag)
         if entrybox:
              return (len(entrybox), entrybox)
         else:
              return (None, None)
         

     def getRep_entry_count(self, repnumber):
         (count, array)  = self.getRep_count_withEntry()
         if repnumber in array:
            holder = []
            for r in self.root.findall("./server/resources/reProviders/%s/reEntries" % repnumber):
                 for renum in r:
                     holder.append(renum.tag) 
            return (len(holder), holder)
         else:
            return (None, None)

     def getCustom_property(self, repnumber, entrynumber):
         (count, array) = self.getRep_count_withEntry()
         (countA, arrayA) = self.getRep_entry_count(repnumber)
         if repnumber in array and entrynumber in arrayA:
            holderA = []
            for c in self.root.findall("./server/resources/reProviders/%s/reEntries/%s/customProperties" % (repnumber, entrynumber)):
                for custom in c:
                   holderA.append(custom.attrib)
            return (len(holderA), holderA)
         else:
            return (None, None)

     def getCustom_property_for_noEntryTag(self, repnumber):
         (countA, arrayB) = self.getRep_count_withoutEntry()
         if repnumber in arrayB:
             holderB = []
             for noEntry in self.root.findall("./server/resources/reProviders/%s/customProperties" % repnumber):
                  for ncustom in noEntry:
                       holderB.append(ncustom.attrib)
             return (len(holderB), holderB)
         else:
             return (None, None)

     def evalHash(self, data):
          _dict = {}
          _name = data['name']
          _value = data['value']
          _dict[_name] = _value
          return _dict

#if __name__ == '__main__':
#     inst = parse('/opt/jenkins/AutoSphere/xml/employer/prtn60employer.xml')
#     count, data = inst.getCustom_property_for_noEntryTag('rep5')
#     for line in data:
#          xx = inst.evalHash(line)
#          print xx        

