import sys
import java.io
import Xparser
import XPathCount
from com.ibm.ISecurityUtilityImpl import PasswordUtil

#********************************************************
#  configure jaas j2c
#********************************************************
def configureJAAS(serverXML, taskName, AdminConfig, AdminControl):

	#global AdminControl
	#global AdminConfig

	cellName = AdminControl.getCell()
	securityConfigID = AdminConfig.getid('/Cell:' +cellName+ '/Security:/')
	
	#Get all J2C Authentication Aliases
	j2cList = AdminConfig.list('JAASAuthData', securityConfigID)

	j2cCount = XPathCount.getCount(serverXML, "//websphere/security/jaas/*", "")

	i = 1
	j2c = ""
	while i < j2cCount+1:
		j2cNum = ("j2c"+str(i))

		dbalias = Xparser.xFind(serverXML, "//websphere/security/jaas/"+j2cNum+"/@name")
        	dbuser = Xparser.xFind(serverXML, "//websphere/security/jaas/"+j2cNum+"/@userid")
		dbpassword = Xparser.xFind(serverXML, "//websphere/security/jaas/"+j2cNum+"/@password")

		decodepass = PasswordUtil.passwordDecode(dbpassword)
		

		jaasAttrs = [['alias', dbalias], ['userId', dbuser], ['password', decodepass]]

		tmp1 = 0
		tmp2 = 0
		tmp3 = 0

		if len (j2cList) > 0:
			for j2cId in j2cList.splitlines():
				if (AdminConfig.showAttribute(j2cId, "alias") == dbalias):
					if (taskName == "createJAAS"):
						tmp1 = 1

					elif (taskName == "updateJAAS"):
						tmp2 = 1
						print "--> start: update JAAS J2C"
						print "-->   Updating JAAS J2C:", dbalias

						#update j2c authentication alias
						AdminConfig.modify(j2cId, [['userId', dbuser], ['password', decodepass]])
					
        					AdminConfig.save()
        					print "--> end: update JAAS J2C"
						print ""

					else:
						tmp3 = 1	
						print "--> start: delete JAAS J2C"
						print "-->   Deleting JAAS J2C:", dbalias

						#delete j2c authentication alias
						AdminConfig.remove(j2cId)
					
        					AdminConfig.save()
        					print "--> end: delete JAAS J2C"
						print ""

					#endIf
					
				#endIf
			#endFor
		#endIf
       		
		if (taskName == "createJAAS"):			 
			if (tmp1 == 0):	
				print "--> start: create JAAS J2C"
				print "-->   Creating jaas j2c:", dbalias

				#create J2C Authentication Alias
				AdminConfig.create('JAASAuthData', securityConfigID, jaasAttrs)
	
				AdminConfig.save()
				print "--> end: create JAAS J2C"
				print ""
			else:
				print "--> skip JAAS J2C creation, alias already exists:", dbalias
				print ""
			#endIf
	
		elif (taskName == "updateJAAS"):
			if  tmp2== 0:
				print "--> skip J2C update, alias does not exists:", dbalias
				print "--> to create alias, run the create_jaas task"
			#endIf
		
		else:
			if  tmp3== 0:
				print "--> skip JAAS J2C deletion, alias does not exists:", dbalias
				print ""
			#endIf

		#endIf

		i = i+1
	#endWhile
#endDef

#********************************************************
# script usage: 
#********************************************************

def usage():
	print " "
        print " "
        print " usage: python security.py [option] [environment type] [instance]"
        print " example: python security.py createJAAS nxsa dev01_nx"
        print " "
        print " current options:"
        print " ----------------"
        print " 1) createJAAS [steps: creates the JAAS J2C alias]"
        print " 2) updateJAAS [steps: updates the JAAS J2C user and password]"
        print " 3) deleteJAAS [steps: deletes the JAAS J2C user and password]"
        print " " 
#endDef
        
#********************************************************
# main: 
#********************************************************

def main():
        
	print " "
	print " "
        

	# check arguments
	if len(sys.argv) < 3:
		usage()
		sys.exit(1)
	#endIf

        # expected input	
        shieldHome = sys.argv[0]
        envType = sys.argv[1] 
        instance = sys.argv[2]
        task = sys.argv[3]


        # variables
	xmlBasePath = (shieldHome+"/xml/")
        
        #xml path
	serverXML = (xmlBasePath+envType+"/"+instance+".xml")
        
	if (task == "createJAAS"):
		configureJAAS(serverXML, "createJAAS")
	elif (task == "updateJAAS"):
		configureJAAS(serverXML, "updateJAAS")
	elif (task == "deleteJAAS"):
		configureJAAS(serverXML, "deleteJAAS")
	else:
		print "option: " + task + " not found"
		usage()
	#endIf 
        
#endDef
# call main
#main()   
        
