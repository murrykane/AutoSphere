#########################################################################
# File: jdbc_resources.py
# Lang: Jython - wsadmin
# Author: Jeffrey Apiado
# Role: JDBC provider classpath and DATASource ResourcePropertyUrl update
# Created: 8/7/2020
#########################################################################

import re, sys
from com.ibm.ws.scripting import ScriptingException

class jdbc:
      def __init__(self, provClassPath, rsPropertyUrl):
          self.provClassPath =  provClassPath
          self.rsPropertyUrl = rsPropertyUrl
          self.cell = AdminControl.getCell()
          ids = AdminConfig.getid('/Cell:%s' % self.cell)
          clusterList = AdminConfig.list('JDBCProvider', ids).splitlines()
          self.clsFilter = [cluster for cluster in clusterList if not re.search('Derby|OTiS', cluster, re.I)]

      def classPath(self):
          print "SCRIPT [[ START ]] ---------------------- JDBC --  DATASOURCE -- CLUSTER -------------------------------------------------------------------------------   [[ RUN ]]"
          display = "JDBC classPath change to --- [ %s ]" % self.provClassPath 
          print display
          classy = '[classpath "${ORACLE_JDBC_DRIVER_PATH}/%s"]' % self.provClassPath
          for clustr in self.clsFilter:
              print "CLUSTER mbean: %s" % clustr
              sis, x = clustr.split('(',2)
              print "        name: %s" % sis
              if re.search('Denodo', sis, re.I):
                  d1 =  "       <WARNING> name: %s" % sis
                  math = 150 - len(d1)
                  d1 += " " * math
                  d1 += ". . . [ SKIP ]"
                  print d1
                  continue
              else:
                  e1 =  "       <INFO> name: %s" % sis
                  math = 150 - len(e1)
                  e1 += " " * math
                  e1 += ". . . [ APPLY ]"
                  print e1
              mbean = '(%s' % x
              # unset attributes first!
              AdminConfig.unsetAttributes(mbean, '["classpath"]')
              try:
                  AdminConfig.modify(mbean,'[%s]' % classy )
              except ScriptingException:
                  print "Error:\n"+str(sys.exc_info()[1])
          AdminConfig.save()

      def propertyUrl(self):
          boo = "URL resource property change to --- [ %s ]" % self.rsPropertyUrl
          print boo
          for clustr in self.clsFilter:
              print "CLUSTER mbean: %s" % clustr
              if re.search('Denodo', clustr, re.I):
                  f1 =  "     <WARNING> name: %s" % clustr
                  math = 150 - len(f1)
                  f1 += " " * math
                  f1 += ". . . [ SKIP ]"
                  print f1
                  continue 
              urls = self.get_j2eeResourceProperty(clustr) 
              self.propertySet(urls)
          print  "SCRIPT [[ END ]] -------------------------- JDBC -- DATASOURCE -- CLUSTER -------------------------------------------------------------------------------- [[ EXIT ]]"          

      def get_j2eeResourceProperty(self, clustr):
          primvar = clustr.split('(')[0]
          clustername, jdbc = primvar.split('_', 2)
          n1 = AdminConfig.list('J2EEResourceProperty', "URL*").splitlines()
          n2 = [x for x in n1 if x.find(clustername) > -1]
          return n2

      def propertySet(self, url):
          for j2 in url:
             g1 =  "     <INFO> URL mbean: %s" % j2
             math = 150 - len(g1)
             g1 += " " * math
             g1 += ". . . [ APPLY ]"
             print g1
             v = j2.split('(')[1]                           
             conc = "(%s" % v
             define = '[name "URL"][type "java.lang.String"][value "%s"][required "true"]' % self.rsPropertyUrl 
             print "     value: %s" % define
             try:
                AdminConfig.modify(conc, '[%s]' % define)
             except ScriptingException:     
                print "Error:\n"+str(sys.exc_info()[1])
          AdminConfig.save()

if __name__ == "__main__":
     x = len(sys.argv)
     if x > 0 and x < 3: 
        cpath = sys.argv[0]
        rsUri = sys.argv[1]
        objinstance = jdbc(cpath, rsUri)
        objinstance.classPath()
        objinstance.propertyUrl()
     else:
        print "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=----------------------------------------"
        print "HELP:                          Missing Number of Arguments !!!!!!!!!                                           "
        print "Syntax: ./wsadmin.sh -lang jython -f /tmp/jdbc_resources.py arg1 arg2                                          "
        print "[Arguments] arg1 [ provider Class Path ]                                                                       "
        print "            arg2 [ resource Property URL ]                                                                     "
        print "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=--=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-----------------------------------------" 
        print "ex: ./wsadmin.sh -lang jython -f ~/jython/jdbc_resources.py ojdbc8.jar jdbc:oracle:thin:@uora3340n:12521/WPRX01"
     # ================================== EOL =================================================================================
