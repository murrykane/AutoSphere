# ====================================================
# Created by: Jeffrey Apiado
# Role: ADD  administrative custom properties
# Input: 'serverName' or 'all'
#        'json file containing propertyname and value
# Created: 6/25/2020
# Type: wsadmin script (websphere)
#        modify: 8/18/20      -   wsadmin no module json supported
# ====================================================
import sys, os, re


class srvinfra_props:
   def __init__(self, sname, jfile):
       if not os.path.isfile(jfile):
          print "Error: undefine json file path in %s ............... [MISSING]" % jfile
          sys.exit(1)
       self.jfile = jfile
       if re.search(r'^all', sname, re.I):
          sbool = True
          raw = AdminConfig.list('ApplicationServer').splitlines()
          self.aole = [item for item in raw if not re.search('dmgr', item, re.I)]
       else:
           ids = AdminConfig.getid('/Server:%s/' % sname)
           self.aole = [AdminConfig.list('ApplicationServer', ids)]
           sbool = False
       self.snamecondition = sbool 

   def runner(self):
       content = open(self.jfile, "r")
       item = content.read()
       content.close()
       my_dict = eval(item)
       for single in self.aole:
           print 'server Mbean: - ',single
           # ===========================================
           content = AdminConfig.list('Property',single).splitlines()
           print 'Current property array -> ',content
           print '------------------------------------------------'
           
           self.add_customprop(content, my_dict, single)
           AdminConfig.save()

   def add_customprop(self, current, hashmap, webcon): 
       print "webcon: ",webcon
       for name, value in hashmap.iteritems():
              inside = self.stringformat(current)
              check = [i for i in inside if re.search(name, i)]
              if check == []:
                 print "---- ADD ----"
                 print "%s propertyname not found in current container property list" % name
                 self.creator(name, value, webcon)
              else: 
                 print "--- skip ---"
                       

   def creator(self, name, value, webcon):
       print "Add new propertyname: %s ... value: %s" % (name, value)
       attr = [['name',name],['value',value]]
       AdminConfig.create('Property', webcon, attr)

   def stringformat(self, somelist):
       hold = []
       for item in somelist:
           if item.startswith('[') and item.endswith(']'):
                hold.append(item[1:-1])
           elif item.find('[') > -1:
                hold.append(item[1:])
           elif item.find(']') > -1:
                hold.append(item[:-1])
           else:
                hold.append(item)
       print "arraylist before return ",hold
       return hold


if __name__== "__main__":
    if len(sys.argv) > 1:
       sname = sys.argv[0]
       jfile = sys.argv[1]
       runtask = srvinfra_props(sname, jfile)
       runtask.runner()
    else:
       print "Argument: ==========================================================================="
       print "Require server name as 1st argument or type 'all'                         ARGS1"
       print "Json file path as 2nd argument ex: /tmp/properties.json                   ARGS2"
       print "======================================================="
       print "command construct: wsadmin.sh -lang jython -f /tmp/administrative_customproperty.py (web60Consumer1 or 'all') /tmp/myproperty.json"
       print """json file: contain hash of properties name and value
                        example:
                 {
                     "ibm.com.prop":"600",
                     "whatever.follows":"string"
                 }
             json syntax checker: 'https://jsonlint.com/' 
       """
       print "======================================================================================"
       sys.exit(0)
