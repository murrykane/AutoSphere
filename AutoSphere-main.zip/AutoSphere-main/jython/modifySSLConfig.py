#===================================================
# 	Name: modifySSLConfig.py
# 	Author: Jeffrey Apiado
# 	Role: SSL Configuration for custom keyStore
# 	Created: 04/04/2018
#===================================================
# START [define globals]
#===================================================
import re
patt=re.compile(r'^(w\w+\d+Key\w+?)\(', re.I)
_alias = "NodeDefaultSSLSettings"
_keyAlias = "npe-web-dp-ssl.bsc.bscal.com"
_truststorename = "CellDefaultTrustStore"
#===================================================
# Built in Modules
#===================================================
from java.lang import ProcessBuilder
from java.util.logging import Logger
from java.util.logging import Level
from java.util.logging import FileHandler
from java.util.logging import LogManager, SimpleFormatter
import os, StringIO, threading, Queue, time
from java.lang import ProcessBuilder
from java.io import InputStreamReader
from java.io import BufferedReader
from java.io import File
#-----------------------------------------------------
#--------------------------------------------------------------------------
class customLog:
    def __init__(self, fname = "jython", style = "txt", strr = '_fixPack'):
        self.fh = FileHandler(fname + strr + '%u_.log',50000,1)
        # note: making sure output in text format
        if style == "txt":
            self.fh.setFormatter( SimpleFormatter() )
        #end

        self.logger = Logger.getLogger("myLogger")
        self.logger.addHandler(self.fh)
    #end

    def debug(self, text):
        self.logger.log(Level.INFO, text)
    #end

    def info(self, text):
        self.logger.log(Level.INFO, text)
    #end

    def warn(self, text):
        self.logger.log(Level.WARNING, text)
    #end

    def error(self, text):
        self.logger.log(Level.SEVERE, text)
    #end

    def HEADING(self, text):
        self.logger.log(Level.CONFIG, text)
    #end

    def finer(self, text):
        self.logger.log(Level.FINER, text)
    #end

    def close(self):
        self.fh.close()
    #end
#end
#=======================================================
class Utils:
    def __init__(self, clog):  
        print "**** class[Utils] ****"
        clog.info(self, "**** class[Utils] ****")
        self.clog = clog
    #end

    def processBuild(self, jcmd):
        SIOS = StringIO.StringIO()
        proc = ProcessBuilder(jcmd)
        proc.directory(File("/")) # keep it in root as its execution working directory
        proc.redirectErrorStream()
        outputStream = proc.start()
            
        br = BufferedReader(InputStreamReader(outputStream.getInputStream()))
        line = br.readLine()
        while line != None:
            SIOS.write(line + "\n")
            line = br.readLine()
        try:
            outStr = SIOS.getvalue()
        except:
            outStr = ""
        #outputStream.waitFor(10, TimeUnit.SECONDS)
        br.close()
        SIOS.flush()
        SIOS.close()

        io = outputStream.waitFor()
        self.clog.info(self, str(io))
        return outStr
    #end        

    def myThread(self, items):
        q = Queue.Queue()
        hold = Queue.Queue()
        for ai in items:
            q.put(ai[1])

        p = threading.Thread(target=listKeyStores, args=(q,hold,))
        p.setDaemon(1)
        p.start()
        p.join()
        global d
        d = hold.get() 
    #end

    def prepSSL(self, scopen):
        self.clog.info(self, str(d))        
        for scope, keyStore in d.iteritems():
             print scope + "=====> ",keyStore
             if keyStore != "nil":
                  self.modifySSL(scope, keyStore, scopen)
                  print "**ConfigSaved***"
             else:
                self.clog.warn(self, "ScopeName: %s has [NULL] keyStoreName" % scope) 
                self.clog.warn(self, "Value: null [SSL config not modified]")
                print "**Unchanged!**"
             #end
    #end

    def modifySSL(self, _scona, _kstoren, _scopen):
        print ""
        print "============================================================================================>"
        prep = "[-alias %s -scopeName %s -keyStoreName %s -keyStoreScopeName %s -trustStoreName %s -trustStoreScopeName %s -serverKeyAlias %s -clientKeyAlias %s]" 
        param = prep % (_alias, _scona, _kstoren, _scopen, _truststorename, _scopen, _keyAlias, _keyAlias)
        print param
        self.clog.info(self, "Argument String: %s" % param)
        #========================================
        ret = AdminTask.modifySSLConfig(param)
		if ret:
		   self.clog.warn(self, str(ret))
		else:
           AdminConfig.save()
        #end =======================================
        print "Config SAVE [done]"
        self.clog.info(self, "Config SAVE [done]")
    #end

def listKeyStores(q, hold):
    DICT={}
    while not q.empty():
         scpname = q.get()
         outscope = AdminTask.listKeyStores('[-scopeName %s]' % scpname).splitlines()
         for item in outscope:
             k = item.encode("ascii", "ignore")
             s = patt.search(k)
             if s:
                contain = s.group(1)
             else:
                contain = None
             #end ====================================
             if contain:
                 DICT[scpname] = contain
                 hold.put(DICT)
             else:
                 DICT[scpname] = "nil"
                 hold.put(DICT)
             #end
	     #end
    #end
        
#==========================================================
class mainStart(customLog, Utils):
    def __init__(self, logdestination):
         customLog.__init__(self, logdestination)
         customLog.info(self, "**** class: mainStart ****")
         Utils.__init__(self, customLog)
         self.managedScopes = AdminTask.listManagementScopes().splitlines()
    #end

    def runStart(self):
        customLog.info(self, "**** module runStart ****")
        strC = [x.split()[1] for x in self.managedScopes if x.find("node") == -1]
        storeScope = strC[0].encode("ascii","ignore") #convert unicode to string ignore special character
        customLog.info(self, str(storeScope)) 
        scopes = [fin.split() for fin in self.managedScopes if fin.find("node") > -1 and fin.find("server") == -1 and fin.find("Dmgr01") == -1]
        customLog.info(self, str(scopes))
        Utils.myThread(self, scopes)
        Utils.prepSSL(self, storeScope) 
    #end

    def conclude(self):
        print "***********************************************"
        print "End of script [SSLConfigurtaion]"
        print "see logs in /tmp/sslModConfig.log_fixPack0_.log"
        print ""
        customLog.info(self, "END of file====================================================")
        customLog.close(self)
    #end
#end
#----------------------------------------------------------

if __name__ == "__main__":
     ix = mainStart("/tmp/sslModConfig.log")
     ix.runStart()
     ix.conclude()
#end
