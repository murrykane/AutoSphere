#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 02/06/2017 Murry Kane     Initial version
#
#_________________________________________________________________________________________________
#
# AdminTask.modifySSLConfig('[-alias CellDefaultSSLSettings -scopeName (cell):WEBN208Cell -keyStoreName CellDefaultKeyStore -keyStoreScopeName (cell):WEBN208Cell -trustStoreName CellDefaultTrustStore -trustStoreScopeName (cell):WEBN208Cell -jsseProvider IBMJSSE2 -sslProtocol SSL_TLSv2 -clientAuthentication false -clientAuthenticationSupported false -securityLevel HIGH -enabledCiphers ]')
# AdminTask.modifySSLConfig('[-alias NodeDefaultSSLSettings -scopeName (cell):WEBN208Cell:(node):WEBN208ContentNode01 -keyStoreName WEBN208Keystore -keyStoreScopeName (cell):WEBN208Cell -trustStoreName CellDefaultTrustStore -trustStoreScopeName (cell):WEBN208Cell -jsseProvider IBMJSSE2 -sslProtocol SSL_TLSv2 -clientAuthentication false -clientAuthenticationSupported false -securityLevel HIGH -enabledCiphers ]')
#

import os, sys, re
from constants import *

if os.path.isfile('%s/wsadminlib.py' % JYTHON_DIR):
  execfile('%s/wsadminlib.py' % JYTHON_DIR)
else:
  print "Needed library wsadminlib.py NOT Found, exiting!"
  sys.exit(1)

enableDebugMessages()
m="updateSSL-TLS:"

#lets validate we are on a DMGR!
if whatEnv() == 'nd':
  sop(m, "Running on DMGR, continueing...")
else:
  sop(m, "ERROR: You must run this script on the DMGR!, exiting!")
  sys.exit(2)

def usage():
  print "Usage: %s Alias, KeyStore, CellDefaultStore, PersonalKeyStore, TLS_value, customPropertyFlag, customPropertyName, customPropertyValue" % m

if ( len(sys.argv) != 9):
  usage()
  sys.exit(1)
else:
  Alias = sys.argv[0]
  KeyStore = sys.argv[1]
  CellDefaultStore = sys.argv[2]
  PersonalKeyStore = sys.argv[3]
  tls_value = sys.argv[4]
  customPropertyFlag = sys.argv[5]
  customPropertyName = sys.argv[6]
  customPropertyValue = sys.argv[7]
  NodeDefaultSSLSetting = sys.argv[8]

cellName = getCellName()  

sop(m,"Alias %s" % Alias)
sop(m,"KeyStore %s" % KeyStore)
sop(m,"CellDefaultStore %s" %CellDefaultStore)
sop(m,"PersonalKeyStore %s" % PersonalKeyStore)
sop(m,"TLSValue %s" % tls_value)
sop(m,"customPropertyFlag %s" % customPropertyFlag)
sop(m,"customPropertyName %s" % customPropertyName)
sop(m,"customPropertyValue %s" % customPropertyValue)
sop(m,"NodeDefaultSSLSetting %s" % NodeDefaultSSLSetting)

# AdminTask.modifySSLConfig('[-alias CellDefaultSSLSettings -scopeName (cell):WEBN208Cell -keyStoreName CellDefaultKeyStore -keyStoreScopeName (cell):WEBN208Cell -trustStoreName CellDefaultTrustStore -trustStoreScopeName (cell):WEBN208Cell -jsseProvider IBMJSSE2 -sslProtocol SSL_TLSv2 -clientAuthentication false -clientAuthenticationSupported false -securityLevel HIGH -enabledCiphers ]')
#if modSSLConfig_TLS_Cell(Alias, cellName, CellDefaultStore, cellName, CellDefaultStore, cellName, tls_value ) == 0:
if modSSLConfig_TLS_Cell(Alias, cellName, KeyStore, cellName, CellDefaultStore, cellName, tls_value ) == 0:
  sop(m,"Success on setting Alias [%s] TLS Value [%s] for Cell Default TrustStore [%s]" % (Alias, tls_value, CellDefaultStore))
else:
  sop(m,"ERROR on setting Alias [%s] TLS Value [%s] for Cell Default TrustStore [%s]" % (Alias, tls_value, CellDefaultStore))

sslList=AdminTask.listSSLConfigs('[-all true -displayObjectName false ]').splitlines()
for row in sslList:
  values = re.split('\s+', row)
  name = values[1]
  scope = values[3]
  if name == NodeDefaultSSLSetting:
    sop(m,"Updating this SSL config [%s] with scope [%s]" % (name, scope))
    # AdminTask.modifySSLConfig('[-alias NodeDefaultSSLSettings -scopeName (cell):WEBN208Cell:(node):WEBN208ContentNode01 -keyStoreName WEBN208Keystore -keyStoreScopeName (cell):WEBN208Cell -trustStoreName CellDefaultTrustStore -trustStoreScopeName (cell):WEBN208Cell -jsseProvider IBMJSSE2 -sslProtocol SSL_TLSv2 -clientAuthentication false -clientAuthenticationSupported false -securityLevel HIGH -enabledCiphers ]')
    if modSSLConfig_TLS_Node(NodeDefaultSSLSetting, scope, PersonalKeyStore, cellName, CellDefaultStore, cellName, tls_value ) == 0:
      sop(m,"Success on setting Alias [%s] TLS Value [%s] for Cell Default TrustStore [%s] scope [%s] on Custom Keystore [%s]" % (name, tls_value, CellDefaultStore, scope, PersonalKeyStore ))
      #AdminConfig.save()
    else:
      sop(m,"ERROR on setting Alias [%s] TLS Value [%s] for Cell Default TrustStore [%s] Personal KeyStore [%s] with Scope [%s]" % (name, tls_value, CellDefaultStore, PersonalKeyStore, scope))
  else:
    sop(m,"Skipping this SSL config %s" % name)

# now lets get nodes to issue syncNode too.... 
NodeList = []
#nodesToGetInfo = listAppServerNodesNoIHS()
nodesToGetInfo = listNodes()
SoapInfo = []
SoapInfo = getServerNamedEndPoint('dmgr', 'SOAP_CONNECTOR_ADDRESS')
sop(m,"Getting DMGR End Point returned: [%s]" % SoapInfo)
dmgrHost = SoapInfo[0]
port = SoapInfo[1]
if not dmgrHost:
  sop(m,"ERROR: We could not determine the DMGR Host, exiting!")
  sys.exit(11)
if not port:
  sop(m,"ERROR: We could not determine the SOAP PORT!, exiting!")
  sys.exit(12)

for node in nodesToGetInfo:
  sop(m,"Getting information for node %s" % node)
  hostname = getNodeHostname(node)
  binPath = getWasProfileRoot(node)
  NodeList.append((node.encode('ascii', 'ignore'), hostname.encode('ascii', 'ignore'), binPath.encode('ascii', 'ignore'), port.encode('ascii', 'ignore'), dmgrHost.encode('ascii', 'ignore')))
     
sop(m,"Nodes to update are: %s" % NodeList) 

# lets add the global security custom property
if customPropertyFlag.upper() == "TRUE":
  #first lets remove the " char from property values
  customPropertyValue = re.sub('["]', '', customPropertyValue)
  sop(m,"We will add the custom property for Global Security with: [%s=%s]" % (customPropertyName, customPropertyValue))
  AdminTask.setAdminActiveSecuritySettings('[-customProperties ["%s=%s"]]' %(customPropertyName,customPropertyValue))
  
# lets clean up and save everything
saveAndSync()
#AdminConfig.save()
sop(m,"Completed Successfully")
