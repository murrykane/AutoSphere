# ====================================================
# Created by: Jeffrey Apiado
# Role: ADD and Modify web container custom properties
# Input: 'serverName' or 'all'
#        'json file containing propertyname and value
# Created: 6/25/2020
# Type: wsadmin script (websphere)
#        modify: 8/18/20      -   wsadmin no module json supported
# ====================================================
import sys, os, re


class webcont_props:
   def __init__(self, sname, jfile):
       if not os.path.isfile(jfile):
          print "Error: undefine json file path in %s ............... [MISSING]" % jfile
          sys.exit(1)
       self.jfile = jfile
       if re.search(r'^all', sname, re.I):
          sbool = True
          self.aole = AdminTask.listServers('[-serverType APPLICATION_SERVER ]').splitlines()
       else:
           ids = AdminConfig.getid('/Server:%s/' % sname)
           self.aole = [ids]
           sbool = False
       self.snamecondition = sbool 

   def runner(self):
       content = open(self.jfile, "r")
       item = content.read()
       content.close()
       my_dict = eval(item)
       for single in self.aole:
           if self.snamecondition:
               sss = AdminConfig.list('Server', single)
           else:
               sss = single
           print 'server Mbean: - ',sss
           # ===========================================
           ias = AdminConfig.list('WebContainer',sss)
           print 'webcontainer - ',ias
           holder = AdminConfig.showAttribute(ias, 'properties')
           print "------------------------------"
           print 'holder: ',holder
           self.add_customprop(holder, my_dict, ias)
           AdminConfig.save()

   def add_customprop(self, current, hashmap, webcon): 
       print "webcon: ",webcon
       if current == '[]':
          print " --- ADD --- "
          for name, value in hashmap.iteritems():
              self.creator(name, value, webcon)
       else:
          for name, value in hashmap.iteritems():
              inside = self.stringformat(current)
              check = [i for i in inside if re.search(name, i)]
              for prop in inside:
                  if check == []:
                      print "---- ADD ----"
                      print "%s propertyname not found in current container property list" % name
                      self.creator(name, value, webcon)
                  elif name == AdminConfig.showAttribute(prop, "name"):
                      print "--- modify ---"
                      AdminConfig.modify(prop, [['value', value]])
                       

   def creator(self, name, value, webcon):
       print "Add new propertyname: %s ... value: %s" % (name, value)
       attr = [['name',name],['value',value]]
       AdminConfig.create('Property', webcon, attr)

   def stringformat(self, someSTR):
       hold = []
       k1 = someSTR.split(' ')
       for item in k1:
           if item.startswith('[') and item.endswith(']'):
                hold.append(item[1:-1])
           elif item.find('[') > -1:
                hold.append(item[1:])
           elif item.find(']') > -1:
                hold.append(item[:-1])
           else:
                hold.append(item)
       print "arraylist before return ",hold
       return hold


if __name__== "__main__":
    if len(sys.argv) > 1:
       sname = sys.argv[0]
       jfile = sys.argv[1]
       runtask = webcont_props(sname, jfile)
       runtask.runner()
    else:
       print "Argument: ==========================================================================="
       print "Require server name as 1st argument or type 'all'                         ARGS1"
       print "Json file path as 2nd argument ex: /tmp/properties.json                   ARGS2"
       print "======================================================="
       print "command construct: wsadmin.sh -lang jython -f /tmp/create_webcontainer_customproperty.py (web60Consumer1 or 'all') /tmp/myproperty.json"
       print """json file: contain hash of properties name and value
                        example:
                 {
                     "ibm.com.prop":"600",
                     "whatever.follows":"string"
                 }
             json syntax checker: 'https://jsonlint.com/' 
       """
       print "======================================================================================"
       sys.exit(0)
