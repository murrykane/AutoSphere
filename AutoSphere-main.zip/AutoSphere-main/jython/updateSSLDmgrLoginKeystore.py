#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 08/26/2017 Murry Kane     Initial version
#
#_________________________________________________________________________________________________
#
import os, sys
from constants import *

if os.path.isfile('%s/wsadminlib.py' % JYTHON_DIR):
  execfile('%s/wsadminlib.py' % JYTHON_DIR)
else:
  print "Needed library wsadminlib.py NOT Found, exiting!"
  sys.exit(1)

enableDebugMessages()
m="updateSSLDmgrLoginKeystore:"

#lets validate we are on a DMGR!
if whatEnv() == 'nd':
  sop(m, "Running on DMGR, continueing...")
else:
  sop(m, "ERROR: You must run this script on the DMGR!, exiting!")
  sys.exit(2)

def usage():
  print "Usage: %s CellDefaultKeyStore, CellDefaultTrustStore, signatureAlgorithm, certRequestAlias, certSize, certCommonName, certOrg, certOrgUnit, certLocale, certState, certZip, certCountry, certificateRequestFilePath, certificateAliasList2, receiveCertPath, base64Encoded, replacecertAlias, newCertAlias, deleteOldCert, deleteSigners, CMSKeyStore, SkipJythonChanges, StepAction" % m
  
if ( len(sys.argv) != 23):
  usage()
  sys.exit(1)
else:
  CellDefaultKeyStore = sys.argv[0]
  CellDefaultTrustStore = sys.argv[1]
  signatureAlgorithm = sys.argv[2]
  certRequestAlias = sys.argv[3]
  certSize = sys.argv[4]
  certCommonName = sys.argv[5]
  certOrg = sys.argv[6]
  certOrgUnit = sys.argv[7]
  certLocale = sys.argv[8]
  certState = sys.argv[9]
  certZip = sys.argv[10]
  certCountry = sys.argv[11]
  certificateRequestFilePath = sys.argv[12]
  certificateAliasList2 = sys.argv[13]
  receiveCertPath = sys.argv[14]
  base64Encoded = sys.argv[15]
  replacecertAlias = sys.argv[16]
  newCertAlias = sys.argv[17]
  deleteOldCert = sys.argv[18]
  deleteSigners = sys.argv[19]
  CMSKeyStore = sys.argv[20]
  SkipJythonChanges = sys.argv[21]
  StepAction = sys.argv[22].upper()

if SkipJythonChanges.upper() == 'TRUE':
  SkipJythonChanges = True
else:
  SkipJythonChanges = False
        
cellName = getCellName()  
serverIDList = []

# lets output what was passed 
sop(m, "CellDefaultKeyStore = %s" % (CellDefaultKeyStore))
sop(m, "signatureAlgorithm =  %s" % (signatureAlgorithm))
sop(m, "certRequestAlias =  %s" % (certRequestAlias))
sop(m, "certSize =  %s" % (certSize))
sop(m, "certCommonName =  %s" % (certCommonName))
sop(m, "certOrg =  %s" % (certOrg))
sop(m, "certOrgUnit =  %s" % (certOrgUnit))
sop(m, "certLocale =  %s" % (certLocale))
sop(m, "certState =  %s" % (certState))
sop(m, "certZip =  %s" % (certZip))
sop(m, "certCountry =  %s" % (certCountry))
sop(m, "certificateRequestFilePath =  %s" % (certificateRequestFilePath)) 
sop(m, "CellDefaultTrustStore =  %s" % (CellDefaultTrustStore))
sop(m, "certificateAliasList2 =  %s" % (certificateAliasList2))
sop(m, "receiveCertPath =  %s" % (receiveCertPath))
sop(m, "base64Encoded =  %s" % (base64Encoded))
sop(m, "replacecertAlias =  %s" % (replacecertAlias))
sop(m, "newCertAlias =  %s" % (newCertAlias))
sop(m, "deleteOldCert =  %s" % (deleteOldCert))
sop(m, "deleteSigners = %s" % (deleteSigners))
sop(m, "CMSKeyStore =  %s" % (CMSKeyStore))
sop(m, "SkipJythonChanges =  %s" % (SkipJythonChanges))
sop(m, "StepAction = %s" % (StepAction))
  
#### TASKS NEEDED....#######################
#AdminTask.createCertificateRequest('[-keyStoreName CellDefaultKeyStore -keyStoreScope (cell):WEBN208Cell -certificateAlias Dmgr_WEBN208 -certificateSize 2048 -certificateCommonName dm1.webn208.blueshieldcloud.net -certificateOrganization "Blue Shield of California" -certificateOrganizationalUnit IT -certificateLocality "El Dorado Hills" -certificateState California -certificateZip 95762 -certificateCountry US -certificateRequestFilePath /tmp/dmgrkey.csr -signatureAlgorithm SHA256withRSA ]')
#AdminTask.getCertificate('[-keyStoreName CellDefaultKeyStore -keyStoreScope (cell):NPIN01Cell -certificateAlias Dmgr_WEBN208 ]')

#1st exchange
# AdminTask.exchangeSigners('[-keyStoreName1 CellDefaultKeyStore -keyStoreScope1 (cell):WEBN208Cell -keyStoreName2 CellDefaultTrustStore -keyStoreScope2 (cell):WEBN208Cell -certificateAliasList2 bscrootca2:bscissueca2 ]')
#
#receive certificate
#AdminTask.receiveCertificate('[-certificateFilePath /tmp/dm1.prtn208.cloud.bscal.com.cer -base64Encoded true -keyStoreName CellDefaultKeyStore -keyStoreScope (cell):WEBN208Cell ]')
#
#deletePersonalCertDefault
# AdminTask.replaceCertificate('[-certificateAlias default -replacementCertificateAlias dmgr_webn208 -deleteOldCert true -deleteOldSigners false -keyStoreName CellDefaultKeyStore -keyStoreScope (cell):WEBN208Cell ]')
#
# Update IHS Plugin
# AdminTask.exchangeSigners('[-keyStoreName1 CMSKeyStore -keyStoreScope1 (cell):WEBN208Cell:(node):WEBN208WebNode01:(server):webn208-ws1 -keyStoreName2 CellDefaultTrustStore -keyStoreScope2 (cell):WEBN208Cell -certificateAliasList2 bscrootca2:bscissueca2 ]')
#
############################################

#create CSR
if StepAction == 'CSR':
  sop(m,"Attempting to create new Certificate Request [%s] in Keystore [%s]" % (newCertAlias,CellDefaultKeyStore))
  #checkPersonalCertRequests('CellDefaultKeyStore', 'WEBN208Cell', 'dmgr_webn2082')
  if checkPersonalCertRequests(CellDefaultKeyStore, cellName, newCertAlias) == 1:
    sop(m,"The following Certificate [%s] does not exist and we will proceed to create it" % newCertAlias)
    try:
      if not SkipJythonChanges:
        AdminTask.createCertificateRequest('[-keyStoreName %s -keyStoreScope (cell):%s -certificateAlias %s -certificateSize %s -certificateCommonName %s -certificateOrganization "%s" -certificateOrganizationalUnit %s -certificateLocality "%s" -certificateState %s -certificateZip %s -certificateCountry %s -certificateRequestFilePath %s -signatureAlgorithm %s]' % (CellDefaultKeyStore, cellName, newCertAlias, certSize, certCommonName, certOrg, certOrgUnit, certLocale, certState, certZip, certCountry, certificateRequestFilePath, signatureAlgorithm))
        # we will make sure everything complets before saving at end
        AdminConfig.save()  
        sop(m, "Success")
      else:
        sop(m,"Skipping configuration change since boolean is set for doing so...")
    except:
      sop (m, "Error creating cert %s . Exception information %s %s" % (certRequestAlias, sys.exc_type, sys.exc_value ))
      sys.exit(8)
  else:
    sop(m,"WARNING: The certificate [%s] ALREADY exists, therefore can't create it!" % newCertAlias)
  sop(m,"Complete with create Certificate, moving on....")
else:
  sop(m,"We are on STEP [%s], which means the CSR has already been created and needs to be chained to the root certificate now" % StepAction)
  
#MBK Only do the entire block below if its not the StepAction = CSR (create certificate request)
if StepAction != 'CSR':
  # exchange signers....
  try:
    sop(m,"Attempting to exchange signers between [%s] and [%s] for these signers [%s]." % (CellDefaultKeyStore, CellDefaultTrustStore, certificateAliasList2))
    if not SkipJythonChanges:
      AdminTask.exchangeSigners('[-keyStoreName1 %s -keyStoreScope1 (cell):%s -keyStoreName2 %s -keyStoreScope2 (cell):%s -certificateAliasList2 %s ]' % (CellDefaultKeyStore, cellName, CellDefaultTrustStore, cellName, certificateAliasList2))
      # we will make sure everything complets before saving at end
      AdminConfig.save() 
      sop(m, "Success")
    else:
      sop(m,"Skipping configuration change since boolean is set for doing so...")
  except:
    sop (m, "Error during exchange signers cert [%s] . Exception information %s %s" % (CellDefaultKeyStore, sys.exc_type, sys.exc_value ))
    sys.exit(10)

  sop(m,"Complete with exchange signers, moving on....") 

  #AdminTask.receiveCertificate('[-certificateFilePath /tmp/dm1.prtn208.cloud.bscal.com.cer -base64Encoded true -keyStoreName CellDefaultKeyStore -keyStoreScope (cell):WEBN208Cell ]')
  # receive certificate..
  # MBK add logic to not recieve a same cert a second time.... skip it then....
  try:
    sop(m,"Attempting to receive certificate [%s] for store [%s] on cell [%s] with Base 64 Encoding is [%s]." % (receiveCertPath, CellDefaultKeyStore, cellName, base64Encoded))
    if not SkipJythonChanges:
      if checkPersonalCertRequests(CellDefaultKeyStore, cellName, newCertAlias) == 0:
        AdminTask.receiveCertificate('[-certificateFilePath %s -base64Encoded %s -keyStoreName %s -keyStoreScope (cell):%s ]' % (receiveCertPath, base64Encoded, CellDefaultKeyStore, cellName))
        # we will make sure everything complets before saving at end
        AdminConfig.save() 
        sop(m, "Success")
      else:
        sop(m,"WARNING: The PersonalCertRequest Does NOT exist, therefore we can not receiveCertificate for it! This must be a restart of the script after a failure!")
    else:
      sop(m,"Skipping configuration change since boolean is set for doing so...")
  except:
    sop (m, "Error during certificate received for [%s] . Exception information %s %s" % (receiveCertPath, sys.exc_type, sys.exc_value ))
    sys.exit(15)
   
  sop(m,"Complete with receive certificate, moving on....")

  # replace certificate..
  try:
    sop(m,"Attempting to replace certificate [%s] for store [%s] on cell [%s] delete Old Cert [%s] with Alias [%s] Delete old Signers [%s]." % (replacecertAlias, CellDefaultKeyStore, cellName, deleteOldCert, newCertAlias, deleteSigners ))
    if not SkipJythonChanges:
      #if checkCert(CellDefaultKeyStore, replacecertAlias) == 0:
      if checkPersonalCert(CellDefaultKeyStore, replacecertAlias) == 0:
        AdminTask.replaceCertificate('[-certificateAlias %s -replacementCertificateAlias %s -deleteOldCert %s -deleteOldSigners %s -keyStoreName %s -keyStoreScope (cell):%s ]' % (replacecertAlias, newCertAlias, deleteOldCert, deleteSigners, CellDefaultKeyStore, cellName))
        # we will make sure everything complets before saving at end
        AdminConfig.save()
        sop(m, "Success")
      else:
        sop(m,"WARNING: The CERT [%s] does not exist in KeyStore [%s], therefore can't issue replaceCertificate! If this is a restart of the script, it was already done...." % (replacecertAlias, CellDefaultKeyStore))
    else:
      sop(m,"Skipping configuration change since boolean is set for doing so...")
  except:
    sop (m, "ERROR: during certificate replacement for [%s] . Exception information %s %s" % (replacecertAlias, sys.exc_type, sys.exc_value ))
    sys.exit(16)

  sop(m,"Complete with replace certificate, moving on....")

  # now lets get nodes to scp the p12 files too.... 
  NodeList = []
  nodesToGetInfo = listAppServerNodesNoIHS()
  SoapInfo = []
  SoapInfo = getServerNamedEndPoint('dmgr', 'SOAP_CONNECTOR_ADDRESS')
  sop(m,"Getting DMGR End Point returned: [%s]" % SoapInfo)
  dmgrHost = SoapInfo[0]
  port = SoapInfo[1]
  if not dmgrHost:
    sop(m,"ERROR: We could not determine the DMGR Host, exiting!")
    sys.exit(11)
  if not port:
    sop(m,"ERROR: We could not determine the SOAP PORT!, exiting!")
    sys.exit(12)
    
  # need to go through all IHS nodes and update them.....
  #
  IHSNodes = []
  IHSNodesToSCP = []
  #IHSNodes = listIHSServerNodes()
  IHSNodes = listIHSServerNodesWithServers()

  #MBK - Lets build an array for the parent program to do so scp's/and syncnode's
  for node,servername in IHSNodes:
    sop(m,"Getting information for IHS node %s with server name %s" % (node,servername))
    hostname = getNodeHostname(node)
    binPath = getWasProfileRoot(node)
    # here we get this info: storeInfo = getKeyStoreInfo('CMSKeyStore', '(cell):WEBN208Cell:(node):WEBN208WebNode01:(server):webn208-ws1')
    # AdminTask.getKeyStoreInfo('[ -keyStoreName %s -scopeName %s]' % ('CMSKeyStore', '(cell):WEBN208Cell:(node):WEBN208WebNode01:(server):webn208-ws1'))
    certInfo = _splitlines(getKeyStoreInfo(CMSKeyStore, '(cell):%s:(node):%s:(server):%s' % (cellName, node, servername)))
    pathName = ""
    if certInfo:
      sop(m, "INFO: We got the information for the keystore with [%s]" % certInfo)
      # lets parse it now... typical response below
      # '[[name CMSKeyStore] [provider IBMCMSProvider] [location ${CONFIG_ROOT}/cells/WEBN208Cell/nodes/WEBN208WebNode01/servers/webn208-ws1/plugin-key.kdb] [type CMSKS] [fileBased true] [hostList ] [readOnly false] [initializeAtStartup false] [customProviderClass ] [createStashFileForCMS true] [slot 0] [useForAcceleration false] [description [CMSKeyStore for web server webn208-ws1.]] [usage ] [managementScope (cells/WEBN208Cell|security.xml#ManagementScope_1434580080041)] [additionalKeyStoreAttrs ] [_Websphere_Config_Data_Id cells/WEBN208Cell|security.xml#KeyStore_1434580080053] [_Websphere_Config_Data_Type KeyStore] [_Websphere_Config_Data_Version ] [password *****] ]'
      #
      for instance in certInfo:
        values = instance.split('[')
        pathName = values[4].split(']')[0].split(' ')[1]
    else:
      sop(m, "ERROR: We were not able to get information on the keystore! for [%s] node [%s] server [%s]" % (CMSKeyStore, node, servername))
      pathName = "None"
    #lets get the web servers plugin file
    webserver = getServerByNodeAndName(node, servername) 
    dumpWebSrvr = AdminConfig.showall(webserver).splitlines()
    pluginFile = None  
    for attr in dumpWebSrvr:
      if attr.find('RemoteKeyRingFilename') == 1:
        pluginFile = attr.split()[1].split(']')[0]
        sop(m, "Found Plugin file [%s] for node [%s] server [%s]" % ( pluginFile, node, servername))
    if not pluginFile:
      sop(m,"ERROR: We could not determine the Web Servers Plugin file!")
    IHSNodesToSCP.append((node.encode('ascii', 'ignore'), hostname.encode('ascii', 'ignore'), binPath.encode('ascii', 'ignore'), port.encode('ascii', 'ignore'), dmgrHost.encode('ascii', 'ignore'), pathName.encode('ascii', 'ignore'), pluginFile.encode('ascii', 'ignore')))
    
  sop(m,"IHS Nodes to SCP updated P12 file too: %s" % IHSNodesToSCP) 

  for node,servername in IHSNodes:
    sop(m,"Working for IHS Plugin [%s] keystore, exchange signer needed for node [%s] with server name [%s]" % (CMSKeyStore, node, servername))
    try:
      if not SkipJythonChanges:
        #AdminTask.exchangeSigners('[-keyStoreName1 CMSKeyStore -keyStoreScope1 (cell):WEBN208Cell:(node):WEBN208WebNode01:(server):webn208-ws1 -keyStoreName2 CellDefaultTrustStore -keyStoreScope2 (cell):WEBN208Cell -certificateAliasList2 bscrootca2:bscissueca2 ]')
        AdminTask.exchangeSigners('[-keyStoreName1 %s -keyStoreScope1 (cell):%s:(node):%s:(server):%s -keyStoreName2 %s -keyStoreScope2 (cell):%s -certificateAliasList2 %s ]' %(CMSKeyStore, cellName, node, servername, CellDefaultTrustStore, cellName, certificateAliasList2))
        # we will make sure everything complets before saving at end
        AdminConfig.save()
        sop(m, "Success")
      else:
        sop(m,"Skipping configuration change since boolean is set for doing so...")
      
    except:
      sop (m, "Error during exchange signers for [%s] on node [%s] and server name [%s]. Exception information %s %s" % (CMSKeyStore, node, servername, sys.exc_type, sys.exc_value ))
      sys.exit(13)

  #lets get the paths for the CellDefaultKeyStore and CellDefaultTrustStore keyfile
  certInfo = _splitlines(getKeyStoreInfo(CellDefaultKeyStore, '(cell):%s' % (cellName)))
  if certInfo:
    sop(m, "INFO: We got the information for the keystore [%s] with [%s]" % (CellDefaultKeyStore, certInfo))
    # lets parse it now... typical response below
    # '[[name CMSKeyStore] [provider IBMCMSProvider] [location ${CONFIG_ROOT}/cells/WEBN208Cell/nodes/WEBN208WebNode01/servers/webn208-ws1/plugin-key.kdb] [type CMSKS] [fileBased true] [hostList ] [readOnly false] [initializeAtStartup false] [customProviderClass ] [createStashFileForCMS true] [slot 0] [useForAcceleration false] [description [CMSKeyStore for web server webn208-ws1.]] [usage ] [managementScope (cells/WEBN208Cell|security.xml#ManagementScope_1434580080041)] [additionalKeyStoreAttrs ] [_Websphere_Config_Data_Id cells/WEBN208Cell|security.xml#KeyStore_1434580080053] [_Websphere_Config_Data_Type KeyStore] [_Websphere_Config_Data_Version ] [password *****] ]'
    #
    for instance in certInfo:
      values = instance.split('[')
      CellKeypathName = values[4].split(']')[0].split(' ')[1]
  else:
    sop(m, "ERROR: We were not able to get information on the keystore! for [%s]" % (CellDefaultKeyStore))
    CellKeypathName = "None"
  certInfo = _splitlines(getKeyStoreInfo(CellDefaultTrustStore, '(cell):%s' % (cellName)))
  if certInfo:
    sop(m, "INFO: We got the information for the keystore [%s] with [%s]" % (CellDefaultTrustStore,certInfo))
    # lets parse it now... typical response below
    # '[[name CMSKeyStore] [provider IBMCMSProvider] [location ${CONFIG_ROOT}/cells/WEBN208Cell/nodes/WEBN208WebNode01/servers/webn208-ws1/plugin-key.kdb] [type CMSKS] [fileBased true] [hostList ] [readOnly false] [initializeAtStartup false] [customProviderClass ] [createStashFileForCMS true] [slot 0] [useForAcceleration false] [description [CMSKeyStore for web server webn208-ws1.]] [usage ] [managementScope (cells/WEBN208Cell|security.xml#ManagementScope_1434580080041)] [additionalKeyStoreAttrs ] [_Websphere_Config_Data_Id cells/WEBN208Cell|security.xml#KeyStore_1434580080053] [_Websphere_Config_Data_Type KeyStore] [_Websphere_Config_Data_Version ] [password *****] ]'
    #
    for instance in certInfo:
      values = instance.split('[')
      CellTrustpathName = values[4].split(']')[0].split(' ')[1]
  else:
    sop(m, "ERROR: We were not able to get information on the keystore! for [%s]" % (CellDefaultKeyStore))
    CellTrustpathName = "None"

  ##############################################################################  

  sop(m, "We got the following for the full paths of the CellDefaultTrustStore [%s] and CellDefaultKeyStore [%s]" % (CellKeypathName, CellTrustpathName))

  for node in nodesToGetInfo:
    sop(m,"Getting information for node %s" % node)
    hostname = getNodeHostname(node)
    binPath = getWasProfileRoot(node)
    NodeList.append((node.encode('ascii', 'ignore'), hostname.encode('ascii', 'ignore'), binPath.encode('ascii', 'ignore'), port.encode('ascii', 'ignore'), dmgrHost.encode('ascii', 'ignore'), CellKeypathName.encode('ascii', 'ignore'), CellTrustpathName.encode('ascii', 'ignore')))
       
  sop(m,"Nodes to SCP updated P12 file too: %s" % NodeList) 

  # lets clean up and save everything
  if not SkipJythonChanges:
    sop(m,"Saving Configuration changes.....")
    #saveAndSync()
    #sop(m,"Saving Configuration changes.....") 
    AdminConfig.save()
  else:
    sop(m,"Skipping configuration change since boolean is set for doing so...")
else:
  sop(m, "StepAction = [%s] which means only the Certificate Request needs to be completed, all other steps will be skipped" % StepAction)
  
sop(m,"Completed Successfully")
