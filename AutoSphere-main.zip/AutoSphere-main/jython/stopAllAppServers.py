#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 02/06/2017 Murry Kane     Initial version
#
#_________________________________________________________________________________________________
#
import os, sys, re
from constants import *

if os.path.isfile('%s/wsadminlib.py' % JYTHON_DIR):
  execfile('%s/wsadminlib.py' % JYTHON_DIR)
else:
  print "Needed library wsadminlib.py NOT Found, exiting!"
  sys.exit(1)

enableDebugMessages()
m="stopAppServers:"
HALFA = []
HALFB = []
ArrayList = []

def includeServer(servername, theArray):
  #theArray should be 3 parts ServerName, NodeName, HostName
  for serverName, theNode, theHost in theArray:
    #sop(m, "Checking for servername %s in Array with ServerElement %s NodeName %s Host %s" % ( servername, serverName, theNode, theHost))
    if servername == serverName:
      #sop(m, "Found match in our list, we will check for BATCH2|02 with this server [%s]" % servername)
      #if servername.lower().find('batch2') or servername.lower().find('batch02'):
      if re.search('batch2', servername, re.IGNORECASE) or re.search('batch02', servername, re.IGNORECASE):
        sop(m,"Since this Server [%s] is a BATCH2|BATCH02 instance, we will skip it!" % servername)
        return False
      else:
        #sop(m,"We will process this server [%s]" % servername)
        return True
      
  #sop(m, "We did not find the server [%s] in the list of servers to process" % servername)
  return False
  


def usage():
  print "Usage: %s 'String of Exclude Nodes' 'ALL or String of Half the Nodes to do at a time' 'SleepTimeBetweenAppServers' 'Total Time to wait for Action(stop/start) 'immidiateFlag' 'terminateFlag'" % m
  print "Example %s 'WEBP02EPresentBatch02/WEBP02ESS01' 'ALL' '30' '300' 'True' 'False'" % m
  
if ( len(sys.argv) != 6):
  usage()
  sys.exit(1)
else:
  ignoreNodeList = sys.argv[0]
  actionType = sys.argv[1]
  sleepTime = int(sys.argv[2])
  totalActionTime = int(sys.argv[3])
  immediate = int(sys.argv[4])
  terminate = int(sys.argv[5])
  
if actionType == 'ALL':
  sop(m,"We will perform complete stop for Application Servers")
else:
  sop(m,"Partial STOP being done against Application Servers")
  HALFA, HALFB = getSplitAppServers()
  if actionType == 'HALFA':
    sop(m,"Using HALFA with array: [%s]" % HALFA)
    ArrayList = HALFA
  elif actionType == 'HALFB':
    sop(m,"Using HALFB with array: [%s]" % HALFB)
    ArrayList = HALFB
  else:
    sop(m,"ERROR: Illegal value passed for Action Type with [%s],exiting!" % actionType)
    sys.exit(3)


sop(m, "Actions for stop command are immidiate [%i] and Terminate [%i]" % (immediate, terminate))  
ignoretype=['dmgr','nodeagent']

ignorelist = ignoreNodeList.split("/")
sop(m,"Ignore NODE List is %s" % ignorelist)

#lets validate we are on a DMGR!
if whatEnv() == 'nd':
  sop(m, "Running on DMGR, continueing...")
else:
  sop(m, "ERROR: You must run this script on the DMGR!, exiting!")
  sys.exit(2)

IHSNodes = []
IHSNodes = listIHSServerNodes()
nodes = _splitlines(AdminConfig.list( 'Node' ))

for node_id in nodes:
  node = getNodeName(node_id)
  sop(m,"Working on Node: %s" % node)
  if node not in ignorelist and node not in IHSNodes:
    serverEntries = _splitlines(AdminConfig.list( 'ServerEntry', node_id ))
    for jvm in serverEntries:
      servername = AdminConfig.showAttribute( jvm, 'serverName' )
      servertype = AdminConfig.showAttribute( jvm, 'serverType' )
      sop(m, "Server Name is %s Server Type is %s" % (servername, servertype))
      if servername not in ignoretype and servername not in ignorelist:
        if actionType == 'ALL':
          stopServer(node, servername, immediate, terminate) # 3rd = immediate 4th = terminate
          sop(m, "Sleeping before moving onto another Application Server for %s seconds" % sleepTime)
          time.sleep(sleepTime)
        else:
          if includeServer(servername, ArrayList):
            stopServer(node, servername, immediate, terminate)  # 3rd = Immediate 4th = terminate
            sop(m, "Sleeping before moving onto another Application Server for %s seconds" % sleepTime)
            time.sleep(sleepTime)            
          else:
            if servername in ignoretype:
              sop(m,"This server(%s) is being skipped since its a type of dmgr/nodeagent" % servername)
            else:
              sop(m,"This server(%s) is being SKIPPED as its not in the partial list to process with action [%s]" % (servername, actionType))
      else:
        if servername in ignoretype:
          sop(m,"This server(%s) is being skipped since its a type of dmgr/nodeagent" % servername)
        else:
          sop(m,"This server(%s) is being skipped as its in the ignore list" % servername)
  else:
    sop(m,"Node being skipped since its a either Deployment Node/IHS Web Server") 