#********************************************************
# purpose: websphere re-usable administrative scripts
# author: jcanepa
# version: 1.0
#********************************************************
 

#import
import sys
sys.path.append("C:\\Documents and Settings\\jcanep01\\AST\\workspace\\admin\\jython")
import java.io
import Xparser
import XPathCount
import server
#import base 
#import javax.xml.xpath

#--------------------------------------------------------------
# initialize global websphere classes
#--------------------------------------------------------------
global AdminConfig
global AdminControl
global AdminApp
global AdminControl
global AdminTask

#********************************************************
# getServerSpecs: 
#********************************************************
def getServerSpecs():
	
	serverConfigPath = "c:/Documents and Settings/jcanep01/AST/workspace/admin/xml/nxsa/dev01_nx.xml"
	applicationConfigPath = open("c:/Documents and Settings/jcanep01/AST/workspace/admin/xml/application/application.xml", "r")
	
	#serverName = Xparser.xFind(serverConfigPath, "//websphere/server/@name")
	count = XPathCount.getCount(serverConfigPath, "//websphere/server/@name") 
	
	#print "the count is:", count
	
	if count > 0:
		print "there is only one server:"
		serverName = Xparser.xFind(serverConfigPath, "//websphere/server/@name")
		nodeName = Xparser.xFind(serverConfigPath, "//websphere/server/@nodeName")
	        heap = Xparser.xFind(serverConfigPath, "//websphere/server/jvm/[maxHeap>100]")
	   
	        
	else: 
		print "there is more than one value"
	
	print "serverName:", serverName
	print "nodeName:", nodeName
	print "maxHeap:", heap
	
	#updatePorts(serverName, nodeName, serverConfigPath)

#********************************************************
# listApplications: 
#********************************************************

def main():

	getServerSpecs()
	#server.serverInit()
	#deployApplication(envDoc)
        
        
main()	 