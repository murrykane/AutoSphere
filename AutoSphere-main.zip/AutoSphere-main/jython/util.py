import sys
import java.io
import Xparser
import XPathCount
import base

#--------------------------------------------------------------
# initialize global websphere classes
#--------------------------------------------------------------

base.setAdminRefs((AdminConfig, AdminControl, AdminTask, AdminApp))

#********************************************************
# updateDmgrPorts: 
#********************************************************
def updateDmgrPorts(serverXML, nodeName, serverName):
	
	#--------------------------------------------------------------
        #     -- variables
        #--------------------------------------------------------------
	#serverName = Xparser.xFind(serverXML, "//websphere/dmgr/@name")
        #nodeName = Xparser.xFind(serverXML, "//websphere/dmgr/@nodeName")
	nodeId = AdminConfig.getid('/Node:'+nodeName+'/')
	host = Xparser.xFind(serverXML, "//websphere/dmgr/@host")
	adminHost = Xparser.xFind(serverXML, "//websphere/dmgr/ports/@adminHost")
	adminHostSec = Xparser.xFind(serverXML, "//websphere/dmgr/ports/@adminHostSec")
	serverEntries = AdminConfig.list('ServerEntry', nodeId).split(java.lang.System.getProperty('line.separator'))

        
	#--------------------------------------------------------------
        #     -- process ports based on build sheet 
        #--------------------------------------------------------------
        print "--> configuring server:", serverName
        print "--> start: update ports"
        
        # BOOTSTRAP_ADDRESS
        base.portProcessor(serverName, nodeName, host, "BOOTSTRAP_ADDRESS", (Xparser.xFind(serverXML, "//websphere/dmgr/ports/@bootstrap")))
        # CELL_DISCOVERY_ADDRESS
        base.portProcessor(serverName, nodeName, host, "CELL_DISCOVERY_ADDRESS", (Xparser.xFind(serverXML, "//websphere/dmgr/ports/@cellDiscovery")))   
        # CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS
        base.portProcessor(serverName, nodeName, host, "CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS", (Xparser.xFind(serverXML, "//websphere/dmgr/ports/@csiv2ServerAuth")))
        # CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS
        base.portProcessor(serverName, nodeName, host, "CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS", (Xparser.xFind(serverXML, "//websphere/dmgr/ports/@csiv2MutualAuth")))
        # DCS_UNICAST_ADDRESS -modifiedShared paramater needs to be specified
        base.portProcessorShared(serverName, nodeName, host, "DCS_UNICAST_ADDRESS", (Xparser.xFind(serverXML, "//websphere/dmgr/ports/@uniAddress")))
        # ORB_LISTENER_ADDRESS
        base.portProcessor(serverName, nodeName, host, "ORB_LISTENER_ADDRESS", (Xparser.xFind(serverXML, "//websphere/dmgr/ports/@orb")))
        # SAS_SSL_SERVERAUTH_LISTENER_ADDRESS
        base.portProcessor(serverName, nodeName, host, "SAS_SSL_SERVERAUTH_LISTENER_ADDRESS", (Xparser.xFind(serverXML, "//websphere/dmgr/ports/@sasSsl")))
        # SOAP
        base.portProcessor(serverName, nodeName, host, "SOAP_CONNECTOR_ADDRESS", (Xparser.xFind(serverXML, "//websphere/dmgr/ports/@soap")))
		# IPC_CONNECTOR_ADDRESS
        base.portProcessor(serverName, nodeName, host, "IPC_CONNECTOR_ADDRESS", (Xparser.xFind(serverXML, "//websphere/dmgr/ports/@ipcPort")))
		# DataPowerMgr_inbound_secure
        base.portProcessor(serverName, nodeName, host, "DataPowerMgr_inbound_secure", (Xparser.xFind(serverXML, "//websphere/dmgr/ports/@datapwdmgr")))
                
        # configure web container
        print "serverEntries: ", serverEntries
	for serverEntry in serverEntries:
  		sName = AdminConfig.showAttribute(serverEntry, "serverName")
  		print "sName: ", sName
  	if sName == serverName:
     		sepString = AdminConfig.showAttribute(serverEntry, "specialEndpoints")
     		sepList = sepString[1:len(sepString)-1].split(" ")
                print "sepList: ", sepList
     		for specialEndPoint in sepList:
        		endPointNm = AdminConfig.showAttribute(specialEndPoint, "endPointName")
        		print "endPointNm: ", endPointNm
        		
        		if endPointNm == "WC_adminhost":
	        		print "--> configuring admin host - port: ", adminHost
	           		ePoint = AdminConfig.showAttribute(specialEndPoint, "endPoint")
	           		AdminConfig.modify(ePoint, [["host", host], ["port", adminHost]])
	                	#break
	                	AdminConfig.save()

                        if endPointNm == "WC_adminhost_secure":
	        		print "--> configuring admin host - port: ", adminHostSec
	           		ePoint = AdminConfig.showAttribute(specialEndPoint, "endPoint")
	           		AdminConfig.modify(ePoint, [["host", host], ["port", adminHostSec]])
	                	#break
	                	AdminConfig.save()
        
        
        
        
        
        
        #--------------------------------------------------------------
        #     -- save the configuration
        #--------------------------------------------------------------
        AdminConfig.save()
        print "--> end: update ports"

#endDef        

def updateNodePorts(serverXML, nodeName, serverName):
	
	#--------------------------------------------------------------
    	#     -- variables
    	#--------------------------------------------------------------
	#serverName = Xparser.xFind(serverXML, "//websphere/nodeagent/@name")
    	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	host = Xparser.xFind(serverXML, "//websphere/nodeagent/@host")
        
	
        
	#--------------------------------------------------------------
        #     -- process ports based on build sheet 
        #--------------------------------------------------------------
        print "--> configuring server:", serverName
        print "--> start: update ports"
          
        # BOOTSTRAP_ADDRESS
        base.portProcessor(serverName, nodeName, host, "BOOTSTRAP_ADDRESS", (Xparser.xFind(serverXML, "//websphere/nodeagent/ports/@bootstrap")))
        # NODE_DISCOVERY_ADDRESS
        base.portProcessor(serverName, nodeName, host, "NODE_DISCOVERY_ADDRESS", (Xparser.xFind(serverXML, "//websphere/nodeagent/ports/@nodeDiscovery")))   
        # NODE_IPV6_MULTICAST_DISCOVERY_ADDRESS
        base.portProcessor(serverName, nodeName, host, "NODE_IPV6_MULTICAST_DISCOVERY_ADDRESS", (Xparser.xFind(serverXML, "//websphere/nodeagent/ports/@ipv6NodeMulticast")))
        # NODE_MULTICAST_DISCOVERY_ADDRESS
        base.portProcessor(serverName, nodeName, host, "NODE_MULTICAST_DISCOVERY_ADDRESS", (Xparser.xFind(serverXML, "//websphere/nodeagent/ports/@nodeMulticast")))
        # CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS
        base.portProcessor(serverName, nodeName, host, "CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS", (Xparser.xFind(serverXML, "//websphere/nodeagent/ports/@csiv2ServerAuth")))
        # CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS
        base.portProcessor(serverName, nodeName, host, "CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS", (Xparser.xFind(serverXML, "//websphere/nodeagent/ports/@csiv2MutualAuth")))
        # DCS_UNICAST_ADDRESS -modifiedShared paramater needs to be specified
        base.portProcessorShared(serverName, nodeName, host, "DCS_UNICAST_ADDRESS", (Xparser.xFind(serverXML, "//websphere/nodeagent/ports/@uniAddress")))
        # ORB_LISTENER_ADDRESS
        base.portProcessor(serverName, nodeName, host, "ORB_LISTENER_ADDRESS", (Xparser.xFind(serverXML, "//websphere/nodeagent/ports/@orb")))
        # SAS_SSL_SERVERAUTH_LISTENER_ADDRESS
        base.portProcessor(serverName, nodeName, host, "SAS_SSL_SERVERAUTH_LISTENER_ADDRESS", (Xparser.xFind(serverXML, "//websphere/nodeagent/ports/@sasSsl")))
        # SOAP
        base.portProcessor(serverName, nodeName, host, "SOAP_CONNECTOR_ADDRESS", (Xparser.xFind(serverXML, "//websphere/nodeagent/ports/@soap")))
		# IPC_CONNECTOR_ADDRESS
        base.portProcessor(serverName, nodeName, host, "IPC_CONNECTOR_ADDRESS", (Xparser.xFind(serverXML, "//websphere/nodeagent/ports/@ipcPort")))
        
        
        #--------------------------------------------------------------
        #     -- save the configuration
        #--------------------------------------------------------------
        AdminConfig.save()
        print "--> end: update ports"
        
#endDef

def stopServer(serverXML, nodeName, serverName):
	
	# ********************** variables ************************ # 	
	#serverName = (Xparser.xFind(serverXML, "//websphere/server/@name"))
	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")

    	# stop server
	base.stopServer(nodeName, serverName)
#endDef	

def jvmJavaCore(serverXML, nodeName, serverName):

        # ********************** variables ************************ #
        #serverName = (Xparser.xFind(serverXML, "//websphere/server/@name"))
        #nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")

        # stop server
        base.jvmJavaCore(nodeName, serverName)
#endDef

def jvmHeapDump(serverXML, nodeName, serverName):

        # ********************** variables ************************ #
        #serverName = (Xparser.xFind(serverXML, "//websphere/server/@name"))
        #nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")

        # stop server
        base.jvmHeapDump(nodeName, serverName)
#endDef


def startServer(serverXML, nodeName, serverName):
	
	# ********************** variables ************************ # 	
	#serverName = (Xparser.xFind(serverXML, "//websphere/server/@name"))
	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
               
	# start server
	base.startServer(nodeName, serverName)

#endDef

def stopCluster(serverXML):

	# ********************** variables ************************ #
	cellName = Xparser.xFind(serverXML, "//websphere/dmgr/@cellName")
	clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")

    	# stop Cluster
	base.stopCluster(cellName, clusterName)

#endDef

def startCluster(serverXML):
	# ********************** variables ************************ # 	
	cellName = Xparser.xFind(serverXML, "//websphere/dmgr/@cellName")
	clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
               
	# start Cluster
	base.startCluster(cellName, clusterName)

#endDef
def rippleStart(serverXML):
	# ********************** variables ************************ # 	
	cellName = Xparser.xFind(serverXML, "//websphere/dmgr/@cellName")
	clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
               
	# start Cluster
	base.rippleStart(cellName, clusterName)

#endDef
def restartServer(serverXML, nodeName, serverName):
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	print "checking to see if server " + serverName + " is running on node " + nodeName
	ServerID = AdminControl.completeObjectName("type=Server,node=" + nodeName + ",process=" + serverName + ",*")
	if len(ServerID) > 0:
		print "server " + serverName + " is running on node " + nodeName
		print "Invoked Restart"
		AdminControl.invoke(ServerID,'restart','[]','[]')
	else:
		print "server " + serverName + " is already stopped on node " + nodeName

def validateEdition(serverXML, nodeName, serverName):
	serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	appCount = XPathCount.getCount(serverXML, "//websphere/applications/*", "")
	if appCount > 0:
        	app = 1
		while app < appCount+1:
			appNum = ("app"+str(app))
			editionNumber = (Xparser.xFind(serverXML,"//websphere/applications/"+appNum+"/@edition"))
        	    	applicationName = (Xparser.xFind(serverXML,"//websphere/applications/"+appNum+"/@name"))            
            		break
	        app=app+1
	print "ValidateApplication: appName="+applicationName+" nodeName="+nodeName+" serverName="+serverName+" ..."
	length = len(editionNumber)
	print "ValidateApplication: editionNumber.length="+str(length)+" editionNumber="+editionNumber
	if (length >= 1):
		print "validateApplication: enablibng validate"+applicationName+"  ..."
		try:
			_excp_ = 0
			validateEnabled = AdminTask.validateEdition (['-appName', ''+applicationName+'', '-edition', ''+editionNumber+'', '-params', '{dynClusterMaxSize 2}{dynClusterMinSize 1}'])                              
			_excp_ = 0 #reset (in case of nested exceptions)
		except:
			_type_, _value_, _tbck_ = sys.exc_info()
			_excp_ = 1
		#endTry 
		temp = _excp_
		if (temp > 0):
			print "validateApplication: Exception trying to enable validation "+applicationName+" "+nodeName+" "+serverName
			return 
		else:
#			if (len(validateEnabled) > 0):
			if validateEnabled == "true":
				print validateEnabled
		        	print "Success: Application edition is in validate mode"
			#endIf 
		#endElse 
			else:
				print "ERROR: ValidateApplication: validate ERROR, NOT ACCESSABLE, cannot enable validate "+applicationName
				sys.exit(1)
	#endElse

def cancelValidateEdition(serverXML, nodeName, serverName):
        serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
        nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
        appCount = XPathCount.getCount(serverXML, "//websphere/applications/*", "")
        if appCount > 0:
                app = 1
                while app < appCount+1:
                        appNum = ("app"+str(app))
                        editionNumber = (Xparser.xFind(serverXML,"//websphere/applications/"+appNum+"/@edition"))
                        applicationName = (Xparser.xFind(serverXML,"//websphere/applications/"+appNum+"/@name"))
                        break
                app=app+1
        print "ValidateApplication: appName="+applicationName+" nodeName="+nodeName+" serverName="+serverName+" ..."
        length = len(editionNumber)
        print "ValidateApplication: editionNumber.length="+str(length)+" editionNumber="+editionNumber
        if (length >= 1):
                print "validateApplication: enablibng validate"+applicationName+"  ..."
                try:
                        _excp_ = 0
                        validateDisabled = AdminTask.cancelValidation ('[-appName '+applicationName+' -edition '+editionNumber+']')   
                        _excp_ = 0 #reset (in case of nested exceptions)
                except:
                        _type_, _value_, _tbck_ = sys.exc_info()
                        _excp_ = 1
                #endTry
                temp = _excp_
                if (temp > 0):
                        print "validateApplication: Exception trying to disable validation "+applicationName+" "+nodeName+" "+serverName
                        return
                else:
                        if validateDisabled == "true":
                                print validateDisabled
                                print "Success: Cancelled Application edition validation"
                        #endIf
                #endElse
                        else:
                                print "ERROR: Application edition validation is not disabled "+applicationName
                                sys.exit(1)

def rolloutAppEdition(serverXML, nodeName, serverName):
	serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	appCount = XPathCount.getCount(serverXML, "//websphere/applications/*", "")
	if appCount > 0:
        	app = 1
                while app < appCount+1:
               	 appNum = ("app"+str(app))
               	 editionNumber = (Xparser.xFind(serverXML,"//websphere/applications/"+appNum+"/@edition"))
               	 applicationName = (Xparser.xFind(serverXML,"//websphere/applications/"+appNum+"/@name"))
               	 numberOfmembers = (Xparser.xFind(serverXML,"//websphere/applications/"+appNum+"/@groupSize"))
            	 break
	        app=app+1
	print "RolloutApplication: appName="+applicationName+" nodeName="+nodeName+" serverName="+serverName+" ..."
	length = len(editionNumber)
	print "RolloutApplication: editionNumber.length="+str(length)+" editionNumber="+editionNumber
	if (length >= 1):
		print "RolloutApplication: Rollout Edition for application"+applicationName+"  ..."
		try:
			_excp_ = 0
			rolloutApplication = AdminTask.rolloutEdition (['-appName', ''+applicationName+'', '-edition', ''+editionNumber+'', '-params', '{rolloutStrategy grouped}{resetStrategy hard}{groupSize '+numberOfmembers+'}{drainageInterval 30}'])
			_excp_ = 0 #reset (in case of nested exceptions)
		except:
			_type_, _value_, _tbck_ = sys.exc_info()
			_excp_ = 1
		#endTry 
		temp = _excp_
		if (temp > 0):
			print "RolloutApplication: Exception trying to Rollout Application "+applicationName+" "+nodeName+" "+serverName
			return 
		else:
#			if (len(validateEnabled) > 0):
			if rolloutApplication == "true":
				print rolloutApplication
		        	print "Success: Application Rollout completed"
			#endIf 
		#endElse 
			else:
				print "ERROR: RolloutApplication: Rollout failed for "+applicationName
				sys.exit(1)
	#endElse

#********************************************************
# script usage: 
#********************************************************

def usage():
	print " "
        print " "
        print " usage: python util.py [option] [environment type] [instance]"
        print " example: python util.py updateDmgrPorts nxsa dev01_nx"
        print " "
        print " current options:"
        print " ----------------"
        print " 1) updateDmgrPorts [steps: updates the dmgr ports based on configuration in instance xml file]"
        print " 2) updateNodePorts [steps: updates the node agent ports based on configuration in instance xml file]"
        print " "
        print " " 
        
#********************************************************
# main: 
#********************************************************

def main():
        
	print " "
	print " "
        
        
        # check arguments
	if len(sys.argv) < 4:
		usage()
		sys.exit(1)
        # expected input

	shieldHome = sys.argv[0]
	envType = sys.argv[1]
	instance = sys.argv[2]
	task = sys.argv[3]
		
        # variables
	xmlBasePath = (shieldHome+"/xml/")	
		
        
        #xml path
	serverXML = (xmlBasePath+envType+"/"+instance+".xml")
	serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	xmlNodeConfig = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	nodeName = base.matchNodeVal(xmlNodeConfig)    
	
	if (task == "updateDmgrPorts"):
		xmlNodeConfig = Xparser.xFind(serverXML, "//websphere/dmgr/@nodeName")
		nodeName = base.matchNodeVal(xmlNodeConfig)
		serverName = Xparser.xFind(serverXML, "//websphere/dmgr/@name")
		updateDmgrPorts(serverXML, nodeName, serverName)
	elif (task == "updateNodePorts"):
		updateNodePorts(serverXML, nodeName, serverName)
	elif (task == "startServer"):
		startServer(serverXML, nodeName, serverName)
	elif (task == "stopServer"):
		stopServer(serverXML, nodeName, serverName)
	elif (task == "stopCluster"):
		stopCluster(serverXML)
	elif (task == "jvmJavaCore"):
		jvmJavaCore(serverXML, nodeName, serverName)
	elif (task == "jvmHeapDump"):
		jvmHeapDump(serverXML, nodeName, serverName)
	elif (task == "startCluster"):
		startCluster(serverXML)
	elif (task == "rippleStart"):
		rippleStart(serverXML)
	elif (task == "restartServer"):
		restartServer(serverXML, nodeName, serverName)
	elif (task == "validateEdition"):
		validateEdition(serverXML, nodeName, serverName)
 	elif (task == "cancelValidateEdition"):
        	cancelValidateEdition(serverXML, nodeName, serverName)
	elif (task == "rolloutAppEdition"):
        	rolloutAppEdition(serverXML, nodeName, serverName)
	elif (task == "stopstartServer"):
		stopServer(serverXML, nodeName, serverName)
		startServer(serverXML, nodeName, serverName)
	else:
		print "option: " + task + " not found"
		usage() 
# call main	        
main()