import sys
import java.io as javaio
import Xparser
import XPathCount
import base
import java.util as util
import string
from os import path


def removeBindings(currScope):
	print"--> remove existing bindings"
	print"--> current scope: ", currScope
	scopeId = AdminConfig.getid(currScope)
	#serverScopeId = 
	bindings = AdminConfig.list("StringNameSpaceBinding", scopeId).splitlines()
	for binding in bindings:
		stringIdentifier = AdminConfig.showAttribute(binding, "name")
		stringValue = AdminConfig.showAttribute(binding, "stringToBind")
		if (stringIdentifier == "ENVIRONMENT" or stringIdentifier ==  "AD_PASSWORD" or stringIdentifier == "scheduler.providerRegistrationExtractSchedule" or stringIdentifier == "scheduler.providerRegTinSchedule" or stringIdentifier == "providerAES256EncryptionService.passPhrase" or stringIdentifier == "scheduler.providerRegistrationExtractSchedule" or stringIdentifier == "mail.host"):
			print "--> found in name space: ", stringIdentifier
			print "--> skipping: ", stringIdentifier+" = "+stringValue
		else:			
			print "--------------------------------------------------------------------"
			print "--> found in name space: ", stringIdentifier
			print "--> removing: ", stringIdentifier+" = "+stringValue
			AdminConfig.remove(binding)


def setInstanceExtProps(key, value, serverScope, clusterScope):
	
	attrs = ["['name' '"+key+"'] ['nameInNameSpace' '"+key+"'] ['stringToBind' ["+value+"]]"]
	#Find Configuration Object
	if (key == "global.batch.enabled"):
		print"--> current scope: ", serverScope
		scopeId = AdminConfig.getid(serverScope)
		cfgObj = AdminConfig.create("StringNameSpaceBinding", scopeId, attrs)
		print "********************************************************************"
		print "--> creating new binding:"
		print "********************************************************************"
		print "name: ", key
		print "value", value
		print "********************************************************************"
	else:
		print"--> current scope: ", clusterScope
		scopeId = AdminConfig.getid(clusterScope)
		cfgObj = AdminConfig.create("StringNameSpaceBinding", scopeId, attrs)
		print "********************************************************************"
		print "--> creating new binding:"
		print "********************************************************************"
		print "name: ", key
		print "value", value
		print "********************************************************************"			
#********************************************************
# create external properties in name space bindings
#  - property file based used for external property updates
#********************************************************
def configureExtProperties(propertyFile, serverName, clusterName, nodeName):
	print "in the configureExtProperties method -"
	cellName = AdminControl.getCell()
    # get server scope and id
	serverScope = '/Node:'+nodeName+'/Server:'+serverName+'/'
	# get cluster scope and id
	clusterScope = '/Cell:'+cellName+'/ServerCluster:'+clusterName+'/'
	#remove server level existing bindings - except ENVIRONMENT or AD_PASSWORD
	removeBindings(serverScope)
	removeBindings(clusterScope)
	AdminConfig.save()
	props = util.Properties()
	# check existance of property file
	#if path.exists(propertyFile)
	loadProp = props.load(javaio.FileInputStream(propertyFile))
	for key in props.keySet().iterator():
		value = props.getProperty(key)
		setInstanceExtProps(key, value, serverScope, clusterScope)
	AdminConfig.save()	

#main	
task = sys.argv[3]
propertyFile = sys.argv[4]
serverName = sys.argv[5]
clusterName = sys.argv[6]
nodeName = sys.argv[7]

configureExtProperties(propertyFile, serverName, clusterName, nodeName)