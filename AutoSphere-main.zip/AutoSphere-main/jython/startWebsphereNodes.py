#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 02/06/2017 Murry Kane     Initial version
#
#_________________________________________________________________________________________________
#
import os, sys
from constants import *

if os.path.isfile('%s/wsadminlib.py' % JYTHON_DIR):
  execfile('%s/wsadminlib.py' % JYTHON_DIR)
else:
  print "Needed library wsadminlib.py NOT Found, exiting!"
  sys.exit(1)

enableDebugMessages()
m="checkClusterNodes:"

#lets validate we are on a DMGR!
if whatEnv() == 'nd':
  sop(m, "Running on DMGR, continueing...")
else:
  sop(m, "ERROR: You must run this script on the DMGR!, exiting!")
  sys.exit(2)

def usage():
  print "Usage: %s 'String of Exclude Nodes'" % m
  print "Example %s 'WEBP02EPresentBatch02/WEBP02ESS01'" % m
  
if ( len(sys.argv) != 1):
  usage()
  sys.exit(1)
else:
  ignoreNodeList = sys.argv[0]

ignorelist = ignoreNodeList.split("/")
sop(m,"Ignore NODE List is %s" % ignorelist)
  
serverIDList = []

nodes = _splitlines(AdminConfig.list( 'Node' ))
for node_id in nodes:
  nodename = getNodeName(node_id)
  hostname = getNodeHostname(nodename)
  platform = getNodePlatformOS(nodename)
  if nodeIsDmgr(nodename):
    sop(m, "NODE %s on %s (%s) - Deployment manager" % (nodename,hostname,platform))
  else:
    sop(m,"NODE %s on %s (%s)" % (nodename,hostname,platform))
    if nodename in ignorelist:
      sop(m,"NODE %s is being skipped since its in the ignore list" % nodename)
    else:
      userroot = getWasProfileRoot(nodename)
      serverEntries = _splitlines(AdminConfig.list( 'ServerEntry', node_id ))
      for serverEntry in serverEntries:
        sName = AdminConfig.showAttribute( serverEntry, "serverName" )
        sType = AdminConfig.showAttribute( serverEntry, "serverType" )
        if sType == "NODE_AGENT":
          isRunning = isServerRunning(nodename,sName)
          if isRunning:
            status = "running"
          else: 
            status = "stopped"
            #if sType == "NODE_AGENT":
            #userroot = getWasProfileRoot(nodename)
            serverIDList.append( (nodename.encode('ascii', 'ignore'), platform.encode('ascii', 'ignore'), hostname.encode('ascii', 'ignore'), userroot.encode('ascii', 'ignore')) )
          #sop(m, "\t%-18s %-15s %s Installation directory [%s]" % (sType,sName,status, userroot))
          sop(m, "\t%-18s %-15s %s" % (sType,sName,status))
        
#sop(m, serverIDList)
print "List of stopped NODES is: %s" % serverIDList
#return serverIDList

