#===================================================
# 	Name: sdkNodeUpdate.py
# 	Author: Jeffrey Apiado
# 	Role: To update sdk version per node
# 	Created: 04/13/2018
#===================================================
# START [define globals]
#===================================================
import re
pattern1 = re.compile(r'^.*(\d+\.\d+_\d+)$')
pattern2 = re.compile(r'^(.*?)\(cells')
#===================================================
# Built in Modules
#===================================================
from java.util.logging import Logger
from java.util.logging import Level
from java.util.logging import FileHandler
from java.util.logging import LogManager, SimpleFormatter
import os, Queue, time
from java.io import InputStreamReader
from java.io import BufferedReader
from java.io import File
from threading import Thread

_srv = AdminConfig.list("Server").splitlines()
_noAgent = [ rsrv for rsrv in _srv if rsrv.find('nodeagent') == -1]
v = "nil"
#--------------------------------------------------------------------------
class customLog:
    def __init__(self, fname = "jython", style = "txt", strr = '_runtime'):
        self.fh = FileHandler(fname + strr + '%u_.log',50000,1)
        # note: making sure output in text format
        if style == "txt":
            self.fh.setFormatter( SimpleFormatter() )
        self.logger = Logger.getLogger("myLogger")
        self.logger.addHandler(self.fh)

    def debug(self, text):
        self.logger.log(Level.INFO, text)

    def info(self, text):
        self.logger.log(Level.INFO, text)

    def warn(self, text):
        self.logger.log(Level.WARNING, text)

    def error(self, text):
        self.logger.log(Level.SEVERE, text)

    def HEADING(self, text):
        self.logger.log(Level.CONFIG, text)

    def finer(self, text):
        self.logger.log(Level.FINER, text)

    def close(self):
        self.fh.close()

#end=======================================================

class main(customLog):
    def __init__(self, logdestination):
         customLog.__init__(self, logdestination)
         customLog.info(self, "**** class: mainStart ****")

    def __str__(self):
         return """
                   [***************************************************************************]
                   [Pre-requisite] Make sure the SDK version was present in the system and match
                                exactly the version you specify as an argument!
                   [***************************************************************************]
                """

    def mainStart(self):
        if len(sys.argv) == 1:
            global v
            v = sys.argv[0]
            customLog.info(self, "Version passed as an argument: %s" % v)
            allNodes = AdminTask.listNodes().splitlines()
            dmgrName = [nodde for nodde in allNodes if nodde.find("Dmgr") > -1]
            customLog.info(self, "**** module runStart ****")
        elif len(sys.argv) < 1:
            print "missing argument -- [required][version]"
            usage()
            sys.exit(2)
        else:
            print "To many arguments -- [required only one]"
            usage()
            sys.exit(2)
        #end
        if allNodes:
           customLog.info(self, "Dmgr node: %s" % dmgrName[0])
           self.dmgr = dmgrName[0] # < string
           customLog.info(self, "Managed Nodes: " + str(allNodes))
           self.allNodes = allNodes
 
    def getCurrentVersion(self):
        customLog.info(self, "***getCurrent SDK Version***") 
        holder = []
        arg1 = "[-nodeName %s]" % self.dmgr
        exec1 = AdminTask.getSDKPropertiesOnNode(arg1)
        strFormat = exec1[2:-2].split("] [")
        print strFormat
        customLog.info(self, str(strFormat))
        print "===" * 20
        for line in strFormat:
            f, s = line.split(" ",2)
            print f,"            => ",s
            customLog.info(self, str(f))
            customLog.info(self, "           => " + str(s))
            match = re.search(pattern1, f) 
            if match:
               holder.append(match.group(1))
        #end
        print "===" * 20
        self.CURRENT_VERSION =  holder[0]          
        customLog.info(self, "Current SDK version captured: %s" % holder[0])
        stat = self.compareSDK()
        if stat:
            q = Queue.Queue(0)
            objthread = Utils(q)
            objthread.start()            

            for websphrNode in self.allNodes:
                 q.put(websphrNode)
              
            objthread.join()    

 
    def compareSDK(self):
        if sys.argv[0] == self.CURRENT_VERSION:
            print "The SDK version installed is current to the version you specify."
            print "Specified: ",sys.argv[0]
            print "Installed: ",self.CURRENT_VERSION
            sys.exit(0)
        else:
            print "Installing SDK version %s to all nodes" % sys.argv[0]
        return "_CONT"   

#end==========================================================
def usage():
    print """[Usage]
                [Pre-requisite] Make sure the SDK version was present in the system and match
                                exactly the version you specify as an argument!
             [================================================================]
             [wsadmin.sh]
                  sdkNodeUpdate.py <argument: version>
          """

#end===========================================================
class Utils(Thread):
    def __init__(self, q):
        Thread.__init__(self)
        self.que = q

    def run(self):
        while 1:
            nname = self.que.get()
            ids = [ serverName for serverName in _noAgent if serverName.find(nname) > -1]
            xmatch = re.search(pattern2, ids[0])
            sname = xmatch.group(1)
            if sname:
                arg2 = '[-nodeName %s -serverName %s -sdkName %s]' % (nname, sname, v)
                print arg2
                #AdminTask.setServerSDK(arg2)
                #AdminTask.save()
                print "Config Save for %s" % sname
            if self.que.empty():
                  break
             
#end===========================================================

if __name__ == "__main__":
     	ix = main("/tmp/sdkVersion")
        print ix
     	ix.mainStart()
        ix.getCurrentVersion()
        print "EOF =========> see logs /tmp/sdkVersion_runtime0_.log"

#end==============================================================






























