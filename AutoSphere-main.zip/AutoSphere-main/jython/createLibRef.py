SHARED LIB MAP to Application
------------------------------


print " get shared lib"
library = AdminConfig.getid('/Library:mlpProvInt1C_sharedLib/')

print "get deployment unit"
deployment = AdminConfig.getid('/Deployment:mlpProvInt1C/')

print "get deploy object"
appDeploy = AdminConfig.showAttribute(deployment, 'deployedObject')

print "get classloader"
classLoad1 = AdminConfig.showAttribute(appDeploy, 'classloader')

print "create lib reference"
AdminConfig.create('LibraryRef', classLoad1, [['libraryName', 'mlpProvInt1C_sharedLib']])

print "save configuration"
AdminConfig.save()



file: deployment.xml
----------------------
<?xml version="1.0" encoding="UTF-8"?>
<appdeployment:Deployment xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:appdeployment="http://www.ibm.com/websphere/appserver/schemas/5.0/appdeployment.xmi" xmi:id="Deployment_1309417524994">
  <deployedObject xmi:type="appdeployment:ApplicationDeployment" xmi:id="ApplicationDeployment_1309417524994" deploymentId="0"startingWeight="1" binariesURL="$(APP_INSTALL_ROOT)/mlpIntCell/mlpProvInt1C.ear" useMetadataFromBinaries="false" enableDistribution="true" createMBeansForResources="true" reloadEnabled="false" appContextIDForSecurity="href:mlpIntCell/mlpProvInt1C" filePermission=".*\.dll=755#.*\.so=755#.*\.a=755#.*\.sl=755" allowDispatchRemoteInclude="false" allowServiceRemoteInclude="false" asyncRequestDispatchType="DISABLED">
    <targetMappings xmi:id="DeploymentTargetMapping_1309417524995" enable="true" target="ClusteredTarget_1309417524995"/>
    <classloader xmi:id="Classloader_1309417524995" mode="PARENT_FIRST">
      <libraries xmi:id="LibraryRef_1309418843819" libraryName="mlpProvInt1C_sharedLib"/>
    </classloader>
    <modules xmi:type="appdeployment:WebModuleDeployment" xmi:id="WebModuleDeployment_1309417524995" deploymentId="1" starting
Weight="10000" uri="provider.war">
      <targetMappings xmi:id="DeploymentTargetMapping_1309417524996" target="ClusteredTarget_1309417524995"/>
    </modules>
    <properties xmi:id="Property_1309417524995" name="metadata.complete" value="false"/>
  </deployedObject>
  <deploymentTargets xmi:type="appdeployment:ClusteredTarget" xmi:id="ClusteredTarget_1309417524995" name="mlpProvInt1C"/>
</appdeployment:Deployment>


