
import os, sys, xreadlines
import string

xmlfile = sys.argv[0]
tempfile = sys.argv[1]

cell = AdminConfig.list("Cell" )
nodes = AdminConfig.list("Node", cell ).split(lineSeparator)

output = open(tempfile, 'w')
came = AdminConfig.showAttribute(cell, "name" )
output.write(came)
output.write("\n")

for node in nodes:
    cname = AdminConfig.showAttribute(cell, "name" )
    nname = AdminConfig.showAttribute(node, "name" )
    output.write(nname)
    output.write("\n")

output.close()
