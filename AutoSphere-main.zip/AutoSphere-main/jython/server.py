#--------------------------------------------------------------
# Build a server:
#  1) server.py contains server specific methods - external jython files 
#     are used to build artifacts outside of the server configurations 
#  2) build method calls initializes calls methods to build a websphere
#     application server instance.   
#--------------------------------------------------------------

#import
import sys
import java.io
import Xparser
import XPathCount
import base
import resources
import environment
import sibus
import jms
import mq
import security
import time
import os

#--------------------------------------------------------------
# initialize global websphere classes
#--------------------------------------------------------------
base.setAdminRefs((AdminConfig, AdminControl, AdminTask, AdminApp, AdminUtilities))
#********************************************************
# create classloader
#********************************************************

def createClassloader(serverXML, nodeName, serverName):

	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	configureClassloader = Xparser.xFind(serverXML, "//websphere/server/classloader/@configure")

	if ( configureClassloader == "false"):
		print "--> classloader configure set to false ... skipping"
	else:
		sharedLib = Xparser.xFind(serverXML, "//websphere/server/classloader/@sharedLib")
		
		server = AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'') 
		appServer = AdminConfig.list('ApplicationServer', server)
		print "--> creating classloader: ",serverName
		classloader = AdminConfig.create('Classloader', appServer, [['mode', 'PARENT_FIRST']])
		print "--> mapping shared lib: ",sharedLib
		AdminConfig.create('LibraryRef', classloader, [['libraryName', sharedLib], ['sharedClassloader', 'true']])

	AdminConfig.save()
	print "-> ------------------------------------"
	print "-> complete: create classloader"
	print "-> ------------------------------------"


#********************************************************
# update thread pools
#********************************************************

def updateThreadPools(serverXML, nodeName, serverName):
	
	threadPoolsConfigure = Xparser.xFind(serverXML, "//websphere/server/threadPool/@configure")

	if ( threadPoolsConfigure == "false"):
		print "--> thread pools set to false ... skipping"
	else:
		#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
		#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
		server = AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'')
		
		# thread pool values  
		defaultMin= Xparser.xFind(serverXML, "//websphere/server/threadPool/default/@minimumSize")
		defaultMax= Xparser.xFind(serverXML, "//websphere/server/threadPool/default/@maximumSize")
		serverStartupMin= Xparser.xFind(serverXML, "//websphere/server/threadPool/serverStartup/@minimumSize")
		serverStartUpMax= Xparser.xFind(serverXML, "//websphere/server/threadPool/serverStartup/@maximumSize")
		  
		threadPools = AdminConfig.list('ThreadPool', server ).splitlines()	

		for currThreadPool in threadPools:
			getPoolName = AdminConfig.showAttribute(currThreadPool, "name")
			if (getPoolName == "WebContainer"):
				# grab values
				minVal= Xparser.xFind(serverXML, "//websphere/server/threadPool/webContainer/@minimumSize")
				maxVal= Xparser.xFind(serverXML, "//websphere/server/threadPool/webContainer/@maximumSize")
				inactivityTimeout = Xparser.xFind(serverXML, "//websphere/server/threadPool/webContainer/@inactiveTimout")        		
						
				print "--> updating pool: ", getPoolName
				print "--> Minimum = ", minVal
				print "--> Maximum = ", maxVal
				print "--> Inactivity Timeout = ", inactivityTimeout
			
				AdminConfig.modify( currThreadPool, [['minimumSize', minVal ], ['maximumSize', maxVal ], ['inactivityTimeout', inactivityTimeout ]] )
				AdminConfig.save()
			if (getPoolName == "server.startup"):
				# grab values
				minVal= Xparser.xFind(serverXML, "//websphere/server/threadPool/serverStartup/@minimumSize")
				maxVal= Xparser.xFind(serverXML, "//websphere/server/threadPool/serverStartup/@maximumSize")
				inactivityTimeout = Xparser.xFind(serverXML, "//websphere/server/threadPool/serverStartup/@inactiveTimout")        		
						
				print "--> updating pool: ", getPoolName
				print "--> Minimum = ", minVal
				print "--> Maximum = ", maxVal
				print "--> Inactivity Timeout = ", inactivityTimeout
			
				AdminConfig.modify( currThreadPool, [['minimumSize', minVal ], ['maximumSize', maxVal ], ['inactivityTimeout', inactivityTimeout ]] )
				AdminConfig.save()
			# more values can be added here
			if (getPoolName == "Default"):
					# grab values
				minVal= Xparser.xFind(serverXML, "//websphere/server/threadPool/default/@minimumSize")
				maxVal= Xparser.xFind(serverXML, "//websphere/server/threadPool/default/@maximumSize")
				
				print "--> updating pool: ", getPoolName
				print "--> Minimum = ", minVal
				print "--> Maximum = ", maxVal
				
				AdminConfig.modify( currThreadPool, [['minimumSize', minVal ], ['maximumSize', maxVal ]] )
				AdminConfig.save()
					
	print "-> ------------------------------------"
	print "-> complete: update thread pools"
	print "-> ------------------------------------"


#********************************************************
# update web container
#********************************************************

def updateWebContainer(serverXML, nodeName, serverName):
        
	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	server = AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'')
	sessionCookieConfigure = Xparser.xFind(serverXML, "//websphere/server/webContainer/sessionCookies/@configure")
	sessionIdConfigure = Xparser.xFind(serverXML, "//websphere/server/webContainer/sessionId/@configure")
	servletCachingConfigure = Xparser.xFind(serverXML, "//websphere/server/webContainer/servletCaching/@configure")

	if (sessionCookieConfigure == "true"):
		sessionCookieEnable = Xparser.xFind(serverXML, "//websphere/server/webContainer/sessionCookies/@enable")
		print "--> setting session enable: ", sessionCookieEnable
		sessionManager = AdminConfig.list('SessionManager', server )
		AdminConfig.modify( sessionManager, [['enableCookies', sessionCookieEnable ]] )

	if (sessionIdConfigure == "true"):
	# update session cookie	
		sessionId = Xparser.xFind(serverXML, "//websphere/server/webContainer/sessionId/@name")
		print "--> setting session ID: ", sessionId
		cookie = AdminConfig.list('Cookie', server )
		AdminConfig.modify( cookie, [['name', sessionId ]] )
		AdminConfig.save()

	if (servletCachingConfigure == "true"):
		# servlet caching
		servletCacheEnable = Xparser.xFind(serverXML, "//websphere/server/webContainer/servletCaching/@enable")
		print "--> setting servlet caching enable: ", servletCacheEnable
		wc = AdminConfig.list('WebContainer', server )
		AdminConfig.modify( wc, [['enableServletCaching', servletCacheEnable ]] )
		AdminConfig.save()	

	print "-> ------------------------------------"
	print "-> complete: update web container"
	print "-> ------------------------------------"

def  addWebContainerProps(serverXML):
	configure = Xparser.xFind(serverXML, "//websphere/server/webContainer/wcprops/@configure")
	if (configure == "false"):
		print "--> add WebContainer Props set to false ... skipping"
		return 0
	wcPropsCount = XPathCount.getCount(serverXML, "//websphere/server/webContainer/wcprops/*", "")
	x = 1
	while x < wcPropsCount+1:
		  wcpNum = ("wcprop"+str(x))
		  wcpName = Xparser.xFind(serverXML, "//websphere/server/webContainer/wcprops/"+wcpNum+"/@name")
		  wcpValue = Xparser.xFind(serverXML, "//websphere/server/webContainer/wcprops/"+wcpNum+"/@value")
		  serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
		  server = AdminConfig.getid('/Server: ' + serverName + '/')              
		  wc = AdminConfig.list('WebContainer',server)
		  attr = [['name',wcpName],['value',wcpValue]]
		  AdminConfig.create('Property', wc, attr)
		  AdminConfig.save()
		  x = x+1

def  addJVMCustomProp(serverXML, nodeName, serverName):
	configure = Xparser.xFind(serverXML, "//websphere/server/customProperties/jvmprops/@configure")
	if (configure == "false"):
		print "--> add JVM Custom Props set to false ... skipping"
		return 0
	jvmPropsCount = XPathCount.getCount(serverXML, "//websphere/server/customProperties/jvmprops/*", "")
	x = 1
	while x < jvmPropsCount+1:
		  jvmpNum = ("jvmprops"+str(x))
		  jvmpName = Xparser.xFind(serverXML, "//websphere/server/customProperties/jvmprops/"+jvmpNum+"/@name")
		  jvmpValue = Xparser.xFind(serverXML, "//websphere/server/customProperties/jvmprops/"+jvmpNum+"/@value")
		  serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
		  server = AdminConfig.getid('/Server: ' + serverName + '/')
		  wc = AdminConfig.list('JavaVirtualMachine',server)
		  attr = [['name',jvmpName],['value',jvmpValue]]
		  AdminConfig.create('Property', wc, attr)
		  AdminConfig.save()
		  x = x+1
def updateObjectRequestBroker(serverXML, nodeName, serverName):
	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	server = AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'')
	orb = AdminConfig.list('ObjectRequestBroker',server)
	orbConfigure = Xparser.xFind(serverXML, "//websphere/server/orb/@configure")
	if (orbConfigure == "true"):
		noLocalCopiesValue = Xparser.xFind(serverXML, "//websphere/server/orb/passbyreference/@enable")
		print "--> setting pass by reference for object request broker :"+noLocalCopiesValue
		AdminConfig.modify(orb,[[ 'noLocalCopies', noLocalCopiesValue ]])
		AdminConfig.save()
	print "-> ------------------------------------"
	print "-> complete: update orb service"
	print "-> ------------------------------------"

#********************************************************
# update verbose GC
#********************************************************

def updateVerboseGC(serverXML, nodeName, serverName):

	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	verboseGC = Xparser.xFind(serverXML, "//websphere/server/jvm/verboseGC/@value")
	server = AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'')
	jvm = AdminConfig.list('JavaVirtualMachine', server )

	print "--> setting verbose garbage collection"
	print "--> args: ", verboseGC
	AdminConfig.modify( jvm, [[ 'verboseModeGarbageCollection', verboseGC ]] )
	AdminConfig.save()
	# TODO - externalize this into a method compMessage(jvm custom properties) 
	print "-> ------------------------------------"
	print "-> complete: update verbose garbage collection"
	print "-> ------------------------------------"

#********************************************************
# update boot classpath
#********************************************************

def updateBootClassPath(serverXML, nodeName, serverName):

	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	bootClasspath = Xparser.xFind(serverXML, "//websphere/server/jvm/bootClasspath/@value")
	server = AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'')
	jvm = AdminConfig.list('JavaVirtualMachine', server )
	#currBcp = AdminConfig.showAttribute(jvm, 'bootClasspath')
	#print "currBcp: ", currBcp
	print "--> setting boot classpath"
	print "--> args: ", bootClasspath
	# clear the current configuration
	AdminConfig.modify( jvm, [[ 'bootClasspath', " " ]] )
	# set the value
	AdminConfig.modify( jvm, [[ 'bootClasspath', bootClasspath ]] )
	AdminConfig.save()
	# TODO - externalize this into a method compMessage(jvm custom properties) 
	print "-> ------------------------------------"
	print "-> complete: update boot classpath"
	print "-> ------------------------------------"

def updateClassPath(serverXML, nodeName, serverName):

	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	classpath = Xparser.xFind(serverXML, "//websphere/server/jvm/classpath/@value")  
	server = AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'')
	jvm = AdminConfig.list('JavaVirtualMachine', server )
	print "--> setting classpath"
	print "--> args: ", classpath
	# clear the current configuration
	AdminConfig.modify( jvm, [[ 'classpath', " " ]] )
	# set the value
	AdminConfig.modify( jvm, [[ 'classpath', classpath ]] )
	AdminConfig.save()
	# TODO - externalize this into a method compMessage(jvm custom properties) 
	print "-> ------------------------------------"
	print "-> complete: update classpath"
	print "-> ------------------------------------"

#********************************************************
# update jvm custom properties: 
#********************************************************
def updateJvmCustomProps(serverXML, nodeName, serverName):

	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	customPropCount = XPathCount.getCount(serverXML, "//websphere/server/jvm/customProperties/*", "")
	server = AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'') 
	jvm = AdminConfig.list('JavaVirtualMachine', server )
		  
	i = 1
	while i < customPropCount+1:
		cPropNum = ("customProp"+str(i))
		name = Xparser.xFind(serverXML, "//websphere/server/jvm/customProperties/"+cPropNum+"/@name")
		checkVal = len(name)
		if (checkVal < 1):
			print " no values defined ... skipping"
			i = 0
			return ""
		else:
			value = Xparser.xFind(serverXML, "//websphere/server/jvm/customProperties/"+cPropNum+"/@value") 
			print "--> creating custom property: "
			print "--> ------------------------- "
			print "-->  name: ", name
			print "--> value: ", value
		 
			props = [ [[ 'name', name ], [ 'value', value ]] ]
			  
			AdminConfig.modify( jvm, [[ 'systemProperties', props]])
			AdminConfig.save()
			i = i+1        

	print "-> ------------------------------------"
	print "-> complete: update jvm custom properties"
	print "-> ------------------------------------"


#********************************************************
# update jvm environment entries:
#********************************************************
def createJvmEnvEntries(serverXML, nodeName, serverName):

        #nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
        #serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
        customPropCount = XPathCount.getCount(serverXML, "//websphere/server/jvm/environmententries/*", "")
        server = AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'')
        jvm = AdminConfig.list('JavaProcessDef', server )

        i = 1
        while i < customPropCount+1:
                cPropNum = ("customProp"+str(i))
                name = Xparser.xFind(serverXML, "//websphere/server/jvm/environmententries/"+cPropNum+"/@name")
                checkVal = len(name)
                if (checkVal < 1):
                        print " no values defined ... skipping"
                        i = 0
                        return ""
                else:
                        value = Xparser.xFind(serverXML, "//websphere/server/jvm/environmententries/"+cPropNum+"/@value")
                        print "serverName --> ", serverName
                        print "--> creating jvm environment entries: "
                        print "--> ------------------------- "
                        print "-->  name: ", name
                        print "--> value: ", value

                        props = [ [ 'name', name ], [ 'value', value ]  ]

                        #AdminConfig.modify( jvm, [[ 'systemProperties', props]])
                        AdminConfig.create('Property',(jvm), props)
                        AdminConfig.save()
                        i = i+1

        print "-> ------------------------------------"
        print "-> complete: create jvm environment entries"
        print "-> ------------------------------------"



#********************************************************
# update nodeagent environment entries:
#********************************************************
def createNodeagentEnvEntries(serverXML, nodeName, serverName):

        #nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
        #serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
        customPropCount = XPathCount.getCount(serverXML, "//websphere/nodeagent/environmententries/*", "")
        srvid = AdminConfig.getid('/Cell:PRTCell/Node:'+nodeName+'/Server:nodeagent')
        pdef = AdminConfig.list('JavaProcessDef', srvid )

        i = 1
        while i < customPropCount+1:
                cPropNum = ("customProp"+str(i))
                name = Xparser.xFind(serverXML, "//websphere/nodeagent/environmententries/"+cPropNum+"/@name")
                checkVal = len(name)
                if (checkVal < 1):
                        print " no values defined ... skipping"
                        i = 0
                        return ""
                else:
                        value = Xparser.xFind(serverXML, "//websphere/nodeagent/environmententries/"+cPropNum+"/@value")
                        print "nodeagent --> ", nodeName
                        print "--> creating nodeagent environment entries: "
                        print "--> ------------------------- "
                        print "-->  name: ", name
                        print "--> value: ", value

                        props = [ [ 'name', name ], [ 'value', value ]  ]

                        #AdminConfig.modify( jvm, [[ 'systemProperties', props]])
                        AdminConfig.create('Property',(pdef), props)
                        AdminConfig.save()
                        i = i+1

        print "-> ------------------------------------"
        print "-> complete: create nodeagent environment entries"
        print "-> ------------------------------------"

#********************************************************
# update dmgr environment entries:
#********************************************************

def createDmgrEnvEntries(serverXML, nodeName, serverName):

        #nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
        #serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
        customPropCount = XPathCount.getCount(serverXML, "//websphere/dmgr/environmententries/*", "")
        nodeName = Xparser.xFind(serverXML, "//websphere/dmgr/@nodeName")
        srvid = AdminConfig.getid('/Cell:PRTCell/Node:'+nodeName+'/Server:dmgr')
        pdef = AdminConfig.list('JavaProcessDef', srvid )

        i = 1
        while i < customPropCount+1:
                cPropNum = ("customProp"+str(i))
                name = Xparser.xFind(serverXML, "//websphere/dmgr/environmententries/"+cPropNum+"/@name")
                checkVal = len(name)
                if (checkVal < 1):
                        print " no values defined ... skipping"
                        i = 0
                        return ""
                else:
                        value = Xparser.xFind(serverXML, "//websphere/dmgr/environmententries/"+cPropNum+"/@value")
                        print "nodeagent --> ", nodeName
                        print "--> creating dmgr environment entries: "
                        print "--> ------------------------- "
                        print "-->  name: ", name
                        print "--> value: ", value

                        props = [ [ 'name', name ], [ 'value', value ]  ]

                        #AdminConfig.modify( jvm, [[ 'systemProperties', props]])
                        AdminConfig.create('Property',(pdef), props)
                        AdminConfig.save()
                        i = i+1

        print "-> ------------------------------------"
        print "-> complete: create dmgr environment entries"
        print "-> ------------------------------------"

#********************************************************
# create HTTP Inbound Channel:
#********************************************************

def createHTTPInboundChannel(serverXML, nodeName, serverName):

           customPropCount = XPathCount.getCount(serverXML, "//websphere/server/jvm/HTTP_inbound_channel_HTTP_2/*", "")
           server = AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'')
           jvm = AdminConfig.list('HTTPInboundChannel', server )
           parse = jvm.splitlines()
           parse[1]
           var = parse[1]

           i = 1
           while i < customPropCount+1:
                cPropNum = ("customProp"+str(i))
                name = Xparser.xFind(serverXML, "//websphere/server/jvm/HTTP_inbound_channel_HTTP_2/"+cPropNum+"/@name")
                checkVal = len(name)
                if (checkVal < 1):
                        print " no values defined ... skipping"
                        i = 0
                        return ""
                else:
                        value = Xparser.xFind(serverXML, "//websphere/server/jvm/HTTP_inbound_channel_HTTP_2/"+cPropNum+"/@value")
                        description = Xparser.xFind(serverXML, "//websphere/server/jvm/HTTP_inbound_channel_HTTP_2/"+cPropNum+"/@description")
                        print "serverName --> ", serverName
                        print "--> creating HTTP_inbound_channel_HTTP_2: "
                        print "--> ------------------------- "
                        print "--> name: ", name
                        print "--> value: ", value
                        print "--> description: ", description

                        props = [ ['name', name], ['value', value], ['description', description]  ]


                        AdminConfig.create('Property',(var), props)
                        AdminConfig.save()
                        i = i+1
				
           print "-> ------------------------------------"
           print "-> complete: create HTTP_inbound_channel_HTTP_2"
           print "-> ------------------------------------"				
		
#********************************************************
# update generic jvm args: 
#********************************************************
def updateGenJvmArgs(serverXML, nodeName, serverName):

	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	genJvmArgs = Xparser.xFind(serverXML, "//websphere/server/jvm/genericJvmArgs/@value")
	server = AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'')
	jvm = AdminConfig.list('JavaVirtualMachine', server )
	print "--> setting jvm generic args"
	print "--> args: ", genJvmArgs
	AdminConfig.modify( jvm, [[ 'genericJvmArguments', genJvmArgs ]] )
	AdminConfig.save()
	# externalize this into a method compMessage(jvm custom properties) 
	print "-> ------------------------------------"
	print "-> complete: update generic jvm args"
	print "-> ------------------------------------"

#********************************************************
# updateJvm Heap: 
#********************************************************
def updateHeap(serverXML, nodeName, serverName):

	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	minHeap = Xparser.xFind(serverXML, "//websphere/server/jvm/heap/@min")

	checkVal = len(minHeap)
	if (checkVal < 1):
		print " no values defined ... skipping"
		i = 0
		return ""
	else:
		maxHeap = Xparser.xFind(serverXML, "//websphere/server/jvm/heap/@max") 
		server = AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'')
		jvm = AdminConfig.list('JavaVirtualMachine', server )
		print "--> setting jvm heap size"
		print "--> min: ", minHeap
		AdminConfig.modify( jvm, [[ 'initialHeapSize', minHeap ]] )
		print "--> max: ", maxHeap
		jvm = AdminConfig.list('JavaVirtualMachine', server )
		AdminConfig.modify( jvm, [[ 'maximumHeapSize', maxHeap ]] )
		AdminConfig.save()
		print "-> ------------------------------------"
		print "-> complete: update jvm heap"
		print "-> ------------------------------------"

#********************************************************
# update wc default: 
#********************************************************
def updateWcPorts(serverXML, nodeName, serverName):
	portsConfigure = Xparser.xFind(serverXML, "//websphere/server/ports/@configure")
	print "ports configure = ", portsConfigure
	if ( portsConfigure == "false" ):
		print "--> ports configure set to false ... skipping"
	else:
		print "in the else loop of WC ports"
		#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
		#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
		host = Xparser.xFind(serverXML, "//websphere/server/@host")
		node = AdminConfig.getid('/Node:'+nodeName+'/')
		wcHost = Xparser.xFind(serverXML, "//websphere/server/ports/@wcHost")
		wcHostSec = Xparser.xFind(serverXML, "//websphere/server/ports/@wcHostSec")
		adminHost = Xparser.xFind(serverXML, "//websphere/server/ports/@adminHost")
		adminHostSec = Xparser.xFind(serverXML, "//websphere/server/ports/@adminHostSec")
		serverEntries = AdminConfig.list('ServerEntry', node).split(java.lang.System.getProperty('line.separator'))

		for serverEntry in serverEntries:
			print "in the server entry loop"
			sName = AdminConfig.showAttribute(serverEntry, "serverName")
			if sName == serverName:
				sepString = AdminConfig.showAttribute(serverEntry, "specialEndpoints")
				sepList = sepString[1:len(sepString)-1].split(" ")
				for specialEndPoint in sepList:
					endPointNm = AdminConfig.showAttribute(specialEndPoint, "endPointName")
					if endPointNm == "WC_defaulthost":
						print "--> configuring WC_defaulthost - port: ", wcHost
						ePoint = AdminConfig.showAttribute(specialEndPoint, "endPoint")
						AdminConfig.modify(ePoint, [["host", host], ["port", wcHost]])
						#break
						AdminConfig.save()
					if endPointNm == "WC_defaulthost_secure":
						print "--> configuring WC_defaulthost_secure - port: ", wcHostSec
						ePoint = AdminConfig.showAttribute(specialEndPoint, "endPoint")
						AdminConfig.modify(ePoint, [["host", host], ["port", wcHostSec]])
						#break
						AdminConfig.save()
					if endPointNm == "WC_adminhost":
						print "--> configuring WC_adminhost - port: ", adminHost
						ePoint = AdminConfig.showAttribute(specialEndPoint, "endPoint")
						AdminConfig.modify(ePoint, [["host", host], ["port", adminHost]])
						#break
						AdminConfig.save()
					if endPointNm == "WC_adminhost_secure":
						print "--> configuring WC_adminhost_secure - port: ", adminHostSec
						ePoint = AdminConfig.showAttribute(specialEndPoint, "endPoint")
						AdminConfig.modify(ePoint, [["host", host], ["port", adminHostSec]])
						#break
						AdminConfig.save()

def updateMonitoringPolicy(serverXML, nodeName, serverName):
	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	server = AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'')
	monPolicy = AdminConfig.list('MonitoringPolicy', server )
	autoRestart = Xparser.xFind(serverXML, "//websphere/server/monitoringPolicy/@autoRestart")
	if ( autoRestart == "true"):
		maxAttemps = Xparser.xFind(serverXML, "//websphere/server/monitoringPolicy/@maxAttemps")
		nodeRestartState = Xparser.xFind(serverXML, "//websphere/server/monitoringPolicy/@nodeRestartState")
		pingInterval = Xparser.xFind(serverXML, "//websphere/server/monitoringPolicy/@pingInterval")
		pingTimeout = Xparser.xFind(serverXML, "//websphere/server/monitoringPolicy/@pingTimeout")
		AdminConfig.modify( monPolicy, [[ 'maximumStartupAttempts', maxAttemps],[ 'pingTimeout', pingTimeout],['pingInterval',pingInterval],['autoRestart', autoRestart],[ 'nodeRestartState',nodeRestartState ]])
		print "Monitoring policy configured"
		AdminConfig.save()
	else:
		print " no values defined for Monitoring policy... skipping"
		return ""

def  updateJvmLogrotation(serverXML, nodeName, serverName):
	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	sys_out_lSize = Xparser.xFind(serverXML, "//websphere/server/jvm/logRotation/sysOutLog/@LogSize")
	sys_out_Hfiles = Xparser.xFind(serverXML, "//websphere/server/jvm/logRotation/sysOutLog/@NoHistoricFiles")
	sys_error_lSize = Xparser.xFind(serverXML, "//websphere/server/jvm/logRotation/sysErrLog/@LogSize")
	sys_error_Hfiles = Xparser.xFind(serverXML, "//websphere/server/jvm/logRotation/sysErrLog/@NoHistoricFiles")
	if ((len(sys_out_lSize))) > 0 :
		print "--> updating SystemOut: ", sys_out_lSize+":"+sys_out_Hfiles
		print "--> updating SystemErr: ", sys_error_lSize+":"+sys_error_Hfiles
		sid = AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'/')
		sys_log = AdminConfig.showAttribute(sid, 'outputStreamRedirect')
		AdminConfig.modify(sys_log, [['rolloverType', "SIZE"],['rolloverSize', sys_out_lSize],['maxNumberOfBackupFiles', sys_out_Hfiles]])
		sys_log = AdminConfig.showAttribute(sid, 'errorStreamRedirect')
		AdminConfig.modify(sys_log, [['rolloverType', "SIZE"],['rolloverSize', sys_error_lSize],['maxNumberOfBackupFiles', sys_error_Hfiles]])
		AdminConfig.save()
	else:
		print "JVM Logrotation tags are not defined in the XML file..so not updating JVM LogRotation"

#********************************************************
# updateJvmPorts: 
#********************************************************
def updatePorts(serverXML, nodeName, serverName):

	#--------------------------------------------------------------
	#     -- variables
	#--------------------------------------------------------------
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	host = Xparser.xFind(serverXML, "//websphere/server/@host")
	server = AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'') 
	ns = AdminConfig.list('NameServer', ''+server+'')
	portsConfigure = Xparser.xFind(serverXML, "//websphere/server/ports/@configure")

	if ( portsConfigure == "false"):
		print "--> ports configure set to false ... skipping"
	else:
		#--------------------------------------------------------------
		#     -- process ports based on build sheet 
		#--------------------------------------------------------------
		print "configuring server:", serverName
		print "start: update ports"
		
		# HTTP - Web Container
		#print "updating WEB_CONTAINER:"
		
		# BOOTSTRAP_ADDRESS
		base.portProcessor(serverName, nodeName, host, "BOOTSTRAP_ADDRESS", (Xparser.xFind(serverXML, "//websphere/server/ports/@bootstrap")))
		# SOAP
		base.portProcessor(serverName, nodeName, host, "SOAP_CONNECTOR_ADDRESS", (Xparser.xFind(serverXML, "//websphere/server/ports/@soap")))   
		# SAS_SSL_SERVERAUTH_LISTENER_ADDRESS
		base.portProcessor(serverName, nodeName, host, "SAS_SSL_SERVERAUTH_LISTENER_ADDRESS", (Xparser.xFind(serverXML, "//websphere/server/ports/@sasSsl")))
		# CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS
		base.portProcessor(serverName, nodeName, host, "CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS", (Xparser.xFind(serverXML, "//websphere/server/ports/@csiv2ServerAuth")))
		# CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS
		base.portProcessor(serverName, nodeName, host, "CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS", (Xparser.xFind(serverXML, "//websphere/server/ports/@csiv2MutualAuth")))
		# DCS_UNICAST_ADDRESS -modifiedShared paramater needs to be specified
		base.portProcessorShared(serverName, nodeName, host, "DCS_UNICAST_ADDRESS", (Xparser.xFind(serverXML, "//websphere/server/ports/@uniAddress")))
		# SIP_DEFAULTHOST
		base.portProcessorShared(serverName, nodeName, host, "SIP_DEFAULTHOST", (Xparser.xFind(serverXML, "//websphere/server/ports/@sip")))
		#SIP_DEFAULTHOST_SECURE -modifiedShared paramater needs to be specified
		base.portProcessorShared(serverName, nodeName, host, "SIP_DEFAULTHOST_SECURE", (Xparser.xFind(serverXML, "//websphere/server/ports/@sipSec")))
		# SIB_ENDPOINT_ADDRESS -modifiedShared paramater needs to be specified
		base.portProcessorShared(serverName, nodeName, host, "SIB_ENDPOINT_ADDRESS", (Xparser.xFind(serverXML, "//websphere/server/ports/@sib")))
		# SIB_ENDPOINT_SECURE_ADDRESS -modifiedShared paramater needs to be specified
		base.portProcessorShared(serverName, nodeName, host, "SIB_ENDPOINT_SECURE_ADDRESS ", (Xparser.xFind(serverXML, "//websphere/server/ports/@sibSec")))
		# SIB_MQ_ENDPOINT_ADDRESS
		base.portProcessor(serverName, nodeName, host, "SIB_MQ_ENDPOINT_ADDRESS", (Xparser.xFind(serverXML, "//websphere/server/ports/@mqEndpoint")))
		# SIB_MQ_ENDPOINT_SECURE_ADDRESS
		base.portProcessor(serverName, nodeName, host, "SIB_MQ_ENDPOINT_SECURE_ADDRESS", (Xparser.xFind(serverXML, "//websphere/server/ports/@mqEndpointSec")))
		# ORB_LISTENER_ADDRESS
		base.portProcessor(serverName, nodeName, host, "ORB_LISTENER_ADDRESS", (Xparser.xFind(serverXML, "//websphere/server/ports/@orb")))
		# IPC_CONNECTOR_ADDRESS
		base.portProcessor(serverName, nodeName, host, "IPC_CONNECTOR_ADDRESS", (Xparser.xFind(serverXML, "//websphere/server/ports/@ipcPort")))
		# OVERLAY_TCP_LISTENER_ADDRESS
		overlay_tcp = Xparser.xFind(serverXML, "//websphere/server/ports/@overlayTCP")
		if (  overlay_tcp != ""):	
			base.portProcessor(serverName, nodeName, host, "OVERLAY_TCP_LISTENER_ADDRESS", (Xparser.xFind(serverXML, "//websphere/server/ports/@overlayTCP")))
		#endif
		# OVERLAY_UDP_LISTENER_ADDRESS
		overlay_udp = Xparser.xFind(serverXML, "//websphere/server/ports/@overlayUDP")
		if (  overlay_udp != ""):	
			base.portProcessor(serverName, nodeName, host, "OVERLAY_UDP_LISTENER_ADDRESS", (Xparser.xFind(serverXML, "//websphere/server/ports/@overlayUDP")))
		#endif
		#--------------------------------------------------------------
		#     -- save the configuration
		#--------------------------------------------------------------
		AdminConfig.save()
		print "end: update ports" 
        
def createInstance(serverXML, nodeName, serverName):

		# ********************** variables ************************ # 
	cellName = AdminControl.getCell()
	cellId = AdminConfig.getid('/Cell:'+cellName+'/')
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	nodeId = AdminConfig.getid('/Node:'+nodeName+'/')
	clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
	portsConfigure = Xparser.xFind(serverXML, "//websphere/server/ports/@configure")
	# ********************** variables ************************ # 
	   
	if ((len(clusterName) > 0)): 
		print "-> creating server: " +serverName + " as part of cluster: " + clusterName        
		clusterExists = AdminConfig.getid("/ServerCluster:"+clusterName+"/")
			#print "clusterExists :", clusterExists
		print (len(clusterExists)) 
		if ((len(clusterExists)) == 0):
			print "-> cluster " +clusterName+ " does not exist creating and adding cluster member " + serverName                 	
			#create cluster 
			print "-> creating cluster"
			AdminConfig.create('ServerCluster', cellId, '[[name '+clusterName+']]') 
			AdminConfig.save()
			time.sleep(15)
			print "-> cluster " +clusterName+ " created"
			#add member to cluster
			print "-> adding " +serverName+ " to " +clusterName
			clusterId = AdminConfig.getid('/ServerCluster:'+clusterName+'/')  
			#AdminConfig.createClusterMember(clusterId, nodeId, '[[memberName '+serverName+']]')
			if ( portsConfigure == "false"):
				print "--> ports configure set to false ... generating unique ports "
				AdminTask.createClusterMember('[-clusterName '+clusterName+' -memberConfig [-memberNode '+nodeName+' -memberName '+serverName+' -memberWeight 2 -genUniquePorts true -replicatorEntry false] -firstMember [-templateName default ]]')
				print "-> "+serverName+ " successfully added to " +clusterName
				AdminConfig.save()
			else:
				print "--> ports configure set to true ... custom ports will be configured"
				AdminTask.createClusterMember('[-clusterName '+clusterName+' -memberConfig [-memberNode '+nodeName+' -memberName '+serverName+' -memberWeight 2 -genUniquePorts false -replicatorEntry false] -firstMember [-templateName default ]]')
				print "-> "+serverName+ " successfully added to " +clusterName
				AdminConfig.save()
				time.sleep(15)
		else:
			#add member to cluster
			print "--> cluster exists: "
			print "--> adding server " +serverName+ " to cluster " +clusterName
			
			clusterId = AdminConfig.getid('/ServerCluster:'+clusterName+'/')
			clusterList = AdminConfig.list('ClusterMember', clusterId)
			#print "cluster list: ", clusterList
			
			if ((len(clusterList)) == 0):
				print "no members defined re-creating cluster to resolve template issue"
				AdminConfig.remove(clusterId)
				AdminConfig.save()
				time.sleep(15)
				AdminConfig.create('ServerCluster', cellId, '[[name '+clusterName+']]')
				AdminTask.createClusterMember('[-clusterName '+clusterName+' -memberConfig [-memberNode '+nodeName+' -memberName '+serverName+' -memberWeight 2 -genUniquePorts false -replicatorEntry false] -firstMember [-templateName default ]]')
				AdminConfig.save()
				time.sleep(15)
			serverExists = AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'/')
			if ((len(serverExists)) == 0):
				clusterId = AdminConfig.getid('/ServerCluster:'+clusterName+'/')
				#print "nodeId: ", nodeId	
				AdminConfig.createClusterMember(clusterId, nodeId, '[[memberName '+serverName+']]')
				#AdminTask.createClusterMember('[-clusterName '+clusterName+' -memberConfig [-memberNode '+nodeName+' -memberName '+serverName+' -memberWeight 2 -genUniquePorts false -replicatorEntry false] -firstMember [-templateName default ]]')
				#AdminTask.createClusterMember('[-clusterName '+clusterName+' -memberConfig [-memberNode '+nodeName+' -memberName '+serverName+']]')
				print "-> "+serverName+ " successfully added to " +clusterName
				AdminConfig.save()
			else:
				
				print "--> server exists removing server " +serverName  
				AdminConfig.remove(serverExists)
				AdminConfig.save()
				clusterList = AdminConfig.list('ClusterMember', clusterId).split(java.lang.System.getProperty('line.separator'))
				#print "cluster list: ", clusterList
				
				print "--> re-adding to cluster:" +serverName 
				clusterId = AdminConfig.getid('/ServerCluster:'+clusterName+'/')
				#print "nodeId: ", nodeId	
				AdminConfig.createClusterMember(clusterId, nodeId, '[[memberName '+serverName+']]')
				print "-> "+serverName+ " successfully added to " +clusterName
				AdminConfig.save()
	else:
		print "-> creating server: " +serverName
		serverExists =  AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'')
		
		if ((len(serverExists)) == 0):
				print "-> server " +serverName+ " does not exist creating ..."
				# TODO - create server                  	
		else:
			print "-> server " +serverName+ " exists skipping create task... "

#********************************************************
# server build launch point 
#********************************************************
def build(serverXML, nodeName, serverName):
	     
	# ********************** variables ************************ # 	
	cellName = AdminControl.getCell()
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
	#clusterLen = (len(clusterName))
	# ********************** end variables ********************* #  
	print "-> -----------------------------------"
	print "-> build specs:"
	print "-> -----------------------------------"
	print "-> server name: ", serverName
	print "-> target node: ", nodeName
	if ((len(clusterName)) > 0):
		print "-> target cluster: ", clusterName
		print "-> ------------------------------------"
		print " "
		print "-> ------------------------------------"
		print "-> starting: create instance"
		print "-> ------------------------------------"
		createInstance(serverXML, nodeName, serverName)
		print "-> ------------------------------------"
		print "-> starting: update ports"
		print "-> ------------------------------------"
		updatePorts(serverXML, nodeName, serverName)
		print "-> ------------------------------------"
		print "-> starting: web container port"
		print "-> ------------------------------------"
		updateWcPorts(serverXML, nodeName, serverName)
		print "-> ------------------------------------"
		print "-> starting: update jvm heap"
		print "-> ------------------------------------"
	print "-> configuring app server"
	updateHeap(serverXML, nodeName, serverName)
	print "-> ------------------------------------"
	print "-> starting: update generic jvm args"
	print "-> ------------------------------------"
	updateGenJvmArgs(serverXML, nodeName, serverName)
	print "-> ------------------------------------"
	print "-> starting: update jvm custom props"
	print "-> ------------------------------------"
	updateJvmCustomProps(serverXML, nodeName, serverName)
        print "-> starting: create jvm environment entries"
        print "-> ------------------------------------"
        #createJvmEnvEntries(serverXML, nodeName, serverName)
        print "-> starting: create nodeagent environment entries"
        print "-> ------------------------------------"
        #createNodeagentEnvEntries(serverXML, nodeName, serverName)
        print "-> starting: create dmgr environment entries"
        print "-> ------------------------------------"
        createHTTPInboundChannel(serverXML, nodeName, serverName)
        print "-> starting: creating HTTP_2 Inbound Custome Properties"
        print "-> ------------------------------------"
        #createDmgrEnvEntries(serverXML, nodeName, serverName)
	print "-> ------------------------------------"
	print "-> starting: update jvm boot classpath"
	print "-> ------------------------------------"
	updateClassPath(serverXML, nodeName, serverName)
	print "-> ------------------------------------"
	print "-> starting: update classpath"
	print "-> ------------------------------------"
	updateBootClassPath(serverXML, nodeName, serverName)
	print "-> ------------------------------------"
	print "-> starting: update boot classpath"
	print "-> ------------------------------------"
	updateVerboseGC(serverXML, nodeName, serverName)       
	print "-> ------------------------------------"
	print "-> starting: update web container"
	print "-> ------------------------------------"
	updateWebContainer(serverXML, nodeName, serverName)
	print "-> starting : update orb service" 
	print "-> --------------------------------"
	updateObjectRequestBroker(serverXML, nodeName, serverName)
	print "-> ------------------------------------"
	print "-> starting: update server thread pool"
	print "-> ------------------------------------"
	updateThreadPools(serverXML, nodeName, serverName)
	print "-> ------------------------------------"
	print "-> starting: updating JVM Logrotation"
	print "-> ------------------------------------"
	updateJvmLogrotation(serverXML, nodeName, serverName)
	print "-> ------------------------------------"
	print "-> starting: update Monitoring Policy"
	print "-> ------------------------------------"
	updateMonitoringPolicy(serverXML, nodeName, serverName)
	print "-> starting: create Java Auth Alias"
	print "-> ------------------------------------"
	security.configureJAAS(serverXML, "createJAAS", AdminConfig, AdminControl)
	print "-> ------------------------------------"
	print "-> starting: create environment variables"
	print "-> ------------------------------------"
	environment.createWasVariables(serverXML, AdminConfig, AdminControl, nodeName, serverName)
	print "-> ------------------------------------"
	print "-> starting: create name space bindings"
	print "-> ------------------------------------"
	environment.nameSpaceBindings(serverXML, AdminConfig, AdminControl, nodeName, serverName)
	print "-> ------------------------------------"
	print "-> starting: create jdbc providers"
	print "-> ------------------------------------"
	resources.createJdbcProvider(serverXML, AdminConfig, AdminControl, nodeName, serverName)
	print "-> ------------------------------------"
	print "-> starting: create datasources"
	print "-> ------------------------------------"
	resources.createDatasource(serverXML, AdminConfig, AdminControl, AdminUtilities, nodeName, serverName)
	print "-> ------------------------------------"
	print "-> starting: create url provider"
	print "-> ------------------------------------"
	resources.createUrlProvider(serverXML, AdminConfig, AdminControl, nodeName, serverName)
	print "-> ------------------------------------"
	print "-> starting: create urls"
	print "-> ------------------------------------"
	resources.createUrls(serverXML, AdminConfig, AdminControl, nodeName, serverName)
	print "-> ------------------------------------"
	print "-> starting: create virtual host"
	print "-> ------------------------------------"
	environment.updateVhost(serverXML, AdminConfig, AdminControl, AdminTask, nodeName, serverName)
	print "-> ------------------------------------"
	print "-> starting: create shared libraries"
	print "-> ------------------------------------"
	environment.sharedLibraries(serverXML, AdminConfig, AdminControl, AdminTask, nodeName, serverName)
	print "-> ------------------------------------"
	print "-> starting: create classloader"
	print "-> ------------------------------------"
	createClassloader(serverXML, nodeName, serverName)
	print "-> ----------------------------------------"
	print "-> starting: create service integration bus"
	print "-> ----------------------------------------"
	sibus.configureSIBus(serverXML, "createSIB", AdminControl, AdminConfig, AdminTask)
	print "-> ------------------------------------"
	print "-> starting: add si bus member"
	print "-> ------------------------------------"
	sibus.configureSIBmembers(serverXML, "addMember", AdminControl, AdminConfig, AdminTask, nodeName, serverName)
	print "-> ------------------------------------"
	print "-> starting: create si bus destination"
	print "-> ------------------------------------"
	sibus.configureSIBDestinations(serverXML, "createDestination", AdminControl, AdminConfig, AdminTask, nodeName, serverName)
	print "-> ------------------------------------"
	print "-> starting: create jms topic"
	print "-> ------------------------------------"
	jms.configureSIBJMS(serverXML, "topics", "create", AdminControl, AdminConfig, AdminTask, nodeName, serverName)
	print "-> ------------------------------------"
	print "-> starting: create jms connection factory"
	print "-> ------------------------------------"
	jms.configureSIBJMS(serverXML, "connectionFactories", "create", AdminControl, AdminConfig, AdminTask, nodeName, serverName)
	print "-> ------------------------------------"
	print "-> starting: create jms activation specification"
	print "-> ------------------------------------"
	jms.configureSIBJMS(serverXML, "activationSpec", "create", AdminControl, AdminConfig, AdminTask, nodeName, serverName)
	print "-> ------------------------------------"
	print "-> starting: create jms queues"
	print "-> ------------------------------------"
	jms.configureSIBJMS(serverXML, "queues", "create", AdminControl, AdminConfig, AdminTask, nodeName, serverName)
	print "-> ------------------------------------"
	mq.createMqQCF(serverXML,AdminConfig,AdminControl, AdminTask, nodeName, serverName)
	#print "-> ------------------------------------"
	#print "--> staring : create security domain"
	#resources.createSecurityDomains(serverXML,AdminConfig, AdminControl, AdminTask)
	#print "-> complete: create instance"

def taskList(serverXML, task, nodeName, serverName):
        if (task == "build"):
        	build(serverXML, nodeName, serverName)
        elif(task == "createInstance"):
        	createInstance(serverXML, nodeName, serverName)
        elif (task == "updateNodePorts"):
        	util.updateNodePorts(serverXML, nodeName, serverName)
        elif (task == "updateDmgrPorts"):
        	util.updateDmgrPorts(serverXML, nodeName, serverName)
        elif (task == "updateWebContainerPorts"):
        	updateWcPorts(serverXML, nodeName, serverName)
        elif (task == "updateWebContainer"):
        	updateWebContainer(serverXML, nodeName, serverName)
        elif (task == "addWebContainerProps"):
            addWebContainerProps(serverXML, nodeName, serverName)
        elif (task == "addJVMCustomProp"):
            addJVMCustomProp(serverXML, nodeName, serverName)
        elif (task == "updateJvmCustomProps"):
            updateJvmCustomProps(serverXML, nodeName, serverName)
        elif (task == "createJvmEnvEntries"):
            createJvmEnvEntries(serverXML, nodeName, serverName)
        elif (task == "createNodeagentEnvEntries"):
            createNodeagentEnvEntries(serverXML, nodeName, serverName)
        elif (task == "createDmgrEnvEntries"):
            createDmgrEnvEntries(serverXML, nodeName, serverName)
	elif (task == "createHTTPInboundChannel"):
            createHTTPInboundChannel(serverXML, nodeName, serverName)
        elif (task == "updateThreadPools"):
        	updateThreadPools(serverXML, nodeName, serverName)
        elif (task == "updateServerPorts"):
        	updatePorts(serverXML, AdminTask, nodeName, serverName)
        elif ( task == "updateHeap"):
        	updateHeap(serverXML, nodeName, serverName)
        elif (task == "updateMonitoringPolicy"):
        	updateMonitoringPolicy(serverXML, nodeName, serverName)
        elif ( task == "updateGenJvmArgs"):
        	updateGenJvmArgs(serverXML, nodeName, serverName)
        elif ( task=="updateJvmLogrotation"):
                updateJvmLogrotation(serverXML, nodeName, serverName)
        elif ( task == "deleteDatasources"):
        	resources.deleteDatasources(serverXML,AdminConfig,AdminControl, nodeName, serverName)
        elif (task == "createJAAS"):
        	security.configureJAAS(serverXML, "createJAAS", AdminConfig, AdminControl)
        elif (task == "updateJAAS"):
        	security.configureJAAS(serverXML, "updateJAAS", AdminConfig, AdminControl)
        elif (task == "deleteJAAS"):
        	security.configureJAAS(serverXML, "deleteJAAS", AdminConfig, AdminControl)
        elif (task == "createJdbcProvider"):
        	resources.createJdbcProvider(serverXML, AdminConfig, AdminControl, nodeName, serverName)
        elif (task == "createDatasource"):
        	resources.createDatasource(serverXML, AdminConfig, AdminControl, AdminTask, nodeName, serverName)
        elif (task == "createUrls"):
        	resources.createUrls(serverXML, AdminConfig, AdminControl, nodeName, serverName)
        elif (task == "createWasVariables"):
        	environment.createWasVariables(serverXML, AdminConfig, AdminControl, nodeName, serverName)
        elif (task == "nameSpaceBindings"):
        	environment.nameSpaceBindings(serverXML, AdminConfig, AdminControl, nodeName, serverName)
        elif (task == "sharedLibraries"):
        	environment.sharedLibraries(serverXML, AdminConfig, AdminControl, AdminTask, nodeName, serverName)
        elif (task == "createSIB"):
        	sibus.configureSIBus(serverXML, "createSIB", AdminControl, AdminConfig, AdminTask)
        elif (task == "addSIBMember"):
        	sibus.configureSIBmembers(serverXML, "addMember", AdminControl, AdminConfig, AdminTask, nodeName, serverName)
        elif (task == "createSIBusDestination"):
        	sibus.configureSIBDestinations(serverXML, "createDestination", AdminControl, AdminConfig, AdminTask, nodeName, serverName)
        elif (task == "configureJmsTopic"):
        	jms.configureSIBJMS(serverXML, "topics", "create", AdminControl, AdminConfig, AdminTask, nodeName, serverName)
        elif (task == "createQCF"):
        	jms.configureSIBJMS(serverXML, "connectionFactories", "create", AdminControl, AdminConfig, AdminTask, nodeName, serverName)
        elif (task == "updateVhost"):
        	environment.updateVhost(serverXML, AdminConfig, AdminControl, AdminTask, nodeName, serverName)
        elif (task == "createClassloader"):
        	createClassloader(serverXML)
        elif (task == "deleteSIB"):
        	sibus.configureSIBus(serverXML, "deleteSIB", AdminControl, AdminConfig, AdminTask)
        elif (task == "removeSIBusMember"):
        	sibus.configureSIBmembers(serverXML, "removeMember", AdminControl, AdminConfig, AdminTask, nodeName, serverName)
        elif (task == "deleteSIBusDestination"):
        	sibus.configureSIBDestinations(serverXML, "deleteDestination", AdminControl, AdminConfig, AdminTask, nodeName, serverName)
        elif (task == "createMqQueues"):
                mq.createMqQueues(serverXML,AdminConfig, AdminControl,AdminTask, nodeName, serverName)
        elif (task == "deleteMqQueue"):
                mq.deleteMqQueue(serverXML,AdminConfig, AdminControl,nodeName, serverName)
        elif (task == "createMqQCF"):
                mq.createMqQCF(serverXML,AdminConfig, AdminControl,AdminTask, nodeName, serverName)
        elif (task == "deleteMqQCF"):
                mq.deleteMqQCF(serverXML,AdminConfig, AdminControl,nodeName, serverName)
        elif (task == "resourceEnvironmentEntries"):
        	resources.resourceEnvironmentEntries(serverXML, AdminConfig, nodeName, serverName)
        elif (task == "resourceEnvironmentProviders"):
        	resources.resourceEnvironmentProviders(serverXML, AdminConfig, nodeName, serverName)
        elif (task == "objectCacheInstances"):
        	resources.objectCacheInstances(serverXML, AdminConfig, AdminTask, nodeName, serverName)
        elif (task == "resourceGeneratePlugin"):
                resources.resourceGeneratePlugin(serverXML, AdminConfig, AdminControl, nodeName, serverName)
        elif (task == "createSecurityDomains"):
                resources.createSecurityDomains(serverXML,AdminConfig, AdminControl, AdminTask)				
        else:
        	print "option: " + task + " not found"
        	usage() 
        
#********************************************************
# script usage: 
#********************************************************

def usage():
	print " "
	print " "
	print " usage: python application.py [environment type] [instance] [option]"
	print " example: python server.py nxsa dev01_nx deploy"
	print " "
	print " current options:"
	print " ----------------"
	print " 1) deploy [steps: stop application, uninstall, install, map modules, map virutal hosts]"
	print " 2) update [steps: stop application, update application]"
	print " 3) uninstall [steps: stop application, uninstall application]"
	print " "
	print " " 
			
#********************************************************
# main: 
#********************************************************
def main():
	print " "
	print " "
	
	# check arguments
	if len(sys.argv) < 4:
		print "not enough args"
		usage()
		sys.exit(1)
	# expected input

	shieldHome = sys.argv[0]
	envType = sys.argv[1]
	instance = sys.argv[2]
	task = sys.argv[3]
		
	print "shield home: ", shieldHome
	print "env type: ", envType
	print "instance: ", instance
	print "task: ", task
	
	print " "
	print " "
	
	# variables
	# need to figure out the xml home xmlHome = /apps/properties
	xmlBasePath = (shieldHome+"/xml/")
	#xmlBasePath = "/apps/profiles/xml/"
	
	#xml path
	serverXML = (xmlBasePath+envType+"/"+instance+".xml")
	serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	xmlNodeConfig = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	nodeName = base.matchNodeVal(xmlNodeConfig)
	taskList(serverXML, task, nodeName, serverName)        

# call main	        
main()
