import sys
import java.io
import Xparser
import XPathCount
import base
import time
import os
from java.lang import Exception


#--------------------------------------------------------------
# initialize global websphere classes
#--------------------------------------------------------------
#base.setAdminRefs((AdminConfig, AdminControl, AdminTask, AdminApp))

def updateLTPACookieName(cellXML):
    LTPACookieName = Xparser.xFind(cellXML, "//websphere/security/global/ltpa/@ltpaCookieName")
    print "LTPACookieName:"+LTPACookieName
    print "updating LTPA Cookie Name with:  "+LTPACookieName
    prop = AdminConfig.getid('/Cell:/Security:/Property:com.ibm.websphere.security.customSSOCookieName/')
    print "prop: "+prop
    AdminConfig.modify(prop, [['value', LTPACookieName]])
    AdminConfig.save()
    print "LTPA Cookie Name has been updated with: "+LTPACookieName
#endDef

def configureLTPACookieName(cellXML):
    LTPACookieName = Xparser.xFind(cellXML, "//websphere/security/global/ltpa/@ltpaCookieName")
    print "LTPACookieName:"+LTPACookieName
    print "Configuring LTPA Cookie Name with:  "+LTPACookieName
    sec = AdminConfig.getid('/Security:/')
    print "security tocken is:  "+sec
    AdminConfig.create('Property', sec, [['name','com.ibm.websphere.security.customSSOCookieName'], ['value', LTPACookieName]])
    AdminConfig.save() 
    print "LTPA Cookie Name has been configured with: "+LTPACookieName

#endDef

def configureSecurity(cellXML):
	#variables
	serverName = Xparser.xFind(cellXML, "//websphere/dmgr/@name")
	nodeName = Xparser.xFind(cellXML, "//websphere/dmgr/@nodeName")
	nodeId = AdminConfig.getid('/Node:'+nodeName+'/')
	host = Xparser.xFind(cellXML, "//websphere/dmgr/@host")
	ldapType = Xparser.xFind(cellXML, "//websphere/security/global/ldap/@type")
	ldapHost = Xparser.xFind(cellXML, "//websphere/security/global/ldap/@hostname")
	ldapPort = Xparser.xFind(cellXML, "//websphere/security/global/ldap/@port")
        ldapsPort = Xparser.xFind(cellXML, "//websphere/security/global/ldap/@sport")
	ldapBaseDN = Xparser.xFind(cellXML, "//websphere/security/global/ldap/@baseDN")
	ldapBindDN = Xparser.xFind(cellXML, "//websphere/security/global/ldap/@bindDN")
	ldapBindPwd = Xparser.xFind(cellXML, "//websphere/security/global/ldap/@bindPassword")
	userRegistryType = Xparser.xFind(cellXML, "//websphere/security/global/ldap/@userRegistryType")
	adminName = Xparser.xFind(cellXML, "//websphere/security/global/ldap/@adminName")
	appSecurityValue = Xparser.xFind(cellXML, "//websphere/security/global/ldap/@appSecurity")
        adminPassword = Xparser.xFind(cellXML, "//websphere/security/global/ldap/@adminpassword")
	if (appSecurityValue == "true"):
		appSecurity = "true"
	else:
		appSecurity = "false"
	#fi

	checkSecurity = AdminTask.isGlobalSecurityEnabled()
	if (checkSecurity == "true"):
		print "Skipped: Global Security is Enabled"
		os._exit(0)
	#fi
	adminRoleCount = XPathCount.getCount(cellXML, "//websphere/security/global/adminroles/*", "")
	#end of variables
	print "Configuring security on Deployment Manager"
	AdminTask.validateLDAPConnection('[-type '+ldapType+' -hostname '+ldapHost+' -port '+ldapPort+' -baseDN '+ldapBaseDN+' -bindDN '+ldapBindDN+' -bindPassword '+ldapBindPwd+' -sslEnabled false ]')
	print "validated LDAP Connection"
	AdminTask.applyWizardSettings('[-secureApps '+appSecurity+' -secureLocalResources false -ignoreCase true -ldapServerType '+ldapType+' -ldapHostName '+ldapHost+' -ldapPort '+ldapPort+' -ldapBaseDN '+ldapBaseDN+' -ldapBindDN '+ldapBindDN+' -ldapBindPassword '+ldapBindPwd+' -userRegistryType '+userRegistryType+' -adminName '+adminName+' -adminPassword '+adminPassword+' ]')
	AdminConfig.save()
	print "Changing security settings"
	AdminTask.configureAdminLDAPUserRegistry('[-userFilter (&(sAMAccountName=%v)(objectClass=user)) -groupFilter (&(cn=%v)(objectClass=group)) -userIdMap user:sAMAccountName -groupIdMap *:cn -groupMemberIdMap memberof:member -certificateFilter  -certificateMapMode EXACT_DN -krbUserFilter (&(krbPrincipalName=%v)(objectclass=ePerson)) -customProperties ["com.ibm.websphere.security.ldap.recursiveSearch=true"] -verifyRegistry false ]')
        print "Changing ldap to ldaps (secured)"
        AdminTask.configureAdminLDAPUserRegistry('[-ldapHost '+ldapHost+' -ldapPort '+ldapsPort+' -ldapServerType '+ldapType+' -baseDN  '+ldapBaseDN+' -bindDN '+ldapBindDN+' -searchTimeout 120 -reuseConnection true -sslEnabled true -sslConfig CellDefaultSSLSettings -autoGenerateServerId true -primaryAdminId '+adminName+' -ignoreCase true -customProperties ["com.ibm.websphere.security.ldap.recursiveSearch=true"] -verifyRegistry false ]')
        print "completed securing ldap"
	AdminConfig.save()
	time.sleep(10)
	print "Mapping Groups to Admin Role"
	
	i =1
	while i < adminRoleCount+1:
		adminRoleNum = ("adminrole"+str(i))
		adminRoleName = Xparser.xFind(cellXML, "//websphere/security/global/adminroles/"+adminRoleNum+"/@name")
		groupCount = XPathCount.getCount(cellXML, "//websphere/security/global/adminroles/"+adminRoleNum+"/*", "")
		j = 1
		while j < groupCount +1:
			groupNum = ("group"+str(j))
			groupCN = Xparser.xFind(cellXML, "//websphere/security/global/adminroles/"+adminRoleNum+"/"+groupNum+"/@CN")
			groupOU = Xparser.xFind(cellXML, "//websphere/security/global/adminroles/"+adminRoleNum+"/"+groupNum+"/@OU")
			print '[-roleName '+adminRoleName+' -accessids ["group:'+ldapHost+':'+ldapsPort+'/CN='+groupCN+','+groupOU+'" ]  -groupids ["'+groupCN+','+groupOU+'@'+ldapHost+':'+ldapsPort+'" ]]'
			AdminTask.mapGroupsToAdminRole('[-roleName '+adminRoleName+' -accessids ["group:'+ldapHost+':'+ldapsPort+'/CN='+groupCN+','+groupOU+'" ]  -groupids ["'+groupCN+','+groupOU+'@'+ldapHost+':'+ldapsPort+'" ]]')
			j = j + 1
		#Endwhile
		i = i + 1
	#EndWhile
	AdminConfig.save()
	print "Finished Mapping Groups to AdminRoles"
	print "Global Security has been enabled"
	print "Synchronizing Nodes"
	dm = AdminControl.queryNames('type=DeploymentManager,*')
	AdminControl.invoke(dm,'multiSync','[false]')
	
	time.sleep(10)
	print " Deployment Manager will be restarted"
        os.system("kill -9 $(ps -ef | grep -v grep | grep java | awk '{print $2}')")
 
#endDef
def sslConfig(cellXML):
        # ********************** variables ************************ # 
	cellName = AdminControl.getCell()
	cellId = AdminConfig.getid('/Cell:'+cellName+'/')
	sslName = Xparser.xFind(cellXML, "//websphere/nodeagent/@nodeName")
	nodeId = AdminConfig.getid('/Node:'+nodeName+'/')
	sslStoreCount = XPathCount.getCount(cellXML, "//websphere/security/ssl/*", "")
        # ********************** variables ************************ # 
	if (sslStoreCount == 0):
		print "Skipped: There is no certificate to import"
		os._exit(0)
	#if
	i =1
	while i < sslStoreCount+1:
		keyStoreNum = ("keyStore"+str(i))
                isport = Xparser.xFind(cellXML, "//websphere/security/ssl/"+keyStoreNum+"/@isport")
                keyStoreName = Xparser.xFind(cellXML, "//websphere/security/ssl/"+keyStoreNum+"/@name")
                certAlias = Xparser.xFind(cellXML, "//websphere/security/ssl/"+keyStoreNum+"/@alias")
                if (isport == "yes"):
			keyStoreName = Xparser.xFind(cellXML, "//websphere/security/ssl/"+keyStoreNum+"/@name")
			remoteHost = Xparser.xFind(cellXML, "//websphere/security/ssl/"+keyStoreNum+"/@host")
			remotePort = Xparser.xFind(cellXML, "//websphere/security/ssl/"+keyStoreNum+"/@port")
			certAlias = Xparser.xFind(cellXML, "//websphere/security/ssl/"+keyStoreNum+"/@alias")
			try:
				AdminTask.retrieveSignerFromPort('[-keyStoreName '+keyStoreName+' -host '+remoteHost+' -port '+remotePort+' -certificateAlias '+certAlias+' ]')
				AdminConfig.save()
			except Exception,msg:
				print msg
                else:
                        try:
                                certName = Xparser.xFind(cellXML, "//websphere/security/ssl/"+keyStoreNum+"/@certname")
                                certAlias = Xparser.xFind(cellXML, "//websphere/security/ssl/"+keyStoreNum+"/@certalias")
                                certPath = Xparser.xFind(cellXML, "//websphere/security/ssl/"+keyStoreNum+"/@certpath") 
                                AdminTask.addSignerCertificate('[-keyStoreName '+keyStoreName+' -keyStoreScope  (cell):'+cellName+' -certificateFilePath '+certPath+' -base64Encoded true -certificateAlias '+certAlias+' ]')
                                AdminConfig.save()
                                print "SSL Certificate  "+certName+" has been added as an alias "+certAlias
                        except Exception,msg:
                                print msg
                #endif
                i = i + 1 

	print "Sucessfully Added Signers"
	print "Synchronizing Nodes"
	dm = AdminControl.queryNames('type=DeploymentManager,*')
	AdminControl.invoke(dm,'multiSync','[false]')
	time.sleep(10)


def restartJVMs():
	print "Restarting Application servers which are already in Started state"
	na = AdminControl.queryNames('type=NodeAgent,*')
	Nodes = na.split('\n')
	noOfNodes = len(Nodes)
	i=0
	while (i < noOfNodes):
		AdminControl.invoke(Nodes[i],'restart','[false true]')
		i = i + 1
#endDef
def update_soaptimeout(cellXML):
	#------variables
	dmgrNodeName = Xparser.xFind(cellXML,"//websphere/dmgr/@nodeName")
	dmgrID = AdminConfig.getid('/Node:'+dmgrNodeName+'/Server:dmgr')
	nodeName =  Xparser.xFind(cellXML,"//websphere/nodeagent/@nodeName")
	nodeagentID = AdminConfig.getid('/Node:'+nodeName+'/Server:nodeagent')
	dmgrsoapCon = AdminConfig.list('SOAPConnector',dmgrID)
	dmgrsoapTimeout = AdminConfig.list('Property',dmgrsoapCon)
	nodesoapCon = AdminConfig.list('SOAPConnector',nodeagentID)
	nodesoapTimeout = AdminConfig.list('Property',nodesoapCon)
	
	print "Updating soap timeout"
	
	soapName = Xparser.xFind(cellXML,"//websphere/soap/@name")
	soapValue = Xparser.xFind(cellXML,"//websphere/soap/@value")
	AdminConfig.modify(dmgrsoapTimeout,'[[name "'+soapName+'"][value "'+soapValue+'"]]')
	AdminConfig.modify(nodesoapTimeout,'[[name "'+soapName+'"][value "'+soapValue+'"]]')
	AdminConfig.save()
	print "Updated soap timeout Please restart DMGR and NodeAgents"
#endDef
def updateADPassword(cellXML):
	scope = Xparser.xFind(cellXML,"//websphere/nameSpace/@scope")
	if (scope == "cluster"):
		
		clusterName = Xparser.xFind(cellXML,"//websphere/nameSpace/@clusterName")
		clusterId = AdminConfig.getid("/ServerCluster:"+clusterName+"/")
		if ((len(clusterId)) > 0):
			nsId = AdminConfig.getid("/ServerCluster:"+clusterName+"/StringNameSpaceBinding:AD_PASSWORD")
			if((len(nsId)) > 0):
				print "Name Space Binding AD_PASSWORD exists"
				AdminConfig.remove(nsId)
				print "Removed existing AD_PASSWORD"
				
			print "Creating Adpassword at "+clusterName+" scope"
			name = Xparser.xFind(cellXML,"//websphere/nameSpace/@name")
			nameInNameSpace = Xparser.xFind(cellXML,"//websphere/nameSpace/@name")
			stringToBind = Xparser.xFind(cellXML,"//websphere/nameSpace/@stringToBind")
			
			AdminConfig.create('StringNameSpaceBinding',clusterId, '[[name "'+name+'"] [nameInNameSpace "'+nameInNameSpace+'"] [stringToBind "'+stringToBind+'"]]')
		AdminConfig.save()
		print "Updated AD_PASSWORD at "+clusterName+" scope"
def configureMailSession(cellXML):
	scope = Xparser.xFind(cellXML,"//websphere/mailSession/scope/@scope")
	if (scope == "cell"):
	   cellName = Xparser.xFind(cellXML,"//websphere/dmgr/@cellName")
	   name = Xparser.xFind(cellXML,"//websphere/mailSession/name/@name")
	   jndi = Xparser.xFind(cellXML,"//websphere/mailSession/jndi/@jndi")
	   host = Xparser.xFind(cellXML,"//websphere/mailSession/host/@host")
	   user = Xparser.xFind(cellXML,"//websphere/mailSession/user/@user")
	   password = Xparser.xFind(cellXML,"//websphere/mailSession/password/@password")
	   description = Xparser.xFind(cellXML,"//websphere/mailSession/description/@desc")
	   AdminConfig.create('MailSession', AdminConfig.getid('/Cell:'+cellName+'/MailProvider:Built-in Mail Provider/'), '[[name "'+name+'"] [debug "false"] [mailStoreUser "'+user+'"] [category ""] [mailTransportHost "'+host+'"] [jndiName "'+jndi+'"] [mailTransportUser "'+user+'"] [mailStorePassword "'+password+'"] [mailStoreHost "'+host+'"] [strict "true"] [description "'+description+'"] [mailTransportPassword "'+password+'"] [mailFrom ""]]')
	   AdminConfig.save()
	   print " Mail Session has been configured"
	   
	else:
	   print "Please set scope to cell"
def certificatesMonitoring(cellXML):
	emailList = Xparser.xFind(CellXML,"//websphere/certificatesMonitoring/emailList/@value")
	frequency = Xparser.xFind(CellXML,"//websphere/certificatesMonitoring/schedule/@frequency")
	day = Xparser.xFind(CellXML,"//websphere/certificatesMonitoring/schedule/@dayOfweek")
	hour = Xparser.xFind(CellXML,"//websphere/certificatesMonitoring/schedule/@hour")
	minute = Xparser.xFind(CellXML,"//websphere/certificatesMonitoring/schedule/@minute")
	threshold = Xparser.xFind(CellXML,"//websphere/certificatesMonitoring/schedule/@threshold")
	AdminTask.modifyWSNotifier ('[-name MessageLog -logToSystemOut true -sendEmail true -emailList '+emailList+']')
	AdminTask.modifyWSSchedule ('[-name ExpirationMonitorSchedule -frequency '+frequency+' -dayOfWeek '+day+' -hour '+hour+' -minute '+minute+' ]')
	AdminTask.modifyWSCertExpMonitor('[-name "Certificate Expiration Monitor" -autoReplace true -deleteOld true -daysBeforeNotification '+threshold+' -isEnabled true -wsScheduleName ExpirationMonitorSchedule -wsNotificationName MessageLog ]')
	AdminConfig.save()
	print "Certificate Expiration Monitor has been setup"
	print "Monitoring occurs every "+frequency+" days "

   

def usage():
	print " "
        print " "
        print " usage: cell.py [environment type] [instance] [option]"
        print " example: python cell.py mlp cellNamexml configure_security"
        print " "
        print " current options:"
        print " ----------------"
        print " "
        print " " 
#endDef
def main():
        
	print " "
	print " "
        
        
        # check arguments
	if len(sys.argv) < 4:
		usage()
		os._exit(1)
        # expected input

	shieldHome = sys.argv[0]
	envType = sys.argv[1]
	instance = sys.argv[2]
	task = sys.argv[3]

	xmlBasePath = (shieldHome+"/xml/")		
        
        #xml path
	cellXML = (xmlBasePath+envType+"/"+instance+".xml")
        

	if (task == "configuresecurity"):
		configureSecurity(cellXML)
	elif (task == "restartJVMs"):
		restartJVMs()
	elif (task == "sslConfig"):
		sslConfig(cellXML)
	elif (task == "update_soaptimeout"):
		update_soaptimeout(cellXML)
	elif (task == "updateADPassword"):
		updateADPassword(cellXML)
	elif (task == "MailSession"):
		configureMailSession(cellXML)
	elif (task == "Cert_Monitor"):
		certificatesMonitoring(cellXML)
        elif (task == "configureLTPACookieName"):
                configureLTPACookieName(cellXML)
        elif (task == "updateLTPACookieName"):
                updateLTPACookieName(cellXML)
	elif (task == "allTasks"):
		print "---------------------------------------"
		updateADPassword(cellXML)
		print "---------------------------------------"
		update_soaptimeout(cellXML)
		print "---------------------------------------"
		sslConfig(cellXML)
		print "---------------------------------------"
		configureSecurity(cellXML)
		print "---------------------------------------"
		configureMailSession(cellXML)
		print "----------------------------------------"
		certificatesMonitoring(cellXML)
	else:
		print "option: " + task + " not found"
		usage() 
# call main
main()   
