#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 02/06/2017 Murry Kane     Initial version
#
#_________________________________________________________________________________________________
#
import os, sys, re
from constants import *

if os.path.isfile('%s/wsadminlib.py' % JYTHON_DIR):
  execfile('%s/wsadminlib.py' % JYTHON_DIR)
else:
  print "Needed library wsadminlib.py NOT Found, exiting!"
  sys.exit(1)

enableDebugMessages()
m="sslUpdateSSLConfigs:"

def usage():
  print "Usage: %s 'Keystore Name', 'Node Default SSL Settings Name', 'default Trust Store Name', 'Server Key Alias', 'Client Key Alias'" % m
  print "Example %s WEBN208Keystore NodeDefaultSSLSettings CellDefaultTrustStore npe-web-dp-ssl.bsc.bscal.com npe-web-dp-ssl.bsc.bscal.com" % m
  
if ( len(sys.argv) != 5):
  usage()
  sys.exit(1)
else:
  keyStoreName = sys.argv[0]
  nodeDefaultName = sys.argv[1]
  defaultTrustStoreName = sys.argv[2]
  serverKeyAlias = sys.argv[3]
  clientKeyAlias = sys.argv[4]

cellName = getCellName()
sop(m,"Keystore Name %s" % keyStoreName)
sop(m,"CellName is %s" % cellName)
sop(m,"Node Default SSL Settings Name is %s" % nodeDefaultName)
sop(m,"Default Trust Store Name is %s" % defaultTrustStoreName)
sop(m,"Server Key Alias is %s" % serverKeyAlias)
sop(m,"Client Key Alias is %s" % clientKeyAlias)

#lets validate we are on a DMGR!
if whatEnv() == 'nd':
  sop(m, "Running on DMGR, coninueing...")
else:
  sop(m, "ERROR: You must run this script on the DMGR!, exiting!")
  sys.exit(2)

sslList=AdminTask.listSSLConfigs('[-all true -displayObjectName false ]').splitlines()
for row in sslList:
  values = re.split('\s+', row)
  name = values[1]
  scope = values[3]
  if name == nodeDefaultName:
    sop(m,"Updating this SSL config %s" % name)
    #AdminTask.modifySSLConfig('[-alias NodeDefaultSSLSettings -scopeName (cell):WEBN208Cell:(node):WEBN208ContentNode01 -keyStoreName WEBN208Keystore -keyStoreScopeName (cell):WEBN208Cell -trustStoreName CellDefaultTrustStore -trustStoreScopeName (cell):WEBN208Cell -serverKeyAlias npe-web-dp-ssl.bsc.bscal.com -clientKeyAlias npe-web-dp-ssl.bsc.bscal.com ]')
    #AdminTask.modifySSLConfig('[-alias %s -scopeName %s -keyStoreName %s -keyStoreScopeName (cell):WEBN208Cell -trustStoreName CellDefaultTrustStore -trustStoreScopeName (cell):WEBN208Cell -serverKeyAlias npe-web-dp-ssl.bsc.bscal.com -clientKeyAlias npe-web-dp-ssl.bsc.bscal.com ]' % (name, scope, keystore))
    #AdminTask.modifySSLConfig('[-alias %s -scopeName %s -keyStoreName %s -keyStoreScopeName (cell):WEBN208Cell -trustStoreName CellDefaultTrustStore -trustStoreScopeName (cell):WEBN208Cell -serverKeyAlias default -clientKeyAlias default ]' % (name, scope,keystore))
    AdminTask.modifySSLConfig('[-alias %s -scopeName %s -keyStoreName %s -keyStoreScopeName (cell):%s -trustStoreName %s -trustStoreScopeName (cell):%s -serverKeyAlias %s -clientKeyAlias %s ]' % (name, scope,keyStoreName, cellName, defaultTrustStoreName, cellName, serverKeyAlias, clientKeyAlias))
    #AdminTask.listSSLConfigs('[-all true -displayObjectName true ]')
    AdminConfig.save()
    sop(m,"Success")
  else:
    sop(m,"Skipping this SSL config %s" % name)
  
saveAndSync()

