#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 03/29/2019 Murry Kane     Initial version
#
#_________________________________________________________________________________________________
#
import os, sys
from constants import *

if os.path.isfile('%s/wsadminlib.py' % JYTHON_DIR):
  execfile('%s/wsadminlib.py' % JYTHON_DIR)
else:
  print "Needed library wsadminlib.py NOT Found, exiting!"
  sys.exit(1)

enableDebugMessages()
m="startCluster:"

def usage():
  print "Usage: %s 'String of Exclude Nodes' 'Cluster Name to manage'" % m
  print "Example %s WEBP02EPresentBatch02/WEBP02ESS01 GPS" % m

  
if ( len(sys.argv) != 2):
  usage()
  sys.exit(1)
else:
  ignoreNodeList = sys.argv[0]
  clusterName = sys.argv[1]

ignorelist = ignoreNodeList.split("/")
sop(m,"Ignore NODE List is %s" % ignorelist)

#lets validate we are on a DMGR!
if whatEnv() == 'nd':
  sop(m, "Running on DMGR, continueing...")
else:
  sop(m, "ERROR: You must run this script on the DMGR!, exiting!")
  sys.exit(2)

#stopAllServerClustersNoWait(ignorelist)
startClusterNoWait(clusterName)
