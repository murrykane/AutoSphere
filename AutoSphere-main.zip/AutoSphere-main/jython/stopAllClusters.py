#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 02/06/2017 Murry Kane     Initial version
#
#_________________________________________________________________________________________________
#
import os, sys
from constants import *

if os.path.isfile('%s/wsadminlib.py' % JYTHON_DIR):
  execfile('%s/wsadminlib.py' % JYTHON_DIR)
else:
  print "Needed library wsadminlib.py NOT Found, exiting!"
  sys.exit(1)

enableDebugMessages()
m="stopClusters:"

def usage():
  print "Usage: %s 'String of Exclude Nodes'" % m
  print "Example %s 'WEBP02EPresentBatch02/WEBP02ESS01'" % m
  
if ( len(sys.argv) != 1):
  usage()
  sys.exit(1)
else:
  ignoreNodeList = sys.argv[0]

ignorelist = ignoreNodeList.split("/")
sop(m,"Ignore NODE List is %s" % ignorelist)

#lets validate we are on a DMGR!
if whatEnv() == 'nd':
  sop(m, "Running on DMGR, continueing...")
else:
  sop(m, "ERROR: You must run this script on the DMGR!, exiting!")
  sys.exit(2)

stopAllServerClustersNoWait(ignorelist)
