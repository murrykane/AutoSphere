import sys
import java.io
import Xparser
import XPathCount
import base

#********************************************************
# create Virutal Host
#********************************************************
def updateVhost(serverXML, AdminConfig, AdminControl, AdminTask, nodeName, serverName):

          # ********************** variables ************************ # 	
		cellName = AdminControl.getCell()
		#serverName = (Xparser.xFind(serverXML, "//websphere/server/@name"))
		#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
		clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
		
		vhostsCount = XPathCount.getCount(serverXML, "//websphere/server/environment/vhosts/*", "")
		i = 1
		while (i < vhostsCount + 1 ):
			vhostsNum = ("vhost"+str(i))
			
			vName = Xparser.xFind(serverXML, "//websphere/server/environment/vhosts/"+vhostsNum+"/@name")
			port = Xparser.xFind(serverXML, "//websphere/server/environment/vhosts/"+vhostsNum+"/@port")
			host = Xparser.xFind(serverXML, "//websphere/server/environment/vhosts/"+vhostsNum+"/@host")
			vHostExist = len(AdminConfig.getid('/VirtualHost:'+vName+'/'))
			#print "vHostExist: ", vHostExist
			# TODO - work on the modification logic for an existing virtual host
			if ( vHostExist > 0 ):
				print 'virtual host %s found ... ' % ( vName )
				print 'checking for matching host alias'
				virtual_host = AdminConfig.getid( '/VirtualHost:'+vName+'/' )
				match="false"
				hostAliaslist = AdminConfig.list('HostAlias',AdminConfig.getid('/VirtualHost:'+vName+'/')).splitlines()
				for alias in hostAliaslist:
					hostname = AdminConfig.showAttribute(alias,'hostname')
					portnum = AdminConfig.showAttribute(alias,'port')
					if ( host == hostname and port == portnum):
						print "Host alias already exists"
						match = "true"
						i = i + 1
						continue
				if ( match == "false"):
					print "--> creating host alias: ", host+ ":" +port
					AdminConfig.create( 'HostAlias', virtual_host, [['hostname', host], ['port', port]] )
					AdminConfig.save()
					i=i+1
				#virtual_host = AdminConfig.getid( '/VirtualHost:'+vName+'/' )
				#AdminConfig.modify( virtual_host, ['HostAlias', ['hostname', host], ['port', port]] )
				#AdminConfig.save()
			else:
				print "--> creating virtual host: ", vName
				cell = AdminConfig.getid('/Cell:'+cellName+'/')
				vtempl = AdminConfig.listTemplates('VirtualHost', 'default_host')
				AdminConfig.createUsingTemplate('VirtualHost', cell, [['name', vName]], vtempl)
				print "--> creating host alias: ", host+ ":" +port
				virtual_host = AdminConfig.getid( '/VirtualHost:'+vName+'/' )
				AdminConfig.create( 'HostAlias', virtual_host, [['hostname', host], ['port', port]] )
				AdminConfig.save()
				i = i+1
	        
#********************************************************
# create websphere variables
#********************************************************
def createWasVariables(serverXML, AdminConfig, AdminControl, nodeName, serverName):


        #check if required configuration
		configure = Xparser.xFind(serverXML, "//websphere/server/environment/websphereVariables/@configure")
		if (configure == "false"):
			print "--> configure set to false ... skipping"
			return 0


        # ********************** variables ************************ # 	
		cellName = AdminControl.getCell()
		#serverName = (Xparser.xFind(serverXML, "//websphere/server/@name"))
		#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
		clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
		wasVariableCount = XPathCount.getCount(serverXML, "//websphere/server/environment/websphereVariables/*", "")
        
		i = 1
		wasVariable = ""
		while i < wasVariableCount+1:
	        
			varNum = ("wasVariable"+str(i))
			scope = Xparser.xFind(serverXML, "//websphere/server/environment/websphereVariables/"+varNum+"/@scope")

	        # get scope - TODO create base lib to do this
			if (scope == "server"):
				scope = 'Node:'+nodeName+'/Server:'+serverName+'' 	
			if (scope == "node"):
				scope = 'Cell:'+cellName+'/Node:'+nodeName+''
			if (scope == "cell"):
				scope = 'Cell:'+cellName+''
			if (scope == "cluster"):
				scope = 'Cell:'+cellName+'/ServerCluster:'+clusterName+''
		         
			# set attributes
			varValue = Xparser.xFind(serverXML, "//websphere/server/environment/websphereVariables/"+varNum+"/@value")
			varName = Xparser.xFind(serverXML, "//websphere/server/environment/websphereVariables/"+varNum+"/@name")
                
			currScope = AdminConfig.getid('/'+scope+'/')
			
			varSubstitutions = AdminConfig.list("VariableSubstitutionEntry",currScope).splitlines()
			
			varSubLen = len(varSubstitutions)
			
			if (varSubLen > 0):
				updateComplete="false"
				for varSubst in varSubstitutions:
					getVarName = AdminConfig.showAttribute(varSubst, "symbolicName")
					if (getVarName == varName):
						print "--> deleting existing: ", varName+ " = ", varValue  
						AdminConfig.remove(varSubst)
						AdminConfig.save()
			print "--> creating: ", varName+ " = ", varValue
			vmap = AdminConfig.getid('/'+scope+'/VariableMap:/')
			AdminConfig.create('VariableSubstitutionEntry', vmap, [['symbolicName', varName], ['value', varValue]])
			AdminConfig.save()
			i = i+1

		print "-> ------------------------------------"
		print "-> complete: create environment variables"
		print "-> ------------------------------------"				 

#********************************************************
# create name space bindings
#********************************************************
def nameSpaceBindings(serverXML, AdminConfig, AdminControl, nodeName, serverName):
	
        #check if required configuration
        configure = Xparser.xFind(serverXML, "//websphere/server/environment/nameSpaceBindings/@configure")
	if (configure == "false"):
		print "--> configure set to false ... skipping"
		return 0	


        # ********************** variables ************************ # 	
	cellName = AdminControl.getCell()
        #serverName = (Xparser.xFind(serverXML, "//websphere/server/@name"))
        #nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
        clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
        nsStringCount = XPathCount.getCount(serverXML, "//websphere/server/environment/nameSpaceBindings/string/*", "")
        
        # NOTE: set up for sting binding - EJB, CORBA and indirect - should be added as required 
        i = 1
	nsStringVariable = ""
	while i < nsStringCount+1:
	        
	        nsStringNum = ("string"+str(i))
		scope = Xparser.xFind(serverXML, "//websphere/server/environment/nameSpaceBindings/string/"+nsStringNum+"/@scope")
	        
	        
	        # get scope - TODO create base lib to do this
	        if (scope == "server"):
	        	currScope = AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'')
	        	scope = 'Node:'+nodeName+'/Server:'+serverName+'' 	
 		if (scope == "node"):
	        	currScope = AdminConfig.getid('/Cell:'+cellName+'/Node:'+nodeName+'')
	        	scope = 'Cell:'+cellName+'/Node:'+nodeName+''
 		if (scope == "cell"):
 			 currScope = AdminConfig.getid('/Cell:'+cellName+'')
 			 scope = 'Cell:'+cellName+''
		if (scope == "cluster"):
		         currScope = AdminConfig.getid('/Cell:'+cellName+'/ServerCluster:'+clusterName+'')
		         scope = 'Cell:'+cellName+'/ServerCluster:'+clusterName+''
		        
		# set attributes
		bindingIdentifier = Xparser.xFind(serverXML, "//websphere/server/environment/nameSpaceBindings/string/"+nsStringNum+"/@bindingIdentifier")
		nameInNameSpace = Xparser.xFind(serverXML, "//websphere/server/environment/nameSpaceBindings/string/"+nsStringNum+"/@nameInNameSpace")
		string = Xparser.xFind(serverXML, "//websphere/server/environment/nameSpaceBindings/string/"+nsStringNum+"/@string")
		
		#check if binding identifier exists - if exists remove the reference
		bindings = AdminConfig.getid('/'+scope+'/NameSpaceBinding:/').splitlines()
		print "bindings: ", bindings
		for binding in bindings:
                	stringIdentifier = AdminConfig.showAttribute(binding, "name")
		        if (stringIdentifier == bindingIdentifier):
		        	print "--> found " +bindingIdentifier+ " configured"
		        	print "--> removing ", bindingIdentifier
		        	AdminConfig.remove(binding)
		        	AdminConfig.save()
		
		print "--> -----------------------------------"
		print "--> string binding: #", i
		print "--> -----------------------------------"
		print "--> bindingIdentifier: ", bindingIdentifier
		print "--> nameInNameSpace: ", nameInNameSpace
		print "--> string: ", string
		print "--> -----------------------------------"
		                
                AdminConfig.create('StringNameSpaceBinding', currScope, [['name', bindingIdentifier], ['nameInNameSpace', nameInNameSpace], ['stringToBind', string]])                                     
                AdminConfig.save()
                i = i+1
	                 
	    	print "-> ------------------------------------"
	    	print "-> complete: create name space bindings"
	    	print "-> ------------------------------------"


def setInstanceExtProps(key, value, currScope):
	attrs = ["['name' '"+key+"'] ['nameInNameSpace' '"+key+"'] ['stringToBind' ["+value+"]]"]
        print "attrs: ", attrs  	
	#Find Configuration Object
	print"--> in setInstanceExtProps method"
	print"--> current scope: ", currScope
	scopeId = AdminConfig.getid('/Cell:'+cellName+'/ServerCluster:'+clusterName+'')
	#cfgObj = AdminConfig.getid(+currScope+"StringNameSpaceBinding:" + key + "/")
	#print "cfgObj: ", cfgObj 	
	#if cfgObj:
	#	AdminConfig.modify(cfgObj, attrs)
		#AdminConfig.save()
	#	print "Namespace binding updated/modified: " + cfgObj
	#else:
	cfgObj = AdminConfig.create("StringNameSpaceBinding", scopeId, attrs)
		#AdminConfig.save()
	print "Namespace binding created: " + cfgObj			
			
			
#********************************************************
# create external properties in name space bindings
#  - property file based used for external property updates
#********************************************************
def configureExtProperties(propertyFile, nodeName, serverName):
	print "in the configureExtProperties method -"
	cellName = AdminControl.getCell()
	#currScope = AdminConfig.getid('/Cell:'+cellName+'/ServerCluster:'+clusterName+'')
	#currScope = '/Cell:'+cellName+'/ServerCluster:'+clusterName+'/'
	currScope = '/Cell:'+cellName+'/Node:'+nodeName+'/Server:'+serverName+'/'
	props = util.Properties()

	# check existance of property file
	#if path.exists(propertyFile)
	loadProp = props.load(javaio.FileInputStream(propertyFile))
	#else:
		#print "property file is not found: ", propertyFile
		#print "exiting ..."
		#sys.exit(0)
	
	#configures namespace binding...
	for key in props.keySet().iterator():
		value = props.getProperty(key)
		setInstanceExtProps(key, value, currScope)

	AdminConfig.save()

#********************************************************
# create shared libraries
#********************************************************
def sharedLibraries(serverXML, AdminConfig, AdminControl, AdminTask, nodeName, serverName):

        #check if required configuration
	configure = Xparser.xFind(serverXML, "//websphere/server/environment/sharedLibraries/@configure")
	if (configure == "false"):
		print "--> configure set to false ... skipping"
		return 0	



        # ********************** variables ************************ # 	
	cellName = AdminControl.getCell()
	#serverName = Xparser.xFind(serverXML, "//websphere/server/@name")
	#nodeName = Xparser.xFind(serverXML, "//websphere/nodeagent/@nodeName")
	clusterName = Xparser.xFind(serverXML, "//websphere/server/@clusterName")
	slStringCount = XPathCount.getCount(serverXML, "//websphere/server/environment/sharedLibraries/*", "")
	
	i = 1
	slStringVariable = ""
	while i < slStringCount+1:
		
		slStringNum = ("lib"+str(i))
		scope = Xparser.xFind(serverXML, "//websphere/server/environment/sharedLibraries/"+slStringNum+"/@scope")
		
		# get scope - TODO create base lib to do this
		if (scope == "server"):
			currScope = AdminConfig.getid('/Node:'+nodeName+'/Server:'+serverName+'')
			scope = 'Node:'+nodeName+'/Server:'+serverName+'' 	
	 	if (scope == "node"):
			currScope = AdminConfig.getid('/Cell:'+cellName+'/Node:'+nodeName+'')
			scope = 'Cell:'+cellName+'/Node:'+nodeName+''
	 	if (scope == "cell"):
	 		currScope = AdminConfig.getid('/Cell:'+cellName+'')
	 		scope = 'Cell:'+cellName+''
		if (scope == "cluster"):
			currScope = AdminConfig.getid('/Cell:'+cellName+'/ServerCluster:'+clusterName+'')
			scope = 'Cell:'+cellName+'/ServerCluster:'+clusterName+''
			
		# set attributes
		name = Xparser.xFind(serverXML, "//websphere/server/environment/sharedLibraries/"+slStringNum+"/@name")
		classpath = Xparser.xFind(serverXML, "//websphere/server/environment/sharedLibraries/"+slStringNum+"/@classpath")
		isolatedClassLoader = Xparser.xFind(serverXML, "//websphere/server/environment/sharedLibraries/"+slStringNum+"/@isolatedClassLoader")

		if (isolatedClassLoader != "true"):
			isolatedClassLoader = "false"
			print isolatedClassLoader
		#endif
		print isolatedClassLoader
			
		#check if binding identifier exists - if exists remove the reference
		shared_libs = AdminConfig.getid('/'+scope+'/Library:/').splitlines()
		shared_libExists = "false"
		print "shared_libs : ", shared_libs
		for lib in shared_libs:
			stringIdentifier = AdminConfig.showAttribute(lib, "name")
			if (stringIdentifier == name):
				print "--> found " +name+ " configured"
				shared_libExists = "true"
				print "--> modifying class path", name
				#AdminConfig.remove(lib)
				AdminConfig.modify( lib,[[ 'name' , name],[ 'classPath', classpath], [ 'isolatedClassLoader', isolatedClassLoader]]) 
			
				AdminConfig.save()
			
		if (shared_libExists == "true" ):
			i = i+1
			continue
		print "--> -----------------------------------"
		print "--> Shared Library: #", i
		print "--> -----------------------------------"
		print "--> name: ", name
		print "--> classpath: ", classpath
		print "--> -----------------------------------"
			
		c1 = AdminConfig.getid('/'+scope+'/')
		AdminConfig.create('Library', c1, [['name', name], ['classPath', classpath], [ 'isolatedClassLoader', isolatedClassLoader]])
		
		i = i+1
		AdminConfig.save() 
    	print "-> ------------------------------------"
    	print "-> complete: create shared libraries   "
    	print "-> ------------------------------------"

