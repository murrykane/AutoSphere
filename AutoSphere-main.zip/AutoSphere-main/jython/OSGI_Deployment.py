# =============================================
# Role: To manage OSGI Extiension ------
# Author: Chellaturai, Sathish
#         Jeffrey Apiado
# Version: V0.15
# ===============================================================================================================================
# Modified:
#         9/60/2020    -  code refactoring [Jeffrey] [v0.1]
#         12/23/2020   -  changes to accept cba files without underscore in filename [Jeffrey]
#         1/4/2021     -  add function to remove local internal repository handler [Jeffrey]
#         1/11/2021    -  script was modified to removed old bunlde repo after upgrade [Jeffrey]
#         1/25/2021    -  code refactoring for version 1.1 [Jeffrey]
#         2/18/2021    -  revert changes defined cbaname and cbaversion in /opt/jenkins![Jeffrey]
#         2/19/2021    -  changes removeOSGiExtensions call to removeOSGiExtension without 's' [Jeffrey]
#         3/17/2021    -  empty_osgiext_box function created to ensure removal of any old OSGi extension [Jeffrey]
#         4/7/2021     -  removed old entry in the internal Bundle Local repository [Jeffrey]
#         4/8/2021     -  removed cba package from the list of osgi extension [Jeffrey]
#         5/12/2021    -  validate script functionality [passed] [Jeffrey]
#         9/22/2021    -  SyncNode function was added [Jeffrey]
#         9/13/202     -  change sys.exit(1) to sys.exit(0) this will ensure it wont fail the whole deployment
#         9/21/2021    -  bail out when OSGI file or OSGI extension already EXISTS [JEFFREY]
#         9/29/2021    -  SystemExit(0) moved to main function
#         10/11/2021   -  change sys.exit(0) to java Runtime exit (works in preventing the whole system shutdown)
#         10/13/2021   -  'except Excemption as e:' expression was resplace by 'except:' and 'sys.exc_info()[1]' to catch error!
# ========================================================================================= ======================================

import os, sys, glob, re, time
from com.ibm.ws.scripting import ScriptingException
from java.lang import Runtime

def main():
  print "[osgi script] version 0.15 ========== "
  print "Local Repository Bundle - OSGI EXTENSIONS ----------- Environment start"
  afile = list_Newfile()
  (symbolic, cbaversion) = arrange_variables(afile)
  print "=============== ADD OSGI cba file from /opt/jenkins  =============" 
  add_Osgi_file(afile)
  (blame, cuname) = bla_variables()
  print 'BLA_ID: %s' % blame
  print 'CuName: %s' % cuname
  # FUNCTION: 'empty_osgiext_box' can be removed in the future if requirement change(specific removal of osgi extension) 
  oldos = empty_osgiext_box(cuname) 
  add_osgi_extension(cuname, cbaversion, symbolic)
  old_entry = remove_deployversion_fromList(symbolic, cbaversion, oldos)
  editCompUnit(cuname, blame, symbolic) 
  print "??? old file to removed: ",old_entry
  internalLocalRepo_CleanUP(old_entry)
  syncNode()
  print " =================== End of Line =============================="

def syncNode():
    print '--> node synchronization initiated'
    allserv = AdminConfig.list('Server').splitlines()
    _filter = [n.split('nodes/')[1] for n in allserv if re.search('nodeagent',n)]
    _nodes = [n.split('/',1)[0] for n in _filter]
    if _nodes:
       for nodename in _nodes:
           if re.search('WebNode', nodename):
              continue
           else:
             print '--> sync: %s to dmgr' % nodename
             ncall = 'type=NodeSync,process=nodeagent,node=%s,*' % nodename
             Sync1 = AdminControl.completeObjectName(ncall)
             print '--> mbeanObject: created and start sync!'
             try:
               cc = AdminControl.invoke(Sync1, 'sync')
               print "--> is Sync: %s" % cc
             except:
               err = str(sys.exc_info())
               print "--> ERROR: %s" % err
       print "--> done"    
   

def list_Newfile():
  print 'Fetch the latest *.cba file in ----> /opt/jenkins/'
  path = '/opt/jenkins/'
  item = glob.glob("%s/*.cba" % path)
  if item:
     item.sort(key=os.path.getmtime)
     if len(item) > 0:
       realpath = item[-1]
     else:
       realpath = item[0]
     print("cbaFile_path found: %s" % realpath)
     return realpath
  else:
     print '<ERROR> No file with .cba extension found in /opt/jenkins folder -- [ MISSING FILE ]'
     sys.exit(1)

def arrange_variables(rfile):
  if re.search('_', rfile):
     symbolic, version = rfile.split('_', 2)
  else:
     compound = rfile.rsplit('-', 1) # split on the last occurance!!
     symbolic = compound[0]
     version = compound[1]
  # =====================================================
  flag = 'set'
  # Get the cba filename basename with .cba extension!
  libname =  symbolic.split('/')[-1]
  # Removed endfix .cba file extension for version comparison!
  raw = version[:-4] 
  print "Task: ---------Arrange variable before process--------"
  print "CBA file name: %s" % libname
  print "CBA file version: %s" % raw
  return (libname, raw)


def add_Osgi_file(rfile):
        print "==== Adding new entry for local internal bundle!!! ====="
        try:
           AdminTask.addLocalRepositoryBundle("[-file %s ]" % rfile)
        except: 
           foo = str(sys.exc_info()[1])
           print "--> Exemption: %s" % foo
           if re.search("already exists in the repository", foo):
               print "--> INFO: cba File already exists in the repository"
               Runtime.getRuntime().exit(0)
           else:
               print "ERROR: ",foo
               sys.exit(1)
        else:
           # Let's save changes !!!!!
           AdminConfig.save()
           print "Successfully added file - %s" % (rfile)
           return 0
           
def bla_variables():
  foo = AdminTask.listBLAs('[-includeDescription true ]').splitlines()
  eba = [ xxx for xxx in foo if xxx.find('EBA') > -1]
  if eba:
     blaId = eba[0]
  else:
     blaId = 'notFound'
  var = AdminTask.listCompUnits('[-blaID %s  -includeDescription true -includeType true ]' % blaId).splitlines()
  noo = [yyy for yyy in var if yyy.endswith('.eba')]
  if noo:
     cuname = noo[0]
  else:
     cuname = 'notFound'
  return (blaId, cuname)
     

def add_osgi_extension(cuname, version, symbol):
     print "Task: ---------- Add osgi extension ------------"
     cuN = cuname.split('=')[1]
     #emblem = symbol.split('/')[-1]
     iversion = version
     symName = "%s.%s" % (symbol, iversion)
     # =================================================================================================
     print '*** Parameter and values ***'
     print 'cuName = %s' % cuN
     print 'symbolicName = %s' % symName
     print 'version = %s' % iversion
     print 'Adding OSGI Extensions'
     try:
       AdminTask.addOSGiExtension('[-cuName %s -symbolicName %s -version %s ]' % (cuN, symName, iversion))
     except:
       error = str(sys.exc_info()[1])
       if re.search('already been added to the composition unit', error):
          print "INFO: {0} symbolic name {1} version - already been added to the composition unit!!".format(symName, iversion)
          Runtime.getRuntime().exit(0)
       else:
          print "ERROR: ",error
          sys.exit(1)
     else:
       AdminConfig.save()

def empty_osgiext_box(konami):
    print "Task: --------- cleanup OSGI extension box ----------"
    cu_name = konami.split('=')[-1]
    try:
       osgibox = AdminTask.listOSGiExtensions('[-cuName %s ]' % cu_name.strip()).splitlines()
    except:
       print "Error:\n"+str(sys.exc_info()[1])
    # ====================================
    holder = []
    if len(osgibox) > 0:
       for extension in osgibox: 
          print "[OSGIext] removing: %s" % extension
          holder.append(extension)
          rawname, pureversion = extension.split(';', 2)      
          try:
              AdminTask.removeOSGiExtension('[-symbolicName %s -version %s -cuName %s ]' % (rawname, pureversion, cu_name))
          except:
              yar = str(sys.exc_info()[1])
              print "Error: ",yar
              continue
          else:
            AdminConfig.save() 
    return holder       

def remove_deployversion_fromList(objext, newversion, oldext):
    if len(oldext) > 0:
       newext = "{0}.{1};{1}".format(objext, newversion)
       newey = [ext for ext in oldext if ext != newext]
    else:
       newey = oldext
    return newey
    
def editCompUnit(cuId, blaid, symbol):
    cuN = cuId.split('=')[1]
    compvar = re.sub('_\d+','',cuN)
    print 'Task: ------ invoke edit_comp_unit --------'
    print '*** Parameter and values ***'
    print 'cuID = %s' % cuId
    print 'blaID = %s' % blaid
    print 'CompUnitStatusStep = %s' % compvar
    #print 'command: AdminTask.editCompUnit'
    print 'Updating the Latest Deployment'
    try:
       AdminTask.editCompUnit('[-cuID %s -blaID %s -CompUnitStatusStep [[%s true "New OSGi application deployment available."]]]' % (cuId, blaid, compvar))
    except:
       contain = str(sys.exc_info()[1])
       if re.search('is up-to-date', contain):
         print "{0} symbolic Name is up to date!!!".format(symbol)
       else:
         print "ERROR: ",contain
         sys.exit(1)
    else:
       AdminConfig.save()
          
def internalLocalRepo_CleanUP(vintage):
    if len(vintage) > 0:
        localRepository_list = vintage
    else:
        return
    # =======================================   
    listentry = AdminTask.listLocalRepositoryBundles().splitlines()
    for row in listentry:
       for ppow in localRepository_list:
           if ppow == row:
              cbaname, cbaversion = row.split(';', 2)
              print "Removing - %s - version %s - from localInternalRepository" % (cbaname, cbaversion)
              try:
                AdminTask.removeLocalRepositoryBundle('[-symbolicName %s -version %s ]' % (cbaname, cbaversion))
              except:
                tell = str(sys.exc_info()[1])
                if re.search("does not exist in the local bundle repository", tell):
                   print "{0} - version: {1} does not exist in the local bundle repository".format(cbaname, cbaversion)
                else:
                   print "Error: ",tell
                   sys.exit(1)
              else:
                   AdminConfig.save()
       #endppow
    #endrow     
    
main()

