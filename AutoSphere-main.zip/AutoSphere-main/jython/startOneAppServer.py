#!/usr/bin/env python
#Murry Kane 
#Version 1.0
#
# Updates
# Date       By             Reason
#_________________________________________________________________________________________________
# 09/12/2019 Murry Kane     Initial version - This will issue a start against 1 Application 
#                           Server within a IBM WebSphere Cluster
#
#_________________________________________________________________________________________________
#
import os, sys, re
from constants import *

if os.path.isfile('%s/wsadminlib.py' % JYTHON_DIR):
  execfile('%s/wsadminlib.py' % JYTHON_DIR)
else:
  print "Needed library wsadminlib.py NOT Found, exiting!"
  sys.exit(1)

enableDebugMessages()
m="startOneAppServer:"

def usage():
  print "Usage: %s 'String of Exclude Nodes' 'Application Server to Start' 'Total Time to wait for Start'" % m
  print "Example %s 'PIMSP01AM01' '300'" % m
  
if ( len(sys.argv) != 3):
  usage()
  sys.exit(1)
else:
  ignoreNodeList = sys.argv[0]
  appServer = sys.argv[1]
  totalActionTime = int(sys.argv[2])
   
ignoretype=['dmgr','nodeagent']

ignorelist = ignoreNodeList.split("/")
sop(m,"Ignore NODE List is %s" % ignorelist)

#lets validate we are on a DMGR!
if whatEnv() == 'nd':
  sop(m, "Running on DMGR, continueing...")
else:
  sop(m, "ERROR: You must run this script on the DMGR!, exiting!")
  sys.exit(2)

IHSNodes = []
IHSNodes = listIHSServerNodes()
nodes = _splitlines(AdminConfig.list( 'Node' ))

for node_id in nodes:
  node = getNodeName(node_id)
  sop(m,"Working on Node: %s" % node)
  if node not in ignorelist and node not in IHSNodes:
    serverEntries = _splitlines(AdminConfig.list( 'ServerEntry', node_id ))
    for jvm in serverEntries:
      servername = AdminConfig.showAttribute( jvm, 'serverName' )
      servertype = AdminConfig.showAttribute( jvm, 'serverType' )
      sop(m, "Server Name is %s Server Type is %s" % (servername, servertype))
      if servername not in ignoretype and servername not in ignorelist:
        if appServer.upper() == servername.upper():
          #startServerNoWait(node, servername)
          startServer(node, servername)
          sop(m, "Completed start of Application Server [%s]" % appServer)
        else:
          sop(m,"This application server(%s) is being skipped since its not equal application instance (%s)" % (servername,appServer))
      else:
        if servername in ignoretype:
          sop(m,"This server(%s) is being skipped since its a type of dmgr/nodeagent" % servername)
        else:
          sop(m,"This server(%s) is being skipped as its in the ignore list" % servername)
  else:
    sop(m,"Node being skipped since its a either Deployment Node/IHS Web Server") 