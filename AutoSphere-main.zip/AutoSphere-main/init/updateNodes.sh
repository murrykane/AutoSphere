#!/bin/ksh

while read line
    do
       xfind=`echo $line | awk -F"_" '{print $1}'`;
       sed -i "s/$xfind/$line/g" $1; 
    done < $2 

rm -f $2;
