#!/bin/bash

export ETLARCHIVE=/apps/VRUP03-common/VRUP03IVRC/etl/archive/*
export FILENAME=Clean_VRU_archives_log.log
export DIRPATH=/home/websphr/CleanVRUArchivesLog
export LOGFILE=${DIRPATH}/${FILENAME}
export DATEL=`date '+%Y-%m-%d %H:%M:%S.%3N'`

#Create if not existing already
if [ ! -d $DIRPATH ] ; then
	mkdir -p $DIRPATH
fi

#Script to clear existing log file
if [ -f $LOGFILE ]; then
	rm -f $LOGFILE
fi

echo "$DATEL - [INFO] Starting ETL archive folder clean up process" >> $LOGFILE
chmod 777 $LOGFILE

#Script to clear files older than 30 days
/bin/find  $ETLARCHIVE -mtime +30 -exec rm -rf {} \;

#Script to monitor the folders and write outcome in a log file
OLDERFILES=$(/bin/find  $ETLARCHIVE -mtime +30 | wc -l)

if [ $OLDERFILES -eq 0 ]; then
	echo "$DATEL - [INFO] ETL archive directory is cleared with files not older than 30 days" >> $LOGFILE
else
	echo "$DATEL - [ERROR] ETL archive directory contain ${OLDERFILES} files older than 30 days after clearing up" >> $LOGFILE
fi
echo "$DATEL - [INFO] Ending ETL archive folder clean up process" >> $LOGFILE

exit 0
