import sys

print "All the Best"

clusterName=sys.argv[0]
propName="com.ibm.ws.webcontainer.httpOnlyCookies"
propValue=sys.argv[1]
print "Cluster Name is : " + clusterName
print "property name is: " + propName
print "property Value is : " + propValue

clusterId = AdminConfig.getid("/ServerCluster:" + clusterName + "/")
clusterMembers = AdminConfig.list("ClusterMember", clusterId ).split(lineSeparator)
for clusterMember in clusterMembers:
    sname = AdminConfig.showAttribute(clusterMember, "memberName")
    sid = AdminConfig.getid('/Server:'+sname+'/')
    cid = AdminConfig.list('Cookie', sid)
    AdminConfig.modify(cid, '[[secure "true"]]')
    print "Restrict cookies to HTTPS Sessions has been Enabled to the Application Server:" + sname
    wc = AdminConfig.list('WebContainer',sid)
    attr = [['name',propName],['value',propValue]]
    print "Creating Web Container Custom prop " + propName + ":" + propValue + " has been the Application Server:" + sname
    AdminConfig.create('Property', wc, attr)
    AdminConfig.save()
