
ENVS=$*
EXEC_DIR=/opt/jenkins/AutoSphere/bin/was

cd ${EXEC_DIR}

for ENV in ${ENVS}

do


  for SERVER in Consumer1 ConsumerBatch1 Content1 CSAdmin1 Provider1 ProviderBatch1 Producer1 ProducerBatch1
  
  do
    
    case ${SERVER} in
    
    
    Consum*)
    
           ENV_TYPE=consumer
    ;;
    
    CSAd*)
    
          ENV_TYPE=csadmin
    ;;
    
    Content*)
    
         ENV_TYPE=content
    ;;
    
    Provid*)
    
         ENV_TYPE=provider
    ;;
    
    
    Produc*)
    
        ENV_TYPE=producer
    ;;
    
    
    esac
    
    echo "-----------------------------------------------------------------------------------"
    echo "running command: sphere.sh -p ${ENV_TYPE} -e ${ENV}${SERVER} -t configure_ext_props"
    echo "-----------------------------------------------------------------------------------"
    sphere.sh -p ${ENV_TYPE} -e ${ENV}${SERVER} -t configure_ext_props
    
    
  done
  
done

cd -
