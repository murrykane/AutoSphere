##########################################################################################
# Author: Dennis Riddlemoser
# This script generates reports based on output from ConfigDump.py
##########################################################################################
# Change history:
# Date        Ref  Who  Comments
#
import ConfigUtils as cu
import sys
import time
import re
import os
#Load libraries from where the path they are installed.
path = os.getenv('IBM_JAVA_COMMAND_LINE')
if path == None or len(path) == 0:
	path=sys.argv[0]
else:
	path=path[path.find("-f") + 2:].strip()
path=path.split(' ')[0]
if path.find(os.sep) > -1:
	path=path.split(' ')[0]
	path=path[:path.rfind(os.sep)+1]
else:
	path = ''

print path
sys.path.append(path)

import ConfigUtils as cu
True=1
False=0

TimeStamp=time.strftime('_%y%m%d%H%M%S')
TitleTimeStamp=time.strftime(' %m/%d/%y %H:%M:%S')
reportFileHTML='HTML'

#color attributes for tables in the HTML reports
tableHeaderColor=' bgcolor="#cccccc" '
tableTitleColor=' bgcolor="#999999" '
tableNotMatchColor=' bgcolor="#dd0000" '
tableMatchColor=' bgcolor="#00dd00" '
tableFlagColor=' bgcolor="#eeee33" '

#table column widths 
headerColWidthNum=350
valueColWidthNum=200
matchColWidthNum=65
headerColWidth=' width="'+str(headerColWidthNum)+'" '
valueColWidth=' width="'+str(valueColWidthNum)+'" '
matchColWidth=' width="'+str(matchColWidthNum)+'" '

def matchColumn(dict):
	if 'MatchColumn' in dict and dict['MatchColumn']=='ignore':
		return False
	else:
		return True

#########################################################################################################
# Opens report files and writes out initial report data.  
#########################################################################################################
def reportInitialize(title,baseFileName):
	cu.printMsg('reportInitialize => '+title, True)
	global TimeStamp
	global TitleTimeStamp
	global reportFileHTML
	
	basePath = ''
	try:
		basePath = cu.PropertiesDict['ConfigurationReportOutputPath'].strip()
		# commented by j.canepa - causes \ values in report name - not required
		#if not basePath[len(basePath)-1:] == '\\':
	    #basePath = basePath+'\\'
	except:
		None 
	baseFileName = basePath + baseFileName
	
	#initialize HTML file report
	reportFileHTML = open(baseFileName+TimeStamp+'.html','w')
	reportFileHTML.write('<html>\n<head>\n<meta http-equiv="content-type" content="text/html; charset=UTF-8">\n<title>'+ \
	                     title+'</title>\n</head>\n<body>')
	reportFileHTML.write('<div class="wrap content">\n<style>\n.normal\n{white-space:\nnormal;}\n.wrapped\n{white-space: pre;\nwhite-space: pre-wrap;\n'\
	                     'white-space: pre-line;\nwhite-space: -pre-wrap;\nwhite-space: -o-pre-wrap\nwhite-space: -moz-pre-wrap;\nwhite-space: -hp-pre-wrap;\nword-wrap: break-word;\n'\
	                     '}</style>\n')
	reportFileHTML.write('<br><big><big><big><b>'+title+TitleTimeStamp+'</b></big></big></big><br><br><br>\n')

#########################################################################################################
# Opens report files and writes out initial report data.  
#########################################################################################################
def reportInitializeCluster(cluster):
	cu.printMsg('reportInitialize => '+cluster, True)
	global reportFileHTML
	global reportFormat
	
	title='Report for cluster "'+ cu.MasterDict[cluster]['name']+'" '+time.strftime('[%y/%m/%d %H:%M:%S]')
	timeStamp=time.strftime('%y%m%d%H%M%S')
	
	#initialize HTML file report
	reportFileHTML = open(cu.MasterDict[cluster]['name']+'.report.'+timeStamp+'.html','w')
	reportFileHTML.write('<html>\n<head>\n<meta http-equiv="content-type" content="text/html; charset=UTF-8">\n<title>'+ \
	                     title+'</title>\n</head>\n<body>')
	reportFileHTML.write('<div class="wrap content">\n<style>\n.normal\n{white-space:\nnormal;}\n.wrapped\n{white-space: pre;\nwhite-space: pre-wrap;\n'\
	                     'white-space: pre-line;\nwhite-space: -pre-wrap;\nwhite-space: -o-pre-wrap\nwhite-space: -moz-pre-wrap;\nwhite-space: -hp-pre-wrap;\nword-wrap: break-word;\n'\
	                     '}</style>\n')
	reportFileHTML.write('<br><big><big><big><b>'+title+'</b></big></big></big><br><br><br>\n')

#########################################################################################################
# writes out final report info and closes report files.  
#########################################################################################################
def reportFinalize():
	cu.printMsg('reportFinalize', True)
	global reportFormat
	global reportFileHTML
	reportFileHTML.write('</div></body>\n</html>')
	reportFileHTML.close()

#########################################################################################################
# begins an individual report
#
# rptParms see writeReport()
#########################################################################################################
def reportBegin(rptParms):
	global reportFileHTML
	cu.printMsg('reportBegin => '+str(rptParms), True)
	#write HTML config report title
	width=headerColWidthNum+matchColWidthNum
	if matchColumn(rptParms):
		width=headerColWidthNum
	for col in rptParms['ColumnHeaders']:
		width=width+valueColWidthNum+2+2+0
	reportFileHTML.write('<table style="table-layout:fixed" border="2" cellpadding="2" cellspacing="0" width='+str(width)+'>\n')
	reportFileHTML.write('<col'+headerColWidth+'/>\n')
	if matchColumn(rptParms):
		reportFileHTML.write('<col'+matchColWidth+'/>\n')
	for col in rptParms['ColumnHeaders']:
		reportFileHTML.write('<col'+valueColWidth+'/>\n')

#########################################################################################################
# ends an individual report
#
# rptParms see writeReport()
#########################################################################################################
def reportEnd(rptParms):
	global reportFileHTML
	cu.printMsg('reportEnd => '+str(rptParms), True)
	#end HTML table
	reportFileHTML.write('</tbody></table><br>\n')

#########################################################################################################
# Writes an individual report based on report parameters passed in.
#
# rptParms = report parameters dictionary
#
# The dictionary needs to have the following keys defined.
# [Tables] = List of output table dictionaries (see below
# [ColumnHeaders] = Column headers for output tables
#
#########################################################################################################
def reportWrite(rptParms):
	cu.printMsg('reportWrite => '+str(rptParms), True)

	reportBegin(rptParms)

	reportTables=rptParms['Tables']
	columnHeaders=rptParms['ColumnHeaders']
	
	for table in reportTables:
		reportWriteTable(table,columnHeaders)

	reportEnd(rptParms)

#########################################################################################################
# writes table for a report
#
# table = a table dictionary (see below)
# ColumnHeaders = Column headers for the table report
#
# A table dictionary has the following keys:
# [Title] = The title of this table report
# [RowHeaders] = The row headers for the table
# [TableData] = A list of lists.  Each list contains an entry for each server for the specific header.
# [Match] = Indicates is all values in the corresponding row are equal.  "ignore" indicates to omit the match column
# [FirstColumnHeader] = Title for the attributes or properties for the table
# 
#########################################################################################################
def reportWriteTable(table,columnHeaders):
	title=table['Title']
	match = []
	if matchColumn(table):
		match=table['Match']
	firstColumnHeader=table['FirstColumnHeader']
	rowHeaders=table['RowHeaders']
	tableData=table['TableData']

	#write HTML config report title
	x=1
	if matchColumn(table):
		x=2
	reportFileHTML.write('<tbody><tr align="left">\n<td colspan="'+str(len(columnHeaders)+x)+  '" rowspan="1"'+tableTitleColor+' valign="top"><big><big><b>'+ \
						 title+'</b></big></big><br></td></tr>\n')

	#write HTML column headers for attributes
	if matchColumn(table):
		reportFileHTML.write('<tr><td class="wrapped"'+tableHeaderColor+headerColWidth+' valign="top"><b>'+firstColumnHeader+'</b><b><br></b> </td>'\
							'<td class="wrapped"'+tableHeaderColor+matchColWidth+' valign="top"><b>Config Matches</b><b><br></b> </td>\n')
	else:
		reportFileHTML.write('<tr><td class="wrapped"'+tableHeaderColor+headerColWidth+' valign="top"><b>'+firstColumnHeader+'</b><b><br></b> </td>\n')

	for header in columnHeaders:
		reportFileHTML.write('<td class="wrapped"'+tableHeaderColor+valueColWidth+' valign="top"><b>' +\
                              header + '</b><b><br></b> </td>\n')
	reportFileHTML.write('</tr>')

	#Write attribute rows
	idx=0
	lastRowHeader = ''
	numHeaderOccurences = 1
	for header in rowHeaders:
		suffix = ''
		if header == lastRowHeader:
			numHeaderOccurences = numHeaderOccurences + 1
			suffix = ' (' + str(numHeaderOccurences) + ')'
		else:
			lastRowHeader = header
			numHeaderOccurences = 1
		#write HTML row header
		reportFileHTML.write('<tr><td class="wrapped"'+tableHeaderColor+headerColWidth+' valign="top"><b>'+header+suffix+'</b><b><br></b> </td>\n')

		#write HTML match value
		if matchColumn(table):
			color = tableMatchColor
			if match[idx] == 'No':
				color = tableNotMatchColor
			elif match[idx] == 'N/A':
				color = tableFlagColor
			reportFileHTML.write('<td class="wrapped"' + color + matchColWidth + 'valign="top">' + match[idx] + '<br></td>\n')

		#write attribute values
		for value in tableData[idx]:
			color=""
			if matchColumn(table) and not cu.isMostCommon(value,tableData[idx]):
				color = tableFlagColor
			#write HTML value
			reportFileHTML.write('<td class="wrapped"'+valueColWidth+color+'valign="top">' + value + '<br></td>\n')
		
		#end HTML row
		reportFileHTML.write('</tr>\n')
		idx=idx+1

#########################################################################################################
# Creates a report table of jvm arguments and adds the table to rptParms
#########################################################################################################
def reportJvmArguments(rptParms):
	cu.printMsg('reportJvmArguments => '+str(rptParms), True)
	servers=rptParms['ServerList']
	uniqueArgList=[]
	argList=[]
	for server in servers:
		argLine=cu.stripEndChars(cu.getConfigFromPath([server]+rptParms['ConfigPath'])['genericJvmArguments'])
		args=argLine.split(' ')
		for arg in args:
			if len(arg) > 0:
				argDict=getArg(arg,server)
				argList.append(argDict)
				if uniqueArgList.count(argDict['arg'])==0:
					cu.printMsg('reportJvmArguments => appending '+argDict['arg'],True)
					uniqueArgList.append(argDict['arg'])
	args=[]
	for arg in uniqueArgList:
		maxArgCount = getMaxArgCountForServers(arg,argList,servers)
		for x in range(0, maxArgCount):
			args.append(arg)
	args.sort()
	cu.printMsg('reportJvmArguments => args = '+str(args), True)
	tableData=[]
	lastArg=''
	numRepeat=0
	for arg in args:
		row=[]
		if arg == lastArg:
			numRepeat=numRepeat+1
		else:
			lastArg=arg
			numRepeat=0
		for server in servers:
			argLine=cu.stripEndChars(cu.getConfigFromPath([server]+rptParms['ConfigPath'])['genericJvmArguments'])
			serverArg=getServerArg(arg,server,argList,numRepeat)
			row.append(serverArg['value'])
		tableData.append(row)
	#insert the entire generic JVM arguments at the top
	args.insert(0,'genericJvmArguments')
	row=[]
	for server in servers:
		row.append(cu.stripEndChars(cu.getConfigFromPath([server]+rptParms['ConfigPath'])['genericJvmArguments']))
	match=[]
	tableData.insert(0,row)
	for row in tableData:
		match.append(cu.listElementsMatch(row))
	argsDict = {'RowHeaders':args,'TableData':tableData,'Match':match,'Title':'JVM Arguments' ,'FirstColumnHeader':''}
	rptParms['Tables'].append(argsDict)

#########################################################################################################
# parses a JVM argument into argument and value returns a dictionary.
#
# return a dictionary with [arg] and [value] keys
#########################################################################################################
def getArg(arg,server):
	cu.printMsg('getArg => '+str(arg), True)
	idx=arg.find(':')
	idx1=arg.find('=')
	if idx == -1 and idx1 > 0 or not idx1 == -1 and idx > idx1:
		idx=idx1
	value=''
	if idx > 0:
		value=arg[idx+1:].strip()
		arg=arg[:idx].strip()
	if len(value) == 0:
		value = 'is set'
	rtnVal={'arg':arg,'value':value,'server':server}
	cu.printMsg('getArg <= '+str(rtnVal), True)
	return rtnVal

#########################################################################################################
# Counts the number of occurrences of a given argument for an individual server in the server list
#########################################################################################################
def getMaxArgCountForServers(argToCheck,argList,servers):
	cu.printMsg('getMaxArgCountForServers => '+ argToCheck, True)
	rtnVal=0
	for server in servers:
		num=0
		for arg in argList:
			if arg['arg'] == argToCheck and arg['server'] == server:
				num=num+1
		if num > rtnVal:
			rtnVal = num
	cu.printMsg('getMaxArgCountForServers <= "'+ argToCheck + '" ' + str(rtnVal), True)
	return rtnVal

#########################################################################################################
# Returns the server argument from the list of arguments
#########################################################################################################
def getServerArg(argToCheck,server,argList,numRepeat):
	cu.printMsg('getServerArg => '+str(argToCheck) + ' ' + str(numRepeat), True)
	numFound = 0
	for arg in argList:
		if arg['arg'] == argToCheck and arg['server'] == server:
			if numFound >= numRepeat:
				return arg
			else:
				numFound = numFound + 1
	return {'arg':argToCheck,'value':'is not set','server':server}

#lists all configuration elements that are effectively collections of name/value pairs
PropertyAttributes=[{'PropName':'properties','PropPath':[]},\
					{'PropName':'customProperties','PropPath':[]},\
					{'PropName':'systemProperties','PropPath':[]},\
					{'PropName':'environment','PropPath':[]},\
					{'PropName':'properties','PropPath':['adminObjectTemplateProps']},\
					{'PropName':'additionalTrustManagerAttrs','PropPath':[]},\
					{'PropName':'webAuthAttrs','PropPath':[]},\
					{'PropName':'resourceProperties','PropPath':['connectionDefTemplateProps']},\
					{'PropName':'resourceProperties','PropPath':['propertySet']}]

#########################################################################################################
# Creates a report table of properties and adds the table to rptParms
# If a given configuration element does not have a properties attribute, a report is not generated.
#########################################################################################################
def reportProperties(rptParms):
	cu.printMsg('reportProperties => '+ str(rptParms), True)
	global PropertyAttributes
	servers=rptParms['ServerList']
	clusterDict = {}
	for propAttr in PropertyAttributes:
		names=[]
		for server in servers:
			serverDict = {}
			clusterDict.update({server:serverDict})
			try:
				config=cu.getConfigFromPath([server]+rptParms['ConfigPath']+propAttr['PropPath'])
				props = config[propAttr['PropName']]
				if cu.isConfigID(props):
					props=cu.stringListAsList(props)
					for prop in props:
						found = False
						try:
							for name in names:
								if name == cu.MasterDict[prop]['name']:
									found = True
							if not found:
								names.append(cu.MasterDict[prop]['name'])
							value = 'present but null'
							try:
								value = cu.MasterDict[prop]['value']
							except:
								value = 'present but null'
							serverDict.update({cu.MasterDict[prop]['name']:value})
						except KeyError as ke:
							#print 'KeyError ' + str(ke)
							None
						except:
							#print "Unexpected error:", sys.exc_info()[0]
							None
			except KeyError as ke:
				#print 'KeyError ' + str(ke)
				None
			except:
				#print "Unexpected error:", sys.exc_info()[0]
				None
		if len(names) > 0:
			names.sort()
			tableData=[]
			match=[]
			for name in names:
				row=[]
				for server in servers:
					try:
						row.append(clusterDict[server][name])
					except:
						row.append('property not set')
				match.append(cu.listElementsMatch(row))
				tableData.append(row)
			propsDict = {'RowHeaders':names,'TableData':tableData,'Match':match,'Title':propAttr['PropName'] + ' for ' + rptParms['Title'],\
			             'FirstColumnHeader':propAttr['PropName']}
			rptParms['Tables'].append(propsDict)

#########################################################################################################
# Creates a report table of attributes and adds the table to rptParms
#########################################################################################################
def reportConfigElementAttrList(rptParms):
	cu.printMsg('reportConfigElementAttrList => '+str(rptParms), True)
	rptParms['Attributes']=cu.PropertiesDict[rptParms['ReportName']+':attributes'].split(',')
	attrs=rptParms['Attributes']
	path=rptParms['ConfigPath']
	servers=rptParms['ServerList']
	attrTable=[]
	match=[]
	tableData=[]
	columnHeaders=[]
	rowHeaders=[]
	for server in servers:
		if 'ColumnHeaderFunc' not in rptParms:
			columnHeaders.append(cu.MasterDict[server]['name']+' ('+cu.getConfigIDNode(server)+', '+cu.getConfigIDCell(server)+')' )
		else:
			columnHeaders.append(rptParms['ColumnHeaderFunc'](server))
	for attr in attrs:
		attrVals = []
		for server in servers:
			config = {}
			try:
				config=cu.getConfigFromPath([server]+path)
			except KeyError as ke:
				#printMsg('ERROR: ' + str(ke),False)
				None
			if len(config.keys()) == 0:
				attrVals.append('configuration not defined')
			else:
				if attr in config.keys():
					attrVals.append(config[attr])
				else:
					attrVals.append('attribute not set')
		attrSet=False
		for val in attrVals:
			if val.find(' not ') == -1:
				attrSet=True
				break
		if attrSet:
			rowHeaders.append(attr)
			match.append(cu.listElementsMatch(attrVals))
			tableData.append(attrVals)
	attrDict = {'RowHeaders':rowHeaders,'TableData':tableData,'Match':match,'Title':rptParms['Title'],'FirstColumnHeader':'Attribute'}
	rptParms['ColumnHeaders']=columnHeaders
	if 'Tables' in rptParms.keys():
		rptParms['Tables'].append(attrDict)
	else:
		rptParms['Tables']=[attrDict]

#########################################################################################################
# Creates a report table for the PMI stat provider configuration and adds it to rptParms
#########################################################################################################
def reportPMIStatProviders(rptParms):
	cu.printMsg('reportPMIConfig => '+str(rptParms), True)
	servers=rptParms['ServerList']
	pmiModuleNames=cu.PropertiesDict['pmiModuleReport.statProviders'].split(',')
	tableData=[]
	match=[]
	rowHaeaders=[]
	for name in pmiModuleNames:
		row=[]
		for server in servers:
			row.append(cu.getPMICellValue(cu.getPMIConfig(name,server)))
		if not len(row) == row.count('not configured'):
			rowHaeaders.append(name)
			match.append(cu.listElementsMatch(row))
			tableData.append(row)
	pmiDict = {'RowHeaders':rowHaeaders,'TableData':tableData,'Match':match,'Title':'PMI Stats Providers','FirstColumnHeader':'Module Name'}
	rptParms['Tables'].append(pmiDict)

#########################################################################################################
# Creates a report table for the PMI stat group configuration and adds it to rptParms
#########################################################################################################
def reportPMIStatGroups(rptParms):
	cu.printMsg('reportPMIStatGroups => '+str(rptParms), True)
	servers=rptParms['ServerList']
	pmiModuleNames=cu.PropertiesDict['pmiModuleReport.statGroup'].split(',')
	tableData=[]
	match=[]
	rowHaeaders=[]
	for name in pmiModuleNames:
		row=[]
		for server in servers:
			config=cu.getPMIConfig(name,server)
			cellValue = 'not configured'
			if config.has_key('pmimodules'):
				cellValue=[]
				pmiMods=cu.stringListAsList(config['pmimodules'])
				for pmiMod in pmiMods:
					cellValue.append(cu.MasterDict[pmiMod]['moduleName'])
				cellValue.sort()
				cellValue = str(cellValue)[1:-1].strip()
			row.append(cellValue)
		if not len(row) == row.count('not configured'):
			rowHaeaders.append(name)
			match.append(cu.listElementsMatch(row))
			tableData.append(row)
	pmiDict = {'RowHeaders':rowHaeaders,'TableData':tableData,'Match':match,'Title':'PMI Stats Groups','FirstColumnHeader':'Stat Group Name'}
	rptParms['Tables'].append(pmiDict)


#########################################################################################################
# Most configuration elements have a a single set of attributes and possibly properties.
# This is a convenience function that generates a report based on that criteria.
#########################################################################################################
def reportConfiguration(rptParms):
	cu.printMsg('reportConfiguration => '+str(rptParms), True)
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	reportWrite(rptParms)

#########################################################################################################
# Generates a report of JVM attributes, system properties, JVM arguments,  and 
#########################################################################################################
def jvmReportSrv(serverList):
	cu.printMsg('jvmReportSrv => '+ str(serverList), True)
	configPath = ['processDefinitions->JavaProcessDef_','jvmEntries->JavaVirtualMachine_']
	rptParms = {'Title':'JVM Configuration','ServerList':serverList,'ReportName':'jvmReportSrv','ConfigPath':configPath}
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	reportJvmArguments(rptParms)
	reportWrite(rptParms)

#########################################################################################################
# Generates a report of the JVM process definition
#########################################################################################################
def processDefinitionReportSrv(serverList):
	cu.printMsg('processDefinitionReportSrv => '+ str(serverList), True)
	configPath = ['processDefinitions->JavaProcessDef_']
	rptParms = {'Title':'Process Definition','ServerList':serverList,'ReportName':'processDefinitionReportSrv','ConfigPath':configPath}
	reportConfiguration(rptParms)

#########################################################################################################
# Generates a report of the JVM execution config
#########################################################################################################
def processExecutionReportSrv(serverList):
	cu.printMsg('processExecutionReportSrv => '+ str(serverList), True)
	configPath = ['processDefinitions->JavaProcessDef_','execution']
	rptParms = {'Title':'Process Execution','ServerList':serverList,'ReportName':'processExecutionReportSrv','ConfigPath':configPath}
	reportConfiguration(rptParms)

#########################################################################################################
# Generates a report of the monitoring policy for servers
#########################################################################################################
def processMonitoringPolicyReportSrv(serverList):
	cu.printMsg('processMonitoringPolicyReportSrv => '+ str(serverList), True)
	configPath = ['processDefinitions->JavaProcessDef_','monitoringPolicy']
	rptParms = {'Title':'Process Monitoring Policy','ServerList':serverList,'ReportName':'processMonitoringPolicyReportSrv','ConfigPath':configPath}
	reportConfiguration(rptParms)

#########################################################################################################
# Generates a report of the trace service config for servers
#########################################################################################################
def traceServiceReportSrv(serverList):
	cu.printMsg('traceServiceReportSrv => '+ str(serverList), True)
	configPath = ['services->TraceService_']
	rptParms = {'Title':'Trace Service Configuration','ServerList':serverList,'ReportName':'traceServiceReportSrv','ConfigPath':configPath}
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	rptParms['ConfigPath'] = ['services->TraceService_','traceLog']
	rptParms['Title'] = 'Trace log'
	rptParms['ReportName'] = 'traceLogSrv'
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	reportWrite(rptParms)

#########################################################################################################
# Generates a report of the NCSA access log config for servers
#########################################################################################################
def httpAccessLogServiceReportSrv(serverList):
	cu.printMsg('httpAccessLogServiceReportSrv => '+ str(serverList), True)
	configPath = ['services->HTTPAccessLoggingService_']
	rptParms = {'Title':'HTTP Access Log Service','ServerList':serverList,'ReportName':'httpAccessLogServiceReportSrv','ConfigPath':configPath}
	reportConfiguration(rptParms)

#########################################################################################################
# Generates a report of the Transaction Service
#########################################################################################################
def transactionServiceReportSrv(serverList):
	cu.printMsg('transactionServiceReportSrv => '+ str(serverList), True)
	configPath = ['components->ApplicationServer_','services->TransactionService_']
	rptParms = {'Title':'Transaction Service','ServerList':serverList,'ReportName':'transactionServiceReportSrv','ConfigPath':configPath}
	reportConfiguration(rptParms)

#########################################################################################################
# Generates a report of the trace service config for servers
#########################################################################################################
def ejbContainerSrv(serverList):
	cu.printMsg('ejbContainerSrv => '+ str(serverList), True)
	configPath = ['components->ApplicationServer_','components->EJBContainer_']
	rptParms = {'Title':'EJB Container','ServerList':serverList,'ReportName':'ejbContainerSrv','ConfigPath':configPath}
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	rptParms['ConfigPath'] = ['components->ApplicationServer_','components->EJBContainer_','cacheSettings']
	rptParms['Title'] = 'EJB Cache Settings'
	rptParms['ReportName'] = 'ejbCacheSrv'
	reportConfigElementAttrList(rptParms)
	rptParms['ConfigPath'] = ['components->ApplicationServer_','components->EJBContainer_','services->MessageListenerService_']
	rptParms['Title'] = 'Messenge Listener Service'
	rptParms['ReportName'] = 'messageListenerServiceSrv'
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	rptParms['ConfigPath'] = ['components->ApplicationServer_','components->EJBContainer_','services->MessageListenerService_','threadPool']
	rptParms['Title'] = 'Messenge Listener Service Thread Pool'
	rptParms['ReportName'] = 'threadPoolSrv'
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	rptParms['ConfigPath'] = ['components->ApplicationServer_','components->EJBContainer_','timerSettings']
	rptParms['Title'] = 'EJB Timer Settings'
	rptParms['ReportName'] = 'ejBTimerSrv'
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	rptParms['ConfigPath'] = [{'function':cu.getDataFromConfigPath,'args':['components->ApplicationServer_','components->EJBContainer_','timerSettings']}]
	rptParms['Title'] = 'EJB Timer DataSource'
	rptParms['ReportName'] = 'dataSourceRsc'
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	rptParms['ConfigPath'] = [{'function':cu.getDataFromConfigPath,'args':['components->ApplicationServer_','components->EJBContainer_','timerSettings']},'provider']
	rptParms['Title'] = 'EJB Timer DataSource Provider'
	rptParms['ReportName'] = 'providerReportRsc'
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	rptParms['ConfigPath'] = [{'function':cu.getDataFromConfigPath,'args':['components->ApplicationServer_','components->EJBContainer_','timerSettings']},'relationalResourceAdapter']
	rptParms['Title'] = 'EJB Timer DataSource Relational Resource Adapter'
	rptParms['ReportName'] = 'resourceAdapterRsc'
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	reportWrite(rptParms)

# Generates a report of the ORB service for servers
#########################################################################################################
def orbServiceReportSrv(serverList):
	cu.printMsg('orbServiceReportSrv => '+ str(serverList), True)
	configPath = ['services->ObjectRequestBroker_']
	rptParms = {'Title':'ORB','ServerList':serverList,'ReportName':'orbServiceReportSrv','ConfigPath':configPath}
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	rptParms['ConfigPath'] = ['services->ObjectRequestBroker_','threadPool']
	rptParms['Title'] = 'ORB Thread Pool'
	rptParms['ReportName'] = 'threadPoolSrv'
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	reportWrite(rptParms)

#########################################################################################################
# Generates a report of the web container config for servers
#########################################################################################################
def webContainerReportSrv(serverList):
	cu.printMsg('webContainerReportSrv => '+ str(serverList), True)
	configPath = ['components->ApplicationServer_','components->WebContainer_']
	rptParms = {'Title':'Web Container','ServerList':serverList,'ReportName':'webContainerReportSrv','ConfigPath':configPath}
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	rptParms['ConfigPath'] = ['services->ThreadPoolManager_','threadPools->WebContainer']
	rptParms['Title'] = 'Web Container Thread Pool'
	rptParms['ReportName'] = 'threadPoolSrv'
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	reportWrite(rptParms)

#########################################################################################################
# Generates a report of the web container thread pool for servers
#########################################################################################################
def webContainerThreadPoolReportSrv(serverList):
	cu.printMsg('threadPoolSrv => '+ str(serverList), True)
	configPath = ['services->ThreadPoolManager_','threadPools->WebContainer']
	rptParms = {'Title':'Web Container Thread Pool','ServerList':serverList,'ReportName':'threadPoolSrv','ConfigPath':configPath}
	reportConfiguration(rptParms)

#########################################################################################################
# Generates a report of the server class loading policies
#########################################################################################################
def applicationServerReportSrv(serverList):
	cu.printMsg('applicationServerReportSrv => '+ str(serverList), True)
	configPath = ['components->ApplicationServer_']
	rptParms = {'Title':'Application Server','ServerList':serverList,'ReportName':'applicationServerReportSrv','ConfigPath':configPath}
	reportConfiguration(rptParms)

#########################################################################################################
# Generates a report of the server class loading policies
#########################################################################################################
def httpPluginReportSrv(serverList):
	cu.printMsg('httpPluginReportSrv => '+ str(serverList), True)
	configPath = ['components->ApplicationServer_','webserverPluginSettings']
	rptParms = {'Title':'HTTP Plugin settings','ServerList':serverList,'ReportName':'httpPluginReportSrv','ConfigPath':configPath}
	reportConfiguration(rptParms)

#########################################################################################################
# Generates a report of the monitoring policy for servers
#########################################################################################################
def sessionManagerReportSrv(serverList):
	cu.printMsg('sessionManagerReportSrv => '+ str(serverList), True)
	configPath = ['components->ApplicationServer_','components->WebContainer_','services->SessionManager_']
	rptParms = {'Title':'Session Manager Configuration','ServerList':serverList,'ReportName':'sessionManagerReportSrv','ConfigPath':configPath}
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	rptParms['ConfigPath'] = ['components->ApplicationServer_','components->WebContainer_','services->SessionManager_','defaultCookieSettings']
	rptParms['Title'] = 'Session Default Cookie Settings'
	rptParms['ReportName'] = 'defaultCookieSettingsSrv'
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	rptParms['ConfigPath'] = ['components->ApplicationServer_','components->WebContainer_','services->SessionManager_','tuningParams']
	rptParms['Title'] = 'Session Manager Tuning Parameters'
	rptParms['ReportName'] = 'sessionManagerTuningParmsReportSrv'
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	rptParms['ConfigPath'] = ['components->ApplicationServer_','components->WebContainer_','services->SessionManager_','tuningParams','invalidationSchedule']
	rptParms['Title'] = 'Session Manager Invalidation Schedule'
	rptParms['ReportName'] = 'sessionInvalidationScheduleReportSrv'
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	rptParms['ConfigPath'] = ['components->ApplicationServer_','components->WebContainer_','services->SessionManager_','sessionDatabasePersistence']
	rptParms['Title'] = 'Session Database Persistence'
	rptParms['ReportName'] = 'sessionDBPersistenceReportSrv'
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	rptParms['ConfigPath'] = [{'function':cu.getDataFromConfigPath,'args':['components->ApplicationServer_','components->WebContainer_',\
	                           'services->SessionManager_','sessionDatabasePersistence']}]
	rptParms['Title'] = 'Session DataSource'
	rptParms['ReportName'] = 'dataSourceRsc'
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	rptParms['ConfigPath'] = [{'function':cu.getDataFromConfigPath,'args':['components->ApplicationServer_','components->WebContainer_',\
	                           'services->SessionManager_','sessionDatabasePersistence']},'provider']
	rptParms['Title'] = 'Session DataSource Provider'
	rptParms['ReportName'] = 'providerReportRsc'
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	rptParms['ConfigPath'] = [{'function':cu.getDataFromConfigPath,'args':['components->ApplicationServer_','components->WebContainer_',\
	                           'services->SessionManager_','sessionDatabasePersistence']},'relationalResourceAdapter']
	rptParms['Title'] = 'Session DataSource Relational Resource Adapter'
	rptParms['ReportName'] = 'resourceAdapterRsc'
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	reportWrite(rptParms)

#########################################################################################################
# Generates a report of the session manager tuning parms for servers
#########################################################################################################
#def sessionManagerTuningParmsReportSrv(serverList):
#	cu.printMsg('sessionManagerTuningParmsReportSrv => '+ str(serverList), True)
#	configPath = ['components->ApplicationServer_','components->WebContainer_','services->SessionManager_','tuningParams']
#	rptParms = {'Title':'Session Manager Tuning Parameters','ServerList':serverList,'ReportName':'sessionManagerTuningParmsReportSrv','ConfigPath':configPath}
#	reportConfiguration(rptParms)

#########################################################################################################
# Generates a report of the session invalidation schedule for servers
#########################################################################################################
#def sessionInvalidationScheduleReportSrv(serverList):
#	cu.printMsg('sessionInvalidationScheduleReportSrv => '+ str(serverList), True)
#	configPath = ['components->ApplicationServer_','components->WebContainer_','services->SessionManager_','tuningParams','invalidationSchedule']
#	rptParms = {'Title':'Session Manager Invalidation Schedule','ServerList':serverList,'ReportName':'sessionInvalidationScheduleReportSrv','ConfigPath':configPath}
#	reportConfiguration(rptParms)

#########################################################################################################
# Generates a report of the session DB persistence config for servers
#########################################################################################################
#def sessionDBPersistenceReportSrv(serverList):
#	cu.printMsg('sessionDBPersistenceReportSrv => '+ str(serverList), True)
#	configPath = ['components->ApplicationServer_','components->WebContainer_','services->SessionManager_','sessionDatabasePersistence']
#	rptParms = {'Title':'Session Database Persistence','ServerList':serverList,'ReportName':'sessionDBPersistenceReportSrv','ConfigPath':configPath}
#	reportConfiguration(rptParms)

#########################################################################################################
# Generates a report of the dynacache config (only base cache and memory cache)
#########################################################################################################
def dynamicCacheReportSrv(serverList):
	cu.printMsg('dynamicCacheReportSrv => '+ str(serverList), True)
	configPath = ['components->ApplicationServer_','services->DynamicCache']
	rptParms = {'Title':'Dynamic Cache','ServerList':serverList,'ReportName':'dynamicCacheReportSrv','ConfigPath':configPath}
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	rptParms['ConfigPath'] = ['components->ApplicationServer_','services->DynamicCache','diskCacheCustomPerformanceSettings']
	rptParms['Title'] = 'Disk Cache Custom Performance Settings'
	rptParms['ReportName'] = 'diskCacheCustomPerformanceSettingsRsc'
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	rptParms['ConfigPath'] = ['components->ApplicationServer_','services->DynamicCache','diskCacheEvictionPolicy']
	rptParms['Title'] = 'Disk Cache Eviction Policies'
	rptParms['ReportName'] = 'diskCacheEvictionPolicyRsc'
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	reportWrite(rptParms)

#########################################################################################################
# Generates a report of the PMI config for servers
#########################################################################################################
def pmiServiceReportSrv(serverList):
	cu.printMsg('pmiServiceReportSrv => '+ str(serverList), True)
	configPath = ['services->PMIService_']
	rptParms = {'Title':'PMI Configuration','ServerList':serverList,'ReportName':'pmiServiceReportSrv','ConfigPath':configPath}
	reportConfigElementAttrList(rptParms)
	reportProperties(rptParms)
	reportPMIStatProviders(rptParms)
	reportPMIStatGroups(rptParms)
	reportWrite(rptParms)

#########################################################################################################
# Generates a report of the monitoring policy for servers
#########################################################################################################
def sipContainerReportSrv(serverList):
	cu.printMsg('sipContainerReportSrv => '+ str(serverList), True)
	configPath = ['components->ApplicationServer_','components->SIPContainer_']
	rptParms = {'Title':'SIP Container','ServerList':serverList,'ReportName':'sipContainerReportSrv','ConfigPath':configPath}
	reportConfiguration(rptParms)

#########################################################################################################
# Generates a report of the SIP stack config for servers
#########################################################################################################
def sipStackReportSrv(serverList):
	cu.printMsg('sipStackReportSrv => '+ str(serverList), True)
	configPath = ['components->ApplicationServer_','components->SIPContainer_','stack']
	rptParms = {'Title':'SIP Stack','ServerList':serverList,'ReportName':'sipStackReportSrv','ConfigPath':configPath}
	reportConfiguration(rptParms)

#########################################################################################################
# Generates a report of SIP timers for servers
#########################################################################################################
def sipTimersReportSrv(serverList):
	cu.printMsg('sipTimersReportSrv => '+ str(serverList), True)
	configPath = ['components->ApplicationServer_','components->SIPContainer_','stack','timers']
	rptParms = {'Title':'SIP Timers','ServerList':serverList,'ReportName':'sipTimersReportSrv','ConfigPath':configPath}
	reportConfiguration(rptParms)

#########################################################################################################
# Generates a report of the portlet container for servers
#########################################################################################################
def portletContainerReportSrv(serverList):
	cu.printMsg('portletContainerReportSrv => '+ str(serverList), True)
	configPath = ['components->ApplicationServer_','components->PortletContainer_']
	rptParms = {'Title':'Portlet Container','ServerList':serverList,'ReportName':'portletContainerReportSrv','ConfigPath':configPath}
	reportConfiguration(rptParms)

#########################################################################################################
# Generates a report of the file transfer service for the node agent of the servers 
#########################################################################################################
def fileTransferServiceReportSrv(serverList):
	cu.printMsg('fileTransferServiceReportSrv => '+ str(serverList), True)
	configPath = ['.*cells/.*/nodes/__NODE__/servers/nodeagent.server.xml.FileTransferService_.*']
	rptParms = {'Title':'File Transfer Service (runs on node agent)','ServerList':serverList,'ReportName':'fileTransferServiceReportSrv','ConfigPath':configPath}
	reportConfiguration(rptParms)

#########################################################################################################
# Generates a report of the file synchronization service for the node agent of the servers 
#########################################################################################################
def fileSynchServiceReportSrv(serverList):
	cu.printMsg('fileSynchServiceReportSrv => '+ str(serverList), True)
	configPath = ['.*cells/.*/nodes/__NODE__/servers/nodeagent.server.xml.ConfigSynchronizationService_.*']
	rptParms = {'Title':'File Synchronization Service (runs on node agent)','ServerList':serverList,'ReportName':'fileSynchServiceReportSrv','ConfigPath':configPath}
	reportConfiguration(rptParms)

#########################################################################################################
# Generates a report of transport channel services and related transport chains
#########################################################################################################
def reportTransportChannelServiceSrv(serverList):
	cu.printMsg('reportTransportChannelService => '+ str(serverList), True)
	configPath = ['services->TransportChannelService_']
	rptParms = {'Title':'Transport Channel Service','ServerList':serverList,'ReportName':'reportTransportChannelServiceSrv','ConfigPath':configPath}
	reportConfiguration(rptParms)
	#Get all Transport Chains
	chains=[]
	#get path elements for server transport chains
	for server in serverList:
		srvChains=''
		try:
			srvChains = cu.stringListAsList(cu.getConfigFromPath([server]+configPath)['chains'])
		except:
			cu.printMsg('WARNING: chains not present in '+ str([server]+configPath), False)
		for chain in srvChains:
			chain=chain.split('(')[0]
			if not chain in chains:
				chains.append(chain)
	chains.sort()
	for chain in chains:
		rptParms['Tables']=[]
		enableRow=[]
		channelRow=[]
		channelList=[]
		for server in serverList:
			configPath=[server,'services->TransportChannelService_','chains->'+chain]
			config=cu.getConfigFromPath(configPath)
			if len(config.keys()) == 0:
				enableRow.append('configuration not defined')
				channelRow.append('configuration not defined')
			else:
				enableRow.append(config['enable'])
				channels=cu.stringListAsList(config['transportChannels'])
				channelCell=''
				for channel in channels:
					channel=channel.split('(')[0]
					channel=channel[:channel.rfind('_')]
					channelCell=channelCell+channel+', '
					if not channel in channelList:
						channelList.append(channel)
				channelRow.append(channelCell[:-2])
		match = [cu.listElementsMatch(enableRow),cu.listElementsMatch(channelRow)]
		tableData = [enableRow,channelRow]
		chainDict={'RowHeaders':['enable','transportChannels'],'Match':match,'Title':'Transport chain: '+chain,'FirstColumnHeader':'Attribute','TableData':tableData}
		rptParms['Tables'].append(chainDict)
		for channel in channelList:
			configPath=['services->TransportChannelService_','chains->'+chain,'transportChannels->'+channel]
			#define transport channel specific attributes
			rptParms.update({'Title':'Channel '+channel,'ServerList':serverList,'ReportName':'reportTransportChannelChainSrv','ConfigPath':configPath})
			reportConfigElementAttrList(rptParms)
			reportProperties(rptParms)
		reportWrite(rptParms)

#########################################################################################################
# Executes all server centric reports
#########################################################################################################
def ServerReport(report):
	serverList=[]
	propLists=[cu.getAllPropKeys(report+':Servers:'),cu.getAllPropKeys(report+':Clusters:')]
	clusterLookup=False
	for propList in propLists:
		for prop in propList:
			prop = prop.strip()
			value = cu.PropertiesDict[prop].split('::')
			if len(value) > 1:
				if clusterLookup:
					configIDs = cu.getClusterConfigIDs(value[0],value[1])
					#print configIDs
					for configID in configIDs:
						srvList = cu.getClusterServerList(configID)
						#BUGBUG Likely the cluster logic is returning servers from multiple cells. 
						for srv in srvList:
							if serverList.count(srv) == 0:
								serverList.append(srv)
				else:
					if len(value) == 2:
						value.insert(1,".*")
					serverList = serverList + cu.getServerConfigIDs(value[0],value[1],value[2])
		clusterLookup=True
	#print serverList
	#sys.exit(2)
	
	cu.printMsg('Running server report ' + report,False)
	if len(serverList) == 0:
		cu.printMsg('ERROR: no servers found for the report.' ,False)
		return
	serverList = cu.sortByCellAndScope(serverList,cu.getNameAndScopeSort)
	cu.printMsg('Server list:',False)
	for server in serverList:
		cu.printMsg('\t\t'+cu.MasterDict[server]['name']+" Cell: "+server.split("/")[1]+" Node: "+server.split("/")[3],False)

	subReports = [['JVM',jvmReportSrv],\
				 ['Process Definition',processDefinitionReportSrv],\
				 ['Process Execution',processExecutionReportSrv],\
				  ['Process Monitoring Policy',processMonitoringPolicyReportSrv],\
				  ['Web Container',webContainerReportSrv],\
				  ['HTTP Plugin',httpPluginReportSrv],\
				  ['Application Server',applicationServerReportSrv],\
				  ['Session Management',sessionManagerReportSrv],\
				  ['SIP Container',sipContainerReportSrv],\
				  ['SIP Stack',sipStackReportSrv],\
				  ['SIP Timer',sipTimersReportSrv],\
				  ['Portlet Container',portletContainerReportSrv],\
				  ['Dynamic Cache',dynamicCacheReportSrv],\
				  ['EJB Container', ejbContainerSrv],\
				  ['Transaction Service',transactionServiceReportSrv],\
				  ['ORB',orbServiceReportSrv],\
				  ['PMI',pmiServiceReportSrv],\
				  ['Trace Service',traceServiceReportSrv],\
				  ['HTTP Access Log Service',httpAccessLogServiceReportSrv],\
				  ['File Transfer Service',fileTransferServiceReportSrv],\
				  ['File Synchronization Service',fileSynchServiceReportSrv],\
				  ['Tranport Channels',reportTransportChannelServiceSrv]]
	reportInitialize(cu.PropertiesDict[report+':Title'],cu.PropertiesDict[report+':FileName'])

	runReportList = cu.PropertiesDict[report+':ReportList'].split(',')
	for subReport in subReports:
		run = False
		for runReport in runReportList:
			if str(subReport[1]).find(runReport) > -1 or runReport=='All':
				run = True
				break
		if run:
			cu.printMsg('Running '+subReport[0],False)
			subReport[1](serverList)
		else:
			cu.printMsg('Skipping '+subReport[0],False)
	reportFinalize()

#########################################################################################################
# Generates the Cell summary report
#########################################################################################################
def CellSummaryReport():
	cu.printMsg('Generating cell summary report',False)
	reports = [['Servers','/.*\#Server_.*','name',True],\
	           ['Clusters','/.*\#ServerCluster_.*','name',False],\
			   ['Virtual Hosts','.*VirtualHost_.*','name',False],\
			   ['Core Groups','.*CoreGroup_.*','name',False],\
			   ['Data Sources','.*DataSource_.*','name',True],\
			   ['JMS Providers','.*JMSProvider_.*','name',True],\
			   ['J2C Resource Adapters','.*J2CResourceAdapter_.*','name',True],\
			   ['Mail Providers','.*MailProvider_.*','name',True],\
			   ['URL Providers','.*URLProvider_.*','name',True],\
			   ['JDBC Providers','.*JDBCProvider_.*','name',True],\
			   ['Service Integration Buses','.*SIBus_.*','name',False],\
			   ['Application Deployments','.*ApplicationDeployment_.*','binariesURL',False],\
			   ['Servlet Cache Instances','.*ServletCacheInstance_.*','name',True],\
			   ['Object Cache Instances','.*ObjectCacheInstance_.*','name',True],\
			   ]
	reportInitialize('Cell Summary Report','Summary')
	columnHeaders=cu.getCellNames(cu.MasterDict)
	columnHeaders.sort()
	rowHeaders=[]
	tableData=[]
	for report in reports:
		cu.printMsg('\t'+ report[0],False)
		list=[]
		rowHeaders.append(report[0])
		for cell in columnHeaders:
			elements=[]
			configIDs = cu.findConfigIDs('.*/'+cell+report[1],True,cu.MasterDict)
			for configID in configIDs:
				value = cu.MasterDict[configID][report[2]]
				reportScope = report[3]
				if reportScope:
					scope = cu.getScope(configID)
					value = value + '<br>&nbsp;&nbsp;&nbsp;<font size="1">'+scope+'<font size="3">'
				elements.append(value)
			if len(elements) > 0:
				elements.sort()
			list.append(cu.listToString(elements,'\n'))
		tableData.append(list)
	#Setup report dictionaries
	tables={'Title':'Cell Summary','RowHeaders':rowHeaders,'TableData':tableData,'FirstColumnHeader':'','MatchColumn':'ignore'}
	rptParms={'ColumnHeaders':columnHeaders,'Tables':[tables],'MatchColumn':'ignore'}
	reportWrite(rptParms)
	reportFinalize()

#########################################################################################################
# 
#########################################################################################################
def getResourceReportDefinitions():
	return {\
	'DataSource': [{'Title':'Data Source','ReportName':'dataSourceRsc','ConfigPath':[]},\
					{'Title':'Data Source Connection Pool','ReportName':'connectionPoolRsc','ConfigPath':['connectionPool']},\
					{'Title':'Data Source Provider','ReportName':'providerReportRsc','ConfigPath':['provider']},\
					{'Title':'Data Source Relational Resource Adpter','ReportName':'resourceAdapterRsc','ConfigPath':['relationalResourceAdapter']},\
					{'Title':'Data Source Relational Resource Adpter Connector','ReportName':'connectorRsc',\
						'ConfigPath':['relationalResourceAdapter','deploymentDescriptor']}\
					],\
	'J2CResourceAdapter':[{'Title':'J2C Resource Adapter','ReportName':'resourceAdapterRsc','ConfigPath':[]},\
						 {'Title':'J2C Resource Adpter Connector','ReportName':'connectorRsc',\
							'ConfigPath':['deploymentDescriptor']}\
							],\
	'JDBCProvider':[{'Title':'JDBC Provider','ReportName':'jdbcProviderRsc','ConfigPath':[]}],\
	'SIBus':[{'Title':'Service Integration Bus','ReportName':'sibRsc','ConfigPath':[]}],\
	'ObjectCacheInstance':[{'Title':'Object Cache','ReportName':'objectCacheRsc','ConfigPath':[]},\
						  {'Title':'Cache Provider','ReportName':'cacheProviderRsc','ConfigPath':['provider']}\
						  ],\
	'ServletCacheInstance':[{'Title':'Servlet Cache','ReportName':'objectCacheRsc','ConfigPath':[]},\
							{'Title':'Cache Provider','ReportName':'cacheProviderRsc','ConfigPath':['provider']},\
							{'Title':'Disk Cache custom Performance Settings','ReportName':'diskCacheCustomPerformanceSettingsRsc',\
								'ConfigPath':['diskCacheCustomPerformanceSettings']},\
							{'Title':'Disk Cache Eviction Policy','ReportName':'diskCacheEvictionPolicyRsc','ConfigPath':['diskCacheEvictionPolicy']}\
							],\
	'Security':[{'Title':'Global Security','ReportName':'securityRsc','ConfigPath':[]},\
			   {'Title':'Cell Default SSL settings','ReportName':'sslConfigRsc','ConfigPath':['defaultSSLSettings']},\
			   {'Title':'Cell Default SSL settings continued','ReportName':'sslConfig1Rsc','ConfigPath':['defaultSSLSettings','setting']},\
			   {'Title':'Cell Default Trust Store','ReportName':'keyStoreRsc','ConfigPath':['defaultSSLSettings','setting','trustStore']},\
			   {'Title':'Cell Default Key Store','ReportName':'keyStoreRsc','ConfigPath':['defaultSSLSettings','setting','keyStore']},\
			   {'Title':'Cell Default Trust Manager','ReportName':'trustManagerRsc','ConfigPath':['defaultSSLSettings','setting','trustManager']},\
			   {'Title':'Cell Default Key Manager','ReportName':'keyManagerRsc','ConfigPath':['defaultSSLSettings','setting','keyManager']},\
			   {'Title':'Cell Default Common Secure Interoperability (CSI) Inbound','ReportName':'csiv2Rsc','ConfigPath':['CSI','claims']},\
			   {'Title':'Cell Default Common Secure Interoperability (CSI) Inbound ID assertion','ReportName':'csiv2idAssertRsc','ConfigPath':['CSI','claims','layers->IdentityAssertionLayer_']},\
			   {'Title':'Cell Default Common Secure Interoperability (CSI) Inbound ID assertion QOP','ReportName':'csiv2idAssertQOPRsc','ConfigPath':['CSI','claims','layers->IdentityAssertionLayer_','supportedQOP']},\
			   {'Title':'Cell Default Common Secure Interoperability (CSI) Inbound Message','ReportName':'csiv2MessageRsc','ConfigPath':['CSI','claims','layers->MessageLayer_']},\
			   {'Title':'Cell Default Common Secure Interoperability (CSI) Inbound Message supported QOP','ReportName':'csiv2MessageQOPRsc','ConfigPath':['CSI','claims','layers->MessageLayer_','supportedQOP']},\
			   {'Title':'Cell Default Common Secure Interoperability (CSI) Inbound Message required QOP','ReportName':'csiv2MessageQOPRsc','ConfigPath':['CSI','claims','layers->MessageLayer_','requiredQOP']},\
			   {'Title':'Cell Default Common Secure Interoperability (CSI) Inbound Transport','ReportName':'csiv2TransportRsc','ConfigPath':['CSI','claims','layers->TransportLayer_']},\
			   {'Title':'Cell Default Common Secure Interoperability (CSI) Inbound Transport Server Authentication','ReportName':'csiv2TransportSrvSAuthRsc','ConfigPath':['CSI','claims','layers->TransportLayer_','serverAuthentication']},\
			   {'Title':'Cell Default Common Secure Interoperability (CSI) Inbound Transport supported QOP','ReportName':'csiv2TransportQOPRsc','ConfigPath':['CSI','claims','layers->TransportLayer_','supportedQOP']},\
			   {'Title':'Cell Default Common Secure Interoperability (CSI) Inbound Transport required QOP','ReportName':'csiv2TransportQOPRsc','ConfigPath':['CSI','claims','layers->TransportLayer_','requiredQOP']},\
			   {'Title':'Cell Default Common Secure Interoperability (CSI) Outbound','ReportName':'csiv2Rsc','ConfigPath':['CSI','performs']},\
			   {'Title':'Cell Default Common Secure Interoperability (CSI) Outbound ID assertion','ReportName':'csiv2idAssertRsc','ConfigPath':['CSI','performs','layers->IdentityAssertionLayer_']},\
			   {'Title':'Cell Default Common Secure Interoperability (CSI) Outbound ID assertion QOP','ReportName':'csiv2idAssertQOPRsc','ConfigPath':['CSI','performs','layers->IdentityAssertionLayer_','supportedQOP']},\
			   {'Title':'Cell Default Common Secure Interoperability (CSI) Outbound Message','ReportName':'csiv2MessageRsc','ConfigPath':['CSI','performs','layers->MessageLayer_']},\
			   {'Title':'Cell Default Common Secure Interoperability (CSI) Outbound Message supported QOP','ReportName':'csiv2MessageQOPRsc','ConfigPath':['CSI','performs','layers->MessageLayer_','supportedQOP']},\
			   {'Title':'Cell Default Common Secure Interoperability (CSI) Outbound Message required QOP','ReportName':'csiv2MessageQOPRsc','ConfigPath':['CSI','performs','layers->MessageLayer_','requiredQOP']},\
			   {'Title':'Cell Default Common Secure Interoperability (CSI) Outbound Transport','ReportName':'csiv2TransportRsc','ConfigPath':['CSI','performs','layers->TransportLayer_']},\
			   {'Title':'Cell Default Common Secure Interoperability (CSI) Outbound Transport Server Authentication','ReportName':'csiv2TransportSrvSAuthRsc','ConfigPath':['CSI','performs','layers->TransportLayer_','serverAuthentication']},\
			   {'Title':'Cell Default Common Secure Interoperability (CSI) Outbound Transport supported QOP','ReportName':'csiv2TransportQOPRsc','ConfigPath':['CSI','performs','layers->TransportLayer_','supportedQOP']},\
			   {'Title':'Cell Default Common Secure Interoperability (CSI) Outbound Transport required QOP','ReportName':'csiv2TransportQOPRsc','ConfigPath':['CSI','performs','layers->TransportLayer_','requiredQOP']},\
			   {'Title':'Certificate Expiration Monitor','ReportName':'certExpMonitorRsc','ConfigPath':['wsCertificateExpirationMonitor']},\
			   {'Title':'Certificate Expiration Monitor Notification','ReportName':'notificationRsc','ConfigPath':['wsCertificateExpirationMonitor','wsNotification']},\
			   {'Title':'Certificate Expiration Monitor Scedule','ReportName':'scheduleRsc','ConfigPath':['wsCertificateExpirationMonitor','wsSchedule']},\
			   ]\
	}
def hasNoName(resourceType):
	list = ['Security']
	return list.count(resourceType) > 0

#########################################################################################################
# Generates the resource reports (Data Sources, Resource Adapters, etc.
#########################################################################################################
def ResourceReport(report):
	reportType = cu.PropertiesDict[report+':ReportType']
	reportTitle = cu.PropertiesDict[report+':Title']
	cu.printMsg('Generating report ' + reportTitle,False)
	resourceReports = {}

	resourcePropList=cu.getAllPropKeys(report+':Resources:')

	resourceReports = getResourceReportDefinitions()
	resources = []
	columnHeaderFunc = cu.getNameAndScope
	if reportType == 'Security':
		columnHeaderFunc = cu.getScope
		resources = cu.findConfigIDs('.*'+reportType+'_.*', True, cu.MasterDict)
	else:
		scopePropList=cu.getAllPropKeys(report+':Scope:')
		if not len(resourcePropList) == len(scopePropList):
			cu.printMsg('Resources do not match scopes for report '+report,False)
			return
		for idx in range(0, len(scopePropList)):
			scope=cu.PropertiesDict[scopePropList[idx]]
			propID=scopePropList[idx].split(':')[len(scopePropList[idx].split(':'))-1]
			resourceElements=cu.PropertiesDict[report+':Resources:'+propID].split('::')
			if scope == 'Cluster':
				if not len(resourceElements) == 3:
					cu.printMsg('Invalid resources specification for scope Cluster in report '+report,False)
					return
			elif scope == 'Cell':
				if not len(resourceElements) == 2:
					cu.printMsg('Invalid resources specification for scope Cell in report '+report,False)
					return
			elif scope == 'Node':
				if not len(resourceElements) == 3:
					cu.printMsg('Invalid resources specification for scope Node in report '+report,False)
					return
			elif scope == 'Server':
				if not len(resourceElements) == 4:
					cu.printMsg('Invalid resources specification for scope Server in report '+report,False)
					return
			elif scope == 'Application':
				if not len(resourceElements) == 3:
					cu.printMsg('Invalid resources specification for scope Application in report '+report,False)
					return
			else:
				cu.printMsg('Invalid scope "'+scope+'" in report '+report,False)
				return

		for idx in range(0, len(scopePropList)):
			scope=cu.PropertiesDict[scopePropList[idx]]
			propID=scopePropList[idx].split(':')[len(scopePropList[idx].split(':'))-1]
			resourceElements=cu.PropertiesDict[report+':Resources:'+propID].split('::')
			if scope == 'Cluster':
				resources = resources + cu.getConfigIDsByAttrValueFromDict('.*cells/'+resourceElements[0]+'/clusters/'+resourceElements[1]+reportType+'_.*',\
																  resourceElements[2],'name',False,cu.MasterDict)
			elif scope == 'Cell':
				resources = resources + cu.getConfigIDsByAttrValueFromDict('.*cells/'+resourceElements[0]+reportType+'_.*',\
																  resourceElements[1],'name',False,cu.MasterDict)
			elif scope == 'Node':
				resources = resources + cu.getConfigIDsByAttrValueFromDict('.*cells/'+resourceElements[0]+'/nodes/'+resourceElements[1]+reportType+'_.*',\
																  resourceElements[2],'name',False,cu.MasterDict)
			elif scope == 'Server':
				resources = resources + cu.getConfigIDsByAttrValueFromDict('.*cells/'+resourceElements[0]+'/nodes/'+resourceElements[1]+'/servers/'+resourceElements[2]+reportType+'_.*',\
																  resourceElements[3],'name',False,cu.MasterDict)
			elif scope == 'Application':
				resources = resources + cu.getConfigIDsByAttrValueFromDict('.*cells/'+resourceElements[0]+'/applications/'+resourceElements[1]+'/deployments/.*'+reportType+'_.*',\
																  resourceElements[2],'name',False,cu.MasterDict)
			else:
				cu.printMsg('Invalid scope "'+scope+'" in report '+report,False)
				return

	if len(resources) == 0:
		cu.printMsg('ERROR: no resources found for the report.' ,False)
		return
	cu.printMsg(reportType + ' list:',False)
	for resource in resources:
		cu.printMsg('\t\t'+cu.MasterDict[resource]['name'],False)

	reportInitialize(reportTitle,cu.PropertiesDict[report+':FileName'])

	rptParms={'ServerList':resources,'ColumnHeaderFunc':columnHeaderFunc}
	for resourceReport in resourceReports[reportType]:
		rptParms['ConfigPath'] = resourceReport['ConfigPath']
		rptParms['Title'] = resourceReport['Title']
		rptParms['ReportName'] = resourceReport['ReportName']
		reportConfigElementAttrList(rptParms)
		reportProperties(rptParms)
	reportWrite(rptParms)
	reportFinalize()

#########################################################################################################
# This report finds all resources by the same name and generates reports on them
#########################################################################################################
def reportAllResourcesByName():
	resourceTypes=['Security','DataSource','J2CResourceAdapter','JDBCProvider','ObjectCacheInstance','ServletCacheInstance','SIBus']
	resourceReports = getResourceReportDefinitions()
	reportInitialize('Singleton resources and resources compared by name','Resources')
	cu.printMsg('Generating report of all of the following resource types by resource name: ' + str(resourceTypes),False)
	for resourceType in resourceTypes:
		cu.printMsg('\tGenerating reports for ' + resourceType,False)
		names = []
		if hasNoName(resourceType):
			names = [resourceType]
		else:
			names = cu.getUniqueConfigAttrValues(resourceType,'name')
		for name in names:
			cu.printMsg('\t\tGenerating report for ' + name,False)
			rptParms = {}
			if hasNoName(resourceType):
				resources = cu.findConfigIDs('.*'+re.escape('#'+resourceType+'_')+'.*', True, cu.MasterDict)
				resources = cu.sortByCellAndScope(resources,cu.getScopeSort)
				rptParms={'ServerList':resources,'ColumnHeaderFunc':cu.getScope}
			else:
				list = []
				resources = cu.getConfigIDsByAttrValueFromDict('.*'+re.escape('#'+resourceType+'_')+'.*',re.escape(name),'name',False,cu.MasterDict)
				for resource in resources:
					if cu.MasterDict[resource]['name'] == name:
						list.append(resource)
						list = cu.sortByCellAndScope(list,cu.getNameAndScopeSort)
				rptParms={'ServerList':list,'ColumnHeaderFunc':cu.getNameAndScope}
			for resourceReport in resourceReports[resourceType]:
				rptParms['ConfigPath'] = resourceReport['ConfigPath']
				if hasNoName(resourceType):
					rptParms['Title'] = resourceReport['Title']
				else:
					rptParms['Title'] = resourceReport['Title'] + ' (' + name + ')'
				rptParms['ReportName'] = resourceReport['ReportName']
				reportConfigElementAttrList(rptParms)
				reportProperties(rptParms)
			reportWrite(rptParms)
	reportFinalize()

#########################################################################################################
#########################################################################################################
# Execution logic begins here 
#########################################################################################################
#########################################################################################################
if len(sys.argv) < 2:
	print 'Syntax:'
	print '\tpython '+ sys.argv[0] + ' [PropertiesFile]'
	sys.exit(0)

cu.printMsg('Begin run.',False)

propIdx = 0
if sys.argv[0].find('.py') > 0:
	propIdx = 1

cu.readProperties(sys.argv[propIdx])

#Get configurations 
cu.readConfigs()


#Run other defined reports
reportProp = cu.PropertiesDict['ReportList'].strip()
if len(reportProp) > 0:
	if reportProp == 'All':
		reportList = cu.getAllPropKeys('.*:ReportType')
		reports = ['Summary','Resources']
		for report in reportList:
			reports.append(report.split(':')[0])
	else:
		reports = reportProp.split(',')
	for report in reports:
		report = report.strip()
		reportType = ''
		if report == 'Summary' or report == 'Resources':
			reportType = report
		else:
			reportType = cu.PropertiesDict[report+':ReportType']
		if reportType == 'Summary':
			CellSummaryReport()
		elif reportType == 'Resources':
			reportAllResourcesByName()
		elif reportType == 'Server':
			ServerReport(report)
		elif reportType == 'DataSource':
			ResourceReport(report)
		elif reportType == 'J2CResourceAdapter':
			ResourceReport(report)
		elif reportType == 'JDBCProvider':
			ResourceReport(report)
		elif reportType == 'ObjectCacheInstance':
			ResourceReport(report)
		elif reportType == 'ServletCacheInstance':
			ResourceReport(report)
		elif reportType == 'SIBus':
			ResourceReport(report)
		elif reportType == 'Security':
			ResourceReport(report)
		else:
			cu.printMsg('ERROR: Invalid report type: ' + reportType,False)

cu.printMsg('End run.',False)
