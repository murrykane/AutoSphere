##########################################################################################
# Author: Dennis Riddlemoser
# This script has library functions for ConfigDump.py and ConfigUtils.py
##########################################################################################
# Change history:
# Date        Ref  Who  Comments
# 2018/01/17  0001 DWR  Added logic to handle unsupported configuration types.
#
import WAuJ_utilities as WAuJ
import sys
import time
import re
import glob
import os
import threading

True=1
False=0
Debug=False

RepositoryFile=''

MasterDict = {}
PropertiesDict = {}

#lists all configuration elements that are effectively collections of name/value pairs
PropertyAttributes=['properties','customProperties','systemProperties','environment']

#########################################################################################################
#prints a message to stdout.  There are two levels of messages, standard and debug.
#the latter are only printed if Debug is set to true
#########################################################################################################
def printMsg(msg,dbg):
	global Debug
	if Debug or not dbg:
		print time.strftime('[%y/%m/%d %H:%M:%S] ') + str(msg)

#Ref0002 Begin: Added to improve exception reporting 
#########################################################################################################
#prints a message to stdout.  There are two levels of messages, standard and debug.
#the latter are only printed if Debug is set to true
#########################################################################################################
def printException(msg,exceptionInfo):
	for line in exceptionInfo:
		msg=msg+'\n'+str(line)
	printMsg('ERROR: ' + msg,False)
#Ref0002 End


#########################################################################################################
# Strips off the end characters of a string.
#
# str = String to strip end characters from
#
# return new string minus end characters
#########################################################################################################
def stripEndChars(str):
	return str[1:-1]

#########################################################################################################
# Converts a string into a list of items
#
# str = String to strip end characters from
#
# return new string minus end characters
#########################################################################################################
def stringListAsList(strList):
	strList=stripEndChars(strList).strip()
	rtnVal = []
	if len(strList) > 0:
		rtnVal = strList.split(' ')
	return rtnVal

#########################################################################################################
# Returns True if the string represents a configuration ID
#
# cfg = String which may or may not be a configuration element ID
#
# return true is cfg is a configuration element ID
#BUGBUG should use regular expressions, needs to be rewritten
#########################################################################################################
def isConfigID(cfg):
	printMsg('isConfigID => '+cfg, True)
	rtnVal = False
	try:
		rtnVal = cfg.find('(') > -1 and cfg.find('#') > -1 and cfg.find('|') > -1 and cfg.find(')') > -1
	except:
		'Do Nothing'
	printMsg('isConfigID <= '+str(rtnVal), True)
	return rtnVal

#########################################################################################################
# Returns true if element is equal to the value that is most common in the list. 
#
# element = value to check in the list
# list = arbitrary list of values
#
# return true is cfg is a configuration element ID
#########################################################################################################
def isMostCommon(element,list):
	count=0
	for x in list:
		if element == x:
			count=count+1
	rtnVal = True
	for x in list:
		i=0
		for y in list:
			if x==y:
				i=i+1
		if count < i:
			rtnVal = False
	return rtnVal

#Ref0001 Begin
#########################################################################################################
# Uses AdminConfig to iterate through a list of top level configuration elements to retrieve
#########################################################################################################
def getConfigElements(configElements,AdminConfig):
	#the following is a hack as a com.ibm.websphere.management.exception.InvalidConfigDataTypeException cannot be caught
	for configElement in configElements:
		t = threading.Thread(name=configElement,target=getConfigElements2, args=(configElement,AdminConfig,))
		printMsg('Getting all elements of type ' + configElement[1],False)
		t.start()
		while t.isAlive():
			time.sleep(1)

#		try:
#			elements = AdminConfig.list(configElement[1]).splitlines()
#			for element in elements:
#				printMsg(configElement[0] + element,False)
#				getConfigAsDict(element,AdminConfig)
#		except:
#			printMsg('ERROR: ' + configElement + ' cannot be read.',False)
#			for msg in sys.exc_info():
#				printMsg(msg,False)

def getConfigElements2(configElement,AdminConfig):
	elements = AdminConfig.list(configElement[1]).splitlines()
	printMsg('Found ' + str(len(elements)) + ' ' + configElement[1],False)
	for element in elements:
		printMsg(configElement[0] + element,False)
		getConfigAsDict(element,AdminConfig)
#Ref0001 End
	

#########################################################################################################
# Uses AdminConfig to get the attributes of the given configuration object then makes a Dictionary object 
# from the information.  Recursively gathers all referenced configuration IDs using the same algorithm.
#
# return the resulting dictionary
#########################################################################################################
def getConfigAsDict(cfg,AdminConfig):
	global MasterDict
	cDict = {}
	if not MasterDict.has_key(cfg):
		printMsg('Getting ' + cfg,True)
		#if AdminConfig reference fials with a NameError, establish a reference to it from system local name space for WASv9
#		AdmConfig = None
#		try:
#			AdmConfig = AdminConfig
#		except:
#			print str(sys._getframe(1).f_locals)
#			AdmConfig = sys._getframe(1).f_locals['AdminConfig']
		try:
			attrs=AdminConfig.show(cfg)
			if attrs == None:
				attrs = []
			else:
				attrs = attrs.splitlines()
			printMsg(attrs,True)
			for attr in attrs:
				attr = stripEndChars(attr)
				idx=attr.find(' ')
				key=attr[:idx]
				value=attr[idx+1:]
				cDict.update({key:value})
#			printMsg('Length: ' + str(len(str(cDict))) + ' CfgID: ' + cfg,False) 
#			if len(str(cDict)) > 10240:
#				printMsg('==== ' + str(cDict),False)
			MasterDict.update({cfg:cDict})
			keys=cDict.keys()
			for key in keys:
				printMsg('key == '+key+' value == '+cDict[key],True)
				if isConfigID(cDict[key]):
					if cDict[key].find('[') == 0:
						cfgIDList = WAuJ.stringListAsList(cDict[key])
						printMsg('cfgIDList-->'+str(cfgIDList),True)
						while len(cfgIDList)>0:
							getConfigAsDict(cfgIDList.pop(),AdminConfig)
					else:
						getConfigAsDict(cDict[key],AdminConfig)
		except:
			printMsg("ERROR: Getting config ID: " + cfg,False)
			for msgLine in sys.exc_info():
				printMsg('\t'+str(msgLine),False)
			
	else:
		printMsg("Master Dictionary contains " + cfg,True)
		cDict=MasterDict[cfg]
	debug=False
	return cDict

#########################################################################################################
# Read properties from a file.  Similar to a Java properties file but not nearly as robust.  Key/value 
# from the properties file are stored as key/value pairs in the PropertiesDict dictionary.
# Example:
#    Properties File:
#        key=value
#    PropertiesDict:
#        PropertiesDict[key]=value
#########################################################################################################
def readProperties(propertiesFile):
	global PropertiesDict
	printMsg('Reading properties from '+propertiesFile,False)
	f = open(propertiesFile,'r')
	lines = f.readlines()
	f.close()
	key='NOT_INITIALIZED'
	append=False
	for line in lines:
		line=line.strip()
		if len(line) > 0 and not line[0] == '#':
			if append:
				if line[len(line)-1]=='\\':
					append=True
					line=line[:-1].strip()
				else:
					append=False
				PropertiesDict[key]=PropertiesDict[key]+line
			if line.find('#') == 0:
				ignoreThisLine='ignoreThisLine'
			elif line.find('=') > 0:
				idx=line.find('=')
				key=line[:idx].strip()
				value=line[idx+1:].strip()
				if len(value) > 0 and value[len(value)-1]=='\\':
					append=True
					value=value[:-1].strip()
				PropertiesDict[key]=value
			elif len(line.strip()) == 0:
				printMsg('Invalid line: '+line,False)
	printMsg('readProperties => '+str(PropertiesDict),True)
	
#########################################################################################################
# Stores the repository file name or directory input from the command line
#########################################################################################################
def setRepositoryConfigFileName(name):
	global RepositoryFile
	RepositoryFile=name

#########################################################################################################
# Writes the cell configuration out to a file.  The format is config IDs are not indented.  Attributes
# associated with coinfig IDs follw the config ID and are indented with a tab.
# Example:
# ConfigID1
# \tAttribute1=value
# \tAttribute2=value
# ConfigID2
# \tAttribute1=value
# \tAttribute2=value
# \tAttribute3=value
#########################################################################################################
def writeRepositoryFile():
	global MasterDict
	global RepositoryFile
	timeStamp=time.strftime('-%y%m%d%H%M%S')
	defaultFile='ConfigDump'+time.strftime('-%y-%m-%d-%H-%M-%S')+'.cfg'
	try:
		#Try to get the cell name WAS property
		defaultFile=getCellNames(MasterDict)[0]+time.strftime('-%y-%m-%d-%H-%M-%S')+'.cfg'
	except:
		try:
			defaultFile=getConfigIDCell(MasterDict.keys()[0])+time.strftime('-%y-%m-%d-%H-%M-%S')+'.cfg'
		except:
			None
	if RepositoryFile=='':
		RepositoryFile=defaultFile
	elif os.path.exists(RepositoryFile):
		if os.path.isdir(RepositoryFile):
			RepositoryFile = RepositoryFile + os.sep + defaultFile
		elif os.path.isfile(RepositoryFile):
			printMsg('File '+RepositoryFile+' exists, cannot write output file.',False)
			sys.exit(2)
	printMsg('Writing repository config file to '+RepositoryFile,False)
	f = open(RepositoryFile,'w')
	f.write('CellSuffix='+timeStamp+'\n')
	mkeys = MasterDict.keys()
	while len(mkeys)>0:
		mkey = mkeys.pop()
		f.write(mkey+'\n')
		printMsg('Key ' + mkey + '\n' + str(MasterDict[mkey]),True)
		keys = MasterDict[mkey].keys()
		while len(keys)>0:
			key = keys.pop()
			f.write('\t'+key+'='+MasterDict[mkey][key]+'\n')
	f.close()

#########################################################################################################
# Reads the cell config from a file per the format defined in writeConfig()
#########################################################################################################
def addCellSuffix(value,cellSuffix):
	idx = 0
	if isConfigID(value):
		while value.find('cells/',idx) > -1:
			idx=value.find('cells/',idx) + 6
			idx1=value.find('/',idx)
			idx2=value.find('|',idx)
			if idx1>-1 and idx1<idx2:
				idx=idx1
			else:
				idx=idx2
			value=value[0:idx]+cellSuffix+value[idx:]
	return value

#########################################################################################################
# Reads the cell config from a file per the format defined in writeConfig()
#########################################################################################################
def readConfigs():
	global MasterDict
	global PropertiesDict
	fileNames=[]
	for fileSpec in PropertiesDict['ConfigurationDumpFiles'].split(','):
		for fileName in glob.glob(fileSpec.strip()):
			fileNames.append(fileName)
	if len(fileNames) == 0:
		printMsg('ERROR: No configuration files found',False)
		sys.exit(1)
	for fileName in fileNames:
		fileName =  str(fileName)
		printMsg('Reading repository config from ' + fileName,False)
		f = open(fileName,'r')
		lines = f.readlines()
		f.close()
		currentKey='NOT_INITILIZED'
		currentDict={}
		debug = False
		cellSuffix=''
		for line in lines:
			if line.find('CellSuffix') == 0:
				idx=line.find('=')
				cellSuffix=line[idx+1:-1].strip()
			elif line.find('\t')==0:
				idx=line.find('=')
				key=line[1:idx]
				value=line[idx+1:-1]
				currentDict[key]=addCellSuffix(value,cellSuffix)
			else:
				if not currentKey=='NOT_INITILIZED':
					MasterDict[currentKey]=currentDict
				currentDict={}
				currentKey=line[:-1]
				currentKey=addCellSuffix(currentKey,cellSuffix)
		MasterDict[currentKey]=currentDict
	#BUGBUG detect for cell name collision
	MasterDict['CellList'] = getCellNames(MasterDict);

#########################################################################################################
# cluster = cluster configuration ID
#
# return the config IDs for all cluster members in a cluster
#########################################################################################################
def getClusterServerList(cluster):
	printMsg('getClusterServerList => '+cluster, True)
	members = WAuJ.stringListAsList(MasterDict[cluster]['members'])
	serverConfigIDs = []
	serverExcludeList=''
	try:
		PropertiesDict['ServerExcludeList'].split(',')
	except:
		None
	servers=findConfigIDs('.*\#Server_.*',True,MasterDict)
	for member in members:
		for server in servers:
			if not MasterDict[member]['memberName'] in serverExcludeList and \
				MasterDict[member]['memberName'] == MasterDict[server]['name'] and \
				getConfigIDCell(cluster)==getConfigIDCell(server):
				serverConfigIDs.append(server)
	printMsg('getClusterServerList <= '+str(serverConfigIDs), True)
	return serverConfigIDs

#########################################################################################################
# Determines if all elements in a list are equal.
#
# returns "Yes" if all elements are equal, otherwise "No"  "N/A" is returned if the list has 0 or 1 elements
#########################################################################################################
def listElementsMatch(lst):
	printMsg('listElementsMatch => '+str(lst), True)
	rtnVal = 'Yes'
	if len(lst) < 2:
		rtnVal = 'N/A'
	else:
		val=lst[0]
		for nextVal in lst:
			if not val == nextVal:
				rtnVal = 'No'
			val = nextVal
	printMsg('listElementsMatch <= '+str(rtnVal), True)
	return rtnVal

#########################################################################################################
# Finds a matching element in the list
#
# Return the last item in the list which matches the pattern or "NOT_FOUND"
#########################################################################################################
def getMatchingItemFromList(pattern,lst):
	printMsg('getMatchingItemFromList => '+pattern+'  '+str(lst), True)
	rtnVal='NOT_FOUND'
	for val in lst:
		if val.find(pattern) >-1:
			rtnVal=val
	printMsg('getMatchingItemFromList <= '+str(rtnVal), True)
	return rtnVal

#########################################################################################################
# Navigates through config element references and returns the one specified.
# Example:
#   ['processDefinitions->JavaProcessDef_','execution']
#   This will find the config ID within processDefinitions matching "JavaProcessDef_" then return the
#   dictionary for the config ID in "execution"
#
# pathElements = list of path elements to navigate
#
# returns an empty dictionary if not found, otherwise the config ID dictionary.  
# BUGBUG, needs to be designed to be recursive and evaluate one element at a time
#########################################################################################################
def getConfigFromPath(pathElements):
	printMsg('getConfigFromPath => '+str(pathElements), True)
	absPath=re.compile('.*/__.*__/.*')
	rtnVal = {}
	if len(pathElements) > 1 and type({}) == type(pathElements[1]):
		newPath = pathElements[1]['function'](pathElements[0],pathElements[1]['args'])
		if len(pathElements) > 2:
			newPath=newPath+pathElements[2:]
		rtnVal = getConfigFromPath(newPath)
	elif len (pathElements) == 2 and absPath.match(pathElements[1]):
		configID=pathElements[1].replace('__SERVER__',MasterDict[pathElements[0]]['name'])
		configID=configID.replace('__NODE__',getConfigIDNode(pathElements[0]))
		configID=findConfigIDs(configID,False,MasterDict)
		if len(configID) > 0:
			rtnVal=MasterDict[configID]
	else:
		for pathElement in pathElements:
			idx = pathElement.find('->')
			try:
				if idx > 0:
					rtnVal = MasterDict[getMatchingItemFromList(pathElement[idx+2:],WAuJ.stringListAsList(rtnVal[pathElement[:idx]]))]
				elif isConfigID(pathElement):
					rtnVal = MasterDict[pathElement]
				else:
					rtnVal = MasterDict[rtnVal[pathElement]]
			except KeyError:
				None
			except:
				#print "Unexpected error:", sys.exc_info()[0]
				None
#				printMsg('WARNING: path not found ' + str(pathElements), False)
				rtnVal = {}
	printMsg('getConfigFromPath <= '+str(rtnVal), True)
	return rtnVal

#########################################################################################################
# Returns the scope for sorting column headers
#########################################################################################################
def getScope(configID):
	rtnVal = ''
	scopeStr=configID[configID.find('cells/'):configID.find('|')]
	name=False
	for element in scopeStr.split('/'):
		if name:
			rtnVal = rtnVal + element + ' '
		else:
			rtnVal = rtnVal + element[:-1] + ": "
		name = not name
	return rtnVal

#########################################################################################################
# Returns the name attribute and scope for sorting column headers
#########################################################################################################
def getNameAndScopeSort(configID):
	return '(' + getScopeSort(configID) + ') ' + MasterDict[configID]['name']

#########################################################################################################
# Returns the scope for inclusion in the Summary report
#########################################################################################################
def getScopeSort(configID):
	rtnVal = ''
	scopeStr=configID[configID.find('cells/'):configID.find('|')]
	for element in scopeStr.split('/'):
		rtnVal = rtnVal + element + ' '
	return rtnVal

#########################################################################################################
# Returns the name attribute and scope for inclusion in the Summary report
#########################################################################################################
def getNameAndScope(configID):
	return MasterDict[configID]['name'] + ' (' + getScope(configID) + ')'

#########################################################################################################
# Returns the node of a config ID
#########################################################################################################
def getConfigIDCell(configID):
	printMsg('getConfigIDCell => '+ configID, True)
	rtnVal = 'getConfigIDCell_error_cell_not_found'
	idx = configID.find("cells/")
	if  idx > -1:
		rtnVal = configID[idx+6:]
		if rtnVal.find("/") > -1:
			rtnVal = rtnVal.split("/")[0]
		if rtnVal.find("|") > -1:
			rtnVal = rtnVal.split("|")[0]
	printMsg('getConfigIDCell <= '+rtnVal, True)
	return rtnVal

#########################################################################################################
# Returns the node of a config ID
#########################################################################################################
def getConfigIDNode(configID):
	printMsg('getConfigIDNode => '+configID, True)
	rtnVal=configID.split('/')[3]
	printMsg('getConfigIDNode <= '+rtnVal, True)
	return rtnVal

#########################################################################################################
# Returns the server of a config ID
#########################################################################################################
def getConfigIDServer(configID):
	printMsg('getConfigIDServer => '+configID, True)
	rtnVal=configID.split('/')[5].split('|')[0]
	printMsg('getConfigIDServer <= '+rtnVal, True)
	return rtnVal

#########################################################################################################
# Returns config IDs based on a regular expression.  Returns all found in a list if all = true
#########################################################################################################
def findConfigIDs(regexStr, all, dict):
	printMsg('findConfigIDs => '+regexStr, True)
	global MasterDict
	if dict == None:
		dict = MasterDict
	keys=dict.keys()
	regex=re.compile(regexStr)
	rtnVal=[]
	for key in keys:
		if regex.match(key):
			rtnVal.append(key)
	if all:
		printMsg('findConfigIDs <= '+str(rtnVal), True)
		return rtnVal
	else:
		if len(rtnVal) > 1:
			printMsg('findConfigIDs WARNING regex "' + regexStr + '" has more than one matching value. ' + str(rtnVal),False)
		elif len(rtnVal) == 0:
			printMsg('findConfigIDs WARNING regex "' + regexStr + '" did not find a matching value. ',False)
			return ''
		printMsg('findConfigIDs <= '+ str(rtnVal), True)
		return rtnVal[0]

#########################################################################################################
# Returns the PMI config for a given server
#########################################################################################################
def getPMIConfig(moduleName,server):
	printMsg('getPMIConfig => '+moduleName+' '+server, True)
	global MasterDict
	serverName=MasterDict[server]['name']
	nodeName=getConfigIDNode(server)
	rtnVal={'NOT_FOUND':'NOT_FOUND'}
	keys=findConfigIDs('.*/'+nodeName+'/.*/'+serverName+'.pmi-config.xml.PMIModule_.*',True,MasterDict)
	for key in keys:
		if MasterDict[key].has_key('moduleName') and MasterDict[key]['moduleName'] == moduleName:
			rtnVal=MasterDict[key]
			break
	printMsg('getPMIConfig <= '+str(rtnVal), True)
	return rtnVal

#########################################################################################################
# Returns the PMI enable attribute sorted 
#########################################################################################################
def getPMICellValue(pmiConfig):
	rtnVal='not configured'
	if pmiConfig.has_key('enable'):
		enable=pmiConfig['enable']
		if enable=='[]':
			enable='not configured'
		if not enable=='not configured':
			enableVals=enable.split(',')
			intVals=[]
			for val in enableVals:
				intVals.append(int(val))
			intVals.sort()
			rtnVal=''
			for i in intVals:
				rtnVal=rtnVal+str(i)+', '
			rtnVal=rtnVal[:-2]
	return rtnVal

#########################################################################################################
# 
#########################################################################################################
def getCellNames(configDict):
	if configDict==None:
		configDict=MasterDict
	rtnVal = []
	keys = configDict.keys()
	for key in keys:
		idx = key.find("cells/")
		if  idx > -1:
			cell = getConfigIDCell(key)
			if rtnVal.count(cell) < 1:
				rtnVal.append(cell)
#	vars = findConfigIDs('.*VariableSubstitutionEntry.*',True,configDict)
#	for var in vars:
#		if configDict[var]['symbolicName']=='WAS_CELL_NAME':
#			cellName=configDict[var]['value']
#			if rtnVal.count(cellName) > 0:
#				printMsg('ERROR: Duplicate cell names found.  '+cellName, False)
#				sys.exit(0)
#			rtnVal.append(cellName)
	printMsg('getCellNames => '+str(rtnVal), True)
	return rtnVal

#########################################################################################################
# Converts a list to a string using the provided delimeter 
#########################################################################################################
def listToString(list,delimeter):
	rtnVal=''
	for element in list:
		rtnVal = rtnVal+element+delimeter
	return rtnVal[:len(delimeter) * -1]

#########################################################################################################
# Returns the config ID based on an attribute value from the specified dictionary
#########################################################################################################
def getConfigIDsByAttrValueFromDict(regexStr,attrValue,attrName,singleton,dictionary):
	printMsg('getConfigIDsByAttrValueFromDict => '+regexStr+','+attrValue+','+attrName, True)
	rtnVal = []
	configIDs=findConfigIDs(regexStr,True,dictionary)
	regex=re.compile('.*'+attrValue+'.*')
	for configID in configIDs:
		if regex.match(dictionary[configID][attrName]):
			rtnVal.append(configID)
	if singleton:
		if len(rtnVal) == 0:
			printMsg('WARNING no ID found => '+regexStr+','+attrValue+','+attrName, True)
			rtnVal='NOT_FOUND'
		elif len(rtnVal) == 1:
			rtnVal = rtnVal[0]
		elif len(rtnVal) > 1:
			printMsg('WARNING no ID found => '+regexStr+','+attrValue+','+attrName, True)
			rtnVal = rtnVal[0]
	printMsg('getConfigIDsByAttrValueFromDict <= '+str(rtnVal), True)
	return rtnVal

#########################################################################################################
# Returns the config ID based on an attribute value
#########################################################################################################
def getConfigIDByAttrValue(regexStr,attrValue,attrName):
	rtnVal = getConfigIDsByAttrValueFromDict(regexStr,attrValue,attrName,True,MasterDict)
	return rtnVal

#########################################################################################################
# Returns the config ID of a server in a cell
#########################################################################################################
def getServerConfigIDs(cell,node,name):
	servers = getConfigIDsByAttrValueFromDict('.*/'+cell+'.*/'+node+'/.*'+re.escape('#Server_')+'.*',name,'name',False,MasterDict)
	rtnVal = []
	for server in servers:
		print server
		try:
			if MasterDict[server]['serverType'] == 'APPLICATION_SERVER':
				rtnVal.append(server)
		except:
			None
	return rtnVal

#########################################################################################################
# Returns the config ID of a cluster in a cell
#########################################################################################################
def getClusterConfigIDs(cell,name):
	#print cell + ' : ' + name
	rtnVal = getConfigIDsByAttrValueFromDict('.*/'+cell+'/.*'+re.escape('#ServerCluster_')+'.*',name,'name',False,MasterDict)
	#print 'rtn: ' + str(rtnVal)
	return rtnVal

#########################################################################################################
# Returns all properties matching the regex from PropertiesDict
#########################################################################################################
def getAllPropKeys(regex):
	regex=re.compile(regex)
	rtnVal=[]
	keys=PropertiesDict.keys()
	for key in keys:
		if regex.match(key):
			rtnVal.append(key)
	return rtnVal

#########################################################################################################
# Returns the Data Source with the given JNDI name
#########################################################################################################
def getDataSourceByJNDI(cell,node,server,name):
	return getConfigIDsByAttrValueFromDict('.*'+cell+'/nodes/'+node+'/servers/'+server+'.*DataSource_.*',name,'jndiName',False,MasterDict)

#########################################################################################################
# Returns the Data Source for a servver report
#########################################################################################################
def getDataFromConfigPath(server,path):
	path.insert(0,server)
	return getDataSourceByJNDI(getConfigIDCell(server),getConfigIDNode(server),getConfigIDServer(server),getConfigFromPath(path)['datasourceJNDIName'])

def getUniqueConfigAttrValues(configType,attr):
	configIDs = findConfigIDs('.*'+re.escape('#'+configType+'_')+'.*', True, MasterDict)
	values = []
	for configID in configIDs:
		if values.count(MasterDict[configID][attr]) == 0:
			values.append(MasterDict[configID][attr])
	values.sort()
	return values

#########################################################################################################
# Sorts the input list by the scope function 
#########################################################################################################
def sortByCellAndScope(list,scopeFunc):
	tempList = []
	idx=0
	for resource in list:
		scope = scopeFunc(resource)
		tempList.append(scope+'%'+str(idx))
		idx = idx + 1
	tempList.sort()
	sortedList = []
	for resource in tempList:
		idx = int(resource.split('%')[1])
		sortedList.append(list[idx])
	return sortedList