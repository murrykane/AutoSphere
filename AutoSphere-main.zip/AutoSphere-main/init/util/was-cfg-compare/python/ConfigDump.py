##########################################################################################
# Author: Dennis Riddlemoser
# This script dumps out the majority of a server or cell configuration in a text format 
# for use with ConfigReport.py to compare configurations.
##########################################################################################
# Change history:
# Date        Ref  Who  Comments
# 2018/01/17  0001 DWR  Added logic to handle unsupported configuration types.
# 2018/01/19  0002 DWR  Added logic to handle systems where the environment is not present.
#

import sys
import os

#Ref0002 Begin
def printException(msg,exceptionInfo):
	for line in exceptionInfo:
		msg=msg+'\n'+str(line)
	print 'ERROR: ' + msg

#Load libraries from where the path they are installed.
path = None
try:
	path = os.getenv('IBM_JAVA_COMMAND_LINE')
	path=path[path.find("-f") + 2:].strip()
	path=path.split(' ')[0]
	if path.find(os.sep) > -1:
		path=path.split(' ')[0]
		path=path[:path.rfind(os.sep)+1]
	else:
		path = ''
except:
	printException('Could not get command line from environment.',sys.exc_info())

sys.path.append(path)
try:
	import ConfigUtils as cu
except:
	printException('Failed to load support scripts.',sys.exc_info())
#Ref0002 End

#########################################################################################################
#########################################################################################################
# Gets configuration data from the repository
#########################################################################################################
#########################################################################################################
True=1
False=0

#Ref0002 Begin
try: 
	cu.printMsg('Begin run.',False)
except:
	print 'ERROR, cannot continue.  Failed to load support scripts.  Run wsadmin -f ConfigDump.py from the same directory it exists in.'
	sys.exit(1)

if len(sys.argv) > 0:
	cu.setRepositoryConfigFileName(sys.argv[0])
#Ref0002 End

configElementList = [['Getting cluster configuration ','ServerCluster'],\
					 ['Getting server configuration ','Server'],\
					 ['Getting PMI configuration ','PMIModule'],\
					 ['Getting Global Security configuration ','Security'],\
					 ['Getting Security Domain configuration ','SecurityDomain'],\
					 ['Getting Authorization Table ','AuthorizationTableExt'],\
					 ['Getting Audit configuration ','Audit'],\
					 ['Getting cell configuration ','Cell'],\
					 ['Getting Core Group configuration ','CoreGroup'],\
					 ['Getting Core Group Bridge configuration ','CoreGroupBridgeSettings'],\
					 ['Getting cell variables ','VariableMap'],\
					 ['Getting Virtual Host configuration ','VirtualHost'],\
					 ['Getting cell Web Services Security configuration ','WSSecurity'],\
					 ['Getting Object Pool Provider configuration ','ObjectPoolProvider'],\
					 ['Getting Work Manager Provider configuration ','WorkManagerProvider'],\
					 ['Getting Schedular Provider configuration ','SchedulerProvider'],\
					 ['Getting JMS Provider configuration ','JMSProvider'],\
					 ['Getting J2C Resource Adapter configuration ','J2CResourceAdapter'],\
					 ['Getting Mail Provider configuration ','MailProvider'],\
					 ['Getting URL Provider configuration ','URLProvider'],\
					 ['Getting JDBC Provider configuration ','JDBCProvider'],\
					 ['Getting Resource Environment Provider configuration ','ResourceEnvironmentProvider'],\
					 ['Getting Data Source configuration ','DataSource'],\
					 ['Getting Service Inigration Bus configuration ','SIBus'],\
					 ['Getting JAX RPC handler configuration ','JAXRPCHandler'],\
					 ['Getting Servlet Cache Instance configuration ','ServletCacheInstance'],\
					 ['Getting Object Cache Instance configuration ','ObjectCacheInstance'],\
					 ['Getting SIB configuration ','SIBus'],\
					 ['Getting SIB WS Security Request Consumer Binding configuration ','SIBWSSecurityRequestConsumerBindingConfig'],\
					 ['Getting SIB WS Security Request Generator Binding configuration ','SIBWSSecurityRequestGeneratorBindingConfig'],\
					 ['Getting SIB WS Security Response Consumer Binding configuration ','SIBWSSecurityResponseConsumerBindingConfig'],\
					 ['Getting SIB WS Security Response Generator Binding configuration ','SIBWSSecurityResponseGeneratorBindingConfig'],\
					 ['Getting Application Deployment configuration ','ApplicationDeployment'],\
					 ]
		
#Ref0001 Moved logic into ConfigUtils.py
cu.getConfigElements(configElementList,AdminConfig)
#Ref0001 End
cu.writeRepositoryFile()

print AdminConfig.queryChanges()

cu.printMsg('End run.',False)
