setInstance() {
    # set environment values based on instance variable        
	case ${1} in
		*ConsumerBatch*) appRoot=(BATCH_NO_URL);;
		*Consumer*) appRoot=bsca/home/home.sp;;
		*CSAdmin*) appRoot=admin/bsc/csr/csr_90.sp;;
		*Content*) appRoot=sites/csac/home.sp;;
		*Preference*) appRoot="preference/optOutPage.jsp?email=testEmail@blueshieldca.com&comList=2088399533&action=0";;
		*ProviderBatch*) appRoot=(BATCH_NO_URL);;
		*Provider*) appRoot=provider/home.sp;;
		*ProducerBatch*) appRoot=(BATCH_NO_URL);;
		*Producer*) appRoot=producer/home.sp;;
		*EPresent*|*ePresent*) appRoot=(BATCH_NO_URL);;
		*ESSBatch*) appRoot=(BATCH_NO_URL);;
		*ESS*) appRoot=employer/ess/login.jsp;;
		*FAPBatch*) appRoot=(BATCH_NO_URL);;
		*FAP*) appRoot=fap/app/search.html;;
	    mlpBatch*) appRoot=(BATCH_NO_URL);;
		*MobileWeb*) appRoot=;;
		*MobileApi*) appRoot=;;
		*MobileSvc*) appRoot=;;
		*CWS*|*cws*) appRoot=employer/cws/login/structure/login_fr.jsp;;
		*VRU*|*vru*) appRoot=vru_test;;
                *) appRoot=;; 
	esac
 } 
 
 getRealm() {
    # set environment values based on instance variable        
	case ${1} in
		WEBN*|MOBN*) realm=npe;;
		WEBH*|MOBH*) realm=phi;;
		WEBS*) realm=stage;;
		*Stg*) realm=intStage;;
		WEBP*|PROD*|mobile*|*Prod*) realm=prod;;
                *) realm="-";; 
	esac
 } 


     
     XML_HOME=/cygdrive/c/svnprod/AutoSphere/xml
	 SHIELD_HOME=/cygdrive/c/svnprod/AutoSphere
     #CLASSPATH="/opt/jenkins/AutoCommon/lib/xmlParser:/opt/jenkins/AutoCommon/lib:/opt/jenkins/java/solaris/64bit/jre/bin"
     #CLASSPATH="/cygdrive/c/svnprod/java"
	 PATH=$PATH;/cygdrive/c/svnprod/ant/bin/ant
     ANT_HOME=/cygdrive/c/svnprod/ant
	 JAVA_HOME=/cygdrive/c/svnprod/java
	 JAVA=${JAVA_HOME}/bin/java
     export PATH
     #echo "CLASSPATH: $CLASSPATH"   
       
     DOC_PATH=C:/Users/bvivek01/Desktop/WebInventory
     HOME_PAGE=deploy_temp.html
     CSV_HOME=env.csv
	 DEBUG=on
	  
	 echo "SERVER NAME,TYPE,REALM,PLATFORM,IP,HOST NAME,DNS ALIAS,CLUSTERNAME,DMGR CONSOLE,APP URL,DATABASE,ESB,MIN HEAP,MAX HEAP,APPLICATION LOGS" > $CSV_HOME
	 
	 LOGFILE=deployPage.log
	CURRTIME=`date`
	 CURRUSER=`id | awk '{print $1}'`
	 echo " " >> $LOGFILE
     echo "-------------------------------" >> $LOGFILE
	 echo "start: $CURRTIME" >> $LOGFILE
	 echo "execution id: ${CURRUSER}" >> $LOGFILE
     echo " starting base environment page build to ${HOME_PAGE}" >> $LOGFILE
	 
    # start individual HTML pages
    echo "<HEAD>" > ${DOC_PATH}/${HOME_PAGE}
    echo "<TITLE>Portal Deployment Reference</TITLE>" >> ${DOC_PATH}/${HOME_PAGE}
    echo "</HEAD>" >> ${DOC_PATH}/${HOME_PAGE}

    echo "<BODY BGCOLOR="WHITE">" >> ${DOC_PATH}/${HOME_PAGE}
    echo "<CENTER>" >> ${DOC_PATH}/${HOME_PAGE}
    echo "<H1>Portal Deployment Reference</H1>" >> ${DOC_PATH}/${HOME_PAGE}
	echo "<H3>last update: ${CURRTIME} </H3>" >> ${DOC_PATH}/${HOME_PAGE}


   
   echo "<table border="1">" >> ${DOC_PATH}/${HOME_PAGE}
   echo "<tr COLSPAN="5" BGCOLOR="#99CCFF">" >> ${DOC_PATH}/${HOME_PAGE}
   # echo "<th> App Server Name</th>"  >> ${DOC_PATH}/${HOME_PAGE}
   # echo "<th> Environment Purpose </th>"  >> ${DOC_PATH}/${HOME_PAGE}
   # echo "<th> Hostname </th>"  >> ${DOC_PATH}/${HOME_PAGE}
   # echo "<th> Admin Console </th>"  >> ${DOC_PATH}/${HOME_PAGE}
   # echo "<th> Application URL </th>"  >> ${DOC_PATH}/${HOME_PAGE}
   # echo "<th> Database </th>"  >> ${DOC_PATH}/${HOME_PAGE}
   # echo "<th> ESB </th>"  >> ${DOC_PATH}/${HOME_PAGE}
   # echo "</tr>" >> ${DOC_PATH}/${HOME_PAGE}
   

   #for name in consumer content csadmin cws ess fap preference producer provider mobile vru 
   for name in consumer content csadmin cws ess fap preference producer provider mobile vru cdm gps iia lsui networx sst thl tridion workflow
   
   do   
   # get the facets xml's
   echo "<tr ALIGN="CENTER" BGCOLOR="#99CCFF">" >> ${DOC_PATH}/${HOME_PAGE}
   echo "<th> ${name} Servers </th>"  >> ${DOC_PATH}/${HOME_PAGE}
   echo "<th> Environment Purpose </th>"  >> ${DOC_PATH}/${HOME_PAGE}
   echo "<th> Platform </th>"  >> ${DOC_PATH}/${HOME_PAGE}
   echo "<th> Hostname </th>"  >> ${DOC_PATH}/${HOME_PAGE}
   echo "<th> Admin Console </th>"  >> ${DOC_PATH}/${HOME_PAGE}
   echo "<th> Application URL </th>"  >> ${DOC_PATH}/${HOME_PAGE}
   echo "<th> Database </th>"  >> ${DOC_PATH}/${HOME_PAGE}
   echo "<th> ESB </th>"  >> ${DOC_PATH}/${HOME_PAGE}
   #echo "<th> </th>"  >> ${DOC_PATH}/${HOME_PAGE}
   echo "</tr>" >> ${DOC_PATH}/${HOME_PAGE}
   
   # does not work with CWS - grep -v "ws"
   #files=`cd ${XML_HOME}/${name}; ls *.xml | grep -v "ws" | awk '{FS="." ; print $1}'`
   files=`cd ${XML_HOME}/${name}; ls *.xml | awk -F. '{print $1}'`
       for x in $files
	   
	   do
	   
	   ENVIRONMENT_TYPE=${name}
	   XML_PATH=${XML_HOME}/${ENVIRONMENT_TYPE}/${x}.xml 
	   appRoot=""
	   
	   
	   serverName=$(xmllint --xpath "string(//websphere/server/@name)" $XML_PATH)
	   serverCheck=`echo "x${serverName}x"`
	   if [ $serverCheck != "xx" ]; then
		   # set values based on a server type
		   setInstance $serverName 
	   else
		   echo ">>>> SERVER DOES NOT EXIST <<<<"
		   envPurpose=VACANT
	   fi
       
	   # get the enviroment realm (npe. phi, stage, intStage, prod)
	   getRealm $serverName
	   envPurpose=$(xmllint --xpath "string(//websphere/environment/@purpose)" $XML_PATH)
	   clusterName=$(xmllint --xpath "string(//websphere/server/@clusterName)" $XML_PATH)
	   platform=$(xmllint --xpath "string(//websphere/installation/@platform)" $XML_PATH)
	   dnsName=$(xmllint --xpath "string(//websphere/server/@host)" $XML_PATH)
	   if [[ $platform == "rhel" && $realm != "prod" && $ENVIRONMENT_TYPE != "sst" && $ENVIRONMENT_TYPE != "mobile" ]]; then
	       dnsName=$dnsName.blueshieldcloud.net
	   fi
	   nodeName=$(xmllint --xpath "string(//websphere/server/@nodeName)" $XML_PATH)
	   cellName=$(xmllint --xpath "string(//websphere/dmgr/@cellName)" $XML_PATH)
	   #admin console access
	   dmgrHostParse=$(xmllint --xpath "string(//websphere/dmgr/@host)" $XML_PATH)
       dm_prefix=`echo $dmgrHostParse | awk -F. '{print $1}'` 
	   if [[ $dm_prefix == "dm1"  && $realm != "prod" ]]; then
		  dmgrHost="${dmgrHostParse}.blueshieldcloud.net" ; else
		  dmgrHost="${dmgrHostParse}"
	   fi
	   dmgrHttpsPort=$(xmllint --xpath "string(//websphere/dmgr/ports/@adminHostSec)" $XML_PATH)
	   #application access
	   appHost=$(xmllint --xpath "string(//websphere/server/environment/vhosts/vhost/@host)" $XML_PATH)
	   appPort=$(xmllint --xpath "string(Xparser $XML_PATH //websphere/server/environment/vhosts/vhost1/@port)" $XML_PATH)
	   #ds_url_temp=$(xmllint --xpath "string(//websphere/server/resources/datasources/datasource1/customProperties/customProperty1/@value)" $XML_PATH)
	   ds_url_temp=$(xmllint --xpath "string(//websphere/server/resources/datasources/datasource1/customProperties/customProperty1/@value)" $XML_PATH)
	   ds_url=`echo $ds_url_temp | awk -F@ '{print $2}' `
	   url_temp=$(xmllint --xpath "string(//websphere/server/resources/urls/url1/@specification)" $XML_PATH)
	   loadBalUrl=$(xmllint --xpath "string(//websphere/loadBalancer/@url)" $XML_PATH)
	   
	   url=`echo $url_temp | awk -F/ '{print $3}' `
	  
	  if [[ ${loadBalUrl} == "vacant" ]]; then
			appUrl="http://${appHost}:${appPort}"  ; else
			appUrl=${loadBalUrl}
	   fi
	   
	   rcVer=`echo $?`
	   #spreadsheet specific
	   
	   dmgrHome=$(xmllint --xpath "string(//websphere/dmgr/profile/@home)" $XML_PATH)
	   nodeHome=$(xmllint --xpath "string(//websphere/nodeagent/profile/@home)" $XML_PATH)
	   dmgrLogs="${dmgrHome}/logs/dmgr"
	   nodeAgentLogs="${nodeHome}/logs/nodeagent"
	   applicationLogs="${nodeHome}/logs/${serverName}"
	   heapMin=$(xmllint --xpath "string(//websphere/server/jvm/heap/@min)" $XML_PATH)
	   heapMax=$(xmllint --xpath "string(//websphere/server/jvm/heap/@max)" $XML_PATH)
	   esbUrl_temp=$(xmllint --xpath "string(//websphere/server/resources/urls/url1/@specification)" $XML_PATH)
	   esbUrl==`echo $esbUrl_temp | awk -F/ '{print $3}' `
	   
	   if [[ $dnsName = "" ]]; then
		  echo " the appHost: $appHost is not found"
		  ip="-"
	   else
          ip=`nslookup $dnsName | awk '/Name/ {getline ;print $2}'`
          hostname=`nslookup $dnsName | awk '/Name/ {print $2}'`		  
	   fi
	   
	  
	   echo "working --> $x"
       
	   if [[ $DEBUG == "on" ]] ; then
		echo "serverName: $serverName"
		echo "clusterName: $clusterName"
		echo "hostName: $hostName"
		echo "nodeName: $nodeName"
		echo "cellName: $cellName"
		echo "dmgrHostParse: $dmgrHostParse"
		echo "dmgrHttpsPort: $dmgrHttpsPort"
		echo "appHost: $appHost"
		echo "appPort: $appPort"
		echo "ds_url_temp: $ds_url_temp"
		echo "ds_url: $ds_url"
		echo "loadBalUrl: $loadBalUrl"
		echo "appUrl: $appUrl"
		echo "appRoot: $appRoot"
		echo "dm_prefix: $dm_prefix"
		echo "url_temp: $url_temp"
		echo "url: $url"
		echo "platform: $platform"
		echo "ip: $ip"
		echo "hostname: $hostname"
		echo "applicationLogs: $applicationLogs"
		echo "realm: $realm"
		
	   fi
	   
	   
	   if [[ ${serverName} != " "  || ${envPurpose} != "VACANT" ]]; then
	   echo "<tr><td> ${serverName} </td><td> ${envPurpose} </td><td> ${platform} </td><td> ${hostname} </td><td> <a href="https://${dmgrHost}:${dmgrHttpsPort}/ibm/console" target=_blank >https://${dmgrHost}:${dmgrHttpsPort}/ibm/console</a> </td> <td> <a href="${appUrl}/${appRoot}" target=_blank> ${appUrl}/${appRoot} </a> </td> <td> ${ds_url} </td> <td> ${url} </td> </tr>" >> ${DOC_PATH}/${HOME_PAGE}
																			    #"=HYPERLINK(""https://uapp132s:10001/ibm/console"",""console"")"
	   #echo "${serverName},${name},${clusterName},${platform},${hostName},${ip},\"\"\"=HYPERLINK(\"\"\"\"\"https://${dmgrHost}:${dmgrHttpsPort}/ibm/console\"\"%20c\"\"\"\"\" TEST URL\"\")\",${appUrl}/${appRoot},${ds_url},${esbUrl},${heapMin},${heapMax},${applicationLogs}" >> ${CSV_HOME}
	   echo "${serverName},${name},${realm},${platform},${ip},${hostname},${dnsName},${clusterName},https://${dmgrHost}:${dmgrHttpsPort}/ibm/console,${appUrl}/${appRoot},${ds_url},${esbUrl},${heapMin},${heapMax},${applicationLogs}" >> ${CSV_HOME}
	   fi
	   
	   done
   done   
   
   echo "</table> " >> ${DOC_PATH}/${HOME_PAGE}
   echo "<P>" >> ${DOC_PATH}/${HOME_PAGE}
  
   echo "</BODY> " >> ${DOC_PATH}/${HOME_PAGE}
   
   
   # permanant home page
   PERM_HOME_PAGE=environments.html
   
   # make backup
   cp ${DOC_PATH}/${PERM_HOME_PAGE} ${DOC_PATH}/${PERM_HOME_PAGE}.bakup
   
   # move into place
   cp ${DOC_PATH}/${HOME_PAGE} ${DOC_PATH}/${PERM_HOME_PAGE}
   
   # set permissions
   chmod 664 ${DOC_PATH}/${PERM_HOME_PAGE}.bakup
   chmod 664 ${DOC_PATH}/${PERM_HOME_PAGE}
   chmod 664 ${DOC_PATH}/${HOME_PAGE}
   chmod 664 $LOGFILE
   ENDTIME=`date`
   
   echo "base environment page moved to ${PERM_HOME_PAGE}" >> $LOGFILE
   echo "complete: $ENDTIME" >> $LOGFILE
   echo "-------------------------------" >> $LOGFILE
