#!/bin/bash
# Shounak De [sde02] 03/19/2021 Initial version!
# Shounak De [sde02] 05/10/2021 Added endpoint check for start/recycle and option to send html emails
# Shounak De [sde02] 06/11/2021 Added guess logic to process kafka and cassandra nodes before other nodes and omit logic to skip processing Collective Controller and IDX Adapters hosts
# Shounak De [sde02] 06/22/2021 Added validation logic to assert httpd/java process running or stopped, and changed recycle logic to stop all then start all, instead of a rolling recycle
# Shounak De [sde02] 07/27/2021 Added support to be run as svc_pegarpa for RPA environments. Also added support for parallel stop/start/purge/validate
# Shounak De [sde02] 09/07/2021 Made delete option a flag to delete Liberty profiles class cache, pid, workarea temp files and transaction log in addition of pegaTmp contents

LIBERTY_SCRIPT="/opt/jenkins/AutoSphere/bin/init/ibm_liberty"
HTTPD_SCRIPT="/opt/jenkins/AutoSphere/bin/init/ibm_httpd"
SSH_TIMEOUT=300 # Send SIGTERM to ssh session after this many seconds (for start/stop operations only)
DEFAULT_USER="websphr"

show_help() {
  echo -e "\n$(basename ${0}): Script to control Pega server(s):"
  echo -e "Stop, start, recycle IBM http servers or IBM Liberty JVMs, with option to purge data and/or run handy info utils: ls|du|df|top\n"
  echo "Mandatory: -e|--env => Eg. -e UDTS01 or --env=iwmh05 (env text is case insensitive)"
  echo "Mandatory: -i|--ihs OR -j|--jvm => [Flags] These are flags, no argument needed. Specify either ihs or jvm, *not* both"
  echo "Optional: -A|--action => Specifies what action to take on the remote host. Can be one of [stop|start|recycle|ps]"
  echo "Optional: -D|--delete => [Flag] This JVM option purges /data/websphere/pegaTmp, and profile .classCache/ .pid/ workarea/* tranlog/* apps/expanded/ on remote host"
  echo "Optional: -S|--storage => This option runs a [df] command on the remote host. Optionaly specify specific mount"
  echo "Optional: -L|--list => This option runs a [ls] and [du] command on the remote host. Always specify remote directory to list as parameter to this option"
  echo "Optional: -T|--top => This option runs a [top] command on the remote host. (Defaults to the service account user owned processes, optionally specify user)"
  echo "Optional: -V|--validate => Validates state of httpd/java processes. Arguments can be one of [running|stopped]. Exits non-zero if validation fails"
  echo "Optional: -c|--child => [Flag] Special handling to wait for (or display) child spawned from main jvm process. Valid only with -j|--jvm [caveat emptor: See Note3]"
  echo "Optional: -g|--guess => [Flag] For -j|--jvm, guess kafka or cassandra node by checking for presence of text [str|cas|b*kg] in CNAME, and act on those host(s) first"
  echo "Optional: -f|--filter => Choose filter (CNAME) text from the --noop command to filter on machines. Multiple filters okay, filters are ORed"
  echo "Optional: -l|--logpath => This overrides the default logpath of /tmp (creates path if not present)"
  echo "Optional: -m|--map => Specify custom map file to use [Default: ${0%.sh}.map]"
  echo "Optional: -n|--noop => [Flag] Print the hosts selected, and actions to be performed, but then exit"
  echo "Optional: -o|--omit => [Flag] For -j|--jvm, omit processing Collective Controller or IDX Adapters (checks for CNAME starting with cc|adapter to decide)"
  echo "Optional: -p|--parallel => [Flag] Run stop/start/purge/validate operations for matched machines in parallel"
  echo "Optional: -s|--sendmail => Email log to supplied address(es). Multiple -s|--sendmail switches or multiple email (comma delimited with no spaces) may be specified"
  echo "Optional: -v|--verbose => [Flag] Not necessary if running with tty/pty attached, needed only for forced output without tty (e.g. launched via jenkins/tidal/cron)"
  echo "-h|--help => [Flag] Print this text and exit"
  echo -e "\nNote0: The parameters (switches/options) to this script may be specified in any order (getopt parser)"
  echo "Note1: Only -A -D -S -L -T and -V (uppercased short options) actually connect to the remote hosts, other options are just to select hosts or modify script behavior"
  echo "Note2: To create a map file, open SharePoint url https://collab.blueshieldca.com/it/aoecollab/Lists/Web%20Server%20Inventory/Pega_Operational.aspx"
  echo "  Under [Actions] dropdown, export to spreadsheet, open in Excel, save as csv, move to same machine as this script, and use --map=<path-to-csv>"
  echo "  To not specify the -m|--map parameter, put it in the same location as the script, with the same name but .map extension, like [${0%.sh}.map]"
  echo "Note3: Use caution when using the -c|--child flag: If the main Pega process does not spawn a child process, then the ssh session"
  echo "  is going to wait around doing nothing (waiting for a child to spawn) till it is killed by timeout (currently set at ${SSH_TIMEOUT}s)"
  echo "Note4: When using -g|--guess in conjunction with -p|--parallel, for startup, the nodes that has kafka/cassandra will be started in parallel first,"
  echo "  and only once that completes, the other nodes (which do not have child processes) will then be started in parallel"
  echo -e "\nExample0: To just check Webserver machine names and Liberty machine names for UDT Stage (respectively):"
  echo -e "  ${0} -e UDTS01 -ni\n  ${0} -e UDTS01 -nj"
  echo "Example1: To recycle only PEP Stage Cassandra *and* Kafka JVMs (with child process handling) and purge pegaTmp"
  echo "  ${0} --env=peps01 --jvm --filter=cdhcas --filter=cdhstrm --action=recycle --delete --child"
  echo "Example2: To stop UDT Dev2 webservers in parallel and send email to multiple destinations referencing an ServiceNow INC task"
  echo "  ${0} -e udtn04 -ip -A stop -s My-Team-DL@blueshieldca.com,My.Manager@blueshieldca.com,Someone.Else@blueshieldca.com [INCTSK00xxx]"
  echo "Example3: To check /data/websphere storage, validate java+child processes are running for SA OpsTest JVM hosts and splunk is running"
  echo "  ${0} -eUDTH05 -jg -Vrunning -S/data/websphere -Tsplunk"
  echo "Example4: To start all (previously stopped) IWM BreakFix JVMs with guess logic and specify a log directory for the run and send mail"
  echo "  ${0} -e IWMH03 -j --guess --action=start --logpath=/data/websphere/logs/$(basename ${0%.sh})/iwmruns --sendmail=My.Email@blueshieldca.com"
  echo "Example5: To stop all production ShieldAdvisor IDX adapters in parallel, then verify all adapters are stopped and finally notify IT-PAM with script output"
  echo "  ${0} --env=udtp01 --filter=adapter --jvm --action=stop --parallel --validate=stopped --sendmail=IT-PAM@blueshieldca.com"
  echo "Example6: To check uptime/memory/swap/cpu usage and $DEFAULT_USER process stats and directory listing of pegaTmp on only the streaming PEP Stage JVM hosts"
  echo "  ${0} -e PEPS01 -j -f strm -L /data/websphere/pegaTmp -T -s SupportPerson@pega.com -s Myself@blueshieldca.com"
  echo "Example7: Schedule a IWM OpsTest JVM recycle with pegaTmp + liberty cache purge 5 hours from now and send an email to team when completed"
  echo -e "  echo \"${0} -e IWMH05 -jgD -A recycle -s IT-NPAOperations-Web@blueshieldca.com\" | at now +5 hours\n"
}

help=0; ihs=0; jvm=0; delete=0; noop=0; guess=0; omit=0; parallel=0; verbose=0; child=0; waitBlock=0; errors=0; errorPersistance=$(mktemp); this_script="$(basename ${0})"; ServiceUser=$DEFAULT_USER; raw_opts="$@"
formatted_opts=$(getopt -o A:cDe:f:ghijL:l:m:nopS::s:T::V:v --long action:,child,delete,env:,filter:,guess,help,ihs,jvm,list:,logpath:,map:,noop,omit,parallel,storage::,sendmail:,top::,validate:,verbose -n $(basename $0) -- "$@"); [[ $? != 0 ]] && echo "$this_script: getopt parse error. Exiting" && exit 1
eval set -- "${formatted_opts}" && while true; do # parse formatted options onto script variables
  case "$1" in
    -A|--action) [[ -n "$2" ]] && action_arg=$2; shift 2;;
    -c|--child) child=1; shift;;
    -D|--delete) delete=1; shift;;
    -e|--env) [[ -n "$2" ]] && env_arg=${2,,}; shift 2;;
    -f|--filter) [[ -z "$filter_arg" ]] && filter_arg=$2 || filter_arg="$filter_arg\|$2"; shift 2;;
    -g|--guess) guess=1; shift;;
    -h|--help) help=1; shift;;
    -i|--ihs) ihs=1; shift;;
    -j|--jvm) jvm=1; shift;;
    -L|--list) [[ -n "$2" ]] && list_arg=$2; shift 2;;
    -l|--logpath) [[ -n "$2" ]] && logpath_arg=$2; shift 2;;
    -m|--map) [[ -n "$2" ]] && map_arg=$2; shift 2;;
    -n|--noop) noop=1; shift;;
    -o|--omit) omit=1; shift;;
    -p|--parallel) parallel=1; shift;;
    -S|--storage) [[ -z "$2" ]] && storage_arg=' ' || storage_arg=$2; shift 2;;
    -s|--sendmail) [[ -z "$sendmail_arg" ]] && sendmail_arg=$2 || sendmail_arg="$sendmail_arg,$2"; shift 2;;
    -T|--top) [[ -z "$2" ]] && top_arg='echo $ServiceUser' || top_arg="echo $2"; shift 2;;
    -V|--validate) [[ -n "$2" ]] && validate_arg=$2; shift 2;;
    -v|--verbose) verbose=1; shift;;
    --) shift; break;;
    *) echo "$this_script: Unexpected option found. Exiting"; exit 1;; # getopt error, most likely in specifying formatted_opts
  esac
done

[[ -z "$env_arg" || $help == 1 ]] && show_help && exit 0 # educate and leave
[[ -z "$map_arg" ]] && map_arg="${0%.sh}.map"; [[ ! -r "$map_arg" ]] && echo "$this_script: Unable to open map $map_arg for reading. Exiting" && exit 2 # need that, can't work without it
[[ -n "$action_arg" && "$action_arg" != "start" && "$action_arg" != "stop" && "$action_arg" != "recycle" && "$action_arg" != "ps" ]] && echo "$this_script: Action must be one of start|stop|recycle|ps. Exiting" && exit 3
[[ -n "$validate_arg" && "$validate_arg" != "running" && "$validate_arg" != "stopped" ]] && echo "$this_script: Validation must be one of running|stopped. Exiting" && exit 4
[[ $ihs == 1 && $jvm == 1 ]] && echo "$this_script: Both IHS and JVM cannot be used at the same time. Exiting" && exit 5 # don't be greedy
[[ $ihs == 0 && $jvm == 0 ]] && echo "$this_script: Either IHS or JVM must be specified. Exiting" && exit 6 # duh
[[ $ihs == 1 && ($child == 1 || $guess == 1 || $omit == 1) ]] && echo "$this_script: IHS option is not compatible with child process handling or host omitting. Exiting" && exit 7 # child processes spawn almost instantaneously for parent httpd, so no need to handle it
[[ $ihs == 1 ]] && servertype="uweb" && SCRIPT="$HTTPD_SCRIPT" && ptype="httpd" && pname='echo httpd\|rotatelogs' && p_opts='echo -u $ServiceUser'
[[ $jvm == 1 ]] && servertype="uapp" && SCRIPT="$LIBERTY_SCRIPT" && ptype="java" && pname='echo $(basename $(dirname $(ls /opt/IBM/WebSphere/Profiles/Liberty/servers/*0*/server.xml)))' && p_opts='echo -fu $ServiceUser'
hosts_cmd='sed "s/\r/\n/g" $map_arg | grep -i "^${env_arg}," | grep -v ",,," | grep ",$servertype" | grep "$filter_arg"' && unit=$(basename ${SCRIPT}.service); [[ $omit == 1 ]] && hosts_cmd="$hosts_cmd | grep -v ',cc\|,adapter'"; [[ $guess == 1 ]] && hosts_cmd="$hosts_cmd | awk -F, '\$2\$3 ~ /str|cas|b*kg/{print} \$2\$3 !~ /str|cas|b*kg/{nm[NR]=\$0;} END{for(ln in nm) print nm[ln];}'"
[[ "${env_arg:0:3}" == "rpa" ]] && ServiceUser="svc_pegarpa" && unit=${unit//ibm/rpa} # RPA specific overrides
[[ $delete == 1 && (-z "$action_arg" || "$action_arg" == "ps" || $ihs == 1) ]] && echo "$this_script: Delete option can only be used with JVM stop|start|recycle actions. Exiting" && exit 8 # don't want to trample on data actively used by Pega
[[ -z "$logpath_arg" ]] && logpath_arg="/tmp"
if [[ $noop == 0 ]]; then
  [[ "$(id -un)" != "$ServiceUser" && (-n "$action_arg" && "$action_arg" != "ps") ]] && echo "$this_script: Please switch to $ServiceUser account before invoking with $action_arg action on ${env_arg^^}" && exit 9 # need big boy id for serious stuff
  [[ ! -d "$logpath_arg" ]] && echo "$this_script: $logpath_arg does not exist: Creating it." && (mkdir -p 2>/dev/null $logpath_arg || exit 10); [[ $? == 10 ]] && echo "$this_script: Unable to create [$logpath_arg]. Exiting" && exit 10 # write permission?
  log_file="$logpath_arg/$(basename ${0%.sh}-$(date +"%FT%H%M%S").log)"
else
  log_file="none (no-operation)"
fi

stop_service_purge() { # stop/purge stub to run inline or in parallel
  host="$1" && extra="$2" && ServersBaseDir="/opt/IBM/WebSphere/Profiles/Liberty/servers"
  [[ "$action_arg" == "recycle" || "$action_arg" == "stop" ]] && echo -e "\n$this_script [$(date +"%x %X")]: Shutting down $ptype on ${host}${extra}:\n" && timeout $SSH_TIMEOUT ssh $host "[[ -n \"\$($SCRIPT ps)\" ]] && (/bin/systemctl is-active -q $unit && sudo /bin/systemctl stop $unit || $SCRIPT stop) || prior='was already previously '; [[ -z \"\$($SCRIPT ps)\" ]] && echo \$($pname)@$host \${prior}stopped || (echo Force killing $ptype on $host && pkill -SIGKILL $(eval $p_opts) \$($pname))"
  [[ ("$action_arg" == "recycle" || "$action_arg" == "stop") && $? == 124 ]] && echo -e "\n$this_script [$(date +"%x %X")]: Normal shutdown timed out on $host: Force killing $ptype:\n" && ssh $host "pkill -SIGKILL $(eval $p_opts) \$($pname) && echo \$($pname)@$host killed"
  [[ $delete == 1 ]] && echo -e "\n$this_script [$(date +"%x %X")]: Deleting pegaTmp/* and Liberty JVM cache on $host${extra}:\n" && ssh $host "[[ -d /data/websphere/pegaTmp ]] && (echo -n '$host:/data/websphere/pegaTmp pre-purge: '; du -sh /data/websphere/pegaTmp | cut -f1; rm -r /data/websphere/pegaTmp/*; echo -n '$host:/data/websphere/pegaTmp post-purge: '; du -sh /data/websphere/pegaTmp | cut -f1) || echo Skipping pegaTmp purge as /data/websphere/pegaTmp does not exist on $host; echo Deleting $host:$ServersBaseDir/.classCache/ && rm -r $ServersBaseDir/.classCache/ && echo Deleting $host:$ServersBaseDir/.pid/ && rm -r $ServersBaseDir/.pid/ && echo Deleting $host:$ServersBaseDir/\$($pname)/workarea/* && rm -r $ServersBaseDir/\$($pname)/workarea/* && [[ -d $ServersBaseDir/\$($pname)/tranlog ]] && (echo Deleting $host:$ServersBaseDir/\$($pname)/tranlog/* && rm -rf $ServersBaseDir/\$($pname)/tranlog/*); [[ -d $ServersBaseDir/\$($pname)/apps/expanded ]] && (echo Deleting $host:$ServersBaseDir/\$($pname)/apps/expanded/ && rm -r $ServersBaseDir/\$($pname)/apps/expanded/); echo Delete operation completed on $host"
}

start_service_validate() { # start/validate stub to run inline or in parallel
  host="$1" && extra="$2" && errors=0 && timeout=0
  [[ "$action_arg" == "recycle" || "$action_arg" == "start" ]] && echo -e "\n$this_script [$(date +"%x %X")]: Starting $ptype on ${host}${extra}:\n" && timeout $SSH_TIMEOUT ssh $host "[[ -z \"\$($SCRIPT ps)\" ]] && (/bin/systemctl is-active -q $unit && sudo /bin/systemctl stop $unit; sudo /bin/systemctl start $unit || $SCRIPT start --clean; sleep 5 && echo -e \"\$($pname)@$host started with PID \$(pgrep $(eval $p_opts) \$($pname)):\n\" && ps -f \$(pgrep $(eval $p_opts) \$($pname))) || echo \$($pname)@$host already running with PID: \$(pgrep $(eval $p_opts) \$($pname))"; [[ ("$action_arg" == "recycle" || "$action_arg" == "start") && $? != 0 ]] && ((errors++))
  [[ ($child == 1 || $guess == 1 && -n $(eval $hosts_cmd | grep $host | awk -F, '$2$3 ~ /str|cas|b*kg/')) && ("$action_arg" == "recycle" || "$action_arg" == "start") && $errors == 0 ]] && echo -e "\n$this_script [$(date +"%x %X")]: Waiting for child process to spawn on $host${extra}:\n" && timeout $SSH_TIMEOUT ssh $host "ppid=\$(pgrep $(eval $p_opts) \$($pname)); wait_secs=0; [[ -z \"\$(ps h --ppid=\${ppid})\" ]] && (while [[ -z \"\$(ps h --ppid=\${ppid})\" ]]; do echo -n \$((++wait_secs)).. && sleep 1; done && echo -e \"\n\nFound child process spawned from parent pid \$ppid after \$wait_secs seconds:\n\" && ps -f --ppid \$ppid) || echo Child PID \$(ps -o pid= --ppid=\${ppid}) is already running from parent PID \${ppid}"; [[ $? == 124 && ($child == 1 || $guess == 1 && -n $(eval $hosts_cmd | grep $host | awk -F, '$2$3 ~ /str|cas|b*kg/')) && ("$action_arg" == "recycle" || "$action_arg" == "start") ]] && timeout=1 && ((errors++))
  [[ -n "$validate_arg" ]] && echo -e "\n$this_script [$(date +"%x %X")]: Validating if $ptype is $validate_arg on $host${extra}:\n" && ssh $host "pids=\$(pgrep $(eval $p_opts) \$($pname)); [[ \"$validate_arg\" == \"running\" ]] && ([[ -z \"\$pids\" ]] && echo \"Validation failed: Found no running $ptype processes on $host\" && exit 11 || echo \"Validation passed: Found running \$($pname)@$host PID: \$(echo \${pids[@]})\"); [[ \$? == 11 ]] && exit 11; [[ \"$validate_arg\" == \"stopped\" ]] && ([[ -n \"\$pids\" ]] && echo \"Validation failed: Found running \$($pname)@$host PID: \$(echo \${pids[@]})\" && exit 11 || echo \"Validation passed: Found no running $ptype processes on $host\")"; [[ $? == 11 ]] && ((errors++))
  [[ "$validate_arg" == "running" && ($errors == 0 || $timeout == 1) && ($child == 1 || $guess == 1 && -n $(eval $hosts_cmd | grep $host | awk -F, '$2$3 ~ /str|cas|b*kg/')) ]] && echo -e "\n$this_script [$(date +"%x %X")]: Validating if a child spawned from main $ptype process is $validate_arg on $host${extra}:\n" && ssh $host "childpids=\$(ps h -o pid --ppid \$(pgrep $(eval $p_opts) \$($pname))); [[ -z \"\$childpids\" ]] && echo \"Validation failed: Found no running child processes from parent PID: \$(pgrep $(eval $p_opts) \$($pname))\" && exit 12 || echo \"Validation passed: Found parent PID: \$(pgrep $(eval $p_opts) \$($pname)) has spawned child PID: \$(echo \${childpids[@]})\""; [[ $? == 12 ]] && ((errors++))
  errors=$(($errors + $(cat $errorPersistance))); [[ $errors -gt 0 ]] && echo $errors >$errorPersistance
}

do_work() { # s'il vous plaît (please, so we play)
  echo $errors >$errorPersistance && echo -e "\n$this_script: The following machine(s) match options selected:\n\nEnv             Machine         Filter (CNAME)\n"
  [[ $guess == 0 ]] && eval $hosts_cmd | awk -F, '{print $1,"        ",$4,"     ",$2$3}' || eval $hosts_cmd | awk -F, '$2$3 ~ /str|cas|b*kg/{print $1,"        ",$4,"[*]  ",$2$3} $2$3 !~ /str|cas|b*kg/{nm[NR]=$1"          "$4"       "$2$3;} END{for(ln in nm) print nm[ln];}'
  echo -e "\nNumber of hosts matched:        $(eval $hosts_cmd | wc -l)\nAction selected:                $(eval [[ -z \"$action_arg\" ]] && echo none || echo $action_arg)\nProcess validation:             $(eval [[ -z \"$validate_arg\" ]] && echo none || echo $ptype is $validate_arg)\nPurge pegaTmp & Liberty cache:  $(eval [[ $delete == 0 ]] && echo no || echo yes)\nStorage (mount) check:          $(eval [[ -z \"$storage_arg\" ]] && echo no || echo yes $storage_arg)\nDirectory listing/usage:        $(eval [[ -z \"$list_arg\" ]] && echo no || echo yes: $list_arg)\nSystem stats (top):             $(eval [[ -z \"$top_arg\" ]] && echo no || echo yes, for $(eval $top_arg) user)\nSend output via email:          $(eval [[ -z \"$sendmail_arg\" ]] && echo no || echo yes, To: $sendmail_arg)\nUsing map file:                 $map_arg\nLogfile for this run:           $(hostname -s):$log_file\nOptions for this run:           $raw_opts\n"
  [[ $noop == 1 ]] && echo -e "$this_script: Exiting as no-operation was opted.\n" && exit 0 # legit bail
  [[ $(eval $hosts_cmd | wc -l) == 0 ]] && echo "$this_script [$(date +"%x %X")]: Exiting as no hosts matched" && echo 1 >$errorPersistance && exit 13 # bad env or filter specified?
  [[ -z "$action_arg" && -z "$storage_arg" && -z "$list_arg" && -z "$top_arg" && -z "$validate_arg" ]] && echo -e "$this_script [$(date +"%x %X")]: Exiting as there is nothing to do.\n" && echo 1 >$errorPersistance && exit 14 # happy day?
  echo -n "$this_script [$(date +"%x %X")]: Script started for [$(eval $hosts_cmd | cut -f4 -d, | paste -s -d,)]"; [[ $parallel == 1 ]] && echo ". Parallel processing was opted: Script output is likely to be out of sequence" || echo
  for host in $(eval $hosts_cmd | cut -f4 -d,); do # ps/stop/purge loop
    [[ "$action_arg" == "ps" ]] && echo -e "\n$this_script [$(date +"%x %X")]: Listing current $ptype process on $host:\n" && ssh $host "/bin/systemctl is-active -q $unit && /bin/systemctl status -l $unit || $SCRIPT ps"
    [[ "$action_arg" == "ps" && ($child == 1 || $guess == 1 && -n $(eval $hosts_cmd | grep $host | awk -F, '$2$3 ~ /str|cas|b*kg/')) && "$(ssh $host /bin/systemctl is-active $unit)" != "active" ]] && echo -e "\n$this_script [$(date +"%x %X")]: Listing child process spawned from above JVM on $host:\n" && ssh $host "ps -f --ppid \$(pgrep $(eval $p_opts) \$($pname))"
    if [[ $parallel == 1 ]]; then stop_service_purge $host " (in background)" &
    else stop_service_purge $host; fi
  done; [[ $parallel == 1 && ("$action_arg" == "recycle" || "$action_arg" == "stop") ]] && sleep 0.1 && echo -e "\n$this_script [$(date +"%x %X")]: Waiting for all stops/purges to complete before proceeding (in foreground)...\n" && wait
  for host in $(eval $hosts_cmd | cut -f4 -d,); do # start/validate/df/ls+du/top loop
    [[ $parallel == 1 && ("$action_arg" == "recycle" || "$action_arg" == "start") && $guess == 1 && $waitBlock == 0 && -z "$(eval $hosts_cmd | grep $host | awk -F, '$2$3 ~ /str|cas|b*kg/')" ]] && waitBlock=1 && echo -e "\n$this_script [$(date +"%x %X")]: Waiting for all parent java that also spawn child processes to start before proceeding with the rest (in foreground)...\n" && wait
    if [[ $parallel == 1 ]]; then start_service_validate $host " (in background)" &
    else start_service_validate $host; fi
    [[ -n "$storage_arg" ]] && echo -e "\n$this_script [$(date +"%x %X")]: Displaying disk storage mount usage on $host:\n" && ssh $host df -h $storage_arg
    [[ -n "$list_arg" ]] && echo -e "\n$this_script [$(date +"%x %X")]: Displaying directory listing of [$host:$list_arg]:\n" && ssh $host "ls -thrl $list_arg && echo -e \"\nDisk usage:\" && du -sh $list_arg"
    [[ -n "$top_arg" ]] && echo -e "\n$this_script [$(date +"%x %X")]: Displaying system stats (and process stats for $(eval $top_arg) processes) on $host:\n" && ssh $host top -b -c -w440 -o +%MEM -n1 -u $(eval $top_arg)
  done; [[ $parallel == 1 && ("$action_arg" == "recycle" || "$action_arg" == "start" || -n "$validate_arg") ]] && sleep 0.1 && echo -e "\n$this_script [$(date +"%x %X")]: Waiting for all starts/validations to complete before proceeding (in foreground)...\n" && wait && errors=$(($errors + $(cat $errorPersistance)))
  [[ "$action_arg" == "recycle" || "$action_arg" == "start" ]] && read -r HTTPResponseCode <<<$(curl -o /dev/null --silent --insecure --location --max-time 180 --write-out '%{http_code}' "https://${env_arg,,}.bsc.bscal.com/prweb") && echo -e "\n$this_script [$(date +"%x %X")]: Tested endpoint [https://${env_arg,,}.bsc.bscal.com/prweb], got response: [$HTTPResponseCode]"
  echo -e "\n$this_script [$(date +"%x %X")]: Completed processing with $errors error(s). Exiting\n"
}

[[ $noop == 1 ]] && do_work || ( [[ -t 1 || $verbose == 1 ]] && (do_work 2>&1 | tee $log_file) || (do_work &>$log_file) ); [[ -s $errorPersistance ]] && errors=$(cat $errorPersistance) && rm $errorPersistance
[[ -f $log_file ]] && chmod go+r $log_file && [[ -n "$sendmail_arg" ]] && colors=(Teal Green Olive Blue DarkBlue Brown DarkGreen DarkOliveGreen SaddleBrown CadetBlue Maroon Indigo Purple DarkOrange SlateBlue) && ((echo -e "From: Pega-Control\nTo: ${sendmail_arg}\nSubject: $* ${env_arg^^} script run for ${action_arg:-$raw_opts}\nContent-Type: text/html; charset=utf-8\nContent-Disposition: inline\n<html>\n<body>\n<pre style=\"font-family: monospace; font-size: 15px\">" && sed "s/\(^$this_script.*\)/<em style=\"color: ${colors[$(($RANDOM % ${#colors[@]}))]};\">\1<\\/em>/;s/\(\S*\)@\(\S*\)/<a style=\"color: black; text-decoration: none\"><font style=\"display: none\">@<\/font>\1@\2<\/a>/g" ${log_file} && echo -e "</pre>\n</body>\n</html>\n") | /usr/sbin/sendmail.postfix -t)
[[ $errors == 0 ]] && exit 0 || exit 99
