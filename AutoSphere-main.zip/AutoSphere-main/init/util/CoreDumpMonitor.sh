#!/bin/sh

#find heap dump files in profiles root
find /opt/WebSphere/AppServer/profiles -type f -name "*.hprof" >hpropfiles.txt
# read hpropfiles.txt for hprof files
		while read line
		do
			if [ ! -d /opt/WebSphere/coredumps ]
			then
				mkdir -p /opt/WebSphere/coredumps
			fi
			mv $line /opt/WebSphere/coredumps
			PID=`echo $line | awk -F'/' '{print $NF }' |awk '{print substr($0,9,length($0)-14)}'`
			JVM=`/usr/ucb/ps auxwww | nawk -v ID=$PID '{ if ($2==ID) print $(NF)}'`
			NODE=`/usr/ucb/ps auxwww |grep ${JVM} | grep -v grep | nawk '{print $(NF-1)}'`
			echo  ${JVM} has a core dump. It has been moved to /opt/Websphere/coredumps. Please  check and restart ${JVM} | mailx -s "OUT-OF-MEMORY-ALERT" John.Canepa@blueshieldca.com KISHORE.KATTA@blueshieldca.com Rajendar.Miyyapuram@blueshieldca.com Devandand.Ravanan@blueshieldca.com
			tail -1000 /opt/WebSphere/AppServer/profiles/${NODE}/logs/${JVM}/SystemOut.log >/opt/WebSphere/coredumps/${JVM}.`date +%Y-%m-%d`.log
		done < hpropfiles.txt
		rm hpropfiles.txt
