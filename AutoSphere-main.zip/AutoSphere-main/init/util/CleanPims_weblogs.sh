/usr/bin/find  /opt/IBM/WebSphere/HTTPServer/logs/pims*-ws*/*log* -mtime +8 -exec rm -f {} \;
/usr/bin/find  /opt/IBM/WebSphere/Plugins/logs/pims*-ws*/*log* -mtime +8 -exec rm -f {} \;