#!/bin/bash
Count=`df -Ph | grep -v 'Filesystem'| awk '{print  $6 "=" $5}' | grep "[9][0-9]" | wc -l`
FS=`df -Ph | grep -v 'Filesystem'| awk '{print  $6 "=" $5}' | grep "[9][0-9]"`
if [ $Count -gt 0 ] ; then
echo "$FS" | mail -s "check file system on `hostname`" IT-NPAOperations-Web@blueshieldca.com
echo " FileSystems found critical @ `date` Check: $FS" >> ~/df2.log
exit
else
echo " Filesystems found ok @ `date` " >> ~/df2.log;
exit
fi

