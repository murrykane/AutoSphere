#!/bin/sh
#find files native_stdout.log and native_stderr.log  which are greater than 20MB and delete them
echo "Removing native_stdout.logs size greater than 20MB"
find /opt/WebSphere/AppServer/profiles -type f -name "native_stdout.log" -size +20M >logs.txt
	while read line
	do
		rm $line 
	done < logs.txt
	rm logs.txt
echo "Removing native_stderr.logs size greater than 20MB"
find /opt/WebSphere/AppServer/profiles -type f -name "native_stderr.log" -size +20M >logs.txt
	while read line
	do 
		rm $line
	done < logs.txt
	rm logs.txt
echo "Rotating gc.logs size greater than 50MB"
find /opt/WebSphere/AppServer/profiles -type f -name "gc.log" -size +50M >gclogs.txt
	while read line
	do 
		mv $line $line.`date +%Y-%m-%d`
	done < gclogs.txt
	rm gclogs.txt

find /opt/WebSphere/AppServer/profiles -type f -name "gc.log.*" -mtime +30 -exec rm {} \;


# finds access.log and error.log which are older than 15 days and deletes the log files
find /opt/WebSphere/HTTPServer/logs -type f -name "*log*" -mtime +15 -exec rm -f {} \;


