/usr/bin/find  /apps/WEB*/logs/web*/*log* -mtime +8 -exec rm -f {} \;

