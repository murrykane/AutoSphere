import sys

print "All the Best"

clusterName=sys.argv[0]
print "Cluster Name is : " + clusterName

clusterId = AdminConfig.getid("/ServerCluster:" + clusterName + "/")
clusterMembers = AdminConfig.list("ClusterMember", clusterId ).split(lineSeparator)
for clusterMember in clusterMembers:
    sname = AdminConfig.showAttribute(clusterMember, "memberName")
    sid = AdminConfig.getid('/Server:'+sname+'/')
    cid = AdminConfig.list('Cookie', sid)
    print "Restrict cookies to HTTPS Sessions Has Been Enabled to the Application Server:" + sname
    AdminConfig.modify(cid, '[[secure "true"] [httpOnly "true"]]')
    AdminConfig.save()

