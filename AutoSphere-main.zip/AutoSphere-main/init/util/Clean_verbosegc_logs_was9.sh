/usr/bin/find /apps/profiles/*/logs/*/verbosegc* -mtime +4 -exec rm -f {} \;
