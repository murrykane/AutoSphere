envName=`cat /etc/virtualimage.properties | grep BSCVM_ENVIRONMENT | tail -c 8 | tr -d '='`
jvmName=`if [ -d /opt/IBM/WebSphere/Profiles/wp_profile/ ]; then
 echo "_PortalNode"
 else echo "_unknown"
fi` 
echo "$envName$jvmName"

