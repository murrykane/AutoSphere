/usr/bin/find /apps/logs/*/*.log.* -mtime +6 -exec rm -f {} \;
/usr/bin/find /apps/plugin/logs/*/*.log.* -mtime +6 -exec rm -f {} \;
#liberty webserver logs clean up
/usr/bin/find /data/websphere/logs/http/*.log.* -mtime +8 -exec rm -f {} \;
/usr/bin/find /data/websphere/logs/plugins/*.log -mtime +8 -exec rm -f {} \;
/usr/bin/find /data/websphere/logs/*/*.log -mtime +8 -exec rm -f {} \;
#WAS9 Rhel7 Migration CLeanup
/usr/bin/find /opt/IBM/WebSphere/HTTPServer/logs/*/*.log.* -mtime +8 -exec rm -f {} \;
/usr/bin/find /opt/IBM/WebSphere/Plugins/logs/*/*.log.* -mtime +8 -exec rm -f {} \;
/usr/bin/find /data/websphere/logs/*/*/verbosegc*.log -mtime +8 -exec rm -f {} \;
/usr/bin/find /data/websphere/logs/*/*/core* -mtime +8 -exec rm -f {} \;
/usr/bin/find /data/websphere/logs/*/*/heapdump*.phd -mtime +8 -exec rm -f {} \;
/usr/bin/find /data/websphere/logs/*/*/javacore*.txt -mtime +8 -exec rm -f {} \;
/usr/bin/find /data/websphere/logs/*/*/Snap*.trc -mtime +8 -exec rm -f {} \;


