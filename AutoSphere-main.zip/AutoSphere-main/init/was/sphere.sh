#!/bin/sh
#**********************************
usage() {
echo "		description: WebSphere Automation Framework
		usage:
			$0 -p <proj_name> -e <env_instance> -t <target> [-a <artifact_path> | -l | -h]
		OPTIONS:				DESCRIPTION:
		-p <project_name>		the name of the project, xml directory
		-e <env_intance>		the name of the environment instance, xml file
		-t <target_name>		the target action to take defined in ant
		-a <artifact_path>		the artifact or deploy unit path location on "deploy" target
		-v <virtual_portal_name>	virtual portal site 
		-l 				list the available ant targets
		-h				display usage or help menu"
	exit 0

}



CUR_PATH=`dirname $0`
. ${CUR_PATH}/../../../AutoCommon/bin/common/configure.properties


while getopts p:e:t:a:v:l arg
do
	case $arg in
		p)	PROJ=$OPTARG;;
		e)	ENV=$OPTARG;;
		t)	TARGET=$OPTARG;;
		a)	ARTIFACT=$OPTARG;;
		v)	VP=$OPTARG;;
		l)	AVAIL_TARGET="true";;
		h|*)	usage;;
	esac
done
#shift $(($OPTIND - 1))

if [ "${AVAIL_TARGET}" = "true" ]; then
	echo "* -------------------------------------"
	echo "* available targets:"
	echo "* -------------------------------------"

	grep -h "target name" ../../ant_tasks/*/*xml | awk '{FS="<target" ; print $2}' | sort -u
	exit 0
fi	

# check arguments
if [ $# -lt 6 ]; then
	usage
	exit 0
fi

UNAME=`uname`
if [ "${TARGET}" = "deploy" ]; then
	if [ "${ARTIFACT}" = "" ]; then
		usage
	fi
fi
	
UNAME=`uname`
case $UNAME in
SunOS)
        OS=solaris
        OS_TYPE=`isainfo -kv | grep 64`
        

        if  [ "${OS_TYPE}" != "" ]; then
                PLATFORM=64bit
        else
                PLATFORM=32bit
        fi
		AUTO_HOME=${SOLARIS_AUTO_HOME}
		JAVA_HOME=${AUTO_HOME}/java/${OS}/${PLATFORM}
	;;

AIX)
        OS=aix
        OS_TYPE=`getconf -a | grep KERN | grep 64`

        if [ "${OS_TYPE}" != "" ]; then
                PLATFORM=64bit
        else
                PLATFORM=32bit
        fi
        AUTO_HOME=${AIX_AUTO_HOME}
		JAVA_HOME=${AUTO_HOME}/java/${PLATFORM}
	;;
Linux)
        OS=rhel
        OS_TYPE=`uname -p | grep 64`
        AUTO_HOME=${RHEL_AUTO_HOME}
        SHIELD_HOME=${AUTO_HOME}/AutoSphere
        XML_HOME=${SHIELD_HOME}/xml
        if [ "${OS_TYPE}" != "" ]; then
                PLATFORM=64bit
        else
                PLATFORM=32bit
        fi
        WAS_HOME=$(echo 'cat //was/@home' | xmllint --shell $XML_HOME/${PROJ}/${ENV}.xml |  awk -F'[="]' '!/>/{print $(NF-1)}') 

	[ -d ${WAS_HOME}/java/bin ] && export JAVA_HOME=${WAS_HOME}/java
        [ -d ${WAS_HOME}/java/8.0 ] && export JAVA_HOME=${WAS_HOME}/java/8.0

	;;
CYGWIN_NT-6.1)
        OS=cygwin
		AUTO_HOME=c:/svnprod
		SHIELD_HOME=c:/svnprod
		export JAVA_HOME=${AUTO_HOME}/java/${PLATFORM}
		
    ;;
esac

SHIELD_HOME=${AUTO_HOME}/AutoSphere
SHIELD_COMMON=${AUTO_HOME}/AutoCommon
CLASSPATH="${SHIELD_COMMON}/lib/xmlParser:${JAVA_HOME}:${SHIELD_HOME}/lib/jython.jar"
PATH=$PATH:${SHIELD_HOME}/ant/bin:${JAVA_HOME}
ANT_HOME=${AUTO_HOME}/ant
export CLASSPATH PATH
XML_HOME=${SHIELD_HOME}

if [ "${ARTIFACT}" = "" ]; then
	${ANT_HOME}/bin/ant -f ${SHIELD_HOME}/ant_tasks/sphere.xml -DENVIRONMENT_TYPE=${PROJ} -DSHIELD_HOME=${SHIELD_HOME} -DINSTANCE=${ENV} -DSHIELD_COMMON=${SHIELD_COMMON} -DJAVA_HOME=${JAVA_HOME} ${TARGET}

else
	echo "deploying ${ARTIFACT} to ${ENV}"
	${ANT_HOME}/bin/ant -f ${SHIELD_HOME}/ant_tasks/sphere.xml ${ANT_OPTS} -DENVIRONMENT_TYPE=${PROJ} -DSHIELD_HOME=${SHIELD_HOME} -DINSTANCE=${ENV} -DSHIELD_COMMON=${SHIELD_COMMON} -DJAVA_HOME=${JAVA_HOME} ${TARGET} -DDEPLOY_UNIT=${ARTIFACT} -DVIRTUAL_PORTAL=${VP} 
fi
