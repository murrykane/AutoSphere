#!/bin/sh


preReq() {
    
	if [ -d "/apps/profiles/properties/" ]; then
       echo "/apps/profiles/properties/ exists"
    else
	mkdir -p /apps/profiles/properties
	fi

	if [ -L "/opt/jenkins/ant" ]; then
	  echo "/opt/jenkins/ant exists"
    else
	  echo "/opt/jenkins/ant does not exist .... creating"
	  ln -s /sysadmin/media/websphr/ant /opt/jenkins/ant
	fi
	
	if [ -L "/opt/jenkins/java" ]; then
	  echo "/opt/jenkins/java exists"
    else
	  echo "/opt/jenkins/java does not exist .... creating"
	  ln -s /sysadmin/media/websphr/java /opt/jenkins/java
	fi
}

createDmgr() {
     
	 
	if [ -d "${DMGR_PROFILE_HOME}/${ENV}Dmgr" ]; then
		echo "${DMGR_PROFILE_HOME}/${ENV}Dmgr exist ... skipping create dmgr profile"
    else
		#create dmgr profile
		echo " --> create $ENV dmgr profile"
		echo "----------------------------------"
		callSphere $1 $2 create_dmgr_profile
	fi
}

createManagedProfile() {
       
	if [ -d "${NODE_PROFILE_HOME}/${NODE_NAME}" ]; then
		echo "${NODE_PROFILE_HOME}/${NODE_NAME} exist ... skipping create managed profile"
    else

		#create managed profile
		echo " --> create $ENV managed profile"
		echo "----------------------------------"
		callSphere $1 $2 create_managed_profile
		#not required
		#callSphere $1 $2 start_node
	fi
}

configureWebServer() {
    
	if [ -f "/apps/${ENV}-ws${INSTANCE_NUM}/conf/${ENV_LOWER}-ws${INSTANCE_NUM}.conf" ]; then
		echo "/apps/${ENV}-ws${INSTANCE_NUM}/conf/${ENV_LOWER}-ws${INSTANCE_NUM}.conf exist ... skipping configure web server"
    else
	    echo "copy bsca template into place"
		cp /opt/jenkins/AutoSphere/wasBaseConfigs/webserver/conf/template/template-ws.conf /opt/jenkins/AutoSphere/templates/ihs/ihs70_conf.template 
		#configure web server
		echo " --> configure web server"
		echo "----------------------------------"
		callSphere $1 $2 ihs_conf_file
		callSphere $1 $2 configure_webserver_response_file
		callSphere $1 $2 configure_webserver
        # check mime file is in place
		if [ -f "/apps/${ENV}-ws${INSTANCE_NUM}/conf/mime.types" ]; then
                   echo "/apps/${ENV}-ws${INSTANCE_NUM}/conf/mime.types exists ..."
		else
		   echo "/apps/${ENV}-ws${INSTANCE_NUM}/conf/mime.types does not exits ... creating"
		   cp  /opt/WebSphere/HTTPServer/conf/mime.types.default /apps/${ENV}-ws${INSTANCE_NUM}/conf/mime.types
		fi
		if [ -d "//apps/${ENV}-ws${INSTANCE_NUM}/plugin/" ]; then
                   echo "//apps/${ENV}-ws${INSTANCE_NUM}/plugin/ exists"
                else
	           mkdir -p /apps/${ENV}-ws${INSTANCE_NUM}/plugin
			   mkdir -p /apps/${ENV}-ws${INSTANCE_NUM}/plugin/logs
	        fi
		# check plugin bin is linked
		if [ -L "/apps/${ENV}-ws${INSTANCE_NUM}/plugin/bin" ]; then
		    echo "/apps/${ENV}-ws${INSTANCE_NUM}/plugin/bin ... exists"
		else
		    echo "/apps/${ENV}-ws${INSTANCE_NUM}/plugin/bin does not exist ... creating"
			ln -s /opt/WebSphere/Plugins/bin /apps/${ENV}-ws${INSTANCE_NUM}/plugin/bin
		fi
		
		#check webserver module directory is linked
		if [ -L "/apps/${ENV}-ws${INSTANCE_NUM}/modules" ]; then
		    echo "/apps/${ENV}-ws${INSTANCE_NUM}/modules ... exists"
		else
		    echo "/apps/${ENV}-ws${INSTANCE_NUM}/modules does not exist ... creating"
			ln -s /opt/WebSphere/HTTPServer/modules /apps/${ENV}-ws1/modules
		fi
		
	 echo " starting the ${ENV}-ws1"
	   /opt/WebSphere/HTTPServer/bin/apachectl -k start -f /apps/${ENV}-ws${INSTANCE_NUM}/conf/${ENV_LOWER}-ws${INSTANCE_NUM}.conf
	fi
}

configureCell() {
    INSTANCE=Cell
	echo "--> configure environment ${INTSTANCE} - configure_adpassword,import certs,updates timeouts and configures security cell.xml"
	callSphere cell ${ENV}Cell1 configure_environment
	
	}

	
 
 setInstance() {
    # set environment values based on instance variable        
	case ${1} in
		consumer) INSTANCE=Consumer HOST=consumer ENV_TYPE=consumer NODE_TYPE=consumer TEMPLATE_TYPE=consumer CLUSTERNAME=${ENV}${INSTANCE}C DU=Consumer.ear;;
		consumerBatch) INSTANCE=ConsumerBatch HOST=consumer-batch ENV_TYPE=consumer NODE_TYPE=consumer-batch TEMPLATE_TYPE=consumerBatch CLUSTERNAME=${ENV}${INSTANCE}C DU=Consumer.ear;;
		csadmin) INSTANCE=CSAdmin HOST=csadmin ENV_TYPE=csadmin NODE_TYPE=csadmin TEMPLATE_TYPE=csadmin CLUSTERNAME=${ENV}${INSTANCE}C DU=Admin.ear;;
		content) INSTANCE=Content HOST=content ENV_TYPE=content NODE_TYPE=content TEMPLATE_TYPE=content CLUSTERNAME=${ENV}${INSTANCE}C DU=Content.ear;;
		dmgr) INSTANCE=Cell HOST=dm ENV_TYPE=cell TEMPLATE_TYPE=cell;;
		preference) INSTANCE=Preference HOST=preference-center ENV_TYPE=preference NODE_TYPE=preference-center TEMPLATE_TYPE=preference CLUSTERNAME=${ENV}${INSTANCE}C DU=Preference.ear;;
		provider) INSTANCE=Provider HOST=provider ENV_TYPE=provider NODE_TYPE=provider TEMPLATE_TYPE=provider CLUSTERNAME=${ENV}${INSTANCE}C DU=Provider.ear;;
		providerBatch) INSTANCE=ProviderBatch HOST=provider-batch ENV_TYPE=provider NODE_TYPE=provider-batch TEMPLATE_TYPE=providerBatch CLUSTERNAME=${ENV}${INSTANCE}C DU=Provider.ear;;
		producer) INSTANCE=Producer HOST=producer ENV_TYPE=producer NODE_TYPE=producer TEMPLATE_TYPE=producer CLUSTERNAME=${ENV}${INSTANCE}C DU=Producer.ear;;
		producerBatch) INSTANCE=ProducerBatch HOST=producer-batch ENV_TYPE=producer NODE_TYPE=producer-batch TEMPLATE_TYPE=producerBatch CLUSTERNAME=${ENV}${INSTANCE}C DU=Producer.ear;;
		epresent) INSTANCE=EPresentBatch HOST=epresent-batch ENV_TYPE=consumer NODE_TYPE=epresent-batch TEMPLATE_TYPE=epresent CLUSTERNAME=${ENV}${INSTANCE}C DU=Consumer.ear;;
		ess) INSTANCE=ESS HOST=ess ENV_TYPE=ess NODE_TYPE=ess TEMPLATE_TYPE=ess CLUSTERNAME=${ENV}${INSTANCE}C DU=ess.war;;
		essBatch) INSTANCE=ESSBatch HOST=ess-batch ENV_TYPE=ess NODE_TYPE=ess-batch TEMPLATE_TYPE=essBatch CLUSTERNAME=${ENV}${INSTANCE}C DU=essbatch.war;;
		fap) INSTANCE=FAP HOST=fap ENV_TYPE=fap NODE_TYPE=fap TEMPLATE_TYPE=fap CLUSTERNAME=${ENV}${INSTANCE}C DU=fap.ear;;
		fapBatch) INSTANCE=FAPBatch HOST=fap-batch ENV_TYPE=fap NODE_TYPE=fap-batch TEMPLATE_TYPE=fapBatch CLUSTERNAME=${ENV}${INSTANCE}C DU=fap.ear;;
		mobileWeb) INSTANCE=MobileWeb HOST=mweb ENV_TYPE=mobile NODE_TYPE=mweb TEMPLATE_TYPE=mobileWeb CLUSTERNAME=${ENV}${INSTANCE}C DU=mobile-web.war;;
		mobileApi) INSTANCE=MobileApi HOST=mapi ENV_TYPE=mobile NODE_TYPE=mapi TEMPLATE_TYPE=mobileApi CLUSTERNAME=${ENV}${INSTANCE}C DU=mobileapi.war;;
		mobileSvc) INSTANCE=MobileSvc HOST=msvc ENV_TYPE=mobile NODE_TYPE=msvc TEMPLATE_TYPE=mobileSvc CLUSTERNAME=${ENV}${INSTANCE}C DU=mobile-svc.war;;
		epresent) INSTANCE=EPresentBatch HOST=epresent-batch ENV_TYPE=consumer NODE_TYPE=epresent-batch TEMPLATE_TYPE=consumerBatch CLUSTERNAME=${ENV}${INSTANCE}C;;
		cell) INSTANCE=cell ENV_TYPE=cell TEMPLATE_TYPE=cell;;
		webserverNode) INSTANCE=Web HOST=ws ENV_TYPE=webserver NODE_TYPE=ws TEMPLATE_TYPE=webserverNode;;
		webserver) INSTANCE=-ws${INSTANCE_NUM} HOST=ws${INSTANCE_NUM} ENV_TYPE=webserver TEMPLATE_TYPE=webserver;;
	esac
 }

#**********************************
callSphere() {

    echo "--> command: ${SHIELD_HOME}/bin/was/sphere.sh -p ${1} -e ${2} -t ${3}"
	${SHIELD_HOME}/bin/was/sphere.sh -p ${1} -e ${2} -t ${3}

}

#**********************************

#**********************************
 
createProjectComponents() {
	# creates the base components for a project environment
	# create deployment maanger
	createDmgr cell ${ENV}Cell1
	# create managed node
	createManagedProfile ${ENV_TYPE} ${ENV}${INSTANCE}${INSTANCE_NUM}
	# create web servers
	setInstance webserver
	#createInstanceXml webserver -ws1 ${ENV} ${ENV_LOWER}
	configureWebServer ${ENV_TYPE} ${ENV}${INSTANCE}
}

createInstance() {

   # create instance
   echo "--> create instance ${INSTANCE}"
   callSphere ${ENV_TYPE} ${ENV}${INSTANCE}${INSTANCE_NUM} build_instance
}

callStart() {
	START=$(date +%c)
    echo "START TIME: $START"
}

callStop() {
	STOP=$(date +%c)
    echo "START TIME: $START"
	echo "STOP TIME: $STOP"
}

openPerms() {
    echo "openning permissions /opt/AutoSphere/tmp"
	chmod -R 775 /opt/jenkins/AutoSphere/tmp
	    echo "openning permissions /opt/AutoSphere/logs"
	chmod -R 775 /opt/jenkins/AutoSphere/logs
}
 

#**********************************
usage() {
echo "		description: WebSphere Automation Framework
		usage:
			$0  -p <project type> -e <env_identifyer>
		OPTIONS:				DESCRIPTION:
     
		-e   <env_identifyer>[required]  	the name of the stripe - (WEBN42)
		
		-p   <project type>[required]	  	project types [consumer, consumerBatch, csadmin, content, preference
		                                        producer, producerBatch, provider, providerBatch, ess, essBatch, 
							fap fapBatch, mobile, mobileApi, epresent]
											
		-a   <archetype>[optional]     	    	archetype [project, integrated, clustered] (default = project)
                                                    	integrated types [consumer, ess, producer, provider, preference, 
													mobile dmgr, web]		
		-w   <websphere component>              websphere components [nodeagent, dmgr, webserver, create_template]
		-h   <help>[optional]               	[display usage or help menu]
		
																			"
		exit 0
}



CUR_PATH=`dirname $0`
. ${CUR_PATH}/../../../AutoCommon/bin/common/configure.properties


while getopts p:e:a:n:s:i:l:b:m:d:x:w:h arg
do
	case $arg in
		e) ENV=$OPTARG;;
		p) PROJ=$OPTARG;;
		a) ARCHETYPE=$OPTARG;;
		n) INSTANCE_NUM=$OPTARG;;
		s) ESB_HOST_PORT=$OPTARG;;
        	i) EDI_HOST_PORT_QM=$OPTARG;;
        	l) ENV_LEVEL=$OPTARG;;
        	b) LOAD_BALANCER=$OPTARG;;
		m) MOBILE_URL=$OPTARG;;
        	d) DB_URL=$OPTARG;;
        	x) DB_PASS=$OPTARG;;
		w) WAS_COMPONENT=$OPTARG;;
		h|*) usage;;
	esac
done

# check arguments
if [ $# -lt 2 ]; then
	usage
	exit 0
fi

UNAME=`uname`

case $UNAME in
SunOS)
        OS=solaris
        OS_TYPE=`isainfo -kv | grep 64`
        AUTO_HOME=${SOLARIS_AUTO_HOME}

        if  [ "${OS_TYPE}" != "" ]; then
                PLATFORM=64bit
        else
                PLATFORM=32bit
        fi
	;;

AIX)
        OS=aix
        OS_TYPE=`getconf -a | grep KERN | grep 64`

        if [ "${OS_TYPE}" != "" ]; then
                PLATFORM=64bit
        else
                PLATFORM=32bit
        fi
        AUTO_HOME=${AIX_AUTO_HOME}
	;;
Linux)
        export OS=rhel
        OS_TYPE=`uname -p | grep 64`

        if [ "${OS_TYPE}" != "" ]; then
                PLATFORM=64bit
        else
                PLATFORM=32bit
        fi
        AUTO_HOME=${RHEL_AUTO_HOME}
		XML_HOME=${RHEL_AUTO_HOME}
		export JAVA_HOME=${AUTO_HOME}/java/${OS}/${PLATFORM}
	;;

esac

#*****************************************************
# START: set / check variables
#*****************************************************
#set prereq's
preReq

#*****************************************************
# start: base script variables
#*****************************************************
SHIELD_HOME=${AUTO_HOME}/AutoSphere
SHIELD_COMMON=${AUTO_HOME}/AutoCommon
CLASSPATH="${SHIELD_COMMON}/lib:${SHIELD_COMMON}/lib/xmlParser:${AUTO_HOME}/java/${OS}/${PLATFORM}:${SHIELD_HOME}/lib/jython.jar"
PATH=$PATH:${SHIELD_HOME}/ant/bin:${JENKINS_HOME}/java/${OS}/${PLATFORM}
ANT_HOME=${AUTO_HOME}/ant
# was home and dmgr profile location
WAS_HOME=/opt/WebSphere/AppServer


export GOLDCOPY_PATH=/opt/jenkins/stage/goldcopy/
export CLASSPATH PATH
#*****************************************************
# check for an alternate XML location
# new for archetype approach - allows on-demand
# creation of XML 
# if [ -z ${XML_HOME} ]; then
   # XML_HOME=${SHIELD_HOME}
# fi


# ensure required variables are set
if [ -z ${ENV} -o -z ${PROJ} ]; then
	echo " environment or project variables are missing
	       ENV = ${ENV}
	       PROJ = ${PROJ}"
    exit 0
fi

#create environment lower case
ENV_LOWER=`echo ${ENV} | tr '[:upper:]' '[:lower:]'`

# # set defaults if not set
: ${ARCHETYPE:=project}
: ${INSTANCE_NUM:=1}
# : ${ESB_HOST_PORT:=uwmb001d.dev.bscal.local:7801}
# : ${EDI_HOST_PORT_QM:=uwmb001d.dev.bscal.local:2401:ESBGD1}
: ${ENV_LEVEL:=npe}

# generate EDI variables
#ediGenVars


# if [ -z ${DB_URL}]; then
   # echo "before - DB_URL: $DB_URL"
   # dbinfo
   # DBURL=${DBHOST}:${DBPORT}:${DBNAME}
   # export DB_URL=${DBURL}
   # echo "after - DB_URL: $DB_URL"
# fi

# if [ -z ${DB_PASS}]; then
   # dbGenPass
# else
   # encodePass
# fi

# if [ -z ${LOAD_BALANCER} ]; then
   # LOAD_BALANCER="http://ws1.${ENV_LOWER}.blueshieldcloud.net:20000"
# fi

# if [ -z ${MOBILE_URL} ]; then
   # MOBILE_URL="http://ws1.${ENV_LOWER}.blueshieldcloud.net:20000/mobile-web/initial_popup.sp"
# fi

# get instance name
setInstance ${PROJ}
CLUSTERNAME=${ENV}${INSTANCE}C

# #determine node configuration
if [ ${INSTANCE_NUM} -eq "1" -o ${INSTANCE_NUM} -eq "3" ]; then
    NODE_NUM="1"
else
    NODE_NUM="2"
fi	

if [  ${ARCHETYPE} == "project" ] ; then
   NODE_NAME=${ENV}Node${NODE_NUM}
   NODE_COMPONENT=${ENV}-node1
   NODE_PROFILE_HOME=/apps/${NODE_COMPONENT}/profiles
   CONFIG_PORTS=false
   DMGR_PROFILE_HOME=/apps/${ENV}-dm1/profiles
   DM_HOST=dm1
else
   NODE_NAME=${ENV}${INSTANCE}Node${NODE_NUM}
   NODE_COMPONENT=${ENV}-${NODE_TYPE}${NODE_NUM}
   NODE_PROFILE_HOME=/apps/${NODE_COMPONENT}/profiles
   CONFIG_PORTS=true
   DMGR_PROFILE_HOME=/apps/${ENV}-dm1/profiles
   DM_HOST=dm1
fi
 
#*****************************************************
# end: base script variables
#*****************************************************


# debug: output variables
echo "
	 -----------------
	 list of variables
	 -----------------
	 ENV = ${ENV}
	 PROJ = ${PROJ}
	 ENV_LOWER = ${ENV_LOWER}
	 ARCHETYPE = ${ARCHETYPE}
	 INSTANCE_NUM = ${INSTANCE_NUM}
	 ESB_HOST_PORT = ${ESB_HOST_PORT}
	 EDI_HOST_PORT_QM = ${EDI_HOST_PORT_QM}
	 EDI_HOST = ${EDI_HOST}
	 EDI_HOST = ${EDI_PORT}
	 EDI_HOST = ${EDI_QM}
	 ENV_LEVEL = ${ENV_LEVEL}
	 INSTANCE = ${INSTANCE}
	 ENV_TYPE = ${ENV_TYPE}
	 NODE_NUM = ${NODE_NUM}
	 NODE_NAME = ${NODE_NAME}
	 NODE_COMPONENT = ${NODE_COMPONENT}
	 NODE_PROFILE_HOME = ${NODE_PROFILE_HOME}
	 DB_URL = ${DB_URL}
	 ENCODE_PASS = ${ENCODE_PASS}
	 LOAD BALANCER = $LOAD_BALANCER
	 MOBILE_URL = $MOBILE_URL
	 HOST = $HOST
	 CLUSTERNAME = $CLUSTERNAME
	 -----------------------------------------
	 variable list complete
	 ----------------------------------------- 
	 
	 # "

#*****************************************************
# build instance:
# ---------------
# 1) if the environment type is dmgr
#      - call create dmgr function	  
# 2) if the environment type is app server 
#     - check for existance of a managed profile and if it does not exist then create
#	  - create app server instance based on xml template
# 3) if web server instance
#      - create instance
#      - post conf and plugin configs	   
#*****************************************************



if [  ${ARCHETYPE} == "integrated" ] ; then
   # create the dmgr if it does not exist
   if [ ${WAS_COMPONENT} == "dmgr" ]; then
	createDmgr ${ENV_TYPE} ${ENV}${INSTANCE}
	#configureCell
	openPerms
    exit 0
   fi
   # create configure web server
   if [ ${WAS_COMPONENT} == "webserver" ]; then
	configureWebServer ${ENV_TYPE} ${ENV}${INSTANCE}
    openPerms
	exit 0
   fi
   if [ ${WAS_COMPONENT} == "nodeagent" ]; then
     createManagedProfile ${ENV_TYPE} ${ENV}${INSTANCE}${INSTANCE_NUM}
     openPerms
	exit 0
   fi
   if [ ${WAS_COMPONENT} == "configure_cell" ]; then
		configureCell
		exit 0
	fi
   #*****************************************************
   # create xml file from the template
   #*****************************************************	 
   # create instance
   echo "--> create instance ${INSTANCE}"
   callSphere ${ENV_TYPE} ${ENV}${INSTANCE}${INSTANCE_NUM} build_instance
   exit 0
else
	# set the hostname for project env
	# remove this entry when dns updates
	# for all application types are part of 
	# the framework
	# ***************************************
	if [ ${WAS_COMPONENT} == "configure_cell" ]; then
		configureCell
		exit 0
	fi


        # create configure web server
        if [ ${WAS_COMPONENT} == "webserver" ]; then
             setInstance ${WAS_COMPONENT}
	     configureWebServer ${ENV_TYPE} ${ENV}${INSTANCE}
             openPerms
             exit 0
        fi

	case ${PROJ} in

    consumer)
		    callStart
			# create dmgr, managed node, webserver
			createProjectComponents
			for INSTANCE in consumer consumerBatch csadmin content preference fap
	        do
					setInstance ${INSTANCE}
					createInstance
			done
			callStop
			openPerms
	;;
	
	provider)
		    callStart
			# create dmgr, managed node, webserver
			createProjectComponents
			for INSTANCE in provider providerBatch csadmin content preference fap
	        do
					setInstance ${INSTANCE}
					createInstance
			done
			callStop
			openPerms
	;;
	
	mobile*)
		    callStart
			# create dmgr, managed node, webserver
			createProjectComponents
			for INSTANCE in mobileWeb MobileApi mobileSVc
	        do
					setInstance ${INSTANCE}
					createInstance
			done
			callStop
			openPerms
	;;
	
	producer)
		    callStart
			# create dmgr, managed node, webserver
			createProjectComponents
			for INSTANCE in producer producerBatch csadmin content preference fap
	        do
					setInstance ${INSTANCE}
					createInstance
			done
			
	;;
	
	*)
		echo "project --> $PROJ not defined" 
	;;
	esac

fi

