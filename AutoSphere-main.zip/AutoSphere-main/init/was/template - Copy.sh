#!/bin/sh

echoVARs() {

# debug: output variables
echo "
	 -----------------
	 list of variables
	 -----------------
	 ENV = ${ENV}
	 PROJ = ${PROJ}
	 ENV_LOWER = ${ENV_LOWER}
	 ARCHETYPE = ${ARCHETYPE}
	 INSTANCE_NUM = ${INSTANCE_NUM}
	 ESB_HOST_PORT = ${ESB_HOST_PORT}
	 DP_HOST = ${DP_HOST}
	 EDI_HOST_PORT_QM = ${EDI_HOST_PORT_QM}
	 EDI_HOST = ${EDI_HOST}
	 EDI_HOST = ${EDI_PORT}
	 EDI_HOST = ${EDI_QM}
	 ENV_LEVEL = ${ENV_LEVEL}
	 INSTANCE = ${INSTANCE}
	 ENV_TYPE = ${ENV_TYPE}
	 NODE_NUM = ${NODE_NUM}
	 NODE_NAME = ${NODE_NAME}
	 NODE_COMPONENT = ${NODE_COMPONENT}
	 NODE_PROFILE_HOME = ${NODE_PROFILE_HOME}
	 DB_URL = ${DB_URL}
	 ENCODE_PASS = ${ENCODE_PASS}
	 LOAD BALANCER = $LOAD_BALANCER
	 MOBILE_URL = $MOBILE_URL
	 HOST = $HOST
	 CLUSTERNAME = $CLUSTERNAME
	 WAS_ROOT = $WAS_ROOT
	 -----------------------------------------
	 variable list complete
	 ----------------------------------------- 
	 
	 "
}

setOS() {

# set specific os settings

case ${OP_PLAT} in
	pure)
		PLATFORM=rhel
		OS_LEVEL=RHEL64
		WAS_ROOT=/opt/WebSphere/
		DM_HOST=dm1-${ENV_LOWER}
		DMGR_PROFILE_HOME=/apps/${ENV}-dm1/profiles
		ORACLE_JDBC_DRIVER_PATH=/opt/oracle/jdbc/lib
		EXTENDED_DOCUMENT_ROOT=/data/CONN01-htdocs/
		SHARED_LIB=/apps/${ENV}-common/
		WEB_CONF_PATH=/apps/${ENV_LOWER}-ws1/conf
		WEB_HOST_NAME=ws${NODE_NUM}-${ENV_LOWER}
		if [  ${ARCHETYPE} == "project" ] ; then
		   NODE_HOST=node1-${ENV_LOWER}
		   NODE_NAME=${ENV}Node${NODE_NUM}
		   NODE_COMPONENT=${ENV}-node1
		   NODE_PROFILE_HOME=/apps/${NODE_COMPONENT}/profiles
		   CONFIG_PORTS=false
		else
		   NODE_HOST=${HOST}${INSTANCE_NUM}.${ENV_LOWER}
		   NODE_NAME=${ENV}${INSTANCE}Node${NODE_NUM}
		   NODE_COMPONENT=${ENV}-${NODE_TYPE}${NODE_NUM}
		   NODE_PROFILE_HOME=/apps/${NODE_COMPONENT}/profiles
		   CONFIG_PORTS=true
		fi
	;;
	linux)
		PLATFORM=rhel
		OS_LEVEL=RHEL64
		WAS_ROOT=/opt/WebSphere/
		DM_HOST=dm1.${ENV_LOWER}
		DMGR_PROFILE_HOME=/apps/${ENV}-dm1/profiles
		ORACLE_JDBC_DRIVER_PATH=/opt/oracle/jdbc/lib
		EXTENDED_DOCUMENT_ROOT=/data/CONN01-htdocs/
		SHARED_LIB=/apps/${ENV}-common/
		WEB_CONF_PATH=/apps/${ENV_LOWER}-ws1/conf
		WEB_HOST_NAME=ws${NODE_NUM}.${ENV_LOWER}
		if [  ${ARCHETYPE} == "project" ] ; then
		   NODE_HOST=node1.${ENV_LOWER}
		   NODE_NAME=${ENV}Node${NODE_NUM}
		   NODE_COMPONENT=${ENV}-node1
		   NODE_PROFILE_HOME=/apps/${NODE_COMPONENT}/profiles
		   CONFIG_PORTS=false
		else
		   NODE_HOST=${HOST}${INSTANCE_NUM}.${ENV_LOWER}
		   NODE_NAME=${ENV}${INSTANCE}Node${NODE_NUM}
		   NODE_COMPONENT=${ENV}-${NODE_TYPE}${NODE_NUM}
		   NODE_PROFILE_HOME=/apps/${NODE_COMPONENT}/profiles
		   CONFIG_PORTS=true
		fi
	;;
	solaris)
		PLATFORM=solaris
		OS_LEVEL=SolarisSparc64
		WAS_ROOT=/opt/WebSphere/
		DM_HOST=${ENV_LOWER}-${HOST}
		DMGR_PROFILE_HOME=${WAS_ROOT}AppServer/profiles
		ORACLE_JDBC_DRIVER_PATH=${WAS_ROOT}oracle/jdbc/lib
		EXTENDED_DOCUMENT_ROOT=/raid/site/htdocs/${ENV}
		SHARED_LIB=${WAS_ROOT}bscConfig/${ENV}
		WEB_CONF_PATH=/opt/WebSphere/HTTPServer/conf
		WEB_HOST_NAME=${ENV_LOWER}-ws${NODE_NUM}
		if [  ${ARCHETYPE} == "project" ] ; then
		   NODE_HOST=${ENV_LOWER}-${HOST}
		   NODE_NAME=${ENV}Node${NODE_NUM}
		   NODE_COMPONENT=${ENV}-node1
		   NODE_PROFILE_HOME=${WAS_ROOT}AppServer/profiles
		   CONFIG_PORTS=false
		else
		   NODE_HOST=${ENV_LOWER}-${HOST}
		   NODE_NAME=${ENV}${INSTANCE}Node${NODE_NUM}
		   NODE_COMPONENT=${ENV}-${NODE_TYPE}${NODE_NUM}
		   NODE_PROFILE_HOME=${WAS_ROOT}AppServer/profiles
		   CONFIG_PORTS=true
		fi
	;;
	windows)
		echo "${OS} is not ready for primetime"
		exit 0
	;;
	*)
		echo "${OS} unexpected"
		echo "syntax:"
		exit 0
	;;
esac

}



ediGenVars() {
export EDI_HOST=`echo ${EDI_HOST_PORT_QM} | cut -d ":" -f1`
export EDI_PORT=`echo ${EDI_HOST_PORT_QM} | cut -d ":" -f2`
export EDI_QM=`echo ${EDI_HOST_PORT_QM} | cut -d ":" -f3`

}

encodePass() {
	DBPASS=`$JAVA_HOME/bin/java -cp ${SHIELD_COMMON}/lib/ws_runtime.jar com.ibm.ws.security.util.PasswordEncoder $DB_PASS | awk '{print $8}'`
	export ENCODE_PASS=`echo $DBPASS | sed -s 's/\"//g'`
}

dbGenPass() {
	DB_PASS=`echo -n $DBNAME | md5sum | cut -c1-30` 
	encodePass
}

dbinfo() {
    # default db info
	NUM=`echo $ENV | cut -c4-`
	export DBHOST=WPR$NUM
	export DBNAME=WPR$NUM
    export DBPORT=1521
}

preReq() {
    
	if [ -d "/apps/profiles/properties/" ]; then
       echo "/apps/profiles/properties/ exists"
    else
	mkdir -p /apps/profiles/properties
	fi

	if [ -L "/opt/jenkins/ant" ]; then
	  echo "/opt/jenkins/ant exists"
    else
	  echo "/opt/jenkins/ant does not exist .... creating"
	  ln -s /sysadmin/media/websphr/ant /opt/jenkins/ant
	fi
	
	if [ -L "/opt/jenkins/java" ]; then
	  echo "/opt/jenkins/java exists"
    else
	  echo "/opt/jenkins/java does not exist .... creating"
	  ln -s /sysadmin/media/websphr/java /opt/jenkins/java
	fi
}

 
 setInstance() {
    # set environment values based on instance variable        
	case ${1} in
		consumer) INSTANCE=Consumer HOST=consumer ENV_TYPE=consumer NODE_TYPE=consumer TEMPLATE_TYPE=consumer CLUSTERNAME=${ENV}${INSTANCE}C DU=Consumer.ear;;
		consumerBatch) INSTANCE=ConsumerBatch HOST=consumer-batch ENV_TYPE=consumer NODE_TYPE=consumer-batch TEMPLATE_TYPE=consumerBatch CLUSTERNAME=${ENV}${INSTANCE}C DU=Consumer.ear;;
		csadmin) INSTANCE=CSAdmin HOST=csadmin ENV_TYPE=csadmin NODE_TYPE=csadmin TEMPLATE_TYPE=csadmin CLUSTERNAME=${ENV}${INSTANCE}C DU=Admin.ear;;
		content) INSTANCE=Content HOST=content ENV_TYPE=content NODE_TYPE=content TEMPLATE_TYPE=content CLUSTERNAME=${ENV}${INSTANCE}C DU=Content.ear;;
		dmgr) INSTANCE=Cell HOST=dm ENV_TYPE=cell TEMPLATE_TYPE=cell;;
		preference) INSTANCE=Preference HOST=preference-center ENV_TYPE=preference NODE_TYPE=preference-center TEMPLATE_TYPE=preference CLUSTERNAME=${ENV}${INSTANCE}C DU=Preference.ear;;
		provider) INSTANCE=Provider HOST=provider ENV_TYPE=provider NODE_TYPE=provider TEMPLATE_TYPE=provider CLUSTERNAME=${ENV}${INSTANCE}C DU=Provider.ear;;
		providerBatch) INSTANCE=ProviderBatch HOST=provider-batch ENV_TYPE=provider NODE_TYPE=provider-batch TEMPLATE_TYPE=providerBatch CLUSTERNAME=${ENV}${INSTANCE}C DU=Provider.ear;;
		producer) INSTANCE=Producer HOST=producer ENV_TYPE=producer NODE_TYPE=producer TEMPLATE_TYPE=producer CLUSTERNAME=${ENV}${INSTANCE}C DU=Producer.ear;;
		producerBatch) INSTANCE=ProducerBatch HOST=producer-batch ENV_TYPE=producer NODE_TYPE=producer-batch TEMPLATE_TYPE=producerBatch CLUSTERNAME=${ENV}${INSTANCE}C DU=Producer.ear;;
		epresent) INSTANCE=EPresentBatch HOST=epresent-batch ENV_TYPE=consumer NODE_TYPE=epresent-batch TEMPLATE_TYPE=epresent CLUSTERNAME=${ENV}${INSTANCE}C DU=Consumer.ear;;
		ess) INSTANCE=ESS HOST=ess ENV_TYPE=ess NODE_TYPE=ess TEMPLATE_TYPE=ess CLUSTERNAME=${ENV}${INSTANCE}C DU=ess.war;;
		essBatch) INSTANCE=ESSBatch HOST=ess-batch ENV_TYPE=ess NODE_TYPE=ess-batch TEMPLATE_TYPE=essBatch CLUSTERNAME=${ENV}${INSTANCE}C DU=essbatch.war;;
		fap) INSTANCE=FAP HOST=fap ENV_TYPE=fap NODE_TYPE=fap TEMPLATE_TYPE=fap CLUSTERNAME=${ENV}${INSTANCE}C DU=fap.ear;;
		fapBatch) INSTANCE=FAPBatch HOST=fap-batch ENV_TYPE=fap NODE_TYPE=fap-batch TEMPLATE_TYPE=fapBatch CLUSTERNAME=${ENV}${INSTANCE}C DU=fap.ear;;
		mobile) INSTANCE=Mobile HOST=mobile ENV_TYPE=mobile NODE_TYPE=mobile TEMPLATE_TYPE=mobile CLUSTERNAME=${ENV}${INSTANCE}C DU=mobile-web.war;;
		mobileWeb) INSTANCE=MobileWeb HOST=mweb ENV_TYPE=mobile NODE_TYPE=mweb TEMPLATE_TYPE=mobileWeb CLUSTERNAME=${ENV}${INSTANCE}C DU=mobile-web.war;;
		mobileApi) INSTANCE=MobileApi HOST=mapi ENV_TYPE=mobile NODE_TYPE=mapi TEMPLATE_TYPE=mobileApi CLUSTERNAME=${ENV}${INSTANCE}C DU=mobileapi.war;;
		mobileSvc) INSTANCE=MobileSvc HOST=msvc ENV_TYPE=mobile NODE_TYPE=msvc TEMPLATE_TYPE=mobileSvc CLUSTERNAME=${ENV}${INSTANCE}C DU=mobile-svc.war;;
		epresent) INSTANCE=EPresentBatch HOST=epresent-batch ENV_TYPE=consumer NODE_TYPE=epresent-batch TEMPLATE_TYPE=consumerBatch CLUSTERNAME=${ENV}${INSTANCE}C;;
		cell) INSTANCE=Cell ENV_TYPE=cell TEMPLATE_TYPE=cell;;
                vru) INSTANCE=IVR HOST=ivr ENV_TYPE=ivr NODE_TYPE=ivr TEMPLATE_TYPE=consumer CLUSTERNAME=${ENV}${INSTANCE}C DU=VRU.ear;;
		webserverNode) INSTANCE=Web HOST=ws ENV_TYPE=webserver NODE_TYPE=ws TEMPLATE_TYPE=webserverNode;;
		webserver) INSTANCE=-ws${INSTANCE_NUM} HOST=ws${INSTANCE_NUM} ENV_TYPE=webserver TEMPLATE_TYPE=webserver
			if [ ${ARCHETYPE} == "project" ]; then
				NODE_NAME=${ENV}Node${NODE_NUM} ; else
				NODE_NAME=${ENV}WebNode${NODE_NUM}
			fi 
		;;
	esac
 }

#**********************************
createInstanceXml() {
    #checking if instance is batch

	case $2 in

	*)
		${ANT_HOME}/bin/ant -f ${SHIELD_HOME}/ant_tasks/sphere.xml ${ANT_OPTS} -DENV_TYPE=$1 -DTEMPLATE_TYPE=${TEMPLATE_TYPE} -DSHIELD_HOME=${SHIELD_HOME} -DINSTANCE=$2 -DENVID_UPPER=$3 -DENVID_LOWER=$4  -DDB_URL=$DB_URL -DENCODE_PASS=$ENCODE_PASS -DNODE_NUM=$NODE_NUM -DLOAD_BALANCER=$LOAD_BALANCER -DENV_LEVEL=$ENV_LEVEL -DESB_HOST_PORT=$ESB_HOST_PORT -DDP_HOST=$DP_HOST -DEDI_HOST=$EDI_HOST -DEDI_PORT=$EDI_PORT -DEDI_QM=$EDI_QM -DINSTANCE_NUM=$INSTANCE_NUM -DNODE_NAME=$NODE_NAME -DNODE_COMPONENT=$NODE_COMPONENT -DNODE_PROFILE_HOME=$NODE_PROFILE_HOME -DMOBILE_URL=$MOBILE_URL -DHOST=$HOST -DARCHETYPE=$ARCHETYPE -DCONFIG_PORTS=$CONFIG_PORTS -DCLUSTERNAME=$CLUSTERNAME  -DXML_HOME=${XML_HOME} -DDMGR_PROFILE_HOME=$DMGR_PROFILE_HOME -DDM_HOST=$DM_HOST -DNODE_HOST=$NODE_HOST -DPLATFORM=$PLATFORM -DOS_LEVEL=$OS_LEVEL -DWAS_ROOT=$WAS_ROOT -DORACLE_JDBC_DRIVER_PATH=$ORACLE_JDBC_DRIVER_PATH -DEXTENDED_DOCUMENT_ROOT=$EXTENDED_DOCUMENT_ROOT -DSHARED_LIB=$SHARED_LIB -DSHIELD_COMMON=${SHIELD_COMMON} -DJAVA_HOME=${JAVA_HOME} -DWEB_CONF_PATH=${WEB_CONF_PATH} -DWEB_HOST_NAME=${WEB_HOST_NAME} configure_instance_xml
	;;
	esac
}

buildTemplate() {
    setInstance $INSTANCE
	setOS
	echoVARs
    createInstanceXml ${ENV_TYPE} ${INSTANCE}${INSTANCE_NUM} ${ENV} ${ENV_LOWER}
}
callStart() {
	START=$(date +%c)
    echo "START TIME: $START"
}

callStop() {
	STOP=$(date +%c)
    echo "START TIME: $START"
	echo "STOP TIME: $STOP"
}

openPerms() {
    echo "openning permissions /opt/AutoSphere/tmp"
	chmod -R 775 /opt/jenkins/AutoSphere/tmp
	    echo "openning permissions /opt/AutoSphere/logs"
	chmod -R 775 /opt/jenkins/AutoSphere/logs
}
 

#**********************************
usage() {
echo "		description: WebSphere Automation Framework
		usage:
			$0  -p <project type> -e <env_identifyer>
		OPTIONS:				DESCRIPTION:
     
		-e   <env_identifyer>[required]  	the name of the stripe - (WEBN42)   
		-p   <project type>[required]	  	project types [consumer, consumerBatch, csadmin, dmgr, content, preference
		                                        producer, producerBatch, provider, providerBatch, ess, essBatch, 
							fap fapBatch, mobile, mobileApi, epresent, webserver, vru]
		-c   <custom>[optional]             this will create one custom template based on project type (default = false)
		-a   <archetype>[optional]     	    	archetype [project, integrated, clustered] (default = project)
                                                    	integrated types [consumer, ess, producer, provider, preference, 
													mobile dmgr, web]		
		-n   <instance number>[optional]    	used with the int/cluster type (1,2,3,4) (default = 1)
		-s   <esb connecttion>[optional]    	[host]:[port] (default = uwmb001d.dev.bscal.local:2401)
		-r   <datapower host>[optional]   [host] (default = [DP_HOST])
		-i   <edi connection>[optional]     	[host]:[port]:[queue manager] (default = uwmb001d.dev.bscal.local:7801:ESBGD1)
		-l   <environment level>[optional]  	[npe, webh, intStage, stage, prod] (default = npe)
		
		-b   <load balancer>[optional]      	example: https://webn90.blueshieldcloud.net
		                                    	(default = http://ws1.[env_identifier].blueshieldcloud.net:20000)
		
		-m   <mobile url>                   	example: https://m.webn90.blueshieldcloud.net/mobile-web/initial_popup.sp 
		                                    	(default = http://ws1.[env_identifier].blueshieldcloud.net:20000/mobile-web/initial_popup.sp)
		
		-d   <database>[optional]           	example: [database server]:[database port]:[database name]
		-x   <database password>[optional]      
		-o   <operating platform>[optional]                     [solaris, linux, windows, pure] (default = linux)
		-h   <help>[optional]               	[display usage or help menu]
		
																			"
		exit 0
}



CUR_PATH=`dirname $0`
. ${CUR_PATH}/../../../AutoCommon/bin/common/configure.properties


while getopts p:e:a:n:s:i:l:b:m:d:x:w:h:y:o:r:c: arg
do
	case $arg in
		e) ENV=$OPTARG;;
		p) PROJ=$OPTARG;;
		a) ARCHETYPE=$OPTARG;;
		c) CUSTOM=$OPTARG;;
		n) INSTANCE_NUM=$OPTARG;;
		r) DP_HOST=$OPTARG;;
		s) ESB_HOST_PORT=$OPTARG;;
        	i) EDI_HOST_PORT_QM=$OPTARG;;
        	l) ENV_LEVEL=$OPTARG;;
        	b) LOAD_BALANCER=$OPTARG;;
		m) MOBILE_URL=$OPTARG;;
        	d) DB_URL=$OPTARG;;
        	x) DB_PASS=$OPTARG;;
		w) WAS_COMPONENT=$OPTARG;;
		o) OP_PLAT=$OPTARG;;
		h|*) usage;;
	esac
done

# check arguments
if [ $# -lt 2 ]; then
	usage
	exit 0
fi


#*****************************************************
# START: set / check variables
#*****************************************************
#set prereq's
#preReq

#*****************************************************
# start: base script variables
#*****************************************************
AUTO_HOME=c:/svnprod
SHIELD_HOME=${AUTO_HOME}/AutoSphere
SHIELD_COMMON=${AUTO_HOME}/AutoCommon
CLASSPATH="${SHIELD_COMMON}/lib:${SHIELD_COMMON}/lib/xmlParser:${AUTO_HOME}/java/${OS}/${PLATFORM}:${SHIELD_HOME}/lib/jython.jar"
PATH=$PATH:${AUTO_HOME}/ant/bin:${AUTO_HOME}/java:${AUTO_HOME}/ant
ANT_HOME=${AUTO_HOME}/ant

export JAVA_HOME=${AUTO_HOME}/java
export CLASSPATH PATH
#*****************************************************
# check for an alternate XML location
# new for archetype approach - allows on-demand
# creation of XML 
if [ -z ${XML_HOME} ]; then
   XML_HOME=${SHIELD_HOME}
fi


# ensure required variables are set
if [ -z ${ENV} -o -z ${PROJ} ]; then
	echo " environment or project variables are missing
	       ENV = ${ENV}
	       PROJ = ${PROJ}"
    exit 0
fi

#create environment lower case
ENV_LOWER=`echo ${ENV} | tr '[:upper:]' '[:lower:]'`

# set defaults if not set
: ${ARCHETYPE:=project}
: ${INSTANCE_NUM:=1}
: ${DP_HOST:=[DP_HOST]}
: ${ESB_HOST_PORT:=uwmb001d.dev.bscal.local:7801}
: ${EDI_HOST_PORT_QM:=uwmb001d.dev.bscal.local:2401:ESBGD1}
: ${ENV_LEVEL:=npe}
: ${OP_PLAT:=linux}
: ${CUSTOM:=false}

# generate EDI variables
ediGenVars


if [ -z ${DB_URL}]; then
   echo "before - DB_URL: $DB_URL"
   dbinfo
   DBURL=${DBHOST}:${DBPORT}:${DBNAME}
   export DB_URL=${DBURL}
   echo "after - DB_URL: $DB_URL"
fi

if [ -z ${DB_PASS}]; then
   dbGenPass
else
   encodePass
fi

if [ -z ${LOAD_BALANCER} ]; then
   LOAD_BALANCER="http://ws1.${ENV_LOWER}.blueshieldcloud.net:20000"
fi

if [ -z ${MOBILE_URL} ]; then
   MOBILE_URL="http://ws1.${ENV_LOWER}.blueshieldcloud.net:20000/mobile-web/initial_popup.sp"
fi

# get instance name
setInstance ${PROJ}
CLUSTERNAME=${ENV}${INSTANCE}C

#determine node configuration
if [ ${INSTANCE_NUM} -eq "1" -o ${INSTANCE_NUM} -eq "3" ]; then
    NODE_NUM="1"
else
    NODE_NUM="2"
fi	



 
#*****************************************************
# end: base script variables
#*****************************************************




#*****************************************************
# build instance:
# ---------------
# 1) if the environment type is dmgr
#      - call create dmgr function	  
# 2) if the environment type is app server 
#     - check for existance of a managed profile and if it does not exist then create
#	  - create app server instance based on xml template
# 3) if web server instance
#      - create instance
#      - post conf and plugin configs	   
#*****************************************************

   # create configure web server
   if [ ${PROJ} == "dmgr" ]; then
	  setInstance dmgr	
	  setOS
      buildTemplate
		exit 0
   fi

   # create configure web server
   if [ ${PROJ} == "webserver" ]; then
		setOS
		setInstance webserver
		createInstanceXml ${ENV_TYPE} -ws1 ${ENV} ${ENV_LOWER}
		exit 0
   fi
   
   # create a single custom template
   if [ ${CUSTOM} == "true" ]; then
		setInstance $PROJ
		buildTemplate
		exit 0
   fi
   
   # create a project or integrated template pattern
   if [ ${ARCHETYPE} == "project" ]; then 
	    case $PROJ in
			provider)
					for INSTANCE in provider providerBatch csadmin content preference fap cell
					do
						buildTemplate
					done
					exit 0
     		;;
			consumer)
					for INSTANCE in consumer consumerBatch csadmin content preference fap cell
					do
						buildTemplate
					done
					exit 0
     		;;
			producer)
					for INSTANCE in producer producerBatch csadmin content preference fap cell
					do
						buildTemplate
					done
					exit 0
     		;;
			mobile)
					for INSTANCE in mobileWeb MobileApi mobileSVc cell
					do
						buildTemplate
					done
					exit 0
     		;;
			*)
					echo "project type: $PROJ -> not found"
					exit 0
     		;;
      	esac
	fi	

    if [ ${ARCHETYPE} == "integrated" ]; then
	  
	  			for INSTANCE in consumer consumerBatch csadmin content preference producer producerBatch provider providerBatch ess essBatch fap fapBatch epresent
					do
						buildTemplate
				    done
				echo "pattern xml complete: run dmgr, web server and cell separately"
				exit 0
                				
   fi
   
