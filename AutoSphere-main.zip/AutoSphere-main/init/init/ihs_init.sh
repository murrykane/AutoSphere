#!/bin/bash
# 
# Murry Kane
# Version 1.1
# jvm_init.sh used to stop/start Websphere for shutdown/startup of unix box as well as Linux Service
# 
# Modification History
# Who                 Date         Notes
#__________________________________________________________________________________________________
# Murry Kane          04/26/2017   Initial Version                 
#                     05/10/2017   For a server that has two web servers needed new logic for getting PID
#                     03/12/2019   Added logic to use JENKINS_DIR
#__________________________________________________________________________________________________


option_count=${#}
command=${1}

# source in the env setup script
if [ ! -z "${PROJ_PATH}" ]
then
  . ${PROJ_PATH}/shell/functions > /dev/null 2>&1
elif [ -s /opt/jenkins/AutoSphere/shell/functions ]
then
  . /opt/jenkins/AutoSphere/shell/functions > /dev/null 2>&1
elif [ -s /nfs/it-pam/scripts/functions ]
then
  . /nfs/it-pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/pam/scripts/functions ]
then
  . ~/pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/.mkane01/scripts/functions ]
then
  . ~/.mkane01/scripts/functions > /dev/null 2>&1
else
  echo "********************************************************************************"
  echo "*  ERROR: Can not define ENV as PROJ_PATH can't be found, exiting...."
  echo "********************************************************************************"
  exit 5
fi

if [ -s ${PAM_SHELL_DIR}/was_functions ]
then
  . ${PAM_SHELL_DIR}/was_functions > /dev/null 2>&1
else
  echo "ERROR: Could not find the was_functions here: [${PAM_SHELL_DIR}/was_functions], exiting!"
  exit 6 
fi

APPLNAME="ihs_init"
eval LOGFILE=${NIGHTLY_LOG_DIR}/${APPLNAME}.${DATE_STAMP}.log
WASNAME="websphr"
ROOTUSER="root"
rc=0
timeout=90
PIDPROC=""
shortSleep=5
IHSOLDCONFIG="${INIT_DIR}/ihs_instances.prop"
IHSNEWCONFIG="${JENKINS_DIR}/ihs_instances.prop"
IHSCONFIG=""
IHSPROC="HTTPServer/bin/httpd"
IHSPID=0

command=$(tolower ${command})

usage()
{
  echo "${0} start|stop|buildconfig"
  echo "Example: ${0} start"
}

if [ "${CURR_USER}" != "${WASNAME}" -a "${CURR_USER}" != "${ROOTUSER}" ]
then
  log_msg "You must be ${WASNAME} or ${ROOTUSER} to execute this script, ABORTING!"
  exit 5
else  
  log_msg "Running as user [${CURR_USER}] with argument [${command}]"
fi

if [ "${CURR_USER}" = "${ROOTUSER}" ]
then
  chown ${WASNAME}:${WASNAME} ${LOGFILE} > /dev/null 2>&1
fi

getFile()
{
  #lets determine if we are using old location or new location for IHS property file
  if [ -s ${IHSOLDCONFIG} ]
  then
    if [ -s ${IHSNEWCONFIG} ]
    then
      log_msg "Config File exists in both locations using new location..."
      IHSCONFIG="${IHSNEWCONFIG}"
    else
      #lets copy to new location...
      cp ${IHSOLDCONFIG} ${IHSNEWCONFIG} 2>/dev/null
      rc=$?
      if [ ${rc} -eq 0 ]
      then
        log_msg "Copied IHS property file to new location"
      else
        log_msg "ERROR: Could NOT copy IHS property file to new location, setting to old location!"
        IHSCONFIG="${IHSOLDCONFIG}"
      fi
    fi 
    IHSCONFIG="${IHSNEWCONFIG}"
  else
    if [ -s ${IHSNEWCONFIG} ]
    then
      log_msg "Using New Location for IHS Property"
      IHSCONFIG="${IHSNEWCONFIG}" 
    else
      log_msg "Defaulting to new location for property file..."
      IHSCONFIG="${IHSNEWCONFIG}" 
    fi
  fi

  log_msg "Using IHS property file: [${IHSCONFIG}]"
  chown ${WASNAME}:${WASNAME} ${IHSCONFIG} 2>/dev/null
  rc=$?
  if [ ${rc} -eq 0 ]
  then
    log_msg "IHSCONFIG file changed to owner: [${WASNAME}]"
  else
    log_msg "ERROR: Could NOT change owner to [${WASNAME}]!"
    exit 16
  fi
  chmod 600 ${IHSCONFIG} 2>/dev/null
  rc=$?
  if [ ${rc} -eq 0 ]
  then
    log_msg "IHSCONFIG file permissions updated"
  else
    log_msg "ERROR: Could NOT change permissions on IHSCONFIG!"
    exit 17
  fi

}

startIhs()
{
   log_msg " Starting IHS instances..."
   if [ -s  ${IHSCONFIG} ]; then
      echo "Starting IHS instances..."
      startIhsInstances
   else
      log_msg "ERROR: Missing ${IHSCONFIG} we can NOT start IHS!"
      exit 55
   fi
}

startIhsInstances()
{

  #mbk lets first get the property file
  getFile

  if [ -z ${IHS_HOME} ]
  then
    #let's setup was_home....
    setIHSHome
    rc=$?
    if [ ${rc} -eq 0 ]
    then
      :
    else
      log_msg "ERROR: Could NOT determine IHS home directory!"
      exit 13
    fi
  fi
  
  while read ihs_conf
  do
    log_msg "Running command : '${IHS_HOME}/bin/apachectl -k start -f ${ihs_conf}'"
    if [ "${CURR_USER}" = "${ROOTUSER}" ]
    then
      sudo su - ${WASNAME} -c "nohup ${IHS_HOME}/bin/apachectl -k start -f ${ihs_conf} >> ${LOGFILE} 2>&1 &"
    else
      nohup ${IHS_HOME}/bin/apachectl -k start -f ${ihs_conf} >> ${LOGFILE} 2>&1 &
    fi
    rc=$?
    if [ ${rc} -eq 0 ]
    then
      sleep ${shortSleep}
      IHSPID=$(ps -ef | grep "${IHSPROC}" | grep -v grep | egrep "^${WASNAME}" | awk -F' ' '{print $2"~"$3}' | egrep -v '~[0-9][0-9]' | cut -d'~' -f1 | sort -ur | head -1)
      re='^[0-9]+$'
      if ! [[ $IHSPID =~ $re ]]
      then
        log_msg "ERROR: PID not found to be a number, which means we did not start IHS successfully!" 
        exit 7
      else
        #lets see if the PID is running....
        check_it=$(ps -A -o pid,cmd|grep ${IHSPID} | grep -v grep |head -n 1 | awk '{print $1}')
        if [ "${check_it}" = "${IHSPID}" ]
        then
          log_msg "Successfully started IHS with PID [${IHSPID}]."
        else
          log_msg "IHS was started with PID [${IHSPID}], but no longer seems to be running!"
          exit 14
        fi
      fi
    else
      log_msg "ERROR: Could NOT start the IHS service!"
      exit ${rc}
    fi
  done < ${IHSCONFIG}
  
}

stopIhs()
{

  #mbk lets first get the property file
  getFile

  if [ -z ${IHS_HOME} ]
  then
    #let's setup was_home....
    setIHSHome
    rc=$?
    if [ ${rc} -eq 0 ]
    then
      :
    else
      log_msg "ERROR: Could NOT determine IHS home directory!"
      exit 13
    fi
  fi
  
  while read ihs_conf
  do
    log_msg "Running command : '${IHS_HOME}/bin/apachectl -k stop -f ${ihs_conf}'"
    if [ "${CURR_USER}" = "${ROOTUSER}" ]
    then
      sudo su - ${WASNAME} -c "nohup ${IHS_HOME}/bin/apachectl -k stop -f ${ihs_conf} >> ${LOGFILE} 2>&1 &"
    else
      nohup ${IHS_HOME}/bin/apachectl -k stop -f ${ihs_conf} >> ${LOGFILE} 2>&1 &
    fi
    rc=$?
    if [ ${rc} -eq 0 ]
    then
      log_msg "Successfully submitted IHS stop command..."
    else
      log_msg "ERROR: Could NOT stop the IHS service!"
      exit ${rc}
    fi    
  done < ${IHSCONFIG}
  
}

buildIhs()
{
  #mbk setting to new location if we are creating file....
  IHSCONFIG="${IHSNEWCONFIG}"

  if [ -s ${IHSCONFIG} ]
  then
    log_msg "The IHSCONFIG[${IHSCONFIG}] exists, removing to build a new one, current content appended to log file..."
    cat ${IHSCONFIG} >> ${LOGFILE} 2>&1
    rm -f ${IHSCONFIG} 2>/dev/null
  fi
  
  ihs_find=$(ps -ef | grep -i "${IHSPROC}" | grep -v grep | egrep "^${WASNAME}" | awk '{print $NF}' | sort -ur)
  log_msg "IHS configuration files found is [${ihs_find}]"
  if [ -z "${ihs_find}" ]
  then
    log_msg "ERROR: We could not find any IHS processes running!"
    exit 10
  else
    #remove the file first
    if [ -e ${IHSCONFIG} ]
    then
      rm ${IHSCONFIG} 2>/dev/null
    fi
    
    #lets see if the file exists before putting to file and ends in '.conf'
    for line in $(echo "${ihs_find}")
    do
      log_msg "Checking IHS instance [${line}]"
      if [ -e ${line} ]
      then
        #now check if it ends with .conf
        #filename=test.csv
        fileext=${line##*.}
        log_msg "File extention is [${fileext}]"
        if [ ${fileext} = "conf" ]
        then
          log_msg "File is a .conf type, adding to property file with: [${line}]"
          #put it to property file...
          echo "${line}" >> ${IHSCONFIG} 2>/dev/null
          log_msg "Adding IHS Instance [${line}] to property file"
        else
          log_msg "File is NOT a .conf type, skipping this file [${line}]!"
        fi
      else
        log_msg "IHS Instance [${line}] not found, skipping this entry"
      fi
    done
    #echo "${ihs_find}" >  ${IHSCONFIG} 2>/dev/null 
    #rc=$?
    if [ -s ${IHSCONFIG} ]
    then
      log_msg "IHSCONFIG file [${IHSCONFIG}] created with content, content appended to log."
      cat ${IHSCONFIG} >> ${LOGFILE} 2>&1
    else
      log_msg "ERROR: Could NOT create IHSCONFIG file!"
      exit 11
    fi
    chown ${WASNAME}:${WASNAME} ${IHSCONFIG} 2>/dev/null
    rc=$?
    if [ ${rc} -eq 0 ]
    then
      log_msg "IHSCONFIG file changed to owner: [${WASNAME}]"
    else
      log_msg "ERROR: Could NOT change owner to [${WASNAME}]!"
      exit 16
    fi
    chmod 600 ${IHSCONFIG} 2>/dev/null
    rc=$?
    if [ ${rc} -eq 0 ]
    then
      log_msg "IHSCONFIG file permissions updated"
    else
      log_msg "ERROR: Could NOT change permissions on IHSCONFIG!"
      exit 17
    fi
  fi
  return 0
  
}


case "${command}" in
     stop)
        log_msg " Stopping all running instances "
        stopIhs
        ;;
     start)
        log_msg " Starting all running instances"
        startIhs
        ;;
     buildconfig)
        log_msg "Building the IHS configuration"
        buildIhs
        ;;
     *)
        usage
        exit 1
esac

log_msg "Successfully completed ${APPLNAME}"

exit 0