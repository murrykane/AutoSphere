#!/bin/sh
echo "All the best"

user_id=svcbscwas-npe
password=sPring-f@st23

stopDmgr()
{
     
                    path="/apps/*/profiles/*/bin"
                    $path/stopManager.sh  -username  $user_id  -password  $password
                    nohup $path/stopManager.sh  -username  $user_id  -password  $password &


 
}



startDmgr()
{
     
                    path="/apps/*/profiles/*/bin"
                    $path/startManager.sh
                    nohup $path/startManager.sh &


      }


first_arg=$1

case "$1" in

     stopDmgr)
        stopDmgr
       ;;
     startDmgr)
        startDmgr
       ;;
     *)
        echo " not correct choice "
        exit 1
esac
