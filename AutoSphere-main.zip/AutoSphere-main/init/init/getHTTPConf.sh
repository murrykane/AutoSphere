#!/bin/bash
# 
# Murry Kane
# Version 1.0
# getHTTPConf.sh used by SystemD UNIT file as pre-step to get the conf file for a given HTTP server
# 
# Modification History
# Who                 Date         Notes
#__________________________________________________________________________________________________
# Murry Kane          07/10/2020   
#__________________________________________________________________________________________________

option_count=${#}
command=${1}

if [ -d /opt/IBM/WebSphere/HTTPServer/conf ]
then
  :
  #echo "We are good, standard setup for IHS/HTTP"
else
  echo "BAD installation of IHS/HTTP, exiting!"
  exit 5
fi

get_conf()
{
  confFile=$(ls /opt/IBM/WebSphere/HTTPServer/conf/*.conf | egrep -v '(httpd.conf|admin.conf)')
  if [ -z $confFile ]
  then
    echo "BAD installation of IHS/HTTP, exiting!"
    exit 5
  else
    :
    #echo "Found the following Config File: [$confFile]"
  fi
  echo $confFile

}


get_instance()
{
  confFile=$(ls /opt/IBM/WebSphere/HTTPServer/conf/*.conf | egrep -v '(httpd.conf|admin.conf)')
  if [ -z $confFile ]
  then
    echo "BAD installation of IHS/HTTP, exiting!"
    exit 5
  else
    ihs_instance=$(grep -i rotatelogs ${confFile} | grep -v grep | head -1 | cut -d' ' -f3 | cut -d'/' -f7)
  fi
  if [ -z $ihs_instance ]
  then
    echo "BAD installation of IHS/HTTP, exiting!"
  else
    :
  fi
  echo $ihs_instance
}

case "${command}" in
     'getconf')
        get_conf
        ;;
     'getinstance')
        get_instance
        ;;
     *)
        echo "Command ${command} is not a correct choice, exiting!"
        exit 1
esac

exit 0