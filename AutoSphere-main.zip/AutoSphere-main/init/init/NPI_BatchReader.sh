#!/bin/bash
# 
# Murry Kane
# Version 1.0
# NPI_BatchReader.sh used to stop/start NPI Batch Reader Proccesses
# 
# Modification History
# Who                 Date         Notes
#__________________________________________________________________________________________________
# Murry Kane          09/21/2017   Initial Version                
# Murry Kane          02/26/2019   Added logic for file existence then skip INIT script, this was done for infrastructure weekends where
#                                  reboots of the systems after patching would bring up the applications that would later break due to 
#                                  Oracle patching after reboots were completed that would break the DB connections for WebSphere
# Murry Kane          02/26/2020   Added logic for validatestart and validatestop along with fixpid
#
#
#__________________________________________________________________________________________________
# 

option_count=${#}
command=${1}

# source in the env setup script
if [ ! -z "${PROJ_PATH}" ]
then
  #echo "proj_path is defined...."
  . ${PROJ_PATH}/shell/functions > /dev/null 2>&1
elif [ -s /opt/jenkins/AutoSphere/shell/functions ]
then
  #echo "found /opt/jenkins/AutoSphere/shell/functions"
  . /opt/jenkins/AutoSphere/shell/functions > /dev/null 2>&1
elif [ -s /nfs/it-pam/scripts/functions ]
then
  #echo "found /nfs/it-pam/scripts/functions"
  . /nfs/it-pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/pam/scripts/functions ]
then
  #echo "found ~/pam/scripts/functions"
  . ~/pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/.mkane01/scripts/functions ]
then
  #echo "found in murry's directory...."
  . ~/.mkane01/scripts/functions > /dev/null 2>&1
else
  echo "********************************************************************************"
  echo "*  ERROR: Can not define ENV as PROJ_PATH can't be found, exiting...."
  echo "********************************************************************************"
  exit 5
fi


APPLNAME="NPI_BatchReader"
eval LOGFILE=${NIGHTLY_LOG_DIR}/${APPLNAME}.${DATE_STAMP}.log
WASNAME="websphr"
ROOTUSER="root"
NPIUSER="npiadm"
rc=0
timeout=90
SkipINIT="/tmp/SKIP_START_APPLICATION.txt"
PIDPROC=""
shortSleep=10
batchReaderPath="/npi/InitiateSystems/Engine10.1.0/messaging/"
batchReaderSAPath="/npi/InitiateSystems/Engine10.1.0/messaging_sa/"
batchReaderCmd="batchreader.ksh"
batchReaderSACmd="batchreader_sa.ksh"

command=$(tolower ${command})

usage()
{
  echo "${0} start|stop"
  echo "Example: ${0} start"
}


if [ "${CURR_USER}" != "${ROOTUSER}" -a "${CURR_USER}" != "${NPIUSER}" ]
then
  log_msg "You must be ${ROOTUSER} or ${NPIUSER} to execute this script, ABORTING!"
  exit 5
else  
  log_msg "Starting Program [${APPLNAME}] with user [${CURR_USER}] with command [${command}]"
fi

if [ "${CURR_USER}" = "${ROOTUSER}" ]
then
  chown ${WASNAME}:${WASNAME} ${LOGFILE} > /dev/null 2>&1
  chmod 777 ${LOGFILE} 
  # let's source in the environment for NPIUser
  #eval echo "~$different_user"
  homeDir=$(eval echo "~${NPIUSER}")
  if [ -s ${homeDir}/.bash_profile ]
  then
    log_msg "Sourcing in [${NPIUSER}] .bash_profile"
    source ${homeDir}/.bash_profile >> ${LOGFILE} 2>&1
    #set >> ${LOGFILE}
  fi
else
  chmod 777 ${LOGFILE}
fi

# lets get the MAD_ROOTDIR home directory
if [ ! -z "${MAD_ROOTDIR}" ]
then
  log_msg "NPI Idenity Hub ROOT DIR is [${MAD_ROOTDIR}]"
else
  log_msg "WARNING: NPI Identity HUB ROOT DIR not found, hard-coding to /npi/InitiateSystems/Engine10.1.0"
  MAD_ROOTDIR="/npi/InitiateSystems/Engine10.1.0"
fi

case ${option_count} in
  0) 
    usage
    exit 5;;
  1)
    # lets validate arguement 1
    if [ "${command}" = "start" ]
    then
      #Lets validate if Skip INIT script is in place....
      log_msg "Checking for SKIP application startup...."
      if [ -e "${SkipINIT}" ]
      then
        log_msg "Skipping Application startup as the SKIP start file [$SkipINIT] is present!"
        exit 99
      fi
    elif [ "${command}" = "stop" ]
    then
      :
    elif [ "${command}" = "validatestart" ]
    then
      :
    elif [ "${command}" = "validatestop" ]
    then
      :
    elif [ "${command}" = "fixpid" ]
    then
      :
    else
      usage
      exit 5
    fi
    ;;
  *) 
    usage
    exit 5
    ;;
esac



startNPIBatchReader()
{
  
  cmdPath=${1}
  cmdBin=${2}
  
  if [ "${cmdPath}" == "" ]
  then
    log_msg "Command Path must be passed!, exiting!"
    return 1
  fi
  if [ "${cmdBin}" == "" ]
  then
    log_msg "Command Script must be passed!, exiting!"
    return 1
  fi
  
  if [ "${CURR_USER}" = "${ROOTUSER}" ]
  then
    log_msg "Attempting to START NPI Batch Reader [${cmdPath}${cmdBin}] with sudo su - ${NPIUSER} -c 'source ~/.bash_profile;cd ${cmdPath};ksh ${cmdBin} 2>&1 > /dev/null & >> ${LOGFILE} 2>&1'" 
    sudo su - ${NPIUSER} -c  "source ~/.bash_profile;cd ${cmdPath};ksh ${cmdBin} 2>&1 > /dev/null &" >> ${LOGFILE} 2>&1
    rc=$?
    if [ ${rc} -eq 0 ]
    then
      log_msg "Successfully issued [${cmdPath}${cmdBin}] on the NPI Batch Reader"
    else
      log_msg "ERROR: Could NOT [${cmdPath}${cmdBin}] the NPI Batch Reader, with RC ${rc}!"
      exit ${rc}
    fi
  else
    log_msg "Attempting to START NPI Batch Reader [${cmdPath}${cmdBin}] with: 'ksh ${cmdBin} 2>&1 > /dev/null &'" 
    cd ${cmdBin}
    ksh ./${cmdBin} 2>&1 > /dev/null & 
    rc=$?
    if [ ${rc} -eq 0 ]
    then
      log_msg "Successfully issued [${cmdPath}${cmdBin}] the NPI Batch Reader"
    else
      log_msg "ERROR: Could NOT issue [${cmdPath}${cmdBin}] on the NPI Batch Reader, with RC ${rc}!"
      exit ${rc}
    fi
  fi
  return 0
  
}

stopNPIBatchReaders()
{

  log_msg "Attempting STOP of the Batch Reader processes"
  batchReadPID=$(ps -ef | grep ${batchReaderCmd} | grep -v grep)
  if [ ! -z "${batchReadPID}" ]
  then
    log_msg "Found [${batchReaderCmd}] process with: [${batchReadPID}]"
    brPID=$(echo "${batchReadPID}" | awk '{print $2}' | head -1)
    log_msg "Killing PID [${brPID}]"
    kill -9 ${brPID} >> ${LOGFILE} 2>&1
  fi
  batchReadSAPID=$(ps -ef | grep ${batchReaderSACmd} | grep -v grep)
  if [ ! -z "${batchReadSAPID}" ]
  then
    log_msg "Found [${batchReaderSACmd}] process with: [${batchReadSAPID}]"
    brSAPID=$(echo "${batchReadSAPID}" | awk '{print $2}' | head -1)
    log_msg "Killing PID [${brSAPID}]"
    kill -9 ${brSAPID} >> ${LOGFILE} 2>&1
  fi   
  
}

validateNPIBatchReaders()
{
  log_msg "Checking the Batch Reader processes are present..."
  batchReadPID=$(ps -ef | grep ${batchReaderCmd} | grep -v grep)
  if [ ! -z "${batchReadPID}" ]
  then
    log_msg "Found [${batchReaderCmd}] process with: [${batchReadPID}]"
    brPID=$(echo "${batchReadPID}" | awk '{print $2}' | head -1)
    log_msg "The Following PID [${brPID}] is running for [${batchReaderCmd}]!"
    log_msg "Please kill this process before trying to start the program, exiting!"
    exit 5
  fi
  batchReadSAPID=$(ps -ef | grep ${batchReaderSACmd} | grep -v grep)
  if [ ! -z "${batchReadSAPID}" ]
  then
    log_msg "Found [${batchReaderSACmd}] process with: [${batchReadSAPID}]"
    brSAPID=$(echo "${batchReadSAPID}" | awk '{print $2}' | head -1)
    log_msg "The Following PID [${brSAPID}] is running for [${batchReaderSACmd}]!"
    log_msg "Please kill this process before trying to start the programs, exiting!"
    exit 6
  fi   
  
}

validateNPIBatchReadersRunning()
{
  goodFlag="good"
  log_msg "Checking the Batch Reader processes are running..."
  batchReadPID=$(ps -ef | grep ${batchReaderCmd} | grep -v grep)
  if [ ! -z "${batchReadPID}" ]
  then
    log_msg "Found [${batchReaderCmd}] process with: [${batchReadPID}]"
    brPID=$(echo "${batchReadPID}" | awk '{print $2}' | head -1)
    log_msg "The Following PID [${brPID}] is running for [${batchReaderCmd}]!"
  else
  log_msg "Didn't find any running process!"
  goodFlag="bad"
  fi
  
  batchReadSAPID=$(ps -ef | grep ${batchReaderSACmd} | grep -v grep)
  if [ ! -z "${batchReadSAPID}" ]
  then
    log_msg "Found [${batchReaderSACmd}] process with: [${batchReadSAPID}]"
    brSAPID=$(echo "${batchReadSAPID}" | awk '{print $2}' | head -1)
    log_msg "The Following PID [${brSAPID}] is running for [${batchReaderSACmd}]!"
  else
    log_msg "Didn't find any running process!"
    goodFlag="bad"
  fi  

  if [ "${goodFlag}" == "bad" ]
  then
    log_msg "Exiting badly as one or both of the Batch Readers are not running!"
    exit 5
  fi
  
}

validateNPIBatchReadersStopped()
{
  goodFlag="good"
  log_msg "Checking the Batch Reader processes are running..."
  batchReadPID=$(ps -ef | grep ${batchReaderCmd} | grep -v grep)
  if [ ! -z "${batchReadPID}" ]
  then
    log_msg "Found [${batchReaderCmd}] process with: [${batchReadPID}]"
    brPID=$(echo "${batchReadPID}" | awk '{print $2}' | head -1)
    log_msg "The Following PID [${brPID}] is running for [${batchReaderCmd}]!"
  goodFlag="bad"
  else
  log_msg "Didn't find any running process!"
  fi
  
  batchReadSAPID=$(ps -ef | grep ${batchReaderSACmd} | grep -v grep)
  if [ ! -z "${batchReadSAPID}" ]
  then
    log_msg "Found [${batchReaderSACmd}] process with: [${batchReadSAPID}]"
    brSAPID=$(echo "${batchReadSAPID}" | awk '{print $2}' | head -1)
    log_msg "The Following PID [${brSAPID}] is running for [${batchReaderSACmd}]!"
  goodFlag="bad"
  else
    log_msg "Didn't find any running process!"
  fi  

  if [ "${goodFlag}" == "bad" ]
  then
    log_msg "Exiting badly as one or both of the Batch Readers are running and should not be!"
    exit 5
  fi
  
}

rc=0
RC=0

case "${command}" in
     stop)
        stopNPIBatchReaders 
        rc=$?
        ;;
     start)
        #first lets validate they are not already running...
        validateNPIBatchReaders
        startNPIBatchReader ${batchReaderPath} ${batchReaderCmd}
        rc=$?
        startNPIBatchReader ${batchReaderSAPath} ${batchReaderSACmd}
        RC=$?
        ;;
     validatestart)
        validateNPIBatchReadersRunning
        ;;
     validatestop)
        validateNPIBatchReadersStopped
        ;;
     fixpid)
        validateNPIBatchReadersRunning
        #if we didn't exit in the above function then they are running...   
        ;;
     *)
        log_msg "Command ${command} is not a correct choice, exiting!"
        exit 1
esac

if [ ${rc} -ne 0 ]
then
  log_msg "ERROR: Could NOT issue [${batchReaderPath} ${batchReaderCmd}] on the NPI Batch Reader, with RC ${rc}!"
  exit ${rc}
fi
if [ ${RC} -ne 0 ]
then
  log_msg "ERROR: Could NOT issue [${batchReaderPath} ${batchReaderCmd}] on the NPI Batch Reader, with RC ${rc}!"
  exit ${rc}
fi

log_msg "Successfully completed ${APPLNAME}" 

exit 0