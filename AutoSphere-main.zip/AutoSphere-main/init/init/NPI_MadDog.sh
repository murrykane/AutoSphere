#!/bin/bash
# 
# Murry Kane
# Version 1.0
# NPI_MadDog.sh used to stop/start NPI start_inbound_msgreader_instance and start_inbound_msgbroker_instance
# 
# Modification History
# Who                 Date         Notes
#__________________________________________________________________________________________________
# Murry Kane          09/21/2017   Initial Version                
# Murry Kane          02/26/2019   Added logic for file existence then skip INIT script, this was done for infrastructure weekends where
#                                  reboots of the systems after patching would bring up the applications that would later break due to 
#                                  Oracle patching after reboots were completed that would break the DB connections for WebSphere
# Murry Kane          02/26/2020   Added logic for validatestart and validatestop along with fixpid
#
#__________________________________________________________________________________________________
# 


option_count=${#}
action=${1}

# source in the env setup script
if [ ! -z "${PROJ_PATH}" ]
then
  #echo "proj_path is defined...."
  . ${PROJ_PATH}/shell/functions > /dev/null 2>&1
elif [ -s /opt/jenkins/AutoSphere/shell/functions ]
then
  #echo "found /opt/jenkins/AutoSphere/shell/functions"
  . /opt/jenkins/AutoSphere/shell/functions > /dev/null 2>&1
elif [ -s /nfs/it-pam/scripts/functions ]
then
  #echo "found /nfs/it-pam/scripts/functions"
  . /nfs/it-pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/pam/scripts/functions ]
then
  #echo "found ~/pam/scripts/functions"
  . ~/pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/.mkane01/scripts/functions ]
then
  #echo "found in murry's directory...."
  . ~/.mkane01/scripts/functions > /dev/null 2>&1
else
  echo "********************************************************************************"
  echo "*  ERROR: Can not define ENV as PROJ_PATH can't be found, exiting...."
  echo "********************************************************************************"
  exit 5
fi


APPLNAME="NPI_MadDog"
eval LOGFILE=${NIGHTLY_LOG_DIR}/${APPLNAME}.${DATE_STAMP}.log
WASNAME="websphr"
ROOTUSER="root"
NPIUSER="npiadm"
rc=0
timeout=90
SkipINIT="/tmp/SKIP_START_APPLICATION.txt"
PIDPROC=""
shortSleep=10
npiBin="/npi/InitiateSystems/Engine10.1.0/Brokers10.1.0/scripts"
npiSH="madconfig.sh"
npiMsgReaderStart="start_inbound_msgreader_instance"
npiMsgReaderStop="stop_inbound_msgreader_instance"
npiMsgBrokerStart="start_inbound_msgbroker_instance"
npiMsgBrokerStop="stop_inbound_msgbroker_instance"
MSGRDR="msgreader"
MSGBKR="msgbroker"
MSGRDRBSC="/config_bscinbound/"
MSGRDRBSCSA="/config_bscinboundsa/"
MSGBKRBSC="/config_bscinbound/"
MSGBKRBSCSA="/config_bscinboundsa/"

# starts
npiMsgReaderBSCStartPropertyFile="${CFG_DIR}/madconfig.start.msgrdr.bscinbound"
npiMsgReaderBSCSAStartPropertyFile="${CFG_DIR}/madconfig.start.msgrdr.bscinboundsa"
npiMsgBrokerBSCStartPropertyFile="${CFG_DIR}/madconfig.start.msgbrkr.bscinbound"
npiMsgBrokerBSCSAStartPropertyFile="${CFG_DIR}/madconfig.start.msgbrkr.bscinboundsa"
# stops
npiMsgReaderBSCStopPropertyFile="${CFG_DIR}/madconfig.stop.msgrdr.bscinbound"
npiMsgReaderBSCSAStopPropertyFile="${CFG_DIR}/madconfig.stop.msgrdr.bscinboundsa"
npiMsgBrokerBSCStopPropertyFile="${CFG_DIR}/madconfig.stop.msgbrkr.bscinbound"
npiMsgBrokerBSCSAStopPropertyFile="${CFG_DIR}/madconfig.stop.msgbrkr.bscinboundsa"

action=$(tolower ${action})

usage()
{
  echo "Please see usage below for correct way to execute this script"
  echo ""
  echo "${0} start|stop"
  echo "Example: ${0} start"
}


if [ "${CURR_USER}" != "${ROOTUSER}" -a "${CURR_USER}" != "${NPIUSER}" ]
then
  log_msg "You must be ${ROOTUSER} or ${NPIUSER} to execute this script, ABORTING!"
  exit 5
else  
  log_msg "Starting Program [${APPLNAME}] with user [${CURR_USER}] with command [${action}]"
fi

if [ "${CURR_USER}" = "${ROOTUSER}" ]
then
  chown ${WASNAME}:${WASNAME} ${LOGFILE} > /dev/null 2>&1
  chmod 777 ${LOGFILE} 
  # let's source in the environment for NPIUser
  #eval echo "~$different_user"
  homeDir=$(eval echo "~${NPIUSER}")
  if [ -s ${homeDir}/.bash_profile ]
  then
    log_msg "Sourcing in [${NPIUSER}] .bash_profile"
    source ${homeDir}/.bash_profile >> ${LOGFILE} 2>&1
    #set >> ${LOGFILE}
  fi
else
  chmod 777 ${LOGFILE}
fi

# lets get the MAD_ROOTDIR home directory
if [ ! -z "${MAD_ROOTDIR}" ]
then
  log_msg "NPI Idenity Hub ROOT DIR is [${MAD_ROOTDIR}]"
else
  log_msg "WARNING: NPI Identity HUB ROOT DIR not found, hard-coding to /npi/InitiateSystems/Engine10.1.0"
  MAD_ROOTDIR="/npi/InitiateSystems/Engine10.1.0"
fi

case ${option_count} in
  0) 
    usage
    exit 5;;
  1)
    # lets validate arguement 1
    if [ "${action}" = "start" ]
    then
      #Lets validate if Skip INIT script is in place....
      log_msg "Checking for SKIP application startup...."
      if [ -e "${SkipINIT}" ]
      then
        log_msg "Skipping Application startup as the SKIP start file [$SkipINIT] is present!"
        exit 99
      fi
    elif [ "${action}" = "stop" ] || [ "${action}" = "fixpid" ] || [ "${action}" = "validatestart" ] || [ "${action}" = "validatestop" ]
    then
      :
    else
      usage
      exit 5
    fi
    ;;
  *) 
    usage
    exit 5
    ;;
esac

stopNPI()
{

  if [ "${CURR_USER}" = "${ROOTUSER}" ]
  then
    #./madconfig.sh -propertyfile /npi/InitiateSystems/Engine10.1.0/Brokers10.1.0/scripts/madconfig.Stop.msgbrkr.bscinbound Stop_inbound_msgbroker_instance
    log_msg "Attempting STOP of the NPI"
    command="cd ${npiBin}; ${npiBin}/${npiSH} -propertyfile ${npiMsgBrokerBSCStopPropertyFile} ${npiMsgBrokerStop}"
    log_msg "Attempting the following command: [${command}]"
    sudo su - ${NPIUSER} -c "${command}" >> ${LOGFILE} 2>&1
    rc=$?
    if [ ${rc} -ne 0 ]
    then
      log_msg "ERROR: Could NOT issue [${command}] on the NPI, with RC ${rc}!"
      #exit ${rc}  #MBK - We will continue to try and stop the other instances....
    fi 
    
    command="cd ${npiBin}; ${npiBin}/${npiSH} -propertyfile ${npiMsgBrokerBSCSAStopPropertyFile} ${npiMsgBrokerStop}"
    #command="cd ${npiBin}; ${npiBin}/${npiSH} -propertyfile ${npiMsgReaderBSCSAStopPropertyFile} ${npiMsgReaderStop}"
    log_msg "Attempting the following command: [${command}]"
    sudo su - ${NPIUSER} -c "${command}" >> ${LOGFILE} 2>&1
    rc=$?
    if [ ${rc} -ne 0 ]
    then
      log_msg "ERROR: Could NOT issue [${command}] on the NPI, with RC ${rc}!"
      #exit ${rc} #MBK - We will continue to try and stop the other instances....
    fi 
    
    command="cd ${npiBin}; ${npiBin}/${npiSH} -propertyfile ${npiMsgReaderBSCStopPropertyFile} ${npiMsgReaderStop}"
    log_msg "Attempting the following command: [${command}]"
    sudo su - ${NPIUSER} -c "${command}" >> ${LOGFILE} 2>&1
    rc=$?
    if [ ${rc} -ne 0 ]
    then
      log_msg "ERROR: Could NOT issue [${command}] on the NPI, with RC ${rc}!"
      #exit ${rc} #MBK - We will continue to try and stop the other instances....
    fi 
    
    #command="cd ${npiBin}; ${npiBin}/${npiSH} -propertyfile ${npiMsgBrokerBSCSAStopPropertyFile} ${npiMsgBrokerStop}"
    command="cd ${npiBin}; ${npiBin}/${npiSH} -propertyfile ${npiMsgReaderBSCSAStopPropertyFile} ${npiMsgReaderStop}"
    log_msg "Attempting the following command: [${command}]"
    sudo su - ${NPIUSER} -c "${command}" >> ${LOGFILE} 2>&1
    rc=$?
    if [ ${rc} -ne 0 ]
    then
      log_msg "ERROR: Could NOT issue [${command}] on the NPI, with RC ${rc}!"
      #exit ${rc} #MBK - We will continue to try and stop the other instances....
    fi 
  else
    log_msg "You must run this as ROOT user, exiting!"
    exit 1
  fi 
  
}

startNPI()
{

  if [ "${CURR_USER}" = "${ROOTUSER}" ]
  then
    #./madconfig.sh -propertyfile /npi/InitiateSystems/Engine10.1.0/Brokers10.1.0/scripts/madconfig.start.msgbrkr.bscinbound start_inbound_msgbroker_instance
    log_msg "Attempting START of the NPI"
    command="cd ${npiBin}; ${npiBin}/${npiSH} -propertyfile ${npiMsgReaderBSCStartPropertyFile} ${npiMsgReaderStart}"
    log_msg "Attempting the following command: [${command}]"
    sudo su - ${NPIUSER} -c "${command}" >> ${LOGFILE} 2>&1
    rc=$?
    if [ ${rc} -ne 0 ]
    then
      log_msg "ERROR: Could NOT issue [${command}] on the NPI, with RC ${rc}!"
      exit ${rc}
    fi 
    
    command="cd ${npiBin}; ${npiBin}/${npiSH} -propertyfile ${npiMsgReaderBSCSAStartPropertyFile} ${npiMsgReaderStart}"
    log_msg "Attempting the following command: [${command}]"
    sudo su - ${NPIUSER} -c "${command}" >> ${LOGFILE} 2>&1
    rc=$?
    if [ ${rc} -ne 0 ]
    then
      log_msg "ERROR: Could NOT issue [${command}] on the NPI, with RC ${rc}!"
      exit ${rc}
    fi 
    
    command="cd ${npiBin}; ${npiBin}/${npiSH} -propertyfile ${npiMsgBrokerBSCStartPropertyFile} ${npiMsgBrokerStart}"
    log_msg "Attempting the following command: [${command}]"
    sudo su - ${NPIUSER} -c "${command}" >> ${LOGFILE} 2>&1
    rc=$?
    if [ ${rc} -ne 0 ]
    then
      log_msg "ERROR: Could NOT issue [${command}] on the NPI, with RC ${rc}!"
      exit ${rc}
    fi 
    
    command="cd ${npiBin}; ${npiBin}/${npiSH} -propertyfile ${npiMsgBrokerBSCSAStartPropertyFile} ${npiMsgBrokerStart}"
    log_msg "Attempting the following command: [${command}]"
    sudo su - ${NPIUSER} -c "${command}" >> ${LOGFILE} 2>&1
    rc=$?
    if [ ${rc} -ne 0 ]
    then
      log_msg "ERROR: Could NOT issue [${command}] on the NPI, with RC ${rc}!"
      exit ${rc}
    fi 
  else
    log_msg "You must run this as ROOT user, exiting!"
    exit 1
  fi    
}

validatestopped()
{

  if [ "${CURR_USER}" = "${ROOTUSER}" ]
  then
    log_msg "Attempting Validation of started for NPI"
    PID1=$(ps -ef | grep -v grep | egrep "^npiadm" | grep -i ${MSGRDR} | grep -i ${MSGRDRBSC} | awk -F' ' '{print $2"~"$NF}' | head -1 | cut -d'~' -f1)
    PID2=$(ps -ef | grep -v grep | egrep "^npiadm" | grep -i ${MSGRDR} | grep -i ${MSGRDRBSCSA} | awk -F' ' '{print $2"~"$NF}' | head -1 | cut -d'~' -f1)
    PID3=$(ps -ef | grep -v grep | egrep "^npiadm" | grep -i ${MSGBKR} | grep -i ${MSGBKRBSC} | awk -F' ' '{print $2"~"$NF}' | head -1 | cut -d'~' -f1)
    PID4=$(ps -ef | grep -v grep | egrep "^npiadm" | grep -i ${MSGBKR} | grep -i ${MSGRDRBSCSA} | awk -F' ' '{print $2"~"$NF}' | head -1 | cut -d'~' -f1)
    if [ ! -z "${PID1}" ] || [ ! -z "${PID2}" ] || [ ! -z "${PID3}" ] || [ ! -z "${PID4}" ] 
    then
      log_msg "FAILURE: One or more processes are running! PID1 for ${MSGRDRBSC} [${PID1}] PID2 for ${MSGRDRBSCSA} [${PID2}] PID3 for ${MSGBKRBSC} [${PID3}] PID4 for ${MSGRDRBSCSA} [${PID4}]"
      exit 5
    else
      log_msg "SUCCESS: All processes are stopped PID1 for ${MSGRDRBSC} [${PID1}] PID2 for ${MSGRDRBSCSA} [${PID2}] PID3 for ${MSGBKRBSC} [${PID3}] PID4 for ${MSGRDRBSCSA} [${PID4}]"
      exit 0
    fi
  else
    log_msg "You must run this as ROOT user, exiting!"
    exit 1
  fi 

}

validatestarted()
{

  if [ "${CURR_USER}" = "${ROOTUSER}" ]
  then
    log_msg "Attempting Validation of started for NPI"
    PID1=$(ps -ef | grep -v grep | egrep "^npiadm" | grep -i ${MSGRDR} | grep -i ${MSGRDRBSC} | awk -F' ' '{print $2"~"$NF}' | head -1 | cut -d'~' -f1)
    PID2=$(ps -ef | grep -v grep | egrep "^npiadm" | grep -i ${MSGRDR} | grep -i ${MSGRDRBSCSA} | awk -F' ' '{print $2"~"$NF}' | head -1 | cut -d'~' -f1)
    PID3=$(ps -ef | grep -v grep | egrep "^npiadm" | grep -i ${MSGBKR} | grep -i ${MSGBKRBSC} | awk -F' ' '{print $2"~"$NF}' | head -1 | cut -d'~' -f1)
    PID4=$(ps -ef | grep -v grep | egrep "^npiadm" | grep -i ${MSGBKR} | grep -i ${MSGRDRBSCSA} | awk -F' ' '{print $2"~"$NF}' | head -1 | cut -d'~' -f1)
    if [ -z "${PID1}" ] || [ -z "${PID2}" ] || [ -z "${PID3}" ] || [ -z "${PID4}" ] 
    then
      log_msg "FAILURE: One or more processes are not running! PID1 for ${MSGRDRBSC} [${PID1}] PID2 for ${MSGRDRBSCSA} [${PID2}] PID3 for ${MSGBKRBSC} [${PID3}] PID4 for ${MSGRDRBSCSA} [${PID4}]"
      exit 5
    else
      log_msg "SUCCESS: All are running PID1 for ${MSGRDRBSC} [${PID1}] PID2 for ${MSGRDRBSCSA} [${PID2}] PID3 for ${MSGBKRBSC} [${PID3}] PID4 for ${MSGRDRBSCSA} [${PID4}]"
      exit 0
    fi
  else
    log_msg "You must run this as ROOT user, exiting!"
    exit 1
  fi 

}

case "${action}" in
     stop)
        stopNPI
        rc=$?
        ;;
     start)
        startNPI
        rc=$?
        ;;
     validatestop)
        validatestopped
        rc=$?
        ;;
     validatestart)
        validatestarted
        rc=$?
        ;;
     fixpid)
        validatestarted
        rc=$?
        ;;
     *)
        log_msg "Command ${command} is not a correct choice, exiting!"
        usage
        exit 1
esac

if [ ${rc} -ne 0 ]
then
  log_msg "ERROR: Could NOT issue [${command}] on the NPI Idenity Hub, with RC ${rc}!"
  exit ${rc}
fi

log_msg "Successfully completed ${APPLNAME}" 

exit 0