#! /bin/bash

# ----------------------
# author: Jeffrey Apiado
# team: IT NPE digital
# -----------------------

argschk=${#}
command=${1}
installpath="/opt/IBM"
declare -a arrvar=( start stop status )

usage()
{
  echo "${0} start|stop|restart"
  echo "Example: ${0} start"
}

case ${argschk} in
  0)
    usage
    exit 5;;
  1)
    # lets validate arguement 1
    if [ "${command}" = "start" ]
    then
      :
    elif [ "${command}" = "stop" ]
    then
      :
    elif [ "${command}" = "restart" ]
    then
      :
    else
      usage
      exit 5
    fi
    ;;
  *)
    usage
    exit 5
    ;;
esac

func_wasprofiles() {
     wpath="${installpath}/WebSphere/AppServer/properties/profileRegistry.xml"
     if [[ -f $wpath ]];then
        tdout=$(grep -Eo 'path=\S+' ${wpath})
        if [[ ${#tdout} -gt 0 ]];then
          echo $tdout
        else
          echo ''
        fi
     else
        echo "Error: failed to locate profileRegistry.xml file"
        exit 2
     fi
}

var=$(func_wasprofiles)

func_getServerName() {
 profilepath=${1}
 xcmd=`${profilepath}/bin/serverStatus.sh -all | grep 'name: IGC' | awk '{print $4}'`
 if [[ ${#xcmd} -gt 0 ]];then
   echo $xcmd
 else
   echo ''
 fi
}

func_dmgrproc() {
   cmd=${1}
   for profile in $var;do
     sis=$(echo ${profile##*/} | awk '{print tolower($0)}')
     if [[ $sis =~ 'dmgr' ]];then
          echo '[ DeploymentManager ]'
          dmgrstat=`ps -ef | grep dmgr | grep -v grep`
          if [[ "${cmd}" = 'start' ]];then
             if [[ $dmgrstat =~ 'java' || ${#dmgrstat} -gt 0 ]];then
                echo 'Deployment Manager was already up and running!!!'
             else
                dmd=$(echo ${profile#"path=\""})
                dmd=${dmd%"\""}
                $dmd/bin/startManager.sh
             fi
          elif [[ "${cmd}" = 'stop' ]];then
             if [[ $dmgrstat =~ 'java' || ${#dmgrstat} -gt 0 ]];then
                dmd=$(echo ${profile#"path=\""})
                dmd=${dmd%"\""}
                $dmd/bin/stopManager.sh
             else
                echo 'Deployment Manager was already down!!!'
             fi
          fi
     fi
   done
}

func_nodeagent() {
   cmda=${1}
   for profpath in $var;do
     vasn=$(echo ${profpath##*/} | awk '{print tolower($0)}')
     if ! [[ $vasn =~ 'dmgr' ]];then
       echo '[ NodeAgent ]'
       node=$(echo ${profpath#"path=\""})
       node=${node%"\""}
       Orig="$IFS"
       IFS='/'
       read -a strarr <<< "$node"
       leaf="${strarr[-1]}"
       IFS="$Orig"
       wild="${leaf}/servers/nodeagent"
       nodestat=`ps -ef | grep $wild | grep -v grep`
       if [[ "${cmda}" = 'start' ]];then
          if [[ "${nodestat}" =~ 'nodeagent' ]];then
             echo "Nodeagent for ${leaf} was already up and running!!!"
          else
             $node/bin/startNode.sh
          fi
       elif [[ "${cmda}" = 'stop' ]];then
          if [[ "${nodestat}" =~ 'nodeagent' ]];then
             $node/bin/stopNode.sh
          else
             echo "Nodeagent for ${leaf} was already down!!!"
          fi
       fi
     fi
   done
}

func_appserver() {
    zcmd=${1}
    for appath in $var;do
      applow=$(echo ${appath##*/} | awk '{print tolower($0)}')
      if ! [[ $applow =~ 'dmgr' ]];then
        echo '[ AppServer ]'
        apps=$(echo ${appath#"path=\""})
        apps=${apps%"\""}
        serverName=$(func_getServerName "${apps}")
        if [[ $serverName ]];then
           astat=`ps -ef | grep $serverName | grep -v grep`
           if [[ "${zcmd}" = 'start' ]];then
             if [[ $astat =~ 'java' ]];then
               echo "Application Server: ${serverName} was already up and running!"
             else
               $apps/bin/startServer.sh $serverName
             fi
           elif [[ "${zcmd}" = 'stop' ]];then
             if [[ $astat =~ 'java' ]];then
               $apps/bin/stopServer.sh $serverName
             else
               echo "Application Server: ${serverName} was already down!"
             fi

           fi
        fi
      fi
    done
}

func_igcprocess() {
  sudo ${installpath}/InformationServer/shared-open-source/bin/${1}-linux-services.sh | {
  while IFS= read -r line
  do
      echo "$line"
  done
  } 
}

func_igcstat() {
  cnt=0
  sudo ${installpath}/InformationServer/shared-open-source/bin/status-linux-services.sh | {
  while IFS= read -r line
  do
    if [[ $line =~ 'running' ]];then
      cnt=$(($cnt+1))
      echo "$line"
    fi
  done
  return $cnt
  }
}

func_igcsrc() {
    cnt=0
    for prefix in "${arrvar[@]}";do
         if [[ -f $installpath/InformationServer/shared-open-source/bin/$prefix-linux-services.sh ]];then
              cnt=$(($cnt+1))  
         fi
    done           
    local ret=$cnt
    echo $ret
}

func_wasprofiles() {
     wpath="${installpath}/WebSphere/AppServer/properties/profileRegistry.xml"    
     if [[ -f $wpath ]];then
        tdout=$(grep -Eo 'path=.* ' ${wpath})
     else
        echo "Error: failed to locate profileRegistry.xml file"
        exit 2
     fi
     echo $tdout

}

# =============================================================
count=$(func_igcsrc)
if [ $count -eq 3 ];then
    func_igcstat
    if [[ $? -eq 3 ]];then
       if [ "${command}" = "stop" ]
       then
          func_igcprocess "${arrvar[1]}"
          func_appserver "${arrvar[1]}"
          func_nodeagent "${arrvar[1]}"
          func_dmgrproc "${arrvar[1]}"
       elif [ "${command}" = "start" ]
       then
          echo 'IGC service already on running state .....'
          func_dmgrproc "${arrvar[0]}"
          func_nodeagent "${arrvar[0]}"
          func_appserver "${arrvar[0]}"
       else
          echo '[ ReSTART1 ] Initiate igc and websphere stop ...'
          func_igcprocess "${arrvar[1]}"
          func_appserver "${arrvar[1]}"
          func_nodeagent "${arrvar[1]}"
          func_dmgrproc "${arrvar[1]}"
          sleep 10
          echo '[ ReSTART1 ] Initiate igc and websphere start ...'
          func_igcprocess "${arrvar[0]}"
          func_dmgrproc "${arrvar[0]}"
          func_nodeagent "${arrvar[0]}"
          func_appserver "${arrvar[0]}"
       fi
    else
       if [ "${command}" = "start" ]
       then
          func_igcprocess "${arrvar[0]}"
          func_dmgrproc "${arrvar[0]}"
          func_nodeagent "${arrvar[0]}"
          func_appserver "${arrvar[0]}"
       elif [ "${command}" = "stop" ]
       then
         echo 'IGC service already on down state .....'
         func_appserver "${arrvar[1]}"
         func_nodeagent "${arrvar[1]}"
         func_dmgrproc "${arrvar[1]}"
       else
         echo '[ ReSTART0 ] Initiate igc and websphere stop ...'
         echo 'IGC service already on down state .....'
         func_appserver "${arrvar[1]}"
         func_nodeagent "${arrvar[1]}"
         func_dmgrproc "${arrvar[1]}"
         sleep 10
         echo '[ ReSTART0 ] Initiate igc and websphere start ...'
         func_igcprocess "${arrvar[0]}"
         func_dmgrproc "${arrvar[0]}"
         func_nodeagent "${arrvar[0]}"
         func_appserver "${arrvar[0]}"
       fi
    fi
else
   echo 'Error: Unable to locate IGC binaries .......'
   echo "Error: Searching in ${installpath} installation path as default ...."
   exit 1 
fi
