#!/bin/bash
# 
# Murry Kane
# Version 1.0
# jvm_init.sh used to stop/start Websphere for shutdown/startup of unix box as well as Linux Service
# 
# Modification History
# Who                 Date         Notes
#__________________________________________________________________________________________________
# Murry Kane          04/13/2017   Initial Version
# Murry Kane          04/26/2017   Added PID of one of the started processes (DMGR or nodeagent)                  
# Murry Kane          03/16/2018   Added logic to check if security is enabled or not and prevent username and password to be used if set
# Murry Kane          02/26/2019   Added logic for file existence then skip INIT script, this was done for infrastructure weekends where
#                                  reboots of the systems after patching would bring up the applications that would later break due to 
#                                  Oracle patching after reboots were completed that would break the DB connections for WebSphere
# Murry Kane          03/17/2019   Removed the file existence logic, we always want nodeagents started, we will use the XML file
#                                  to prevent application servers from starting when needed
# Murry Kane          07/08/2020   Copied from jvm_init.sh to rewrite this script to use SystemD with RHEL7 
#                                  As well as remove un-needed logic (XML file not needed anymore to get username/password)
#                                  paths should be more standard as well
#                                  Will use 'skipInit' logic to not start application instances for WebSphere, it will still start
#                                  nodeagents and DMGR
# Murry Kane          07/15/2020   Removing all refrences of sudo commands and systemd should run as websphere only! Also removed the
#                                  export of PIDPROC
#__________________________________________________________________________________________________


option_count=${#}
command=${1}

# source in the env setup script
if [ ! -z "${PROJ_PATH}" ]
then
  #echo "proj_path is defined...."
  . ${PROJ_PATH}/shell/functions > /dev/null 2>&1
elif [ -s /opt/jenkins/AutoSphere/shell/functions ]
then
  #echo "found /opt/jenkins/AutoSphere/shell/functions"
  . /opt/jenkins/AutoSphere/shell/functions > /dev/null 2>&1
elif [ -s /nfs/it-pam/scripts/functions ]
then
  #echo "found /nfs/it-pam/scripts/functions"
  . /nfs/it-pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/pam/scripts/functions ]
then
  #echo "found ~/pam/scripts/functions"
  . ~/pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/.mkane01/scripts/functions ]
then
  #echo "found in murry's directory...."
  . ~/.mkane01/scripts/functions > /dev/null 2>&1
else
  echo "********************************************************************************"
  echo "*  ERROR: Can not define ENV as PROJ_PATH can't be found, exiting...."
  echo "********************************************************************************"
  exit 5
fi

if [ -s ${PAM_SHELL_DIR}/was_functions ]
then
  . ${PAM_SHELL_DIR}/was_functions > /dev/null 2>&1
else
  echo "ERROR: Could not find the was_functions here: [${PAM_SHELL_DIR}/was_functions], exiting!"
  exit 6
fi

APPLNAME="jvm_systemd"
eval LOGFILE=${NIGHTLY_LOG_DIR}/${APPLNAME}.${DATE_STAMP}.log
WASNAME="websphr"
ROOTUSER="root"
rc=0
timeout=90
PIDPROC=""
shortSleep=10
SkipINIT="/tmp/SKIP_START_APPLICATION.txt"

command=$(tolower ${command})

usage()
{
  echo "${0} start|stop|force|forcestart"
  echo "Example: ${0} start"
}

if [ "${CURR_USER}" != "${WASNAME}" ]
then
  log_msg "You must be ${WASNAME} execute this script, ABORTING!"
  exit 5
else  
  log_msg "Running as user [${CURR_USER}] with argument [${command}]"
fi

case ${option_count} in
  0) 
    usage
    exit 5;;
  1)
    # lets validate arguement 1
    if [ "${command}" = "start" ]
    then
      :
    elif [ "${command}" = "stop" ]
    then
      :
    elif [ "${command}" = "force" ]
    then
      :
    elif [ "${command}" = "forcestart" ]
    then
      :
    else
      usage
      exit 5
    fi
    ;;
  *) 
    usage
    exit 5
    ;;
esac


stopWebsphere()
{
  #lets stop everything defined to PROFILES_ROOT
  #now we need a for loop for the number of profiles on this server
  for profile_inst in $(echo "${PROFILES_LIST}")
  do
    log_msg "Working on stopping profile ${profile_inst}"
    getProfileRoot ${profile_inst}
    rc=$?
    if [ ${rc} -eq 0 ]
    then
      log_msg "For [${profile_inst}] the installation path is: ${PROFILE_ROOT}"
    else
      log_msg "ERROR: Could NOT determine PROFILE_ROOT for Websphere on ${profile_inst}"
      exit ${rc}
    fi
    # Added logic to see if directory exists for PUREAPP as manageprofiles.sh outputs profiles not on local server!
    if [ -d "${PROFILE_ROOT}" ]
    then
      log_msg "The profile [${profile_inst}] installation directory [${PROFILE_ROOT}] exists...."
    else
      log_msg "The profile [${profile_inst}] installation directory [${PROFILE_ROOT}] DOES NOT EXIST, skipping this profile!"
      continue
    fi
    
    #see if security is enabled.....
    securityEnabled=1
    securityEnabledCheck "${PROFILE_ROOT}"
    securityEnabled=$?
    log_msg "Security is set to [${securityEnabled}]  Note: 0 is Enabled and 1 is Disabled"
    
    #see if its a DMGR
    if isNodeDMGR "${profile_inst}" >> ${LOGFILE} 2>&1
    then
      cat /tmp/serverstatus.out >> ${LOGFILE} 2>/dev/null
      its_there=$(cat /tmp/serverstatus.out 2>/dev/null| grep -v grep | grep -i "Deployment Manager" | awk -F' ' '{print $NF}')
      #log_msg "Current status: [${its_there}]"
      if [ "${its_there}" = "STARTED" ] 
      then
        log_msg "This is a DMGR and will stop it using: ${PROFILE_ROOT}/bin/stopManager.sh"
        #use stopManager.sh since its a DMGR
        log_msg "Issueing: ${PROFILE_ROOT}/bin/stopManager.sh -timeout ${timeout} >> ${LOGFILE} 2>&1"
        ${PROFILE_ROOT}/bin/stopManager.sh -timeout ${timeout} >> ${LOGFILE} 2>&1
        rc=$?
        if [ ${rc} -eq 0 ]
        then
          log_msg "Successfully stopped the DMGR manager"
        else
          log_msg "ERROR: Could NOT stop the DMGR, with RC = ${rc}!"
          #exit ${rc}
        fi
      else
        log_msg "DMGR is already stopped, not need to stop it..."
      fi
    else
      log_msg "This is not a DMGR instance: [${profile_inst}]"
    fi
    
    #Check if its has an application instance...
    if isAppServer "${profile_inst}" "${PROFILE_ROOT}" >> ${LOGFILE} 2>&1 
    then
      cat /tmp/serverstatus.out >> ${LOGFILE} 2>/dev/null
      #this is a nodeagent/appserver we will try and stop both
      its_there=$(cat /tmp/serverstatus.out 2>/dev/null| grep -v grep | grep -i "The Node Agent" | awk -F' ' '{print $NF}')
      #log_msg "Current status: [${its_there}]"
      if [ "${its_there}" = "STARTED" ] 
      then
        log_msg "This is a application server with a node agent, using ${PROFILE_ROOT}/bin to stop."    
        log_msg "Using the following command: ${PROFILE_ROOT}/bin/stopNode.sh -stopservers -saveNodeState -timeout ${timeout} >> ${LOGFILE} 2>&1"
        # since we can use the -stopservers swith on the nodeagent we don't have to do the stopServer.sh commands....
        ${PROFILE_ROOT}/bin/stopNode.sh -stopservers -saveNodeState -timeout ${timeout} >> ${LOGFILE} 2>&1
        rc=$?
        if [ ${rc} -eq 0 ]
        then
          log_msg "Successfully stopped the NodeAgent for ${profile_inst}"
        else
          log_msg "ERROR: Could NOT stop the NodeAgent for ${profile_inst}, with RC ${rc}!"
          exit ${rc}
        fi
      else
        log_msg "NodeAgent is already stopped, no need to stop it..."
        #MBK need to check if app servers are running still, which can happen!
        its_there=$(cat /tmp/serverstatus.out 2>/dev/null| grep -v grep | grep -i "Application Server" | head -1 | awk -F' ' '{print $NF}')
        if [ "${its_there}" = "STARTED" ]
        then
          log_msg "At least one Application server is running, need to attempt to stop all of them"
          appName=""
          appNameList=$(cat /tmp/serverstatus.out | grep -vi "nodeagent" | grep -i "Application Server" | awk -F'"' '{print $2}')
          if [ -z ${appNameList} ]
          then
            log_msg "Something is wrong, should have found at least one application server that was started"
          else
            echo "Found the following Application Name(s): [${appNameList}] for Profile ${PROFILE_NAME}"
          fi
          for app_inst in $(echo "${appNameList}")
          do 
            #lets check for it first
            app_running=$(cat /tmp/serverstatus.out 2>/dev/null | grep -v grep | grep -i "The Application Server" | grep -i "${app_inst}" | awk -F' ' '{print $NF}')
            #log_msg "Current status [${app_running}]"
            if [ "${app_running}" = "STARTED" ]
            then
              #log_msg "Attempting Stop for the Application Server [${app_inst}] with ${PROFILE_ROOT}/bin/stopServer.sh ${app_inst} -username ${was_user_id} -password ${was_encrypted_password} >> ${LOGFILE} 2>&1"     
              log_msg "Attempting Stop for the Application Server [${app_inst}] with ${PROFILE_ROOT}/bin/stopServer.sh ${app_inst} >> ${LOGFILE} 2>&1"
              ${PROFILE_ROOT}/bin/stopServer.sh ${app_inst} >> ${LOGFILE} 2>&1
              rc=$?
              if [ ${rc} -eq 0 ]
              then
                log_msg "Successfully stoped the Application [${app_inst}] for ${profile_inst}"
              else
                log_msg "ERROR: Could NOT stop the Application for ${profile_inst}, with RC ${rc}!"
                #exit ${rc}
              fi 
            else
              log_msg "Application Instance ${app_inst} is NOT STARTED, no need to stop it..."
            fi
          done
          log_msg "All Done with Application Servers"
        fi
      fi
    else
      log_msg "Could not determine if this is a Application Server or not"
      cat /tmp/serverstatus.out >> ${LOGFILE} 2>/dev/null
    fi
    
    #Lets see if it's a WEB instance only....
    if isWebServer "${profile_inst}" "${PROFILE_ROOT}" >> ${LOGFILE} 2>&1
    then
      cat /tmp/serverstatus.out >> ${LOGFILE} 2>/dev/null
      #this is a nodeagent/appserver we will try and start both
      log_msg "This is a Web Server with a node agent as well, using ${PROFILE_ROOT}/bin to stop."
      #lets see if nodeagent is already running...
      its_there=$(cat /tmp/serverstatus.out 2>/dev/null| grep -v grep | grep -i "the node agent" | awk -F' ' '{print $NF}')
      nodeName=$(cat /tmp/serverstatus.out 2>/dev/null| grep -v grep | grep -i "the node agent" | awk -F'"' '{print $2}')
      #log_msg "Current status: [${its_there}]"
      if [ "${its_there}" != "STARTED" ] 
      then
        log_msg "NodeAgent is already stopped, no need to stop it"
      else
        #log_msg "Attempting Stop for the NodeAgent with ${PROFILE_ROOT}/bin/stopNode.sh -username ${was_user_id} -password ${was_encrypted_password}"     
        log_msg "Attempting Stop for the NodeAgent with ${PROFILE_ROOT}/bin/stopNode.sh >> ${LOGFILE} 2>&1"
        ${PROFILE_ROOT}/bin/stopNode.sh >> ${LOGFILE} 2>&1
        rc=$?
        if [ ${rc} -eq 0 ]
        then
          log_msg "Successfully stopped the NodeAgent for ${profile_inst}"
        else
          log_msg "ERROR: Could NOT stop the NodeAgent for ${profile_inst}, with RC ${rc}!"
          exit ${rc}
        fi
      fi
    else
      cat /tmp/serverstatus.out >> ${LOGFILE} 2>/dev/null
      log_msg "Could Not determine if this was an Web Server or not...."
    fi
  done
}

startWebsphere()
{
  #lets stop everything defined to PROFILES_ROOT
  #now we need a for loop for the number of profiles on this server
  
  FORCE="NO"
  if [ -z "$1" ]
  then
    log_msg "Normal Start IBM WebSphere being performed"
    FORCE="NO"
  else
    log_msg "FORCE - Start IBM WebSphere being performed!"
    FORCE="YES"
  fi
   
  for profile_inst in $(echo "${PROFILES_LIST}")
  do
    log_msg "Working on starting profile ${profile_inst}"
    getProfileRoot ${profile_inst} >> ${LOGFILE} 2>&1
    rc=$?
    if [ ${rc} -eq 0 ]
    then
      log_msg "For [${profile_inst}] the installation path is: ${PROFILE_ROOT}"
    else
      log_msg "ERROR: Could NOT determine PROFILE_ROOT for Websphere on ${profile_inst}"
      exit ${rc}
    fi
    # Added logic to see if directory exists for PUREAPP as manageprofiles.sh outputs profiles not on local server!
    if [ -d "${PROFILE_ROOT}" ]
    then
      log_msg "The profile [${profile_inst}] installation directory [${PROFILE_ROOT}] exists...."
    else
      log_msg "The profile [${profile_inst}] installation directory [${PROFILE_ROOT}] DOES NOT EXIST, skipping this profile!"
      continue
    fi
    #see if its a DMGR
    if isNodeDMGR "${profile_inst}" >> ${LOGFILE} 2>&1
    then
      its_there=$(cat /tmp/serverstatus.out 2>/dev/null| grep -v grep | grep -i "Deployment Manager" | awk -F' ' '{print $NF}')
      dmgrName=$(cat /tmp/serverstatus.out 2>/dev/null| grep -v grep | grep -i "Deployment Manager" | awk -F'"' '{print $2}')
      #log_msg "Current status: [${its_there}]"
      if [ "${its_there}" = "STARTED" ] 
      then
        log_msg "DMGR is already running, no need to start it, getting PID to send to the PIDFILE..."
        PIDPROC=$(cat ${PROFILE_ROOT}/logs/${dmgrName}/${dmgrName}.pid 2>/dev/null)
        log_msg "DMGR PID is [${PIDPROC}]" 
      else
        #lets see if the flag is set to not start DMGR
        if [ "${dmgr_startup}" = "NO" ] && [ "${FORCE}" = "NO" ]
        then
          log_msg "This DMGR will not be started based on XML setting for DMGR startup!"
        else
          #use startManager.sh since its a DMGR
          log_msg "This is a DMGR and will start it using: ${PROFILE_ROOT}/bin/startManager.sh >> ${LOGFILE} 2>&1"
          ${PROFILE_ROOT}/bin/startManager.sh >> ${LOGFILE} 2>&1
          rc=$?
          if [ ${rc} -eq 0 ]
          then
            log_msg "Successfully submitted the start for the DMGR Manager, sleep for ${shortSleep} seconds to wait for PID file..."
            sleep ${shortSleep}
            #get the PID
            if [ -z ${PIDPROC} ]
            then
              PIDPROC=$(cat ${PROFILE_ROOT}/logs/${dmgrName}/${dmgrName}.pid 2>/dev/null)      
              log_msg "${dmgrName} PID found to be [${PIDPROC}]"
            fi
          else
            log_msg "ERROR: Could NOT start the DMGR, with RC = ${rc}!"
            #exit ${rc}
          fi
        fi
      fi
    fi
    
    #lets see if this has application instances for Websphere
    if isAppServer "${profile_inst}" "${PROFILE_ROOT}" >> ${LOGFILE} 2>&1
    then
      cat /tmp/serverstatus.out >> ${LOGFILE} 2>/dev/null
      #this is a nodeagent/appserver we will try and start both
      log_msg "This is a application server with a node agent as well, using ${PROFILE_ROOT}/bin to start."
      #lets see if nodeagent is already running...
      its_there=$(cat /tmp/serverstatus.out 2>/dev/null| grep -v grep | grep -i "the node agent" | awk -F' ' '{print $NF}')
      nodeName=$(cat /tmp/serverstatus.out 2>/dev/null| grep -v grep | grep -i "the node agent" | awk -F'"' '{print $2}')
      #log_msg "Current status: [${its_there}]"
      if [ "${its_there}" = "STARTED" ] 
      then
        log_msg "NodeAgent is already running, no need to start it"
      else
        #lets check if the SKIP FILE present has setting to not start the nodeagent!
        if [ "${nodeagent_startup}" = "NO" ] && [ "${FORCE}" = "NO" ]
        then
          log_msg "We have SKIP FILE present to not start NodeAgent on startup set!"
        else
          log_msg "Attempting Start for the NodeAgent with ${PROFILE_ROOT}/bin/startNode.sh >> ${LOGFILE} 2>&1"     
          ${PROFILE_ROOT}/bin/startNode.sh >> ${LOGFILE} 2>&1
          rc=$?
          if [ ${rc} -eq 0 ]
          then
            log_msg "Successfully started the NodeAgent for ${profile_inst}, sleep for ${shortSleep} seconds to wait for PID file..."
            sleep ${shortSleep}
            #get the PID
            if [ -z ${PIDPROC} ]
            then
              PIDPROC=$(cat ${PROFILE_ROOT}/logs/${nodeName}/${nodeName}.pid 2>/dev/null)
              log_msg "${nodeName} PID found to be [${PIDPROC}]"
            fi
          else
            log_msg "ERROR: Could NOT start the NodeAgent for ${profile_inst}, with RC ${rc}!"
            exit ${rc}
          fi
        fi
      fi
      # lets first check if the SKIP FILE is present then do not start Application Servers on startup
      if [ "${appsrvr_startup}" = "NO" ] && [ "${FORCE}" = "NO" ]
      then
        log_msg "SKIP File present we will NOT start Application Servers set on this instance, skipping application server startups!"
      else
        #now the application server(s)
        for app_inst in $(echo "${appNameList}")
        do 
          #lets check for it first
          app_running=$(cat /tmp/serverstatus.out 2>/dev/null | grep -v grep | grep -i "The Application Server" | grep -i "${app_inst}" | awk -F' ' '{print $NF}')
          #log_msg "Current status [${app_running}]"
          if [ "${app_running}" = "STARTED" ]
          then
            log_msg "Application Instance ${app_inst} is STARTED, no need to start it..."
          else
            batch2check=$(echo "${app_inst}" | egrep -i 'batch2|batch02')
            if [ ! -z ${batch2check} ]
            then
              log_msg "This is a BATCH2 application(${app_inst}), and therefore will not be started!"
            else
              log_msg "Attempting the Start for the Application Server [${app_inst}] with ${PROFILE_ROOT}/bin/startServer.sh ${app_inst} >> ${LOGFILE} 2>&1"     
              ${PROFILE_ROOT}/bin/startServer.sh ${app_inst} >> ${LOGFILE} 2>&1
              rc=$?
              if [ ${rc} -eq 0 ]
              then
                log_msg "Successfully started the Application [${app_inst}] for ${profile_inst}"
              else
                log_msg "ERROR: Could NOT start the Application for ${profile_inst}, with RC ${rc}!"
                #exit ${rc}
              fi
            fi 
          fi
        done
      fi
    else
      cat /tmp/serverstatus.out >> ${LOGFILE} 2>/dev/null
      log_msg "Could Not determine if this was an Application Server or not...."
    fi
    
    #lets see if this is a standalone web instance server
    if isWebServer "${profile_inst}" "${PROFILE_ROOT}" >> ${LOGFILE} 2>&1
    then
      cat /tmp/serverstatus.out >> ${LOGFILE} 2>/dev/null
      #this is a nodeagent/appserver we will try and start both
      log_msg "This is a Web Server with a node agent as well, using ${PROFILE_ROOT}/bin to start."
      #lets see if nodeagent is already running...
      its_there=$(cat /tmp/serverstatus.out 2>/dev/null| grep -v grep | grep -i "the node agent" | awk -F' ' '{print $NF}')
      nodeName=$(cat /tmp/serverstatus.out 2>/dev/null| grep -v grep | grep -i "the node agent" | awk -F'"' '{print $2}')
      #log_msg "Current status: [${its_there}]"
      if [ "${its_there}" = "STARTED" ] 
      then
        log_msg "NodeAgent is already running, no need to start it"
      else
        #lets check if the SKIP FILE is present to not start the nodeagent!
        if [ "${nodeagent_startup}" = "NO" ] && ["${FORCE}" = "NO" ]
        then
          log_msg "We have SKIP FILE present to not start NodeAgent on startup set!"
        else
          log_msg "Attempting Start for the NodeAgent with ${PROFILE_ROOT}/bin/startNode.sh >> ${LOGFILE} 2>&1"     
          ${PROFILE_ROOT}/bin/startNode.sh >> ${LOGFILE} 2>&1
          rc=$?
          if [ ${rc} -eq 0 ]
          then
            log_msg "Successfully started the NodeAgent for ${profile_inst}, sleep for ${shortSleep} seconds to wait for PID file..."
            sleep ${shortSleep}
            #get the PID
            if [ -z ${PIDPROC} ]
            then
              PIDPROC=$(cat ${PROFILE_ROOT}/logs/${nodeName}/${nodeName}.pid 2>/dev/null)
              log_msg "${nodeName} PID found to be [${PIDPROC}]"
            fi
          else
            log_msg "ERROR: Could NOT start the NodeAgent for ${profile_inst}, with RC ${rc}!"
            exit ${rc}
          fi
        fi
      fi
    else
      cat /tmp/serverstatus.out >> ${LOGFILE} 2>/dev/null
      log_msg "Could Not determine if this was an Web Server or not...."
    fi
  done
}

forceStopWebsphere()
{

  #killFlag="FALSE"
  #log_msg "Kill Flag = [${killFlag}]"
  #we will do a kill -9 on the pid, to force down the java processes.....
  for profile_inst in $(echo "${PROFILES_LIST}")
  do
    log_msg "Working on stopping profile ${profile_inst}"
    getProfileRoot ${profile_inst}
    rc=$?
    if [ ${rc} -eq 0 ]
    then
      log_msg "For [${profile_inst}] the installation path is: ${PROFILE_ROOT}"
    else
      log_msg "ERROR: Could NOT determine PROFILE_ROOT for Websphere on ${profile_inst}"
      exit ${rc}
    fi
    # Added logic to see if directory exists for PUREAPP as manageprofiles.sh outputs profiles not on local server!
    if [ -d "${PROFILE_ROOT}" ]
    then
      log_msg "The profile [${profile_inst}] installation directory [${PROFILE_ROOT}] exists...."
    else
      log_msg "The profile [${profile_inst}] installation directory [${PROFILE_ROOT}] DOES NOT EXIST, skipping this profile!"
      continue
    fi 
    #lets get all PID files from profile_root
    find "${PROFILE_ROOT}" -name "*.pid" -print0 2>/dev/null |while IFS= read -r -d $'\0' file
    do 
      log_msg "Working on file: ${file} to get PID"
      PID=$(cat ${file})
      check_it=$(ps -ef | grep -i java | grep -v grep | egrep "^${WASNAME}" | grep -i "${PID}" | awk -F' ' '{print $2"~"$NF}' | cut -d'~' -f1)
      #the above can be a list of PID's lets see if one of them is the file stored one....
      findPID=$(echo "${check_it}" | grep "${PID}")
      #log_msg "PID [${PID}] running java PIDS [${check_it}] if found this will have values [${findPID}]"
      if [ "${findPID}" != "" ]
      then
        log_msg "Working on file [${file}] PID from PID_FILE [${PID}] killing found PID(s): [${check_it}]"
        #kill -9 ${PID}
        kill -9 ${check_it}
        rc=$?
        if [ ${rc} -eq 0 ]
        then
          #set the flag
          #killFlag="TRUE"
          #log_msg "Kill Flag = [${killFlag}]"
          log_msg "Successfully killed the running process for [${file}] with PID from PID_FILE [${PID}] with PID(s): [${check_it}]"
          #lets clean up the PID file
          rm -f ${file}
          rc=$?
          if [ ${rc} -eq 0 ]
          then     
            log_msg "Successfully removed the PID file [${file}]"
          else
            log_msg "ERROR: We could not remove the PID file [${file}]"
          fi
        else
            log_msg "ERROR: Could NOT kill the running process for [${file}] with PID [${PID}]"
        fi
      else
        log_msg "For file [${file}], we found no running PID with: [${PID}]"
      fi
    done
  done
  
  # MBK - since we are doing a read -r -d on the find result above, causes a subshell and all variables are lost.....
  #log_msg "Kill Flag = [${killFlag}]"
  #if [ "${killFlag}" == "FALSE" ]
  #then
  #  log_msg "WARNING: We could not find any PID files, we found NOTHING to force DOWN!"
  #fi
    
}

#lets do the init 
log_msg "Starting the WAS systemd function"
was_systemd_setup >> ${LOGFILE} 2>&1
rc=$?
if [ ${rc} -eq 0 ]
then
  log_msg "Completed the WAS systemd init function"
else
  log_msg "ERROR: Could NOT complete the was_systemd_setup!, exiting!"
  exit ${rc}
fi

log_msg "Getting Current Status of Websphere with Profile Root [${PROFILE_ROOT}]"
getWebsphereStatus "${PROFILE_ROOT}" 60 >> ${LOGFILE} 2>&1
rc=$?
if [ ${rc} -eq 0 ]
then
  log_msg "Completed the WAS Get Status function"
  cat /tmp/serverstatus.out >> ${LOGFILE} 2>/dev/null
else
  log_msg "WARN: Could NOT complete the get WebSphere Status which means everything is down..."
fi

case "${command}" in
     'stop')
        stopWebsphere
        ;;
     'start')
        startWebsphere
        ;;
     'force')
        forceStopWebsphere
        ;;
     'forcestart')
        startWebsphere force
        ;;
     *)
        log_msg "Command ${command} is not a correct choice, exiting!"
        exit 1
esac

#rm -f /tmp/serverstatus.out 2>/dev/null 2>&1
if [ "${CURR_USER}" = "${ROOTUSER}" ]
then
  chown ${WASNAME}:${WASNAME} ${LOGFILE} > /dev/null 2>&1
fi

log_msg "Successfully completed ${APPLNAME}" 

exit 0