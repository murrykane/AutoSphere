#!/bin/bash
# 
# Murry Kane
# Version 1.0
# NPI_IdenityHub.sh used to stop/start NPI Identity HUB
# 
# Modification History
# Who                 Date         Notes
#__________________________________________________________________________________________________
# Murry Kane          09/21/2017   Initial Version                
# Murry Kane          02/26/2019   Added logic for file existence then skip INIT script, this was done for infrastructure weekends where
#                                  reboots of the systems after patching would bring up the applications that would later break due to 
#                                  Oracle patching after reboots were completed that would break the DB connections for WebSphere
# Murry Kane          02/26/2020   Added logic for validatestart and validatestop along with fixpid
#
#
#__________________________________________________________________________________________________
# 

option_count=${#}
command=${1}

# source in the env setup script
if [ ! -z "${PROJ_PATH}" ]
then
  #echo "proj_path is defined...."
  . ${PROJ_PATH}/shell/functions > /dev/null 2>&1
elif [ -s /opt/jenkins/AutoSphere/shell/functions ]
then
  #echo "found /opt/jenkins/AutoSphere/shell/functions"
  . /opt/jenkins/AutoSphere/shell/functions > /dev/null 2>&1
elif [ -s /nfs/it-pam/scripts/functions ]
then
  #echo "found /nfs/it-pam/scripts/functions"
  . /nfs/it-pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/pam/scripts/functions ]
then
  #echo "found ~/pam/scripts/functions"
  . ~/pam/scripts/functions > /dev/null 2>&1
elif [ -s ~/.mkane01/scripts/functions ]
then
  #echo "found in murry's directory...."
  . ~/.mkane01/scripts/functions > /dev/null 2>&1
else
  echo "********************************************************************************"
  echo "*  ERROR: Can not define ENV as PROJ_PATH can't be found, exiting...."
  echo "********************************************************************************"
  exit 5
fi


APPLNAME="NPI_IdentityHub"
NAME=npiIdenityHub_init
PIDFILE=/var/run/$NAME.pid
eval LOGFILE=${NIGHTLY_LOG_DIR}/${APPLNAME}.${DATE_STAMP}.log
WASNAME="websphr"
ROOTUSER="root"
NPIUSER="npiadm"
rc=0
timeout=90
SkipINIT="/tmp/SKIP_START_APPLICATION.txt"
PIDPROC=""
shortSleep=10
npiScript="/npi/InitiateSystems/Engine10.1.0/identity_hub/inst/mpinet_identity_hub/conf/mpinet_identity_hub.sh"
npiBin="/npi/InitiateSystems/Engine10.1.0/scripts"
npiLogDir="/npi/InitiateSystems/Engine10.1.0/identity_hub/log"
npiIdenName="mpinet_identity_hub"
IDENITYHUB="MPINETIDENTITY_HUB"



command=$(tolower ${command})

usage()
{
  echo "${0} start|stop"
  echo "Example: ${0} start"
}


if [ "${CURR_USER}" != "${ROOTUSER}" -a "${CURR_USER}" != "${NPIUSER}" ]
then
  log_msg "You must be ${ROOTUSER} or ${NPIUSER} to execute this script, ABORTING!"
  exit 5
else  
  log_msg "Starting Program [${APPLNAME}] with user [${CURR_USER}] with command [${command}]"
fi

if [ "${CURR_USER}" = "${ROOTUSER}" ]
then
  chown ${WASNAME}:${WASNAME} ${LOGFILE} > /dev/null 2>&1
  chmod 777 ${LOGFILE} 
  # let's source in the environment for NPIUser
  #eval echo "~$different_user"
  homeDir=$(eval echo "~${NPIUSER}")
  if [ -s ${homeDir}/.bash_profile ]
  then
    log_msg "Sourcing in [${NPIUSER}] .bash_profile"
    source ${homeDir}/.bash_profile >> ${LOGFILE} 2>&1
    #set >> ${LOGFILE}
  fi
else
  chmod 777 ${LOGFILE}
fi

# lets get the MAD_ROOTDIR home directory
if [ ! -z "${MAD_ROOTDIR}" ]
then
  log_msg "NPI Idenity Hub ROOT DIR is [${MAD_ROOTDIR}]"
else
  log_msg "WARNING: NPI Identity HUB ROOT DIR not found, hard-coding to /npi/InitiateSystems/Engine10.1.0"
  MAD_ROOTDIR="/npi/InitiateSystems/Engine10.1.0"
fi

case ${option_count} in
  0) 
    usage
    exit 5;;
  1)
    # lets validate arguement 1
    if [ "${command}" = "start" ]
    then
      #Lets validate if Skip INIT script is in place....
      log_msg "Checking for SKIP application startup...."
      if [ -e "${SkipINIT}" ]
      then
        log_msg "Skipping Application startup as the SKIP start file [$SkipINIT] is present!"
        exit 99
      fi
    elif [ "${command}" = "stop" ]
    then
      :
    elif [ "${command}" = "validatestop" ]
    then
      :
    elif [ "${command}" = "validatestart" ]
    then
      :
    elif [ "${command}" = "fixpid" ]
    then
      :
    else
      usage
      exit 5
    fi
    ;;
  *) 
    usage
    exit 5
    ;;
esac

cleanLogs()
{
  if [ -d ${npiLogDir} ]
  then
    find ${npiLogDir} -maxdepth 2 -type f \( -name "${npiIdenName}.out.[0-9]*" \) -print0 2>/dev/null |while IFS= read -r -d $'\0' file
    do
      if [ -s ${file} ]
      then
        exT=$(echo ${file} | awk -F'.' '{print $NF}')
        log_msg "Working on backing up file [${file}] with extention [${npiLogDir}/${npiIdenName}.log.${exT}.${DATETIME_STAMP}]"
        mv ${file} ${npiLogDir}/${npiIdenName}.log.${exT}.${DATETIME_STAMP} >> ${LOGFILE} 2>&1
        rc=$?
        if [ ${rc} -eq 0 ]
        then
          log_msg "Successfully created date and time stamp of log file..."
        else
          log_msg "ERROR: Could NOT create a date and time stamp of the log file: [${file}]!"
        fi
      else
        log_msg "Log File [${file}] is empty, we will just remove it...."
        rm -f ${file} >> ${LOGFILE} 2>&1 
      fi
    done    
    # remove old files....
    #echo "here....."
    find ${MAD_ROOTDIR} -maxdepth 5 -type f \( -name "${npiIdenName}.log.[0-9]*" -o -name "Snap.*.trc" -o -name "javacore*.txt" -o -name "core.*.dmp" \) -mtime +"90" -print0 2>/dev/null |while IFS= read -r -d $'\0' file
    do
      log_msg "Working on removing file ${file}"
      rm -f ${file} 2>/dev/null 
    done
  else
    log_msg "Directory [${npiLogDir}] DOES NOT exist, therefore log clean up will not be performed."
  fi
  
}

cleanOldPids()
{
  log_msg "Looking for other processes running as NPI user [${NPIUSER}]"
  runningProcs=$(ps -fu ${NPIUSER} | egrep -v '(egrep|UID |sudo su|su -|-bash)')
  if [ ! -z "${runningProcs}" ]
  then
    log_msg "Found Running proccesses for user ${NPIUSER} with:"
    echo "${runningProcs}" >> ${LOGFILE} 2>&1
    PIDS=$(echo "${runningProcs}" | awk '{print $2}')
    #log_msg "Killing the following PIDS [${PIDS}]"
    for thePID in $(echo "${PIDS}") 
    do
      log_msg "Killing the following PID [${thePID}]"
      kill -9 ${thePID}
    done
  else
    log_msg "No left over processes running for NPI Identity Manger"
  fi
  
}
actionNPIIdentityHub()
{
  
  command=${1}
  
  if [ "${command}" == "" ]
  then
    log_msg "Action must be passed!, exiting!"
    return 1
  fi
  
  if [ "${CURR_USER}" = "${ROOTUSER}" ]
  then
    log_msg "Attempting the ${command} NPI Identity Hub with sudo su - ${NPIUSER} -c 'source ~/.bash_profile;cd ${npiBin};${npiScript} ${command} >> ${LOGFILE} 2>&1'" 
    #cd ${npiBin}
    sudo su - ${NPIUSER} -c  "source ~/.bash_profile;cd ${npiBin};${npiScript} ${command}" >> ${LOGFILE} 2>&1
    rc=$?
    if [ ${rc} -eq 0 ]
    then
      log_msg "Successfully issued [${command}] on the NPI Identity Hub"
    else
      log_msg "ERROR: Could NOT [${command}] the NPI Idenity Hub, with RC ${rc}!"
      exit ${rc}
    fi
  else
    log_msg "Attempting the [${command}] NPI Identity Hub with '${npiScript} ${command}'" 
    cd ${npiBin}
    ${npiScript} ${command} >> ${LOGFILE} 2>&1
    rc=$?
    if [ ${rc} -eq 0 ]
    then
      log_msg "Successfully issued [${command}] the NPI Identity Hub"
    else
      log_msg "ERROR: Could NOT issue [${command}] on the NPI Idenity Hub, with RC ${rc}!"
      exit ${rc}
    fi
  fi
  return 0
  
}

fixpids()
{
  currentPID=$(cat ${PIDFILE})
  log_msg "Attempting fixing the PID, currently defined in the PID file is [${currentPID}]"
  PROC=$(ps -ef | grep -v grep | grep "${npiIdenName}" | grep "${IDENITYHUB}" | awk -F' ' '{print $2"~"$11}' | head -1)
  PIDFile=$(echo "${PROC}" | cut -d"~" -f2 | cut -d'=' -f2)
  thePID=$(echo "${PROC}" | cut -d"~" -f1)
  if [ -s "${PIDFile}" ]
  then
    PID=$(cat ${PIDFile})
  else
    PID="${thePID}"
  fi
  log_msg "Current PID is: [${PID}] with Old PID [${currentPID}]"
  if [ -z "${PID}" ]
  then
    log_msg "FAILURE: We could not find the current PID for NPI Identify HUB"
    exit 5
  else
    echo "${PID}" > ${PIDFILE} 2> /dev/null 
    log_msg "SUCCESS: Added the PID to the pidfile..."
    exit 0
  fi
  
}

validatestarted()
{
  currentPID=$(cat ${PIDFILE})
  log_msg "Attempting validating a started NPI Identity Hub, currently defined in the PID file is [${currentPID}]"
  PROC=$(ps -ef | grep -v grep | grep "${npiIdenName}" | grep "${IDENITYHUB}" | awk -F' ' '{print $2"~"$11}' | head -1)
  PIDFile=$(echo "${PROC}" | cut -d"~" -f2 | cut -d'=' -f2)
  thePID=$(echo "${PROC}" | cut -d"~" -f1)
  if [ -s "${PIDFile}" ]
  then
    PID=$(cat ${PIDFile})
  else
    PID="${thePID}"
  fi
  log_msg "Current PID is: [${PID}] with PID defined in PIDFILE is [${currentPID}]"
  if [ -z "${thePID}" ]
  then
    log_msg "FAILURE: The NPI Identity HUB is not running!"
    exit 5
  else
    log_msg "SUCCESS: The NPI Identity HUB is running, with PID [${thePID}]"
    exit 0
  fi  
  
}

validatestopped()
{

  currentPID=$(cat ${PIDFILE})
  log_msg "Attempting validating a started NPI Identity Hub, currently defined in the PID file is [${currentPID}]"
  PROC=$(ps -ef | grep -v grep | grep "${npiIdenName}" | grep "${IDENITYHUB}" | awk -F' ' '{print $2"~"$11}' | head -1)
  PIDFile=$(echo "${PROC}" | cut -d"~" -f2 | cut -d'=' -f2)
  thePID=$(echo "${PROC}" | cut -d"~" -f1)

  if [ -s "${PIDFile}" ]
  then
    PID=$(cat ${PIDFile})
  else
    PID="${thePID}"
  fi
  log_msg "Current PID is: [${PID}] with PID defined in PIDFILE is [${currentPID}]"
  if [ -z "${thePID}" ]
  then
    log_msg "SUCCESS: The NPI Identity HUB is not running"
    exit 0
  else
    log_msg "FAILURE: The NPI Identity HUB is running, with PID [${thePID}]"
    exit 5
  fi  
  

}

case "${command}" in
     stop)
        actionNPIIdentityHub ${command}
        rc=$?
        cleanLogs
        cleanOldPids
        ;;
     start)
        actionNPIIdentityHub ${command}
        rc=$?
        ;;
     fixpid)
        fixpids
        rc=$?
        ;;
     validatestart)
        validatestarted
        rc=$?
        ;;
     validatestop)
        validatestopped
        rc=$?
        ;;
     *)
        log_msg "Command ${command} is not a correct choice, exiting!"
        exit 1
esac

if [ ${rc} -ne 0 ]
then
  log_msg "ERROR: Could NOT issue [${command}] on the NPI Idenity Hub, with RC ${rc}!"
  exit ${rc}
fi

log_msg "Successfully completed ${APPLNAME}" 

exit 0