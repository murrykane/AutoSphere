
function Get-NextFreeDrive {
  68..90 | ForEach-Object { "$([char]$_):" } | 
  Where-Object { 'w:', 'c:', 'd:' -notcontains $_  } | 
  Where-Object { 
    (new-object System.IO.DriveInfo $_).DriveType -eq 'noRootdirectory' 
  }
}



$TASK=$args[0]

if ($TASK -eq "MAP") {
	
	$UNC=$args[1]
	$DRIVE=(Get-NextFreeDrive)[0]

	$net = new-object -ComObject WScript.Network
	$net.MapNetworkDrive($DRIVE, $UNC)
	return $DRIVE
   }

else {
	$DRIVE=$args[1]
	$net = new-object -ComObject WScript.Network
	start-Sleep -s 10
	$net.RemoveNetworkDrive($DRIVE)
     }


