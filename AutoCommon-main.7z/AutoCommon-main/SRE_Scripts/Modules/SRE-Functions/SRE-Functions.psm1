﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	07/31/2019
	 Updated on:	07/31/2019
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	SRE-Functions.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server. 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script is a functions holder, which can be sourced in from other powershell
        scripts to use common functions that are common for many actions.


Date:      Who:            Changes:
-----------------------------------
07/31/2019 Murry Kane      Initial

    Example

    ./{Directory}\SRE-Functions.ps1
#>

#This method is for exiting a powershell script it works for both command line or from within the ISE
function ExitWithCode 
{ 
    param 
    ( 
        $exitcode,
        $ISEFlag
    )

    if([string]::IsNullOrEmpty($ISEFlag))
    {
        write-host "Setting ISE to default TRUE"
        $ISEFlag = True
    }
    if([string]::IsNullOrEmpty($exitcode))
    {
        write-host "Setting exit code to 99"
        $exitcode = 99
    }
    #Write-Host "ISE Flag [$ISEFlag] Exit Code [$exitcode]"
    if($ISEFlag)
    {
        #lets try and stop transcript..
        try{
            stop-transcript|out-null
        }
        catch [System.InvalidOperationException]{}
        if ($exitCode -gt 0)
        {
            Throw("Exiting ISE Script with [$exitcode]")
        }
        else
        {
            Write-Host "Exiting ISE Script with [$exitcode]"
        }
    }
    else
    {
        if ($exitcode -gt 0)
        {
            Write-Warning "Exiting powershell Script with [$exitcode]"
        }
        else
        {
            Write-Host "Exiting powershell Script with [$exitcode]"
        }
        $host.SetShouldExit($exitcode)
        exit $exitcode
    }
}

#Used to check '-AsJob' remote jobs to wait until each job is complete or failed and log what transpired on each system
function checkJobAndLog
{
    # ExitCodeTypes:
    # 1 - Only Errors increment the exit code
    # 2 - Errors and Warnings increment the exit code
    # 3 - Errors, Warnings and Verbose output increment the exit code
    param(
        [parameter(ValueFromPipeline=$true)]$Session,
        [parameter(ValueFromPipeline=$true)]$Jobs,
        [ValidateSet(1,2,3)][int]$ExitCodeType = 1
        )
    
    #turn on verbose
    $VerbosePreference = 'Continue'
    
    $SleepTime = 5
    $exit_code = 0
    While ($(Get-Job -State Running).count -gt 0){
        $JobsCount = $Jobs.ChildJobs.Count
        for ($i=0; $i -lt $JobsCount; $i++) {
            $ChildJob = $Jobs.ChildJobs[$i]
            Write-Verbose "Job [$($ChildJob.Name)] Server [$($ChildJob.Location)] State is [$($ChildJob.State)]"
        }
        Write-Verbose "Sleeping for $SleepTime.... Current Date: $(Get-Date -format 'u')"
        Start-Sleep -Seconds $SleepTime
    }
    # just to make sure the above while loop is wrong.....
    Wait-Job $Jobs

    Write-Host "=================================================================================================================================================================="
    $JobCount = $Jobs.ChildJobs.Count
    #Write-Host "Count of child Jobs is $JobCount"
    for ($i=0; $i -lt $JobCount; $i++) {
        #Write-Host "Working on loop instance $i"
        $ChildJob = $Jobs.ChildJobs[$i]
        if($ChildJob.Verbose){
            #Write-Host "....................The below VERBOSE output from remote job................"
            $ChildJob.Verbose | Write-Verbose
            if ($ExitCodeType -gt 2) { $exit_code = $exit_code + 1 }
        }
        if($ChildJob.Output){
            #Write-Host "....................The below WRITE-OUTPUT from remote job................"
            #$ChildJob.Output | Write-Output
        }
        if($ChildJob.Warning){
            Write-Host "....................The below WARNING output from remote job................"
            $ChildJob.Warning | Write-Warning
            Write-Host "Sleeping for 0 seconds to view output" -ForegroundColor Yellow
            #Start-Sleep -Seconds 1
            if ($ExitCodeType -gt 1) { $exit_code = $exit_code + 1 }
        }
        if($ChildJob.Error){
            Write-Host "....................The below ERROR output from remote job................"
            $ChildJob.Error | Write-Warning 
            Write-Host "Sleeping for 2 seconds to view output" -ForegroundColor Yellow
            Start-Sleep -Seconds 2
            $exit_code = $exit_code + 1
        }
        Write-Host "=================================================================================================================================================================="
    }

    Remove-Job $Jobs
    remove-pssession $Session
    Get-Job | Remove-Job -force
    #turn off verbose
    $VerbosePreference = 'SilentlyContinue'
    return $exit_code

}

#Used to check '-AsJob' remote jobs to wait until each job is complete or failed and log what transpired on each system
# same as other above method but more for python or other languages other than powershell
function checkRemoteJobAndLog
{
    
    param(
        [parameter(ValueFromPipeline=$true)]$Session,
        [parameter(ValueFromPipeline=$true)]$Jobs
        )
    
    #turn on verbose
    $VerbosePreference = 'Continue'
    
    $SleepTime = 5
    $exit_code = 0
    While ($(Get-Job -State Running).count -gt 0){
        $JobsCount = $Jobs.ChildJobs.Count
        for ($i=0; $i -lt $JobsCount; $i++) {
            $ChildJob = $Jobs.ChildJobs[$i]
            Write-Verbose "Job [$($ChildJob.Name)] Server [$($ChildJob.Location)] State is [$($ChildJob.State)]"
        }
        Write-Verbose "Sleeping for $SleepTime.... Current Date: $(Get-Date -format 'u')"
        Start-Sleep -Seconds $SleepTime      
    }
    # just to make sure the above while loop is wrong.....
    Wait-Job $Jobs

    $JobCount = $Jobs.ChildJobs.Count
    for ($i=0; $i -lt $JobCount; $i++) {
        Write-Host "=================================================================================================================================================================="
        $ChildJob = $Jobs.ChildJobs[$i]
        Write-Host "Job [$($ChildJob.Name)] ran on server [$($ChildJob.Location)] output below:"
        $ChildJob | Receive-Job
        Write-Host "=================================================================================================================================================================="
    }

    Remove-Job $Jobs
    remove-pssession $Session
    Get-Job | Remove-Job -force
    #turn off verbose
    $VerbosePreference = 'SilentlyContinue'
    return $exit_code

}

# same as above 2 methods but specific to puppet remote execution on servers
function checkRemotePuppetJobAndLog
{
    
    param(
        [parameter(ValueFromPipeline=$true)]$Session,
        [parameter(ValueFromPipeline=$true)]$Jobs
        )
    
    #turn on verbose
    $VerbosePreference = 'Continue'
    
    $SleepTime = 5
    $exit_code = 0
    While ($(Get-Job -State Running).count -gt 0){
        $JobsCount = $Jobs.ChildJobs.Count
        for ($i=0; $i -lt $JobsCount; $i++) {
            $ChildJob = $Jobs.ChildJobs[$i]
            Write-Verbose "Job [$($ChildJob.Name)] Server [$($ChildJob.Location)] State is [$($ChildJob.State)]"
        }
        Write-Verbose "Sleeping for $SleepTime.... Current Date: $(Get-Date -format 'u')"
        Start-Sleep -Seconds $SleepTime      
    }
    # just to make sure the above while loop is wrong.....
    Wait-Job $Jobs

    $JobCount = $Jobs.ChildJobs.Count
    Write-Host "Count of child Jobs is $JobCount"
    for ($i=0; $i -lt $JobCount; $i++) {
        Write-Host "=================================================================================================================================================================="
        $ChildJob = $Jobs.ChildJobs[$i]
        Write-Host "Job [$($ChildJob.Name)] ran on server [$($ChildJob.Location)] output below:"
        $ChildJob | Receive-Job
        Write-Host "=================================================================================================================================================================="
    }

    Remove-Job $Jobs
    remove-pssession $Session
    Get-Job | Remove-Job -force
    #turn off verbose
    $VerbosePreference = 'SilentlyContinue'
    return $exit_code

}


#Used to check '-AsJob' remote jobs to wait until each job is complete or failed and log what transpired on each system
function checkJobAndLogKeepingExitCode
{
    # ExitCodeTypes:
    # 1 - Only Errors increment the exit code
    # 2 - Errors and Warnings increment the exit code
    # 3 - Errors, Warnings and Verbose output increment the exit code
    param(
        [parameter(ValueFromPipeline=$true)]$Session,
        [parameter(ValueFromPipeline=$true)]$Jobs,
        [ValidateSet(1,2,3)][int]$ExitCodeType = 1
        )
    
    #turn on verbose
    $VerbosePreference = 'Continue'
    
    $SleepTime = 5
    #$exit_code = 0
    While ($(Get-Job -State Running).count -gt 0){
        $JobsCount = $Jobs.ChildJobs.Count
        for ($i=0; $i -lt $JobsCount; $i++) {
            $ChildJob = $Jobs.ChildJobs[$i]
            Write-Verbose "Job [$($ChildJob.Name)] Server [$($ChildJob.Location)] State is [$($ChildJob.State)]"
        }
        Write-Verbose "Sleeping for $SleepTime.... Current Date: $(Get-Date -format 'u')"
        Start-Sleep -Seconds $SleepTime
    }
    # just to make sure the above while loop is wrong.....
    Wait-Job $Jobs

    Write-Host "=================================================================================================================================================================="
    $JobCount = $Jobs.ChildJobs.Count
    #Write-Host "Count of child Jobs is $JobCount"
    for ($i=0; $i -lt $JobCount; $i++) {
        #Write-Host "Working on loop instance $i"
        $ChildJob = $Jobs.ChildJobs[$i]
        if($ChildJob.Verbose){
            #Write-Host "....................The below VERBOSE output from remote job................"
            $ChildJob.Verbose | Write-Verbose
            #if ($ExitCodeType -gt 2) { $exit_code = $exit_code + 1 }
        }
        if($ChildJob.Output){
            Write-Host "....................The below WRITE-OUTPUT from remote job................"
            $ChildJob.Output | Write-Output
        }
        if($ChildJob.Warning){
            Write-Host "....................The below WARNING output from remote job................"
            $ChildJob.Warning | Write-Warning
            #Write-Host "Sleeping for 0 seconds to view output" -ForegroundColor Yellow
            #Start-Sleep -Seconds 1
            #if ($ExitCodeType -gt 1) { $exit_code = $exit_code + 1 }
        }
        if($ChildJob.Error){
            Write-Host "....................The below ERROR output from remote job................"
            $ChildJob.Error | Write-Warning 
            #Write-Host "Sleeping for 2 seconds to view output" -ForegroundColor Yellow
            #Start-Sleep -Seconds 2
            #$exit_code = $exit_code + 1
        }
        Write-Host "=================================================================================================================================================================="
    }

    Remove-Job $Jobs
    remove-pssession $Session
    Get-Job | Remove-Job -force
    #turn off verbose
    $VerbosePreference = 'SilentlyContinue'
    return

}


# used for common startup on scripts to define log directory and home location and if script is started from within ISE
function scriptStartup
{
    #setting some basic variables and defaults
    $LOG_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\logs'
    $SRE_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\SRE_Scripts'
    $SRE_Automation_Enabled_DEFAULT='Enabled'

    #get some environment variables
    if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\software\BSC_Automation' -ErrorAction Ignore -Name SRE_LOGS).SRE_LOGS)))
    {
        $LOG_DIR = (Get-Itemproperty -path 'hklm:\software\BSC_Automation' -ErrorAction Ignore -Name SRE_LOGS).SRE_LOGS
    }
    else
    {
        $LOG_DIR = $LOG_DIR_DEFAULT 
    }

    #get SRE home dir from environment variables
    if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'HKLM:\software\BSC_Automation' -ErrorAction Ignore -Name SRE_HOME).SRE_HOME)))
    {
        $SRE_HOME = (Get-Itemproperty -path 'HKLM:\software\BSC_Automation' -ErrorAction Ignore -Name SRE_HOME).SRE_HOME
    }
    else
    {
        $SRE_HOME = $SRE_HOME_DIR_DEFAULT 
    }

    #get SRE Self-Healing enabled/disabled 
    if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'HKLM:\software\BSC_Automation' -ErrorAction Ignore -Name SRE_Automation_Enabled).SRE_Automation_Enabled)))
    {
        $SRE_Automation_Enabled = (Get-Itemproperty -path 'HKLM:\software\BSC_Automation' -ErrorAction Ignore -Name SRE_Automation_Enabled).SRE_Automation_Enabled
    }
    else
    {
        $SRE_Automation_Enabled = $SRE_Automation_Enabled_DEFAULT 
    }

    #determine if started from within the ISE or command line
    if ($Host.Name -eq "Windows PowerShell ISE Host") {
        $ISE=$true
    } else {
        $ISE=$false
    }

    return @($ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled)
}


# Used to verify if server name is valid. Returns error code 0 if true, 33 if false
function isValidServer
{
    
    param
    (
        [parameter(Mandatory=$true)]
        [string]$Server
    )

    $Address = $null
    $EC = 0

    Write-Verbose "Validating Server [$Server]..."

    try
    {
        $Address = [System.Net.Dns]::GetHostAddresses("$Server").IPAddressToString
        Write-Host "Server [$Server] IP Address is $Address"
        return $EC
    }
    catch
    {
        $EC = 33
        Write-Warning "Server [$Server] IP Address could not resolve."
        return $EC
    }
}

# Used to validate server platform and env domain are consistent. Use -RunOnLocalHost to force the function to return 0 (our laptops don't end in 'p' but are PROD)
function validateDomain
{
    
    param
    (
        [Parameter(Mandatory=$true)]
        [string]$Server,
        [switch]$RunOnLocalHost
    )
    
    # Set error code
    $EC = 0

    # Get Environment Domain
    $Domain = (Get-ChildItem Env:'UserDomain' -ErrorAction Ignore).Value

    # Get platform (PROD/OTHER)
    $ServerLetter = $Server.Substring($Server.Length - 1,1)

    if ($ServerLetter -eq "p")
    {
        $Platform = "PROD"
    }
    elseif ($RunOnLocalHost)
    {
        # Set to appropriate platform based on domain
        if ($Domain -eq "BSC")
        {
            $Platform = "PROD"
        }
        else
        {
            $Platform = "OTHER"
        }
    }
    else 
    {
        $Platform = "OTHER"
    }

    Write-Verbose "Platform for server [$Server] is [$Platform], Active Directory domain is [$Domain]."

    # Validate we are not trying to cross domains
    if ($Platform -eq "PROD" -and $Domain -ne "BSC")
    {
        $EC = 21
        Write-Warning "We cannot run a script from a Non-prod Active Directory domain [$Domain] to a production server [$Server], exiting script!"
        return $EC
    }
    elseif ($Platform -ne "PROD" -and $Domain -eq "BSC")
    {
        $EC = 22
        Write-Warning "We cannot run a script from a Prod Active Directory domain [$Domain] to a non-production server [$Server], exiting script!"
        return $EC
    }
    else
    {
        Write-Host "Running script in Active Directory domain [$Domain] for server of type [$Platform]"
        return $EC
    }
}


# Validates the remote python session data. Returns NULL reason to exit if okay to proceed, 
# otherwise returns a string that can be printed by Write-Warning prior to ExitWithCode
# Returns @($ReasonToExit, $PythonScriptPaths)
function ValidateRemotePythonSession
{
    param(
        [Parameter(Position=0)]
        [string[]]$PythonScripts
    )
    
    try
    {
        # ---------------- This Section comes from scriptStartup function ---------------- #
        $SRE_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\SRE_Scripts'
        $SRE_Automation_Enabled_DEFAULT='Enabled'

        # Get SRE_Home
        if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'HKLM:\software\BSC_Automation' -ErrorAction Ignore -Name SRE_HOME).SRE_HOME)))
        {
            $SRE_HOME = (Get-Itemproperty -path 'HKLM:\software\BSC_Automation' -ErrorAction Ignore -Name SRE_HOME).SRE_HOME
        }
        else
        {
            $SRE_HOME = $SRE_HOME_DIR_DEFAULT 
        }

        # Get SRE_Automation_Enabled
        if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'HKLM:\software\BSC_Automation' -ErrorAction Ignore -Name SRE_Automation_Enabled).SRE_Automation_Enabled)))
        {
            $SRE_Automation_Enabled = (Get-Itemproperty -path 'HKLM:\software\BSC_Automation' -ErrorAction Ignore -Name SRE_Automation_Enabled).SRE_Automation_Enabled
        }
        else
        {
            $SRE_Automation_Enabled = $SRE_Automation_Enabled_DEFAULT 
        }
        # -------------------------------------------------------------------------------- #

        # Validate Self Heal is Enabled
        if ($SRE_Automation_Enabled -ne "Enabled")
        {
            return @("Error: SRE Automation has been disabled on remote server.",$null)
        }


        # Get python directory
        if ($SRE_HOME -match "(\S+)\\AutoCommon")
        {
            $PYTHON_HOME = "$($Matches[1])\AutoSphere\python"
            Write-Host "Python Home Directory is [$PYTHON_HOME]"
        }
        else
        {
            return @("Could not locate path to python directory. Exiting!",$null)
        }

        # Validate Path to Python Script(s)
        $PythonScriptPaths = New-Object System.Collections.ArrayList
    
        foreach ($PythonScript in $PythonScripts)
        {
            $PythonScriptPath = "$PYTHON_HOME\$PythonScript"
    
            if (-not $(Test-Path $PythonScriptPath))
            {
                return @("Could not validate path to Python Script [$PythonScriptPath]. Exiting!",$null)
            }
            else
            {
                $ScriptNum = $PythonScriptPaths.Add($PythonScriptPath) + 1
                Write-Host "Path to Python Script [$ScriptNum] is [$PythonScriptPath]"
            }
        }

        return @($null,$PythonScriptPaths)

    }
    catch
    {
        return @($($_.Exception.ToString()),$null)
    }
}


# Function searches for the python executable for the specified version
# Returns NULL reason to exit if python executable was found
# Returns @($ReasonToExit,$PythonExe)
function Get-PythonExecutablePath
{

    param(
        [Parameter(Position=0)]
        [ValidateSet("2","3")]
        [string]$PythonVersion = "2"
        )


    try
    {
        $PythonExe = (Get-Command python.exe -ErrorAction Stop).path

        if ($PythonExe -match "Python$PythonVersion")
        {
            return @($null,$PythonExe)
        }
        else
        {
            return @("Error: Python executable [$PythonExe] is incorrect version. Exiting!",$null)
        }
    }
    catch
    {    
        # Get All 1 Letter Drives
        $Drives = (Get-PSDrive | Where-Object { $_.Name.Length -eq 1 })

        # Loop 
        foreach ($Drive in $Drives) 
        {
            $Root = $Drive.Root
    
            Write-Host "Checking for Python $PythonVersion on drive [$($Drive.Name)]..."


            if (Test-Path "$Root`Python$PythonVersion*")
            {
                $PythonDir = (Get-ChildItem "$Root`Python$PythonVersion*")[0].FullName
                $PythonExe = "$PythonDir\python.exe"

                if (-not $(Test-Path $PythonExe))
                {
                    Write-Host "Unable to locate python.exe in Python $PythonVersion directory [$PythonDir]."
                    $PythonExe = $null
                }
                else 
                {
                    Write-Host "Python $PythonVersion executable found at path [$PythonExe]."
                    return @($null,$PythonExe)
                }
            }
            else
            {
                Write-Host "Python directory not found on drive [$($Drive.Name)]"
            }

        }

        return @("Error: Could not find Python $PythonVersion executable. Exiting!",$null)
    }
    
}


# This function prints the output stream from a python script
# that was run remotely. Returns LogOutput
function Get-PythonLogOutput
{
    param(
        [parameter(Mandatory=$true)]$Job
        )
    
    # Turn on verbose
    $initialVerbose = $VerbosePreference
    $VerbosePreference = 'Continue'
    
    $SleepTime = 5
    
    While ($(Get-Job -State Running).count -gt 0){
        $JobsCount = $Job.ChildJobs.Count
        for ($i=0; $i -lt $JobsCount; $i++) {
            $ChildJob = $Job.ChildJobs[$i]
            Write-Verbose "Job [$($ChildJob.Name)] Server [$($ChildJob.Location)] State is [$($ChildJob.State)]"
        }
        Write-Verbose "Sleeping for $SleepTime.... Current Date: $(Get-Date -format 'u')"
        Start-Sleep -Seconds $SleepTime
    }
    # just to make sure the above while loop is not wrong.....
    Wait-Job $Job

    
    Write-Host "=================================================================================================================================================================="
    Write-Host "Job [$($Job.Name)] ran on server [$($Job.Location)] output below:"
    $LogOutput = ($Job | Receive-Job) -join "`n"
    Write-Host $LogOutput
    Write-Host "=================================================================================================================================================================="
    

    Remove-Job $Job
    Get-Job | Remove-Job -Force

    return $LogOutput
}


# this function runs a python script as a job on a PSSession
# retrieves script output from job and python exit code
# it returns $ReasonToExit. If $null, continue, otherwise exit
#
# Examples
# $ReasonToExit = RunPythonAsJob -Session $Session -PythonExe $PythonExe -PythonScriptName $PyScriptStart -PythonScriptPath $PyScriptStartPath -PythonArgs "--clusterName=$Server"
# RunPythonAsJob -Session $Session -PythonExe "C:\Python26\python.exe" -PythonScriptName "HelloWorld.py" -PythonScriptPath "C:\HelloWorld.py"
function RunPythonAsJob
{
    param(
        [Parameter(Mandatory=$true,Position=0)]
        [System.Management.Automation.Runspaces.PSSession]$Session,
        [Parameter(Mandatory=$true,Position=1)]
        [string]$PythonExe,
        [Parameter(Mandatory=$true,Position=2)]
        [string]$PythonScriptName,
        [Parameter(Mandatory=$true,Position=3)]
        [string]$PythonScriptPath,
        [Parameter(Mandatory=$false,Position=4)]
        [string]$PythonArgs
        )
    
    try
    {
        # Create Python Command
        if ($PythonArgs -ne $null)
        {
            $PythonCommand = "$PythonExe '$PythonScriptPath' $PythonArgs"
        }
        else
        {
            $PythonCommand = "$PythonExe '$PythonScriptPath'"
        }
        
        # Run Command as Job
        Write-Host "Running Python Script [$PythonScriptName] with command [$PythonCommand]"
        $Job = Invoke-Command -Session $Session -ScriptBlock { Invoke-Expression -Command "$Using:PythonCommand 2>&1" } -AsJob

        # Get Output of Python Script
        $LogOutput = Get-PythonLogOutput -Job $Job

        # Get Python Exit Code
        $PythonExitCode = Invoke-Command -Session $Session -ScriptBlock { return $LASTEXITCODE }
        Write-Host "Python Script [$PythonScriptName] Exit Code: [$PythonExitCode]"

        # Verify Python Script Executed Successfully
        if ($PythonExitCode -eq $null)
        {
            $ReasonToExit = "Error: Python Script [$PythonScriptName] return a null Exit code... Exiting!"
            return $ReasonToExit
        }
        elseif ($PythonExitCode -ne 0) 
        {
            
            $ReasonToExit = "Error: Failure while running Python Script [$PythonScriptName]... Exit Code = $PythonExitCode"
            return $ReasonToExit
        }
        else
        {
            Write-Host "All good on job. [$PythonScriptName] successfully ran on server [$($Session.ComputerName)]"
        }
    
        return $null
    }

    catch
    {
        $ReasonToExit = "Error while trying to run [$PythonScriptName]: $($_.Exception.ToString())"
        return $ReasonToExit
    }
}


#################
# This function is to Encrypt A String.
# $string is the string to encrypt, $passphrase is a second security "password" that has to be passed to decrypt.
# $salt is used during the generation of the crypto password to prevent password guessing.
# $init is used to compute the crypto hash -- a checksum of the encryption
#################
function Encrypt-String($String, $Passphrase, $salt="SaltCrypto", $init="IV_Password", [switch]$arrayOutput)
{
	# Create a COM Object for RijndaelManaged Cryptography
	$r = new-Object System.Security.Cryptography.RijndaelManaged
	# Convert the Passphrase to UTF8 Bytes
	$pass = [Text.Encoding]::UTF8.GetBytes($Passphrase)
	# Convert the Salt to UTF Bytes
	$salt = [Text.Encoding]::UTF8.GetBytes($salt)

	# Create the Encryption Key using the passphrase, salt and SHA1 algorithm at 256 bits
	$r.Key = (new-Object Security.Cryptography.PasswordDeriveBytes $pass, $salt, "SHA1", 5).GetBytes(32) #256/8
	# Create the Intersecting Vector Cryptology Hash with the init
	$r.IV = (new-Object Security.Cryptography.SHA1Managed).ComputeHash( [Text.Encoding]::UTF8.GetBytes($init) )[0..15]

	# Starts the New Encryption using the Key and IV   
	$c = $r.CreateEncryptor()
	# Creates a MemoryStream to do the encryption in
	$ms = new-Object IO.MemoryStream
	# Creates the new Cryptology Stream --> Outputs to $MS or Memory Stream
	$cs = new-Object Security.Cryptography.CryptoStream $ms,$c,"Write"
	# Starts the new Cryptology Stream
	$sw = new-Object IO.StreamWriter $cs
	# Writes the string in the Cryptology Stream
	$sw.Write($String)
	# Stops the stream writer
	$sw.Close()
	# Stops the Cryptology Stream
	$cs.Close()
	# Stops writing to Memory
	$ms.Close()
	# Clears the IV and HASH from memory to prevent memory read attacks
	$r.Clear()
	# Takes the MemoryStream and puts it to an array
	[byte[]]$result = $ms.ToArray()
	# Converts the array from Base 64 to a string and returns
	return [Convert]::ToBase64String($result)
}

function Decrypt-String($Encrypted, $Passphrase, $salt="SaltCrypto", $init="IV_Password")
{
	# If the value in the Encrypted is a string, convert it to Base64
	if($Encrypted -is [string]){
		$Encrypted = [Convert]::FromBase64String($Encrypted)
	}

	# Create a COM Object for RijndaelManaged Cryptography
	$r = new-Object System.Security.Cryptography.RijndaelManaged
	# Convert the Passphrase to UTF8 Bytes
	$pass = [Text.Encoding]::UTF8.GetBytes($Passphrase)
	# Convert the Salt to UTF Bytes
	$salt = [Text.Encoding]::UTF8.GetBytes($salt)

	# Create the Encryption Key using the passphrase, salt and SHA1 algorithm at 256 bits
	$r.Key = (new-Object Security.Cryptography.PasswordDeriveBytes $pass, $salt, "SHA1", 5).GetBytes(32) #256/8
	# Create the Intersecting Vector Cryptology Hash with the init
	$r.IV = (new-Object Security.Cryptography.SHA1Managed).ComputeHash( [Text.Encoding]::UTF8.GetBytes($init) )[0..15]


	# Create a new Decryptor
	$d = $r.CreateDecryptor()
	# Create a New memory stream with the encrypted value.
	$ms = new-Object IO.MemoryStream @(,$Encrypted)
	# Read the new memory stream and read it in the cryptology stream
	$cs = new-Object Security.Cryptography.CryptoStream $ms,$d,"Read"
	# Read the new decrypted stream
	$sr = new-Object IO.StreamReader $cs
	# Return from the function the stream
	Write-Output $sr.ReadToEnd()
	# Stops the stream	
	$sr.Close()
	# Stops the crypology stream
	$cs.Close()
	# Stops the memory stream
	$ms.Close()
	# Clears the RijndaelManaged Cryptology IV and Key
	$r.Clear()
}