﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	05/29/2020
	 Updated on:	05/29/2020
	 Created by:   	Kyle Parrott
	 Organization: 	Blue Shield of California
	 Filename:     	SnowFunctions.ps1

	The scripts being built in this grouping are for working with the 
    ServiceNow API.
	===========================================================================
	.DESCRIPTION
		This script is a module which can be sourced in from other powershell
        scripts to use common functions for working with the snow API.


Date:      Who:            Changes:
-----------------------------------
05/29/2020 Kyle parrott    Initial
01/22/2021 Murry Kane      Added logic to connect to Production ServiceNow by default for CMDB lookups 
                               if you prefer to connect by what the local doamin is (dev.bscal.... etc)
                               then pass -uselocaldomain paramenter to both methods as such
                                  $SnowCred = Get-ServiceNowCredential -uselocaldomain 
                                  $SnowCred = Get-ServiceNowCredential -uselocaldomain -cred $thecred

                                  For getting URL base 2015 do the below when on a server that is dev.bscal...
                                      
                                  $UriBase = Get-ServiceNowUriBase -uselocaldomain 
03/01/2021 Murry Kane      Added new function for adding attachment to SNow table/sys_id
    Example

    ./{Directory}\SnowFunctions.psm1
#>

# Usage: 
#     $SNowCred = Get-ServiceNowCredential
#     $SNowCred = Get-ServiceNowCredential -Cred $Cred
#     $SnowCred = Get-ServiceNowCredential -Cred $Cred -uselocaldomain
function Get-ServiceNowCredential{
    param(
    [Parameter(Mandatory=$false)][System.Management.Automation.PSCredential]$cred,
    [Parameter(Mandatory=$false)][switch]$uselocaldomain
    )

    $oldverbose = $VerbosePreference
    $VerbosePreference = "continue"
    $SNowCred = ''

    try
    {

        $encryptFile = ""
        #lets determine local domain to determine which SRE to connect too (DEV/BSC domains)
        $domain = Get-WMIObject Win32_ComputerSystem | Select-Object -ExpandProperty domain
        if ($domain -eq "bsc.bscal.com")
        {
            $encryptFile = "Q:\Installs\Users\svcsre_prod.txt"
            if ([System.Net.Dns]::GetHostName() -like 'winf4595p')
            {
                $sreServer = "\\winf4595p\D$"   
            }
            elseif ([System.Net.Dns]::GetHostName() -like 'winf4594p')
            {
                $sreServer = "\\winf4594p\D$" 
            }
            else
            {
                $sreServer = "\\winf4595p\D$"
            }
        }
        else
        {
            $sreServer = "\\winf2286n\D$"
            #need to see if we will get the DEV or BSC for login...
            if(-not $uselocaldomain)
            {
                $encryptFile = "Q:\Installs\Users\svcsre_prod.txt" 
            }
            else
            {
                $encryptFile = "Q:\Installs\Users\svcsre_dev.txt" 
            }
        }
        Write-Verbose "Using encrypted file: [$encryptFile] with SRE Server Mount [$sreServer]"
        #Write-Verbose "Using SRE Server Mount [$sreServer]"

        if(-not $uselocaldomain)
        {
            #by default we will use production unless its requested to use local domain on the running server
            Write-Verbose "We will use Production for CMDB queries for accuracy"
            
            if($Cred -ne [System.Management.Automation.PSCredential]::Empty) {
                $PSDrive = New-PSDrive -Name Q -PSProvider FileSystem -Root $sreServer -Credential $Cred
            }
            else {
                $PSDrive = New-PSDrive -Name Q -PSProvider FileSystem -Root $sreServer
            }

            if([string]::IsNullOrWhiteSpace($PSDrive))
            {
                #this means an error occurred....
                throw "Could not map a drive successfully to get credentials, exiting badly!"
            }
        }
        else
        {
            #in this case we will use local domain to determine which ServiceNow instance to connect too
            Write-Verbose "We will use local domain to determine ServiceNow instance to do CMDB lookups"

            if ($domain -eq "bsc.bscal.com") {
                if ($Cred -ne [System.Management.Automation.PSCredential]::Empty) {
                    $PSDrive = New-PSDrive -Name Q -PSProvider FileSystem -Root $sreServer -Credential $Cred
                }
                else {
                    $PSDrive = New-PSDrive -Name Q -PSProvider FileSystem -Root $sreServer
                }
            }
            else {
                if([System.Net.Dns]::GetHostName() -like 'winf2286n' -or $Cred -eq [System.Management.Automation.PSCredential]::Empty) {
                    $PSDrive = New-PSDrive -Name Q -PSProvider FileSystem -Root $sreServer  
                }
                else
                {
                    $PSDrive = New-PSDrive -Name Q -PSProvider FileSystem -Root $sreServer -Credential $Cred
                }
            }
            #check if null now...
            if([string]::IsNullOrWhiteSpace($PSDrive))
            {
                #this means an error occurred....
                throw "Could not map a drive successfully to get credentials, exiting badly!"
            }
        }
    
        $usernameline = get-content -Path $encryptFile | Select-String -Pattern USERNAME
        $passwordline = get-content -Path $encryptFile | Select-String -Pattern PASSWORD
        $username = $usernameline.ToString().Substring(9, $usernameline.ToString().length-9)
        $password = $passwordline.ToString().Substring(9, $passwordline.ToString().length-9)
        $udecrypted = Decrypt-String $username "U_MyStrongPassword"
        $pdecrypted = Decrypt-String $password "P_MyStrongPassword"
        $SNowPass = ConvertTo-SecureString –String $pdecrypted –AsPlainText -Force
        $SNowCred = New-Object –TypeName System.Management.Automation.PSCredential –ArgumentList $udecrypted, $SNowPass
    }
    Catch
    {
        throw $_.Exception.ToString();
    }
    finally
    {   
        # Remove PS Drive
        Remove-PSDrive -Name Q -Force -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
        $VerbosePreference = $oldverbose
    }
    return $SNowCred
}


# Provides base uri for snow instance based on current domain
# Usage: 
#     $UriBase = Get-ServiceNowUriBase
function Get-ServiceNowUriBase {
    param(
        [Parameter(Mandatory=$false)][switch]$uselocaldomain
        )
    
    $oldverbose = $VerbosePreference
    $VerbosePreference = "continue"
    $UriBase = ''
    if(-not $uselocaldomain)
    {
        #by default we will use production unless its requested to use local domain on the running server
        $UriBase = 'https://blueshieldca.service-now.com'
        #Write-Verbose "We will use Production ServiceNow for CMDB queries for accuracy"
    }
    else
    {
        #in this case we will use local domain to determine which ServiceNow instance to connect too
        $domain = Get-WMIObject Win32_ComputerSystem | Select-Object -ExpandProperty domain
        if ($domain -eq "bsc.bscal.com") {
            $UriBase = 'https://blueshieldca.service-now.com'
        }
        else {
            $UriBase = 'https://blueshieldca2015.service-now.com'
        }
        Write-Verbose "We will use local domain to determine ServiceNow instance to do CMDB lookups which resulted with: [$UriBase]"
    }
    
    $VerbosePreference = $oldverbose
    return $UriBase
}

# Queries the ServiceNow Api
# Usage:
#     $Result = Query-ServiceNowApi -Uri $Uri -SNowCred $SNowCred
function Query-ServiceNowApi($Uri,$SNowCred) {
    
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    $Response = Invoke-RestMethod -Uri $Uri -Credential $SNowCred -ContentType "application/json"
    $Result = $Response.result

    return $Result
}


# Pass a list of servers to this function to generate the uri
# necessary to query their cmdb information
# NOTE: You can update the sysparam_fields to include additional fields,
#       but please ensure no fields are removed from the response
# Usage:
#     $Servers = @("winf4594p","winf4595p")
#     $Uri = Get-ServiceNowServerQueryUri -Servers $Servers
#     $Result = Query-ServiceNowApi -Uri $Uri -SNowCred $SnowCred
function Get-ServiceNowServerQueryUri($Servers) {
    $sysparam_query = "nameIN"
    
    foreach ($Server in $Servers) {
        if ($sysparam_query -eq "nameIN") {
            $sysparam_query += $Server
        }
        else {
            $sysparam_query += "%2C" + $Server
        }
    }

    $UriBase = Get-ServiceNowUriBase

    $Uri = "$UriBase/api/now/table/cmdb_ci_server?sysparm_query=$sysparam_query&sysparm_fields=name%2Csys_class_name%2Cused_for&sysparm_limit=1000"
    
    return $Uri
}

function add-SnowAttachment {
    param(
            [Parameter(Mandatory=$true)][string]$table_name,
            [Parameter(Mandatory=$true)][string]$sys_id,
            [Parameter(Mandatory=$true)][string]$file_name,
            [Parameter(Mandatory=$true)][string]$phys_file,
            [Parameter(Mandatory=$true)][string]$doc_type,
            [Parameter(Mandatory=$true)][string]$snow_instance,
            [Parameter(Mandatory=$true)][string]$snow_user,
            [Parameter(Mandatory=$true)][string]$snow_pass
            )
    ##################################################
    #lets add the attachement based on passed parms... 
    ##################################################
    $oldverbose = $VerbosePreference
    $VerbosePreference = "continue"
    $result = ''

    # Build auth header
    #Write-Verbose "decoded pass $snow_pass"
    #Write-Verbose "decoded username $snow_user"
    $base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(('{0}:{1}' -f $snow_user, $snow_pass)))

    # Set proper headers
    $headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $headers.Add('Authorization',('Basic {0}' -f $base64AuthInfo))
    $headers.Add('Accept','application/json')
    $headers.Add('Content-Type','application/json')
    #$headers.Add('Content-Type', $doc_type)

    # Specify endpoint uri
    $uri = "$snow_instance/api/now/attachment/file?table_name=$table_name&table_sys_id=$sys_id&file_name=$file_name"

    # Specify HTTP method
    $method = "POST"


    try
    {
        # Send HTTP request
        $response = Invoke-WebRequest -Headers $headers -Method $method -Uri $uri -InFile $phys_file 
        $StatusCode = $Response.StatusCode
    }
    catch
    {
        $StatusCode = $_.Exception.Response.StatusCode.value__  
        $StatusDesc = $_.Exception.Response.StatusDescription
        #Write-Verbose = $_.Exception.Response.value__ 
        if($_.ErrorDetails.Message) {
            Write-Verbose $_.ErrorDetails.Message
        } else {
            Write-Verbose $_
        }
    }

    Write-Verbose "Response status: $StatusCode"

    if ($StatusCode -ne 201)
    {
        #bad 
        Write-Warning "WARNING: We could not add the attachment to the ServiceNow Instance!"
        Write-Warning "WARNING: Status Code [$StatusCode] with error: [$StatusDesc]"
    }
    else
    {
        # Print response
        write-verbose $response.RawContent

        $response2 = $response.Content | ConvertFrom-Json
        $downloadLink = $response2.result.download_link 
        $size = $response2.result.size_bytes
        #$size
        #$downloadLink
        $result = $downloadLink

        Write-Verbose "Size $size and download link $downloadLink"
    }

    $VerbosePreference = $oldverbose
    return $result

}


