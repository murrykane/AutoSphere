﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	11/12/2019
	 Updated on:	11/12/2019
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:      InstallTidal.psm1

	The scripts being built in this grouping are for SRE Production Support
	The majority will be run from the Primary SRE Server, WINF2286N, WINF3095P or WINF3096p.
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script will install Tidal Agent and needed configuration for the Tidal Agent

MODIFICATIONS
_____________________________________________________________________________________________________________________________
    Date       By            Reason
    11/12/2019 Murry Kane    Initial
    12/07/2020 Murry Kane    if production remove setting the TIDAL account on the windows service as we don't have the 
                             password
    01/29/2021 Murry Kane    look for any version of .net over 3.5 and proceed if one is present, otherwise install 3.5
                             also added new version of the Tidal Agent to be installed if not present
_____________________________________________________________________________________________________________________________
    Example


#>


function SRE-InstallTidal 
{
[CmdletBinding()]
Param(
    [Parameter(Position=0)]
    [System.Management.Automation.PSCredential]$Cred
)

    #################
    # Powershell Allows The Loading of .NET Assemblies
    # Load the Security assembly to use with this script 
    #################
    [Reflection.Assembly]::LoadWithPartialName("System.Security")
 
    #################
    # This function is to Encrypt A String.
    # $string is the string to encrypt, $passphrase is a second security "password" that has to be passed to decrypt.
    # $salt is used during the generation of the crypto password to prevent password guessing.
    # $init is used to compute the crypto hash -- a checksum of the encryption
    #################
    function Encrypt-String($String, $Passphrase, $salt="SaltCrypto", $init="IV_Password", [switch]$arrayOutput)
    {
	    # Create a COM Object for RijndaelManaged Cryptography
	    $r = new-Object System.Security.Cryptography.RijndaelManaged
	    # Convert the Passphrase to UTF8 Bytes
	    $pass = [Text.Encoding]::UTF8.GetBytes($Passphrase)
	    # Convert the Salt to UTF Bytes
	    $salt = [Text.Encoding]::UTF8.GetBytes($salt)
 
	    # Create the Encryption Key using the passphrase, salt and SHA1 algorithm at 256 bits
	    $r.Key = (new-Object Security.Cryptography.PasswordDeriveBytes $pass, $salt, "SHA1", 5).GetBytes(32) #256/8
	    # Create the Intersecting Vector Cryptology Hash with the init
	    $r.IV = (new-Object Security.Cryptography.SHA1Managed).ComputeHash( [Text.Encoding]::UTF8.GetBytes($init) )[0..15]
	
	    # Starts the New Encryption using the Key and IV   
	    $c = $r.CreateEncryptor()
	    # Creates a MemoryStream to do the encryption in
	    $ms = new-Object IO.MemoryStream
	    # Creates the new Cryptology Stream --> Outputs to $MS or Memory Stream
	    $cs = new-Object Security.Cryptography.CryptoStream $ms,$c,"Write"
	    # Starts the new Cryptology Stream
	    $sw = new-Object IO.StreamWriter $cs
	    # Writes the string in the Cryptology Stream
	    $sw.Write($String)
	    # Stops the stream writer
	    $sw.Close()
	    # Stops the Cryptology Stream
	    $cs.Close()
	    # Stops writing to Memory
	    $ms.Close()
	    # Clears the IV and HASH from memory to prevent memory read attacks
	    $r.Clear()
	    # Takes the MemoryStream and puts it to an array
	    [byte[]]$result = $ms.ToArray()
	    # Converts the array from Base 64 to a string and returns
	    return [Convert]::ToBase64String($result)
    }
 
    function Decrypt-String($Encrypted, $Passphrase, $salt="SaltCrypto", $init="IV_Password")
    {
	    # If the value in the Encrypted is a string, convert it to Base64
	    if($Encrypted -is [string]){
		    $Encrypted = [Convert]::FromBase64String($Encrypted)
   	    }
 
	    # Create a COM Object for RijndaelManaged Cryptography
	    $r = new-Object System.Security.Cryptography.RijndaelManaged
	    # Convert the Passphrase to UTF8 Bytes
	    $pass = [Text.Encoding]::UTF8.GetBytes($Passphrase)
	    # Convert the Salt to UTF Bytes
	    $salt = [Text.Encoding]::UTF8.GetBytes($salt)
 
	    # Create the Encryption Key using the passphrase, salt and SHA1 algorithm at 256 bits
	    $r.Key = (new-Object Security.Cryptography.PasswordDeriveBytes $pass, $salt, "SHA1", 5).GetBytes(32) #256/8
	    # Create the Intersecting Vector Cryptology Hash with the init
	    $r.IV = (new-Object Security.Cryptography.SHA1Managed).ComputeHash( [Text.Encoding]::UTF8.GetBytes($init) )[0..15]
 
 
	    # Create a new Decryptor
	    $d = $r.CreateDecryptor()
	    # Create a New memory stream with the encrypted value.
	    $ms = new-Object IO.MemoryStream @(,$Encrypted)
	    # Read the new memory stream and read it in the cryptology stream
	    $cs = new-Object Security.Cryptography.CryptoStream $ms,$d,"Read"
	    # Read the new decrypted stream
	    $sr = new-Object IO.StreamReader $cs
	    # Return from the function the stream
	    Write-Output $sr.ReadToEnd()
	    # Stops the stream	
	    $sr.Close()
	    # Stops the crypology stream
	    $cs.Close()
	    # Stops the memory stream
	    $ms.Close()
	    # Clears the RijndaelManaged Cryptology IV and Key
	    $r.Clear()
    }

    function ExitWithCode 
    { 
        param 
        ( 
            $exitcode,
            $ISEFlag
        )

        if([string]::IsNullOrEmpty($ISEFlag))
        {
            write-verbose "Setting ISE to default TRUE"
            $ISEFlag = True
        }

        #Write-Host "ISE Flag [$ISEFlag] Exit Code [$exitcode]"
        if($ISEFlag)
        {
            #lets try and stop transcript..
            try{
                stop-transcript|out-null
            }
            catch [System.InvalidOperationException]{}
            if ($exitCode -gt 0)
            {
                Throw("Exiting ISE Script with [$exitcode]")
            }
            else
            {
                Write-verbose "Exiting ISE Script with [$exitcode]"
            }
        }
        else
        {
            if ($exitcode -gt 0)
            {
                Write-Warning "Exiting powershell Script with [$exitcode]"
            }
            else
            {
                Write-verbose "Exiting powershell Script with [$exitcode]"
            }
            $host.SetShouldExit($exitcode)
            exit $exitcode
        }
    }


    function Get-DotNetFrameworkVersion
    {
        param(
            [string]$ComputerName = $env:COMPUTERNAME
        )

        $netInstalled = $false
        $dotNetRegistry  = 'SOFTWARE\Microsoft\NET Framework Setup\NDP'
        $dotNet4Registry = 'SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full'
        $dotNet4Builds = @{
            '30319'  = @{ Version = [System.Version]'4.0'                                                     }
            '378389' = @{ Version = [System.Version]'4.5'                                                     }
            '378675' = @{ Version = [System.Version]'4.5.1'   ; Comment = '(8.1/2012R2)'                      }
            '378758' = @{ Version = [System.Version]'4.5.1'   ; Comment = '(8/7 SP1/Vista SP2)'               }
            '379893' = @{ Version = [System.Version]'4.5.2'                                                   }
            '380042' = @{ Version = [System.Version]'4.5'     ; Comment = 'and later with KB3168275 rollup'   }
            '393295' = @{ Version = [System.Version]'4.6'     ; Comment = '(Windows 10)'                      }
            '393297' = @{ Version = [System.Version]'4.6'     ; Comment = '(NON Windows 10)'                  }
            '394254' = @{ Version = [System.Version]'4.6.1'   ; Comment = '(Windows 10)'                      }
            '394271' = @{ Version = [System.Version]'4.6.1'   ; Comment = '(NON Windows 10)'                  }
            '394802' = @{ Version = [System.Version]'4.6.2'   ; Comment = '(Windows 10 Anniversary Update)'   }
            '394806' = @{ Version = [System.Version]'4.6.2'   ; Comment = '(NON Windows 10)'                  }
            '460798' = @{ Version = [System.Version]'4.7'     ; Comment = '(Windows 10 Creators Update)'      }
            '460805' = @{ Version = [System.Version]'4.7'     ; Comment = '(NON Windows 10)'                  }
            '461308' = @{ Version = [System.Version]'4.7.1'   ; Comment = '(Windows 10 Fall Creators Update)' }
            '461310' = @{ Version = [System.Version]'4.7.1'   ; Comment = '(NON Windows 10)'                  }
            '461808' = @{ Version = [System.Version]'4.7.0356';                                               }
            '461814' = @{ Version = [System.Version]'4.7.03062';Comment = '(BSC latest version)'              }
        }

        foreach($computer in $ComputerName)
        {
            if($regKey = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $computer))
            {
                if ($netRegKey = $regKey.OpenSubKey("$dotNetRegistry"))
                {
                    foreach ($versionKeyName in $netRegKey.GetSubKeyNames())
                    {
                        write-verbose "versionkeyname $versionKeyName"
                        if ($versionKeyName -match '^v[123]') {
                            $versionKey = $netRegKey.OpenSubKey($versionKeyName)
                            $version = [System.Version]($versionKey.GetValue('Version', ''))
                            New-Object -TypeName PSObject -Property ([ordered]@{
                                    ComputerName = $computer
                                    Build = $version.Build
                                    Version = $version
                                    Comment = ''
                            })
                        
                        }
                        Write-verbose "version is $version"
                        if($version -ge 3.5)
                        {
                          Write-verbose "Its greater or equal then 3.5...."
                          $netInstalled = $true
                        }
                    }
                }

                if ($net4RegKey = $regKey.OpenSubKey("$dotNet4Registry"))
                {
                    if(-not ($net4Release = $net4RegKey.GetValue('Release')))
                    {
                        $net4Release = 30319
                    }
                    $Version = $dotNet4Builds["$net4Release"].Version
                    Write-verbose "Version is $Version"
                    New-Object -TypeName PSObject -Property ([ordered]@{
                            ComputerName = $Computer
                            Build = $net4Release
                            Version = $dotNet4Builds["$net4Release"].Version
                            Comment = $dotNet4Builds["$net4Release"].Comment
                    })
                    if($Version -match '^[4]') 
                    {
                        $netInstalled = $true
                        write-verbose "Its over 4.0 version of .Net"                
                    }
                }
            }
        }
    
        return $netInstalled
    }


    function Set-Recovery{
        param
        (
            [string] [Parameter(Mandatory=$true)] $ServiceDisplayName,
            [string] [Parameter(Mandatory=$true)] $Server,
            [string] $action1 = "restart",
            [int] $time1 =  120000, # in miliseconds
            [string] $action2 = "restart",
            [int] $time2 =  120000, # in miliseconds
            [string] $actionLast = "",
            [int] $timeLast = 120000, # in miliseconds
            [int] $resetCounter = 4000 # in seconds
        )
        $serverPath = "\\" + $server
        $services = Get-CimInstance -ClassName 'Win32_Service' | Where-Object {$_.DisplayName -imatch $ServiceDisplayName}
        $action = $action1+"/"+$time1+"/"+$action2+"/"+$time2+"/"+$actionLast+"/"+$timeLast

        foreach ($service in $services){
            # https://technet.microsoft.com/en-us/library/cc742019.aspx
            $output = sc.exe $serverPath failure $($service.Name) actions= $action reset= $resetCounter
        }
    }


    function Install-Net35
    {
    <#
    .SYNOPSIS
      Installs .Net 3.5 framework
    .DESCRIPTION
      Installs .Net 3.5 framework
    .EXAMPLE
      Install-Net35
    #>
    ( 
        $PSDrive
    )

      try
      {
        # Set defaults during execution 
        $ErrorActionPreference = "continue";
        $oldverbose = $VerbosePreference
        $VerbosePreference = "continue"

        $values = Get-DotNetFrameworkVersion
        $isInstalled = $values[$value.count-1]

        Write-Verbose "Is .NET installed: $isInstalled"

        #$HKLMPath = "HKLM:\SOFTWARE\Microsoft\Net Framework Setup\NDP\v3.5\"

        if([string]::IsNullOrEmpty($PSDrive))
        {
            write-verbose "You must send the PSDrive, exiting"
            ExitWithCode -ISEFlag $ISE -exitcode 8
        }

        if(-not $isInstalled)
        {
          write-Verbose "WARNING: This is an issue, every machine in BSC should have .Net installed";
          Write-Error ".NET is NOT installed on this machine, every machine should have a installed version, exiting badly!"
          ExitWithCode -ISEFlag $ISE -exitcode 18 
          
          <#   Old way to install .Net 3.5 version.....
          $sourcedir = "Q:\Installs\Tools\sxs"
          $localSourcedir = $env:TEMP;
          if (![System.IO.Directory]::Exists($localSourcedir))
          {
            [System.IO.Directory]::CreateDirectory($localSourcedir) | Out-Null
          }
          Write-Verbose "Copying files needed for installation...";
          if (!(Test-Path -Path "$localSourcedir\sxs"))
          {
            write-verbose "Need to copy files...."
            Copy-Item -Path $sourcedir -Recurse -Destination $($localSourcedir + "\") -Container -Force
          }
          else
          {
            write-Verbose "Installer files found. Will proceed with installation of .NET 3.5."
          }

          $installFile = "$env:TEMP\" +  $sourcedir.Split("\")[($sourcedir.Split("\")).Count - 1]
          write-verbose "Install file is [$installFile]"

          #install it
          install-WindowsFeature Net-Framework-Core -source $installFile

          if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path $HKLMPath -ErrorAction Ignore -Name Version).Version)))
          {
            write-Verbose "Installed correctly...."
          }
          else
          {
            write-error "failed to install .Net 3.5";
            ExitWithCode -ISEFlag $ISE -exitcode 19
          }
          #>
        }
      }
      catch
      {
        Write-Error $_.Exception.ToString();
      }
      finally
      {
        # Return defaults at end of execution
        $ErrorActionPreference = "Continue";
        $VerbosePreference = $oldverbose
      }
    }

    function Install-TidalAgent
    {
    <#
    .SYNOPSIS
      Installs Tidal Agent
      Support installation on 64bit OS for:
      Windows 7, Windows 10, and Server 2008 and 2012, 2016
    .DESCRIPTION
      Installs Tidal Agent on Windows servers.
    .EXAMPLE
      Install-TidalAgent
    #>
    ( 
        $PSDrive
    )
      try
      {
        # Set defaults during execution 
        # help https://www.vmware.com/support/vcm/doc/help/vcm-57/Content/Core/CM_GS_Task_Windows_InstallAgentWinMach_Manually_MSI.htm
        #
        $ErrorActionPreference = "continue";
        $oldverbose = $VerbosePreference
        $VerbosePreference = "continue"

        if([string]::IsNullOrEmpty($PSDrive))
        {
            write-verbose "You must send the PSDrive, exiting"
            ExitWithCode -ISEFlag $ISE -exitcode 8
        }
           
        $TidalVer = Get-Service -Name "Tidal*"
        if ($TidalVer -Like '*Tidal*')
        {
          write-Verbose "Tidal is already installed."
        }
        else
        {
          write-Verbose "Beginning install of Tidal on host now...";
          write-Verbose "Checking for Tidal installer on share";

          $sourcedir = "Q:\Installs\Tidal_Agents\TAW_3.3.1.6_32BIT"
          $localSourcedir = $env:TEMP;
          if (![System.IO.Directory]::Exists($localSourcedir))
          {
            [System.IO.Directory]::CreateDirectory($localSourcedir) | Out-Null
          }
          Write-Verbose "Copying files needed for installation...";
          if (!(Test-Path -Path "$localSourcedir\TAW_3.3.1.6_32BIT"))
          {
            #Copy-Item -Path $sourcedir -Destination $($localSourcedir + "\") -Force;
            Copy-Item -Path $sourcedir -Recurse -Destination $($localSourcedir + "\") -Container -Force
            #get the msi file now...
            $sourcedir = $sourcedir + "\TAW_3.3.1.6_32BIT\TWA_Agent.msi"
          }
          else
          {
            write-Verbose "Installer files found. Will proceed with installation of Tidal Agent"
            $sourcedir = $sourcedir + "\TAW_3.3.1.6_32BIT\TWA_Agent.msi"
          }

          $installString = $("/qb /i $env:TEMP\" + $sourcedir.Split("\")[($sourcedir.Split("\")).Count - 2] + "\" + $sourcedir.Split("\")[($sourcedir.Split("\")).Count - 1] + " INSTALLDIR=`"D:\Program Files (x86)\TIDAL`"");
          Write-Verbose "Using args [$installString]"
          Start-Process "msiexec.exe" -ArgumentList $installString -Wait
          #Start-Process "msiexec.exe" -ArgumentList "/qb /i 'C:\Users\ADMMKA~1\AppData\Local\Temp\TAW_3.3.1.6_32BIT\TWA Agent.msi'" -Wait;
          #$HKLMPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*"
          #$boltVer = Get-ItemProperty $HKLMPath | select-object displayname
          #if ($boltVer -Like '*Tidal*')
          $TidalVer = Get-Service -Name "Tidal*"
          if ($TidalVer -Like '*Tidal*')
          {
            Write-Verbose "Installation of Tidal successful.";
            #lets stop the agent if install started it....
            Invoke-Command -ComputerName localhost -ScriptBlock {get-service -name "*Tidal*" | Stop-Service -ErrorAction Ignore} -Credential $Cred
          }
          else
          {
            Write-Error "Failed to install Tidal, exiting!"
            ExitWithCode -ISEFlag $ISE -exitcode 21
          }
        }
      }
      catch
      {
        Write-Error $_.Exception.ToString();
        ExitWithCode -ISEFlag $ISE -exitcode 49
      }
      finally
      {
        # Return defaults at end of execution
        $ErrorActionPreference = "Continue";
        $VerbosePreference = $oldverbose
      }
    }

    function Install-VisualStudioCodeSoftware {
    <#
    .SYNOPSIS
      Installs Visual Studio Code software on Windows servers with the default configuration documented on Grid by Innovation Services team
      https://grid.bsc.bscal.com/display/IAT/How+to+setup+your+Puppet+development+environment. Support installation on Windows 7, Windows 10,
      and Server 2008 and 2012. Has not been tested on Windows server 2016.
    .DESCRIPTION
      Installs Visual Studio Code software on Windows servers.
    .EXAMPLE
      Install-VisualStudioCodeSoftware
    #>
    ( 
        $PSDrive
    )
      try {
        # Set defaults during execution 
        $ErrorActionPreference = "continue";
        $oldverbose = $VerbosePreference
        $VerbosePreference = "continue"
        #$HKLMPath = "HKLM:\SOFTWARE\Microsoft\"
        #$vscVer = Get-ItemProperty $HKLMPath | select-object displayname
        #$HKLMPath = "HKLM:\SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64\"

        if([string]::IsNullOrEmpty($PSDrive))
        {
            write-verbose "You must send the PSDrive, exiting"
            ExitWithCode -ISEFlag $ISE -exitcode 8
        }
        $HKLMPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*"
        $vscVer = Get-ItemProperty $HKLMPath | select-object displayname
        if($vscVer -Like '*Microsoft Visual Studio Code*') {
          write-Verbose "Visual Studio Code is already installed."
        }
        else {
          write-Verbose "Beginning install of Visual Studio Code on host now...";
          write-Verbose "Checking for Visual Studio Code installer on share";

          $sourcedir = "Q:\Installs\Tools\VSCodeSetup-x64-1.40.1.exe"
          $infdir = "Q:\Installs\Tools\vsc.inf"
          $localSourcedir = $env:TEMP;
          if (![System.IO.Directory]::Exists($localSourcedir)) {
            [System.IO.Directory]::CreateDirectory($localSourcedir) | Out-Null
          }
          Write-Verbose "Copying files needed for installation...";
          if (!(Test-Path -Path $localSourcedir\VSCodeSetup-x64-1.40.1.exe) -or !(Test-Path -Path $localSourcedir\vsc.inf)) {
            Copy-Item -Path $sourcedir -Destination $($localSourcedir + "\") -Force;
            Copy-Item -Path $infdir -Destination $($localSourcedir + "\") -Force;
          }
          else {
            write-Verbose "Installer files found. Will proceed with installation of Visual Studio Code."
          }
          $vscInstallstring = "/VerySilent /LOADINF=$localSourcedir\vsc.inf";
          Write-Verbose "VCS Install string [$vscInstallstring] with local directory [$localSourceDir]"
          Start-Process "$localSourcedir\VSCodeSetup-x64-1.40.1.exe" -ArgumentList $vscInstallstring -Wait 
          #Invoke-Command -ComputerName localhost -ScriptBlock { Start-Process "$args[0]\VSCodeSetup-x64-1.40.1.exe" -ArgumentList $args[1]  -Wait;} -ArgumentList $localSourcedir -Credential $Cred 
          $HKLMPath = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*"
          $vscVer = Get-ItemProperty $HKLMPath | select-object displayname
          if($vscVer -Like '*Microsoft Visual Studio Code*') {
            Write-Verbose "Installation of Visual Studio Code successful.";
          }
          else
          {
            Write-Error "Failed to install Visual Studio, exiting!"
            ExitWithCode -ISEFlag $ISE -exitcode 22
          }
        }
      }
      catch {
        Write-Error $_.Exception.ToString();
        ExitWithCode -ISEFlag $ISE -exitcode 39
      }
      finally {
        # Return defaults at end of execution
        $ErrorActionPreference = "Continue";
        $VerbosePreference = $oldverbose
      }
    }

    function set-ServiceUserForTidal {
    <#
    .SYNOPSIS
      Installs the corerct user account for Tidal on the Service
    .DESCRIPTION
      Installs the correct user account for Tidal on the Service 
    .EXAMPLE
      set-ServiceUserForTidal
    #>
    ( 
        $PSDrive
    )
      try {
        $ErrorActionPreference = "continue";
        $oldverbose = $VerbosePreference
        $VerbosePreference = "continue"

        if([string]::IsNullOrEmpty($PSDrive))
        {
            write-verbose "You must send the PSDrive, exiting"
            ExitWithCode -ISEFlag $ISE -exitcode 8
        }
        # 
        $tidalAgent = (get-Service -name Tidal*).Name
        if ($tidalAgent)
        {
            write-Verbose "setting account...."


            <#
                # Prompt the user for the password	
 
	            $ustring = read-host "(Case Sensitive) Please Enter Username"
	            $pstring = read-host "(Case Sensitive) Please Enter User Password"
	            # Encrypt the string and store it into the $encrypted variable
	            $uencrypted = Encrypt-String $ustring "U_MyStrongPassword"
	            $pencrypted = Encrypt-String $pstring "P_MyStrongPassword"
 
	            # Write result to the screen
	            write-host "Encrypted Username is: $uencrypted"
	            write-host ""
	            write-host "Encrypted Password is: $pencrypted"
	            write-host ""
 
	            write-host "Testing Decryption of Username / Password..."
	            write-host ""	
	            # Decrypts the string and stores the decrypted value in $decrypted
	            $udecrypted = Decrypt-String $uencrypted "U_MyStrongPassword"
	            $pdecrypted = Decrypt-String $pencrypted "P_MyStrongPassword"
	
	            # Writes the decrpted value to the screen
	            write-host "Decrypted Password is: $udecrypted"
	            write-host ""
	            write-host "Decrypted Password is: $pdecrypted"
 
             #>

            #lets get the username/password
            $domain = Get-WMIObject Win32_ComputerSystem | Select-Object -ExpandProperty domain
            if ($domain -eq "bsc.bscal.com")
            {
                # just return if in production 
                $ErrorActionPreference = "Continue";
                $VerbosePreference = $oldverbose
                write-Verbose "Skipping setting password for Service Tidal..."
                return
                $usernameline = get-content -Path Q:\Installs\Users\Tidal_prod.txt | Select-String -Pattern USERNAME
                $passwordline = get-content -Path Q:\Installs\Users\Tidal_prod.txt | Select-String -Pattern PASSWORD
            }
            else
            {
                $usernameline = get-content -Path Q:\Installs\Users\Tidal_dev.txt | Select-String -Pattern USERNAME
                $passwordline = get-content -Path Q:\Installs\Users\Tidal_dev.txt | Select-String -Pattern PASSWORD
            }
            #$usernameline = get-content -Path Q:\Installs\Users\Tidal_prod.txt | Select-String -Pattern USERNAME
            #$passwordline = get-content -Path Q:\Installs\Users\Tidal_prod.txt | Select-String -Pattern PASSWORD
            $username = $usernameline.ToString().Substring(9, $usernameline.ToString().length-9)
            $password = $passwordline.ToString().Substring(9, $passwordline.ToString().length-9)

            #$secpasswd = ConvertTo-SecureString "XXXXXXXXXXX" -AsPlainText -Force
            #$mycreds = New-Object System.Management.Automation.PSCredential ("XXXXXXXXXX", $secpasswd)
            $udecrypted = Decrypt-String $username "U_MyStrongPassword"
            $pdecrypted = Decrypt-String $password "P_MyStrongPassword"

            $svc=gwmi win32_service -filter "name='$tidalAgent'"
            $svc.StopService()
            $svc.change($null,$null,$null,$null,$null,$null,$udecrypted,$pdecrypted,$null,$null,$null)
            #$svc.StartService() #MBK we will start it later....

        }
      }
      catch {
        Write-Error $_.Exception.ToString();
        ExitWithCode -ISEFlag $ISE -exitcode 29
      }
      finally {
        # Return defaults at end of execution
        $ErrorActionPreference = "Continue";
        $VerbosePreference = $oldverbose
      }
    }


    function set-firewallRulesForTidal {
    <#
    .SYNOPSIS
      Installs the corerct user account for Tidal on the Service
    .DESCRIPTION
      Installs the correct user account for Tidal on the Service 
    .EXAMPLE
      set-ServiceUserForTidal
    #>
      try {
        $ErrorActionPreference = "continue";
        $oldverbose = $VerbosePreference
        $VerbosePreference = "continue"

        # 
        $tidalAgentIn = (Get-NetFirewallRule -DisplayName *Tidal*Inbound).DisplayName
        $tidalAgentOut = (Get-NetFirewallRule -DisplayName *Tidal*Outbound).DisplayName

        if(!$tidalAgentIn)
        {
            write-verbose "Creating the INBOUND firewall rule..."
            New-NetFirewallRule -DisplayName "Tidal Agent Inbound" -Direction Inbound -Action Allow -Protocol TCP -LocalPort 5912-5916 -Profile Any
        }
        else
        {
            write-verbose "INBOUND firewall rule already exists...."
        }

        if(!$tidalAgentOut)
        {
            write-verbose "Creating the OUTBOUND firewall rule..."
            New-NetFirewallRule -DisplayName "Tidal Agent Outbound" -Direction Outbound -Action Allow -Protocol TCP -RemotePort 5591 -Profile Any
        }
        else
        {
            write-verbose "OUTBOUND firewall rule already exists...."
        }

      }
      catch {
        Write-Error $_.Exception.ToString();
        ExitWithCode -ISEFlag $ISE -exitcode 59
      }
      finally {
        # Return defaults at end of execution
        $ErrorActionPreference = "Continue";
        $VerbosePreference = $oldverbose
      }
    }

    function set-folderAccessTidal {
    <#
    .SYNOPSIS
      Sets File Permissions for tidal directory
    .DESCRIPTION
      Sets File Permissions for tidal directory 
    .EXAMPLE
      set-folderAccess

      check out ---> https://stackoverflow.com/questions/2928738/how-to-grant-permission-to-users-for-a-directory-using-command-line-in-windows?rq=1
    #>
      try {
        $ErrorActionPreference = "continue";
        $oldverbose = $VerbosePreference
        $VerbosePreference = "continue"

        # 
        $Dir = 'D:\Program Files (x86)\Tidal'
        $acl = get-acl $Dir

        $domain = Get-WMIObject Win32_ComputerSystem | Select-Object -ExpandProperty domain
        if ($domain -eq "bsc.bscal.com")
        {
            #$AccessRule1 = New-Object System.Security.AccessControl.FileSystemAccessRule("bsc\svctidal","FullControl","Allow")
            #$AccessRule2 = New-Object System.Security.AccessControl.FileSystemAccessRule("bsc\Tidal_Administrators","FullControl","Allow")
            $Account1 = "bsc\svctidal"
            $Account2 = "bsc\Tidal_Administrators"
        }
        else
        {
            #$AccessRule1 = New-Object System.Security.AccessControl.FileSystemAccessRule("dev\svctidal","FullControl","Allow")
            #$AccessRule2 = New-Object System.Security.AccessControl.FileSystemAccessRule("dev\Tidal_Administrators","FullControl","Allow")
            $Account1 = "dev\svctidal"
            $Account2 = "dev\Tidal_Administrators"
        }


        write-verbose "Setting Folder Permissions for Tidal folder To Accounts [$Account1] and [$Account2]..."

        $InheritanceFlag = [System.Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [System.Security.AccessControl.InheritanceFlags]::ObjectInherit
        $PropagationFlag = [System.Security.AccessControl.PropagationFlags]::None
        $objType = [System.Security.AccessControl.AccessControlType]::Allow 

        $Permission1 = $Account1,"Modify", $InheritanceFlag, $PropagationFlag, $objType
        $Permission2 = $Account2,"Modify", $InheritanceFlag, $PropagationFlag, $objType

        $AccessRule1 = New-Object System.Security.AccessControl.FileSystemAccessRule $permission1
        $AccessRule2 = New-Object System.Security.AccessControl.FileSystemAccessRule $permission2

        $acl.SetAccessRule($AccessRule1)
        $acl.SetAccessRule($AccessRule2)
        #$acl.SetAccessRuleProtection($false, $true)
        $acl | Set-Acl 'D:\Program Files (x86)\Tidal'
        #icacls "D:\Program Files (x86)\Tidal" /grant $Account1 :(OI)(CI)F /T
        #icacls "D:\Program Files (x86)\Tidal" /grant $Account2 :(OI)(CI)F /T

      }
      catch {
        Write-Error $_.Exception.ToString();
        ExitWithCode -ISEFlag $ISE -exitcode 69
      }
      finally {
        # Return defaults at end of execution
        $ErrorActionPreference = "Continue";
        $VerbosePreference = $oldverbose
      }
    }

    #lets get the PSDRIVE
    $domain = Get-WMIObject Win32_ComputerSystem | Select-Object -ExpandProperty domain
    if ($domain -eq "bsc.bscal.com")
    {
        $PSDrive = New-PSDrive -Name Q -PSProvider FileSystem -Root \\winf4595p\D$ -Credential $Cred
    }
    else
    {
        $PSDrive = New-PSDrive -Name Q -PSProvider FileSystem -Root \\winf2286n\D$ -Credential $Cred
    }
    #validate the PSDrive now...
    if(Get-PSDrive -Name Q -ErrorAction Ignore)
    {
        Write-Verbose "Drive is there...."
    }
    else
    {
        Write-Error "PSDrive not found, exiting!"
        ExitWithCode -ISEFlag $ISE -exitcode 10
    }
    #determine if started from within the ISE or command line
    if ($Host.Name -eq "Windows PowerShell ISE Host") {
        $ISE=$true
    } else {
        $ISE=$false
    }

    #lets validate .Net 3.5 is installed otherwise install it
    Install-Net35 -PSDrive $PSDrive

    
    #Lets Install VisualStudio  #MBK Not needed for Tidal
    #Install-VisualStudioCodeSoftware -PSDrive $PSDrive

    #lets Install Tidal
    Install-TidalAgent -PSDrive $PSDrive

    #set correct account for service 
    set-ServiceUserForTidal -PSDrive $PSDrive

    #lets set the recovery of the service for Tidal
    Set-Recovery -ServiceDisplayName "TIDAL_AGENT_1" -Server "localhost"

    $sourcedir = "Q:\Tidal_Agents\TAW_3.3.1.6_32BIT\TIDAL_JL3_64-bit_OS.reg"
    Invoke-Command {reg import $sourcedir *>&1 | Out-Null}

    #update the tagent.ini
    Set-Content -Path 'D:\Program Files (x86)\TIDAL\Agent\Bin\tagent.ini' -Value "[config]`r`nSSLVLDCRT=N`r`nSFTPUMASK=002`r`nDEBUG=Y`r`nFILELOCKCHECK=Y`r`n`r`n[TIDAL_AGENT_1]`r`n"

    #set the firewall rules
    set-firewallRulesForTidal

    #set the folder access for Tidal
    set-folderAccessTidal

    $ErrorActionPreference = "continue";
    $oldverbose = $VerbosePreference
    $VerbosePreference = "continue"

    #start the Tidal Agent
    Write-Verbose "Starting the Tidal Agent..."
    #get-service -name *Tidal* | start-service
    Invoke-Command -ComputerName localhost -ScriptBlock {get-service -name "*Tidal*" | Start-Service -ErrorAction Ignore} -Credential $Cred

    
    #remove mapped drive
    Remove-PSDrive -Name Q


    Write-Verbose "All done...."

    return 0

} #end installTidal function