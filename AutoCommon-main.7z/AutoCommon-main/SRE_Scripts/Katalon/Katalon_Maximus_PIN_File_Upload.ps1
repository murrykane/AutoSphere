﻿cd \
&"D:\Software\KatalonRuntimeEngine\katalonc.exe" -noSplash -runMode=console --config -webui.autoUpdateDrivers=true -projectPath="D:\Katalon Projects\Provider Information Network (PIN) File Automation\Provider Information Network (PIN) File Automation.prj" -retry=0 -testSuitePath="Test Suites/PIN File Upload" -executionProfile="default" -browserType="Chrome" -apiKey="84ba61c6-7c73-43bd-9055-f91938613c8d"
if( $LASTEXITCODE -eq 0 ) {
	Write-Output "Command executed successfully"
	# do something, like `Restart-Computer -Force`
} else {
	Write-Output "Last command failed"
    throw "Failed the Katalon process"
}


#exit good
[Environment]::Exit(0)