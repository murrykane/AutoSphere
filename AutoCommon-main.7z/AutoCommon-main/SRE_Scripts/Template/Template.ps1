﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	07/26/2019
	 Updated on:	07/26/2019
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	Template.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server, WINF313P or WINF4028p. 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script is a template for building any other script, it has the base setup that
        should be common to all scripts.


Date:      Who:            Changes:
-----------------------------------
01/08/2019 Murry Kane      Initial
04/07/2021 Murry Kane      Added check for error_code > 0 before hard-coding to 99
                           Added generic function for CMDB data retrieval for application to server

    Example

    ./{Directory}\Template.ps1 -Environment FACN52 
#>

[CmdletBinding()]
Param(
  #[Parameter(Mandatory=$True,Position=1)]
   [string[]]$Environment,
   [Parameter(Mandatory=$False, Position=2)][switch]$uselocaldomain
	
)

#Function to get CMDB data for mapping servers to applications for a given environment
function Get-ServerList {
    try {

        #lets see if we we are going against production or 2015 CMDB
        $SnowCred = ''
        $UriBase = ''

        if(-not $uselocaldomain)
        {
            $SNowCred = Get-ServiceNowCredential
            $UriBase = Get-ServiceNowUriBase
        }
        else
        {
            Write-Host "-UseLocalDomain option passed to script, using local domain to determine which ServiceNow Instance to connect with"
            $SNowCred = Get-ServiceNowCredential -uselocaldomain
            $UriBase = Get-ServiceNowUriBase -uselocaldomain                
        }

        if([string]::IsNullOrWhiteSpace($SNowCred) -or [string]::IsNullOrWhiteSpace($UriBase))
        {
            $exit_code = 4
            Write-Warning "We could not get credentials to make the REST call to ServiceNow" 
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }
        else
        {
            Write-Host "URI Base $UriBase"
        }

        # Query Server to App Relationship Table
        Write-Host "Querying ServiceNow API for getting the application server(s)"
        $Uri = "$UriBase/api/now/table/cmdb_rel_ci?sysparm_query=parent.nameSTARTSWITH$($CMDBEnvironment)Facets%20HIPAA%20Gateway%5EORparent.nameSTARTSWITH$($CMDBEnvironment)Facets%20ISL%5Eparent.install_statusIN11%5Echild.install_statusIN11%5Etype.nameSTARTSWITHRuns%20On%3A%3ARuns%5Echild.nameSTARTSWITHFacets%20App%20Server%5EORchild.nameSTARTSWITHFacets%20Interactive%5Echild.sys_class_name%3Dcmdb_ci_app_server&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=child&sysparm_limit=1000"

        Write-Host "Using URI [$Uri]"

        $Result = Query-ServiceNowApi -Uri $Uri -SNowCred $SNowCred

        Write-Host "Result is " + $result   
        $Servers = $result | ForEach-Object { (($_).child -split "@")[1] } | select -Unique

        return $Servers
    }
    catch {
        return $null
    }
}

try
{
    # Set some basic variables
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    
    # Import functions
    Import-Module SRE-Functions -Force -WarningAction SilentlyContinue

    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning "Error: SRE Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }


    # Modify Input parameters as needed...
    if ($ISE) {
        # get the required input if not supplied when running from ISE
        if(-not($Environment)) {
            $Environment = @()
            do 
            {
                $input = (Read-Host "Input your Environment (FACP02, FACN32, FACN31): ")
                if ($input -ne '') {$Environment += $input}
            }
            until ($input -eq '')
        }
    }

    #validate inputs
    if (-not($Environment)) 
    {
        $exit_code = 32
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }


    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "SRE HOME Directory is $SRE_HOME"
    Write-Host "Script name is: $currentScriptName"
    Write-Host "ISE is [$ISE]"
    Write-Host "Environment is [$Environment]"


    #ALL the main code should go below here 
    #######################################

    #end main code#########################


}
catch
{
    Write-Warning $_.Exception.ToString();
    if($exit_code -lt 1 )
    {
        $exit_code = 99
    }
}

finally
{

    #cleanup
    Remove-Module -Name SRE-Functions

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}