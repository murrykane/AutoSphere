﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	04/07/2021
	 Updated on:	04/07/2021
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	BPH_Finance_fileExtract.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server, WINF313P or WINF4028p. 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script is a template for building any other script, it has the base setup that
        should be common to all scripts.


Date:      Who:            Changes:
-----------------------------------
04/07/2021 Murry Kane      Initial


    Example

    ./{Directory}\BHP_Finance_fileExtract.ps1
#>

[CmdletBinding()]
Param(	
)

try
{
    # Set some basic variables
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    
    # Import functions
    Import-Module SRE-Functions -Force -WarningAction SilentlyContinue

    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning "Error: SRE Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }


    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "SRE HOME Directory is $SRE_HOME"
    Write-Host "Script name is: $currentScriptName"


    #ALL the main code should go below here 
    #######################################
    $7ZipPath = '"C:\Program Files\7-Zip\7z.exe"'
    $zipFile = '"c:\junk\Junk.zip"'
    $zipFilePassword = "thepass"
    $command = "& $7ZipPath e -oc:\junk\test -y -tzip -p$zipFilePassword $zipFile"
    #end main code#########################
    Invoke-Expression $command

}
catch
{
    Write-Warning $_.Exception.ToString();
    if($exit_code -lt 1 )
    {
        $exit_code = 99
    }
}

finally
{

    #cleanup
    Remove-Module -Name SRE-Functions

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}