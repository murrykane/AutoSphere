﻿
function WaitForHewProcessToComplete($HewFileProcessingDir) {
    try {
        # Wait for completion
        $MaxWaitTime = 60
        $CurrWait = 0
        $FilesToWaitFor = @("COB 270 5010 Output.txt","hew.log")

        foreach ($File in $FilesToWaitFor) {
            $FilePath = "$HewFileProcessingDir\$File"
            $Found = $false
            Write-Host "Searching for required file [$FilePath]"
            while ($CurrWait -lt $MaxWaitTime) {
                Start-Sleep -Seconds 1

                if (Test-Path $FilePath) {
                    Write-Host "Success"
                    $Found = $true
                    break
                }
                $CurrWait = $CurrWait + 1
            }
            if ($CurrWait -ge $MaxWaitTime) {
                Write-Warning "ERROR: Unable to find required file [$FilePath]"
                return $false
            }
        }
        return $true
    }
    catch {
        Write-Warning $_.Exception.ToString()
        return $false
    }
}



# Set Vars
$HewExeDir = "C:\Program Files (x86)\GDIT\HEW"
$HewFileProcessingDir = "C:\Users\kparro01\AppData\Local\GDIT\HEW"




# Run HEW Command for 270 File (Requires naming convention of : 'COB 270 Input.txt')
& "$HewExeDir\HEW.exe" -on

# Wait for completion
$Success = WaitForHewProcessToComplete -HewFileProcessingDir $HewFileProcessingDir
if (-not $Success) {
    Write-Error "EXIT"
}

# Check for Errors
$Log = Get-Content -Path "$HewFileProcessingDir\hew.log" | Out-String

if ($Log -match "Error") {
    $ErrStart = $Log.IndexOf("Error")
    $ErrMsg = $Log.Substring($ErrStart,$Log.Length - $ErrStart)
    Write-Warning "The following error occurred while processing the file:`n$ErrMsg"
}

# Rename Files
$TimeStamp = $(get-date -format s | foreach {$_ -replace ":", "-"})
#$FilesToRename = @("COB 270 Input.txt","COB 270 5010 Output.txt","hew.log")
$FilesToRename = @("COB 270 5010 Output.txt","hew.log")
foreach ($File in $FilesToRename) {
    $OldName = "$HewFileProcessingDir\$File"
    $NewFile = "$TimeStamp_$File"
    Rename-Item -Path "$OldName" -NewName $NewFile
}


# Archive Files
$TimeStamp = $(get-date -format s | foreach {$_ -replace ":", "-"})
$FilesToArchive = @("COB 270 5010 Output.txt","hew.log")





# Move Output File to Outbound Location

