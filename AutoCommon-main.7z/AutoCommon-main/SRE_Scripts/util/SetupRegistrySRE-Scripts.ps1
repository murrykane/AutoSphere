﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	07/30/2019
	 Updated on:	07/30/2019
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	SetupRegistrySRE-Scripts.ps1

	The scripts being built in this grouping are for SRE Production Support
	The majority will be run from the Primary SRE Servers. However,
	it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script will create or modify Registry entries for use of other scripts. Mainly to setup
        the log directory and SRE home paths. As well as setting a kill switch for self-healing.

MODIFICATIONS
_____________________________________________________________________________________________________________________________
    Date       By            Reason
    07/30/2019 Murry Kane    Initial
    08/05/2019 Murry Kane    Remoted all exitwithcode calls as this program is ran before that is setup on a server
_____________________________________________________________________________________________________________________________
    Example


    ./{PATH}\SetupRegistrySRE-Scripts.ps1
#>

[CmdletBinding()]
Param(
  #[Parameter(Mandatory=$True,Position=1)]
   [string]$SRE_LOGS,
   [string]$SRE_HOME,
   [string]$SRE_Automation_Enabled,
   [string[]]$PSModulePathEntries
	
)

$exit_code = 0
$LOG_DIR_DEFAULT='D:\apps\logs'
$SRE_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\SRE_Scripts'
$SRE_Automation_Enabled_DEFAULT='Enabled'
$PSModulePathEntries_DEFAULT= ';' + $SRE_HOME_DIR_DEFAULT + '\modules\'
$currentScriptName = $MyInvocation.MyCommand.Name
$filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
$HKLM_BSC_Auto = 'hklm:\software\BSC_Automation'
$HKLM_Env = 'hklm:\system\currentcontrolset\control\session manager\environment'



Function Test-RegistryValue($regkey, $name) {
    $exists = Get-ItemProperty -Path "$regkey" -Name "$name" -ErrorAction SilentlyContinue
    If (($exists -ne $null) -and ($exists.Length -ne 0)) {
        Return $true
    }
    Return $false
}


# Gets the specified registry value or $null if it is missing
function Get-RegistryValue($path, $name)
{
    $key = Get-Item -LiteralPath $path -ErrorAction SilentlyContinue
    if ($key) {
        $key.GetValue($name, $null)
    }
}

Try
{


    if ($Host.Name -eq "Windows PowerShell ISE Host") {
        $ISE=$true
    } else {
        $ISE=$false
    }
    if ($ISE) {
        # get the required input
        if(-not($SRE_LOGS)) {
            $SRE_LOGS = Read-Host "Provide the LOG_DIR for SRE scripts (Press enter to accept the default [$($LOG_DIR_DEFAULT)])"
            $SRE_LOGS = ($LOG_DIR_DEFAULT,$SRE_LOGS)[[bool]$SRE_LOGS]
        }
        if(-not($SRE_HOME)) {
            $SRE_HOME = Read-Host "Provide the SRE_HOME for SRE home path(Press enter to accept the default [$($SRE_HOME_DIR_DEFAULT)])"
            $SRE_HOME = ($SRE_HOME_DIR_DEFAULT,$SRE_HOME)[[bool]$SRE_HOME]
        } 
        if(-not($SRE_Automation_Enabled)) {
            $SRE_Automation_Enabled = Read-Host "Provide the SRE_Automation_Enabled for scripts (Press enter to accept the default [$($SRE_Automation_Enabled_DEFAULT)])"
            $SRE_Automation_Enabled = ($SRE_Automation_Enabled_DEFAULT,$SRE_Automation_Enabled)[[bool]$SRE_Automation_Enabled]
        }
        if(-not($PSModulePathEntries)) {
            $PSModulePathEntries = Read-Host "Provide the PSModulePath entries to be added(Press enter to accept the default [$($PSModulePathEntries_DEFAULT)])"
            $PSModulePathEntries = ($PSModulePathEntries_DEFAULT,$PSModulePathEntries)[[bool]$PSModulePathEntries]
        }
    }

    if (-not($SRE_LOGS)) 
    {
        $exit_code = 32
        #Write-Error "LOG_DIR is required, exiting!"
        Throw "LOG_DIR is required, exiting!"
        #ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    if (-not($SRE_HOME))
    {
        $exit_code = 33
        Throw "SRE_HOME is required, exiting!"
        #ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    if (-not($SRE_Automation_Enabled))
    {
        $exit_code = 33
        Throw "SRE_Automation_Enabled is required, exiting!"
        #ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    if (-not($PSModulePathEntries))
    {
        $exit_code = 34
        Throw "PSModulePathEntries is required, exiting!"
        #ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    $testDir = Test-path -Path 'hklm:\software\BSC_Automation' -ErrorAction silentlycontinue
    if ($testDir)
    {
        write-host "BSC_Automation Exists...."       
    }
    else
    {
        write-host "Creating BSC_Automation Registry value"
        New-Item -Path 'HKLM:\Software\' -Name 'BSC_Automation' -ErrorAction Stop
    }

    # Test existing value
    #Test-RegistryValue $HKLM_BSC_Auto 'sre_home'
    $val = Get-RegistryValue $HKLM_BSC_Auto 'sre_home'
    if ($val -eq $null) 
    { 
        write-host "SRE_HOME is missing value, creating the key..."
        New-ItemProperty -Path 'HKLM:\Software\BSC_Automation' -Name 'sre_home' -Value $SRE_HOME -ErrorAction Stop
    } 
    else 
    { 
        if ( $val -eq $SRE_HOME )
        {
            #write-host "they are the same...."
            Write-Host "SRE_HOME is [$val] which is the same as requested [$SRE_HOME]"
        }
        else
        {
            write-host "Difference's found [$val] with requested value [$SRE_HOME], setting it now..."
            Set-ItemProperty -Path $HKLM_BSC_Auto -Name 'sre_home' -Value $SRE_HOME
        }
        
    }

    # Test existing value
    #Test-RegistryValue $HKLM_BSC_Auto 'sre_logs'
    $val = Get-RegistryValue $HKLM_BSC_Auto 'sre_logs'
    if ($val -eq $null) 
    { 
        write-host "SRE_LOGS is missing value, creating the key..."
        New-ItemProperty -Path 'HKLM:\Software\BSC_Automation' -Name 'sre_logs' -Value $SRE_LOGS -ErrorAction Stop
    } 
    else 
    { 
        if ( $val -eq $SRE_LOGS )
        {
            #write-host "they are the same...."
            Write-Host "SRE_LOGS is [$val] which is the same as requested [$SRE_LOGS]"
        }
        else
        {
            write-host "Difference's found [$val] with requested value [$SRE_LOGS], setting it now..."
            Set-ItemProperty -Path $HKLM_BSC_Auto -Name 'sre_logs' -Value $SRE_LOGS
        }
        
    }

    #lets now make sure the path exists elese create it
    If(!(test-path $SRE_LOGS))
    {
          New-Item -ItemType Directory -Force -Path $SRE_LOGS
    }

    $val = Get-RegistryValue $HKLM_BSC_Auto 'sre_automation_enabled'
    if ($val -eq $null) 
    { 
        write-host "SRE_Automation_Enabled is missing value, creating the key..."
        New-ItemProperty -Path 'HKLM:\Software\BSC_Automation' -Name 'sre_automation_enabled' -Value $SRE_Automation_Enabled -ErrorAction Stop
    } 
    else 
    { 
        if ( $val -eq $SRE_Automation_Enabled )
        {
            #write-host "they are the same...."
            Write-Host "SRE_Automation_Enabled is [$val] which is the same as requested [$SRE_Automation_Enabled]"
        }
        else
        {
            write-host "Difference's found [$val] with requested value [$SRE_Automation_Enabled], setting it now..."
            Set-ItemProperty -Path $HKLM_BSC_Auto -Name 'sre_automation_enabled' -Value $SRE_Automation_Enabled
        }
        
    }

    $val = Get-RegistryValue $HKLM_Env 'PSModulePath'
    if ($val -eq $null) 
    { 
        write-host "This should be defined! for PSModulePath...."
    } 
    else 
    { 
        if ( $val -like "*" + $PSModulePathEntries + "*")
        {
            #write-host "they are the same...."
            Write-Host "PSModulePath contains [$PSModulePathEntries]"
        }
        else
        {
            write-host "Missing entries [$PSModulePathEntries] in [$val], setting it now..."
            #$SetValues = $val + ";" + $PSModulePathEntries
            #Set-ItemProperty -Path $HKLM_Env -Name 'PSModulePath' -Value $SetValues
            [Environment]::SetEnvironmentVariable("PSModulePath", $Val + $PSModulePathEntries, "Machine")
        }
        
    }

}
catch
{
    Write-Error $_.Exception.ToString();
    $exit_code = 99
}

finally
{

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"

    #ExitWithCode -exitcode $exit_code -ISEFlag $ISE

}


