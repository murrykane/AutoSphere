﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	03/03/2020
	 Updated on:	03/03/2020
	 Created by:   	Jupp Valdez
	 Organization: 	Blue Shield of California
	 Filename:     	FileCleanup.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server, WINF313P or WINF4028p. 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
        IOS-143
        Story: NAS diskspace filled up usually is caused by the QA / Dev teams who are either lacking of technical knowledge or 
        who are just having a bad habit by ignoring the advices or no one would like to take on the responsibility to clean up the files 
        after testing are completed. Whenever a diskspace is filling up, not a single job would be able to run for that entire
        environment, as a result, onshore and offshore resources would be sitting idle entire day and we would lose time and money 
        because nothing is moving and miss the project deadline.

		Intent of this script: This script deletes files and folders that are more than a month old.


Date:      Who:            Changes:
-----------------------------------
03/03/2020 Jupp Valdez     Initial

    Example

    ./{Directory}\FileCleanup.ps1
#>

[CmdletBinding()]
Param(
    [Parameter(Position=0)]
    [ValidateScript({ Test-Path -Path $_ -PathType Container })]
    <#[ValidatePattern('^D:\\')] #>
    [string]$path = '\\dev\facn51\Core\Facets\RIS\Logfiles',
    [Parameter(Position=1)]
    [string]$Days = 30
	
)

try
{
    # Set some basic variables
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)

    $CurrentTime = Get-Date
    $RangeTime = (Get-Date).AddDays(-$Days)
    
    # Import functions
    Import-Module SRE-Functions -Force -WarningAction SilentlyContinue

    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning "Error: SRE Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }


    # Modify Input parameters as needed...


    #validate inputs


    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "SRE HOME Directory is $SRE_HOME"
    Write-Host "Script name is: $currentScriptName"
    Write-Host "ISE is [$ISE]"

    #ALL the main code should go below here 
    #######################################
    Get-ChildItem -Path $path -File | Where-Object { $_.LastWriteTime -lt $RangeTime } | Remove-Item -Force -Verbose
    #Get-ChildItem -Path $path -Recurse -Force -Directory | Sort-Object -Descending FullName | Where-Object { $_.PSIsContainer -and @(Get-ChildItem -LiteralPath:$_.fullname).Count -eq 0 } | Remove-Item -ErrorAction SilentlyContinue -WarningAction SilentlyContinue -InformationAction SilentlyContinue -Verbose
    $i = 0
    $dirs = Get-ChildItem -Path $path -Directory | Select -Property FullName
    foreach($dir in $dirs) {
        if($i %100 -eq 0) {
            [system.gc]::Collect()
            Sleep -Milliseconds 500
        }
        Get-ChildItem $dir.FullName -Recurse -Force -File | Where-Object { $_.LastWriteTime -lt $RangeTime } | Remove-Item -Force -Verbose
        Get-ChildItem $dir.FullName -Recurse -Force -Directory | Sort-Object -Descending Fullname | Where-Object { @(Get-ChildItem -LiteralPath:$_.fullname).Count -eq 0 } | Remove-Item -ErrorAction SilentlyContinue -WarningAction SilentlyContinue -InformationAction SilentlyContinue -Verbose
        
        if(@(Get-ChildItem -LiteralPath:$dir.FullName).Count -eq 0) {
            Remove-Item $dir.FullName -Force -ErrorAction SilentlyContinue -WarningAction SilentlyContinue -InformationAction SilentlyContinue -Verbose
        }
        $i++
    } 
    #Get-ChildItem -Path $path -Depth 0 -Directory | Where-Object { @(Get-ChildItem -LiteralPath:$_.fullname).Count -eq 0 } | Remove-Item -ErrorAction SilentlyContinue -WarningAction SilentlyContinue -InformationAction SilentlyContinue -Verbose

    #end main code#########################


}
catch
{
    Write-Warning $_.Exception.ToString();
    $exit_code = 99
}

finally
{

    #cleanup
    Remove-Module -Name SRE-Functions

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}