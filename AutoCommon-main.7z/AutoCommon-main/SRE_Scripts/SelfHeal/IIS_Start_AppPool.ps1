﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	09/16/2021
	 Updated on:	09/16/2021
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	IIS_Start_AppPool.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server for SRE team. 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script attempts to start Application Pools for a given Application for IIS


Date:      Who:            Changes:
-----------------------------------
09/16/2021 Murry Kane        Initial


    Example

    ./{Directory}\IIS_Start_AppPool.ps1 -Server winf2286n -Cred <PSCredential>
#>

[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true,Position=0)]
    [string]$Server,
    [Parameter(Mandatory=$true,Position=1)]
    [System.Management.Automation.PSCredential]$Cred
    )

function Ping-WinServer($Server) {
    try {
        $TestCnt = 1
        $SleepTime = 60
    
        while (-not (Test-Connection -ComputerName $Server -Quiet)) {
    
            if ($TestCnt -gt 7) {
                Write-Warning "ERROR: Test Connection for server [$Server] failed [$TestCnt] times. Exiting!"
                return 186
            }

            Write-Warning "Test Connection for server [$Server] failed attempt [$TestCnt]... sleeping $SleepTime seconds"
            Start-Sleep -Seconds $SleepTime
    
            $TestCnt += 1
        }

        Write-Host "Test connection for server [$Server] succeeded for attempt [$TestCnt]"

        if ($TestCnt -gt 1) {
            Write-Host "Sleeping 1 more time to allow server to fully come up"
            Start-Sleep -Seconds $SleepTime
        }

        return 0
    }
    catch {
        Write-Warning $_.Exception.ToString();
        return 61
    }
}

function start-AppPool() {
    #// use this --> https://stackoverflow.com/questions/36599456/how-to-start-and-stop-application-pool-in-iis-using-powershell-script
    #// Get-IISAppPool:
    #

    try {

        (Get-IISAppPool).Name | ForEach-Object -Process {
            if((Get-WebAppPoolState -Name $_).Value -ne 'Started'){
                Write-Host ('Starting Application Pool: {0}' -f $_)
                Start-WebAppPool -Name $_        
            }
            else
            {
                Write-Host ('Application Pool [{0}] is already running' -f $_)
            }
        }
        return 0
    }
    catch {
        Write-Host "Unexpected Error:`n$($_.Exception.ToString())"
        return 50
    }
}

try
{
    # Set some basic variables
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    
    # Import functions
    Import-Module SRE-Functions -Force -WarningAction SilentlyContinue

    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning "Error: SRE Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }


    # Modify Input parameters as needed...
    if ($ISE) {
        # get the required input if not supplied when running from ISE
        if(-not($Server)) {
            do
            {
                $Server = (Read-Host "Input the server name (ex: winf2286n): ")
            }
            until ($Server -ne '')
        }
        if(-not($Cred)) {
            do
            {
                $Cred = Get-Credential -ErrorAction SilentlyContinue
            }
            until ($Cred -ne '')
        }
    }

    # Validate inputs
    if (-not $Server)
    {
        $exit_code = 30
        Write-Warning "Server is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    if (-not $Cred)
    {
        $exit_code = 35
        Write-Warning "Credential is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "SRE HOME Directory is $SRE_HOME"
    Write-Host "Script name is: $currentScriptName"
    Write-Host "ISE is [$ISE]"
    Write-Host "Server is [$Server]"
    Write-Host "Username is [$($Cred.UserName)]"


    #ALL the main code should go below here 
    #######################################

    Write-Host "Attempting to restart IIS Application Pool"

    $exit_code = Ping-WinServer -Server $Server

    if ($exit_code -ne 0) {
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    
    # First try to restart the agent using os-agent.bat
    $Session = New-PSSession -ComputerName $Server -Cred $Cred
    $exit_code = Invoke-Command -Session $Session -ScriptBlock ${function:start-AppPool}
 
    #end main code#########################

}
catch
{
    Write-Warning $_.Exception.ToString();
    if($exit_code -lt 1 )
    {
        $exit_code = 99
    }

}

finally
{
    #cleanup
    Remove-Module -Name SRE-Functions
    Remove-PSSession -Session $Session -ErrorAction SilentlyContinue

    Write-Host "All done with: $currentScriptName"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}