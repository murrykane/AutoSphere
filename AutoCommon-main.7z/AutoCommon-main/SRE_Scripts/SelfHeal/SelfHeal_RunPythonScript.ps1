﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	09/06/2019
	 Updated on:	09/06/2019
	 Created by:   	Kyle Parrott
	 Organization: 	Blue Shield of California
	 Filename:     	SelfHeal_RunPythonScript.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server, WINF313P or WINF4028p. 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script run a python script on a server using the credentials provided.


Date:      Who:            Changes:
-----------------------------------
09/06/2019 Kyle Parrott    Initial
06/02/2021 Murry Kane      Need a way to get the default password for svcsre if no CRED is passed in, to use for Tidal Jobs

    Example

    ./{Directory}\SelfHeal_RunPythonScript.ps1 -Server localhost -PythonScript HelloWorld.py -PythonVersion "3" -Cred {credential}
    ./{Directory}\SelfHeal_RunPythonScript.ps1 -Server localhost -PythonScript HelloWorld.py -PythonVersion "2" -PythonArgs "Arg1 Arg2 Arg3" -Cred {credential}
#>

[CmdletBinding()]
Param(
    [Parameter(Position=0)]
    [string]$Server,
    [Parameter(Position=1)]
    [string]$PythonScript,
    [Parameter(Position=2)]
    [string]$PythonArgs = $null,
    [Parameter(Position=3)]
    [ValidateSet("2","3")]
    [string]$PythonVersion = "2",
    [Parameter(Position=4)]
    [System.Management.Automation.PSCredential]$Cred
)

try
{
    # Set some basic variables
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    
    # Import functions
    Import-Module SRE-Functions -Force -WarningAction Ignore

    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(Get-Date -Format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning "Error: SRE Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Modify Input parameters as needed....
    if ($ISE) 
    {
        # Get the required input if not supplied when running from ISE
        if(-not($Server)) 
        {
            do
            {
                $Server = (Read-Host "Input your Server (wapp4059p, etc): ")
            }
            until ($Server -ne '')
        }
        if(-not($PythonScript)) 
        {
            do 
            {
                $PythonScript = (Read-Host "Input your Python Script Name: ")
            }
            until ($PythonScript -ne '')
        }
        <#
        if(-not($Cred)) 
        {
            do
            {
                $Cred = Get-Credential
            }
            until ($Cred -ne '')
        }
        #>
    }


    # Validate inputs
    if (-not $Server)
    {
        $exit_code = 31
        Write-Warning "Server is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    if (-not $PythonScript)
    {
        $exit_code = 32
        Write-Warning "Python Script is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    if (-not $Cred)
    {
        #$exit_code = 33
        #Write-Warning "Credential is required, exiting!"
        #ExitWithCode -exitcode $exit_code -ISEFlag $ISE
        #MBK lets get the needed credential...

        $domain = Get-WMIObject Win32_ComputerSystem | Select-Object -ExpandProperty domain
        if ($domain -eq "bsc.bscal.com")
        {
            if(Test-Path -Path d:\Installs\Users\AD-svcsre_prod.txt)
            {
                $usernameline = get-content -Path D:\Installs\Users\AD-svcsre_prod.txt | Select-String -Pattern USERNAME 
                $passwordline = get-content -Path D:\Installs\Users\AD-svcsre_prod.txt | Select-String -Pattern PASSWORD
            }
            else
            {
                $exit_code = 33
                Write-Warning "Credential is required and file not found to retrieve it, exiting!"
                ExitWithCode -exitcode $exit_code -ISEFlag $ISE               
            }
        }
        else
        {
            if(Test-Path -Path d:\Installs\Users\AD-svcsre_dev.txt)
            {
                $usernameline = get-content -Path D:\Installs\Users\AD-svcsre_dev.txt | Select-String -Pattern USERNAME
                $passwordline = get-content -Path D:\Installs\Users\AD-svcsre_dev.txt | Select-String -Pattern PASSWORD  
            }
            else
            {
                $exit_code = 33
                Write-Warning "Credential is required and file not found to retrieve it, exiting!"
                ExitWithCode -exitcode $exit_code -ISEFlag $ISE  
            }
        }


        $username = $usernameline.ToString().Substring(9, $usernameline.ToString().length-9)
        $password = $passwordline.ToString().Substring(9, $passwordline.ToString().length-9)
        $udecrypted = Decrypt-String "$username" "U_MyStrongPassword"
        $pdecrypted = Decrypt-String "$password" "P_MyStrongPassword"
        $ThePass = ConvertTo-SecureString –String $pdecrypted –AsPlainText -Force
        $Cred = New-Object –TypeName System.Management.Automation.PSCredential –ArgumentList $udecrypted, $ThePass

    }

    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "SRE HOME Directory is $SRE_HOME"
    Write-Host "Script name is: $currentScriptName"
    Write-Host "ISE is [$ISE]"
    Write-Host "Server is [$Server]"
    Write-Host "Python Script is [$PythonScript]"
    Write-Host "Python Args are [$PythonArgs]"
    Write-Host "Username is [$($Cred.UserName)]"

     
    # Validate server exists
    $EC1 = isValidServer($Server)

    if ($EC1 -ne 0)
    {
        $exit_code = $EC1
        Write-Warning "Invalid server [$Server]. Exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    
    # ----------------------- Main -----------------------

    # Let's validate we are not trying to cross domains (NPE to PROD or vise-versa)
    $EC2 = validateDomain -Server $Server -RunOnLocalHost

    if ($EC2 -ne 0)
    {
        $exit_code = $EC2
        Write-Warning "Cannot start service across domains. Exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    
    # Now that the validations are complete, let's run the python script
    Write-Host "Attempting to run [$PythonScript] on server [$Server]"
   

    # Set up PS Session
    $Session = New-PSSession -ComputerName $Server -Credential $Cred -Verbose

    # Let's validate the Python script exists and automation is enabled on remote server
    $ReasonToExit, $PythonScriptPath = Invoke-Command -Session $Session -ScriptBlock ${function::ValidateRemotePythonSession} -ArgumentList $PythonScript

    if ($ReasonToExit -ne $null)
    {
        $exit_code = 40
        Write-Warning $ReasonToExit
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Let's validate that the correct version of Python is installed on the server
    Write-Host "Searching for Python $PythonVersion executable on server [$Server]."
    $ReasonToExit, $PythonExe = Invoke-Command -Session $Session -ScriptBlock ${function:Get-PythonExecutablePath} -ArgumentList $PythonVersion
    
    if ($ReasonToExit -ne $null)
    {
        $exit_code = 41
        Write-Warning $ReasonToExit
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Run Python Script
    Write-Host "Running Python Script with command [$PythonExe '$PythonScriptPath' $PythonArgs]"
    $Job = Invoke-Command -Session $Session -ScriptBlock { Invoke-Expression -Command "$Using:PythonExe '$Using:PythonScriptPath' $Using:PythonArgs" } -AsJob

    # Get Output of Python Script
    $LogOutput = Get-PythonLogOutput -Job $Job

    # Get Python Exit Code
    $PythonExitCode = Invoke-Command -Session $Session -ScriptBlock { return $LASTEXITCODE }
    Write-Host "Python Exit Code: [$PythonExitCode]"
    
    # Remove the PSSession
    $Session | Remove-PSSession -ErrorAction SilentlyContinue

    
    # Verify Python Script Executed Successfully
    if ($PythonExitCode -eq $null)
    {
        $exit_code = 51
        Write-Warning "Error: Python Exit code returned NULL... Exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    elseif ($PythonExitCode -ne 0) 
    {
        $exit_code = $PythonExitCode
        Write-Warning "Error: Failure while running Python Script [$PythonScript]... Exit Code = $PythonExitCode"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    else
    {
        Write-Host "All good on job. [$PythonScript] successfully ran on server [$Server]"
    }

    # --------------------- End Main ---------------------

}
catch
{
    Write-Warning $_.Exception.ToString();
    $exit_code = 99
}

finally
{
    # Cleanup
    Remove-Module -Name SRE-Functions

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}

