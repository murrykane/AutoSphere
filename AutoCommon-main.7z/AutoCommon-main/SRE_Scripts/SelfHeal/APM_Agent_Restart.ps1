﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	05/04/2020
	 Updated on:	05/04/2020
	 Created by:   	Kyle Parrott
	 Organization: 	Blue Shield of California
	 Filename:     	APM_Agent_Restart.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server, WINF313P or WINF4028p. 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script attempts to start the APM agent on a remote Windows server.


Date:      Who:            Changes:
-----------------------------------
05/04/2020 Kyle Parrott      Initial
05/26/2020 Kyle Parrott      Added Ping-WinServer
6/25/2020  Kyle Parrott      Added Force stop w/ service
10/04/2021 Hung Ly           Added sleep after ping tests from fail to success

    Example

    ./{Directory}\APM_Agent_Restart.ps1 -Server winf2286n -Cred <PSCredential>
#>

[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true,Position=0)]
    [string]$Server,
    [Parameter(Mandatory=$true,Position=1)]
    [System.Management.Automation.PSCredential]$Cred
    )

function Ping-WinServer($Server) {
    try {
        $TestCnt = 1
        $SleepTime = 60
    
        while (-not (Test-Connection -ComputerName $Server -Quiet)) {
    
            if ($TestCnt -gt 7) {
                Write-Warning "ERROR: Test Connection for server [$Server] failed [$TestCnt] times. Exiting!"
                return 186
            }

            Write-Warning "Test Connection for server [$Server] failed attempt [$TestCnt]... sleeping $SleepTime seconds"
            Start-Sleep -Seconds $SleepTime
    
            $TestCnt += 1
        }

        #Hung Ly - Additional sleeptime when after ping tests succeed after a few tries
        if ($TestCnt -gt 1) {
            Write-Warning "Sleeping $Sleeptime seconds..."
            Start-Sleep -Seconds $SleepTime
        }#Hung-Ly----------------------------------------------------------------------

        Write-Host "Test connection for server [$Server] succeeded for attempt [$TestCnt]"
        return 0
    }
    catch {
        Write-Warning $_.Exception.ToString();
        return 61
    }
}

function Restart-ApmAgent() {
    try {
        if (-not (Test-Path "D:\IBM\APM\bin\os-agent.bat")) {
            Write-Host "Error: Could not find [D:\IBM\APM\bin\os-agent.bat]."
            return 5
        }
        # Stop the Agent
        Write-Host "Stopping APM Agent..."
        D:\IBM\APM\bin\os-agent.bat stop 2>&1 | Out-Null

        # Validate Stop
        $StopStatus = (D:\IBM\APM\bin\os-agent.bat status 2>&1) | Out-String
        
        if ($StopStatus -notmatch "Agent is not running") {
            Write-Host "Error: Failed to stop APM Agent using os-agent.bat"
            return 10
        }

        # Start Service
        Write-Host "Starting APM Agent..."
        D:\IBM\APM\bin\os-agent.bat start 2>&1 | Out-Null

        # Validate Start
        $StartStatus = (D:\IBM\APM\bin\os-agent.bat status 2>&1) | Out-String
        
        if ($StartStatus -notmatch "Agent is running") {
            Write-Host "Error: Failed to start APM Agent using os-agent.bat"
            return 20
        }
        else {
            Write-Host "Successfully restarted APM Agent"
            return 0
        }
    }
    catch {
        Write-Host "Unexpected Error:`n$($_.Exception.ToString())"
        return 50
    }
}

function Restart-ApmAgentForce() {
    try {
        $DisplayName = "Monitoring Agent for Windows OS - Primary#*"
        $ApmService = Get-Service -DisplayName "$DisplayName"

        if ($ApmService.Length -ne 1) {
            Write-Host "Error: Unable to find unique service matching display name [$DisplayName]"
            return 10
        }

        $ServiceName = $ApmService.Name
        Write-Host "Stopping APM agent using service [$ServiceName]..."
        Stop-Service $ServiceName -Force
        
        $CurrentStatus = (Get-Service $ServiceName).Status
        if ($CurrentStatus -ne "Stopped") {
            Write-Host "Error: Failed to stop APM Agent using the service name"
            return 20
        }

        Write-Host "Starting APM agent..."
        Start-Service $ServiceName

        $CurrentStatus = (Get-Service $ServiceName).Status
        if ($CurrentStatus -ne "Running") {
            Write-Host "Error: Failed to start APM Agent using the service name"
            return 30
        }

        return 0

    }
    catch {
        Write-Host "Unexpected Error:`n$($_.Exception.ToString())"
        return 50
    }
}

try
{
    # Set some basic variables
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    
    # Import functions
    Import-Module SRE-Functions -Force -WarningAction SilentlyContinue

    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning "Error: SRE Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }


    # Modify Input parameters as needed...
    if ($ISE) {
        # get the required input if not supplied when running from ISE
        if(-not($Server)) {
            do
            {
                $Server = (Read-Host "Input the server name (ex: winf2286n): ")
            }
            until ($Server -ne '')
        }
        if(-not($Cred)) {
            do
            {
                $Cred = Get-Credential -ErrorAction SilentlyContinue
            }
            until ($Cred -ne '')
        }
    }

    # Validate inputs
    if (-not $Server)
    {
        $exit_code = 30
        Write-Warning "Server is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    if (-not $Cred)
    {
        $exit_code = 35
        Write-Warning "Credential is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "SRE HOME Directory is $SRE_HOME"
    Write-Host "Script name is: $currentScriptName"
    Write-Host "ISE is [$ISE]"
    Write-Host "Server is [$Server]"
    Write-Host "Username is [$($Cred.UserName)]"


    #ALL the main code should go below here 
    #######################################

    Write-Host "Attempting to restart APM Agent on server [$Server]"

    $exit_code = Ping-WinServer -Server $Server

    if ($exit_code -ne 0) {
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    
    # First try to restart the agent using os-agent.bat
    $Session = New-PSSession -ComputerName $Server -Cred $Cred
    $exit_code = Invoke-Command -Session $Session -ScriptBlock ${function:Restart-ApmAgent}
    
    # If unsuccessful, force restart using agent service
    if ($exit_code -ne 0) {
        Write-Host "Failed to stop APM agent using os-agent.bat file. Attempting to restart the agent using the service."
        $exit_code = Invoke-Command -Session $Session -ScriptBlock ${function:Restart-ApmAgentForce}
    }
    #end main code#########################

}
catch
{
    Write-Warning $_.Exception.ToString();
    $exit_code = 99
}

finally
{
    #cleanup
    Remove-Module -Name SRE-Functions
    Remove-PSSession -Session $Session -ErrorAction SilentlyContinue

    Write-Host "All done with: $currentScriptName"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}