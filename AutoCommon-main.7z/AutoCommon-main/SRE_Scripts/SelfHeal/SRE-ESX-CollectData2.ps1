﻿<#	
	.NOTES
	===========================================================================
	 Created on:    01/07/2020
	 Updated on:	01/07/2020
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:      SRE-ESX_CollectData.ps1

	The scripts being built in this grouping are for SRE Production Support
	The majority will be run from the Primary SRE Server, WINF2286N, WINF3095P or WINF3096p.
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script will collect data needed for a ESX failure used by incidement management for recovery of the failure

MODIFICATIONS
_____________________________________________________________________________________________________________________________
    Date       By            Reason
    01/07/2020 Murry Kane    Initial
    01/15/2020 Murry Kane    Reviewed code with Raymond Lee and determine some changes to the query into Vcenter needed 
                             refinement 
    01/22/2020 Murry Kane    This script will recover EDI if any server within the ESX failure contained an EDI server
                             Logic should look to see if any TM server is contained in the list, if there is a TM server,
                             then a full recycle is needed, else just start the affected server with the full start program
    01/28/2020 Murry Kane    Added optional/defaulted time to go back in hours for searching Vcenter for restarted hosts
    02/04/2020 Murry Kane    Fixed the email list, for some reason you need " instead of ' for users in email
    02/10/2020 Murry Kane    Changes to the re-check logic for failed hosts
                                - Workflow within Service Now will sleep 5 minutes
                                - sleep time to 60 seconds 6 intervals (until found records)
                                - Once found records sleep 3 minutes then find records again for final list
                             Add optional parm to script for no rechecks on failed servers skip logic above
_____________________________________________________________________________________________________________________________
    PARMS

    ESXServer     - Vcenter Server this will most likely be one of the following: WCIN107P, wcin124P, WINF235P, WINF236P, WINF240P, AND WINF242P
    CRED          - The username and password that will connect to the VMWare Vcenter defined above
    HoursBack     - This is the hours from current to look back in time for the error message in the Vcenter console
    VMHost        - This is the VM Host that we are using to narrow the search against within Vcenter (this is part of the event into SMP) 
    SkipRechecks  - This will not go into any retry logic to find failed servers within VCenter (1 try only)

    Examples 

    SRE-ESX-CollectData.ps1 -ESXServer winf242p -Cred $Cred
    SRE-ESX-CollectData.ps1 -ESXServer winf240p -Cred $Cred -HoursBack 8
    SRE-ESX-CollectData.ps1 -ESXServer winf240p -Cred $Cred -HoursBack 3 -VMHost lvebp-esx250.bsc.bscal.com 
    SRE-ESX-CollectData.ps1 -ESXServer winf240p -Cred $Cred -HoursBack 12 -VMHost lvebp-esx250.bsc.bscal.com -SkipRechecks

#>

[CmdletBinding()]
Param(
    [Parameter(Position=0)]
    [string]$ESXServer,
    [Parameter(Position=1)]
    [System.Management.Automation.PSCredential]$Cred,
    [Parameter(Position=2)]
    [int]$HoursBack = 1,
    [Parameter(Position=3, Mandatory=$false)]
    [string]$VMHost,
    [Parameter(Position=4, Mandatory=$false)]
    [switch]$SkipRechecks
)

try
{

    function checkEDIFailure
    {
        Import-Module -name Get-BSCServersInfo -WarningAction Ignore -Force
        $ediservers = get-bscserversinfo -Environment $EDIENV -WhichProperty app -PropValue EDI -ColumnReturn ServerName
        $tmservers = get-bscserversinfo -Environment $EDIENV -WhichProperty role -PropValue EDITM -ColumnReturn ServerName

        Write-Host "EDI Environment we will be working with: [$EDIENV]"
        Write-Host "EDI servers: [$ediservers]"
        Write-Host "TM servers: [$tmservers]"

        #phase 2 see if any server is for EDI and 
        #$theReport = import-csv -path $CSVReport
        $theReport = import-csv -path D:\Reports\ESXServerFailureReport_2020-01-14T16-04-00.csv
        $TMFlag=$false
        $EDIFlag=$false
        $theReport |  foreach-object -Process { 
            $server = $_.Server
            Write-Host "working on server $server"
            #find if EDI server or not....
            if($tmservers -like $server)
            {
                $TMFlag=$true
            }
            if($ediservers -like $server)
            {
                $EDIFlag=$true
            }
        }
        Write-Host "EDI TM Server flag [$TMFlag] and EDI server flag [$EDIFlag]"
        if($TMFlag)
        {
            #full recycle needed....
            write-Host "Full recycle needed for EDI"
            <#
            $ScriptRoute = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($env:PAM_HOME + "\EDI\EDI_Services_STOP.ps1"))

            # Execute script at location:
            &"$ScriptRoute" -Environment $EDIENV -MaintType infra

            $ScriptRoute = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($env:PAM_HOME + "\EDI\EDI_Services_START.ps1"))

            # Execute script at location:
            &"$ScriptRoute" -Environment $EDIENV -MaintType infra
            #>
        }
        elseif(!$TMFlag -and $EDIFlag)
        {
            #start all of EDI
            Write-Host "Starting broken EDI services..." 
            $ScriptRoute = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($env:PAM_HOME + "\EDI\EDI_Services_START.ps1"))

            # Execute script at location:
            &"$ScriptRoute" -Environment $EDIENV -MaintType core
        }
    }

    function getFailedHosts
    {

        [CmdletBinding()]
        param (
            [VMware.VimAutomation.ViCore.Impl.V1.VIServerImpl]$VCenter
        )

        Write-Host "Attempting check for restarted hosts within Vcenter..."
        $Date = Get-Date

        #$TheList = Get-VIEvent -maxsamples 100000 -Start ($Date).AddHours(-$HoursBack) -type Warning | Where {$_.FullFormattedMessage -match "vSphere HA restarted virtual machine(.*)$VMHost"} | select CreatedTime,FullFormattedMessage,destFolder,destName,destHost,reason,template,key,chainId,userName,datacenter,computerResourse,host,vm,dynamicType,dynamicProperty | sort CreatedTime -Descending 
        $TheList = Get-VIEvent -maxsamples 100000 -Start ($Date).AddHours(-$HoursBack) -type Warning | Where {$_.FullFormattedMessage -match "vSphere HA agent on(.*)in cluster(.*)cannot reach some management network addresses of other hosts(.*)"} | select CreatedTime,FullFormattedMessage,destFolder,destName,destHost,reason,template,key,chainId,userName,datacenter,computerResourse,host,vm,dynamicType,dynamicProperty | sort CreatedTime -Descending 

        if($($TheList.count) -gt 0)
        {
            Write-Host "Records found for failed over hosts with count [$($TheList.count)]..."
            Write-Host "$TheList"
        }

        return $TheList

    }

    # Set some basic variables
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    $mailfromuser="IT-SiteReliabilityEngineering@blueshieldca.com"
    $mailSubject="ESX Failure Report"
    $SMTPServer = "emailrelay.bsc.bscal.com"
    $SMTPPort = "25"
    $mailBody = ""
    #$mailtolist=@("it-noc@blueshieldca.com", "ITServerEngineering@blueshieldca.com", "IT-SiteReliabilityEngineering@blueshieldca.com", "IMAware@blueshieldca.com", "it-pam@blueshieldca.com")
    $mailtolist='murry.kane@blueshieldca.com'

    # Import functions
    Import-Module SRE-Functions -Force -WarningAction Ignore

    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"
    $CSVReport = "D:\Reports\ESXServerFailureReport_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".csv"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning "WARNING: SRE Management Server Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Modify Input parameters as needed....
    if ($ISE) {
        # Get the required input if not supplied when running from ISE
        if(-not($ESXServer)) {
            do
            {
                $ESXServer = (Read-Host "Input your ESX Server(VCenter host) (WCIN###P or WINF###P, etc): ")
            }
            until ($ESXServer -ne '')
        }
        if(-not($Cred)) {
            do 
            {
                $Cred = Get-Credential -Message "Please provide the username/password for the SRE Script"
            }
            until ($Cred -ne [System.Management.Automation.PSCredential]::Empty)
        }
    }


    # Validate inputs
    if (-not $ESXServer)
    {
        $exit_code = 31
        Write-Warning "ESX Server is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    if (-not $Cred)
    {
        $exit_code = 33
        Write-Warning "Credential is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    if (-not $HoursBack)
    {
        $exit_code = 34
        Write-Warning "HoursBack is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "SRE HOME Directory is $SRE_HOME"
    Write-Host "Script name is: $currentScriptName"
    Write-Host "ISE is [$ISE]"
    Write-Host "ESX Server is [$ESXServer]"
    Write-Host "ESX Host is [$VMHost]"
    Write-Host "Username is [$($Cred.UserName)]"
    Write-Host "Hours Back is [$HoursBack]"
    Write-Host "Skip Rechecks is [$SkipRechecks]"


    # Validate server exists
    $EC1 = isValidServer($ESXServer)

    if ($EC1 -ne 0)
    {
        $exit_code = $EC1
        Write-Warning "Invalid server [$ESXServer]. Exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # ----------------------- Main -----------------------

    
    # Let's validate we are not trying to cross domains (NPE to PROD or vise-versa)
    $EC2 = validateDomain -Server $ESXServer -RunOnLocalHost

    if ($EC2 -ne 0)
    {
        $exit_code = $EC2
        Write-Warning "Cannot cross domains. Exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    


    $domain = Get-WMIObject Win32_ComputerSystem | Select-Object -ExpandProperty domain
    if ($domain -eq "bsc.bscal.com")
    {
        if([System.Net.Dns]::GetHostName() -like 'winf4595p')
        {
            $PSDrive = New-PSDrive -Name Q -PSProvider FileSystem -Root \\winf4595p\D$  
        }
        else
        {
            $PSDrive = New-PSDrive -Name Q -PSProvider FileSystem -Root \\winf4595p\D$ -Credential $Cred
        }
        $usernameline = get-content -Path Q:\Installs\Users\svcsre_prod.txt | Select-String -Pattern USERNAME
        $passwordline = get-content -Path Q:\Installs\Users\svcsre_prod.txt | Select-String -Pattern PASSWORD
        $BSCSNow = 'https://blueshieldca.service-now.com'
        $EDIENV = @('EDIP01','HIXP02')
    }
    else
    {
        if([System.Net.Dns]::GetHostName() -like 'winf2286n')
        {
            $PSDrive = New-PSDrive -Name Q -PSProvider FileSystem -Root \\winf2286n\D$  
        }
        else
        {
            $PSDrive = New-PSDrive -Name Q -PSProvider FileSystem -Root \\winf2286n\D$ -Credential $Cred
        }
        $usernameline = get-content -Path Q:\Installs\Users\svcsre_dev.txt | Select-String -Pattern USERNAME
        $passwordline = get-content -Path Q:\Installs\Users\svcsre_dev.txt | Select-String -Pattern PASSWORD
        $BSCSNow = 'https://blueshieldca2015.service-now.com'
        $EDIENV = @('EDIN02')
    }


    $username = $usernameline.ToString().Substring(9, $usernameline.ToString().length-9)
    $password = $passwordline.ToString().Substring(9, $passwordline.ToString().length-9)
    $udecrypted = Decrypt-String $username "U_MyStrongPassword"
    $pdecrypted = Decrypt-String $password "P_MyStrongPassword"
    $SNowPass = ConvertTo-SecureString –String $pdecrypted –AsPlainText -Force
    $SNowCreds = New-Object –TypeName System.Management.Automation.PSCredential –ArgumentList $udecrypted, $SNowPass

    #remove mapped drive
    Remove-PSDrive -Name Q 

    Write-Verbose "Username line  is $usernameline" 
    Write-Verbose "password line  is $passwordline"
    Write-Verbose "Username is $username" 
    Write-Verbose "password is $password"
    Write-Verbose "Username unencrypted is $udecrypted"
    Write-Verbose "Cred is $SNowCreds"

    #lets connect to VMWare
    $VCenter = Connect-VIServer -Credential $cred -Server $ESXServer -Force

    $recordsFound = $false
    $recheckStarted = $false

    ################################
    #Check for failed hosts loop....
    for ($i=0; ($i -lt 6) -and (-not $recordsFound); $i++)
    {
        Write-Host "Working on loop [$i] to find restarted Vcenter Hosts"
        $TheList = getFailedHosts -Vcenter $VCenter
        if($($TheList.count) -gt 0 )
        {
            Write-Host "We found records...."
            #MBK recheck needed...
            #$recordsFound = $true
            if(-not $recheckStarted)
            {
                if(-not $SkipRechecks)
                {
                    Write-host "Sleeping for 3 minutes to make sure we didn't get a partial list of restarted servers...."
                    Start-Sleep -Seconds 180
                    $recheckStarted = $true
                }
                else
                {
                    #need to exit then
                    Write-Host "Skipping recheck logic as requested..."
                    $recordsFound = $true
                }
            }
            else
            {
                Write-Host "Final check is complate for restarted servers...."
                $recordsFound = $true
            }
        }
        else
        {
            if(-not $SkipRechecks)
            {
                Write-Host "No Records found, sleeping 60 seconds to recheck"
                Start-Sleep -Seconds 60
            }
            else
            {
                Write-Host "Skipping recheck logic as requested..."
                $recordsFound = $true
            }

        }

    }
    ################################

    if($($TheList.count) -gt 0 )
    {
        Write-Host "List of Servers Failed over count is [$($TheList.Count)]"

        #Lets get the most current from CMDB...
        $URLLegit = "$BSCSNow/api/now/table/u_srvr_to_app_rel?sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=u_server%2Cu_server.sys_class_name%2Cu_server.ref_cmdb_ci_hardware.used_for%2Cu_server.ref_cmdb_ci_computer.os%2Cu_server.ref_cmdb_ci_computer.os_version%2Cu_server.ref_cmdb_ci_hardware.hardware_status%2Cu_application%2Cu_application.ref_cmdb_ci_appl.u_number%2Cu_application.ref_cmdb_ci_appl.u_business_criticality%2Cu_application.install_status%2Cu_application.supported_by%2Cu_application.managed_by%2Cu_application.owned_by%2Cu_application.support_group&sysparm_limit=20000"
        
        Write-Host "Using URI $URLLegit"
        $CMDBServerToService = Invoke-RestMethod -Uri $URLLegit -Credential $SNowCreds -Body $Body -ContentType "application/json"

        Write-Host "Objects found in the CMDB is [$($CMDBServerToService.Result.Count)]" 
        $csvContents = @()


        $TheList |  foreach-object -Process { 
            #$server = $_.vm.name.toString()
            $server = $_.host.name.toString()
            #$datacenter = $_.datacenter.toString()
            $createdTime = $_.CreatedTime.GetDateTimeFormats('u')
            $fullMsg = $_.FullFormattedMessage.ToString()
            write-host "Affected host is [$server]"
            #write-host "Affected host is [$server] Data Center [$datacenter]"
            $foundit = $false 

            # first add a column to denote health of failed over server....
            $hostStatus = 'Offline'
            if (Test-Connection $server -BufferSize 16 -Count 1 -ea 0 -quiet) 
            {
	            $hostStatus = 'Online'
            }

            For ($i=0; $i -le $CMDBServerToService.Result.Count; $i++) {
                $lsrvr = $CMDBServerToService.Result[$i].u_server 
                #write-verbose "working on $lsrvr"
                if ($lsrvr -like $server) {
 
                    Write-Verbose "Found it...."
                    $row = New-Object System.Object
 
                    $row | Add-Member -MemberType NoteProperty -Name "Server" -Value $server
                    #$row | Add-Member -MemberType NoteProperty -Name "Data Center" -Value $datacenter
                    $row | Add-Member -MemberType NoteProperty -Name "Occurred Time" -Value "$createdTime"
                    $row | Add-Member -MemberType NoteProperty -Name "Operational Status" -Value $CMDBServerToService.Result[$i].'u_server.ref_cmdb_ci_hardware.used_for'
                    $row | Add-Member -MemberType NoteProperty -Name "Application" -Value $CMDBServerToService.Result[$i].'u_application'
                    $row | Add-Member -MemberType NoteProperty -Name "Business Criticality" -Value $CMDBServerToService.Result[$i].'u_application.ref_cmdb_ci_appl.u_business_criticality'
                    $row | Add-Member -MemberType NoteProperty -Name "Supported by" -Value $CMDBServerToService.Result[$i].'u_application.supported_by'
                    $row | Add-Member -MemberType NoteProperty -Name "Manager" -Value $CMDBServerToService.Result[$i].'u_application.managed_by'
                    $row | Add-Member -MemberType NoteProperty -Name "Support Team" -Value $CMDBServerToService.Result[$i].'u_application.support_group'
                    $row | Add-Member -MemberType NoteProperty -Name "ESX Message" -Value $fullMsg
 
                    #$csvContents += $row
                    $foundit = $true 
                    #break each server can have many apps.... need to get all rows...
                    $row | Add-Member -MemberType NoteProperty -Name "Host Status" -Value $hostStatus
                    $csvContents += $row
                }
            }
            if($foundit)
            {
                write-verbose "We already added the found rows..."
            }
            else
            {
                write-verbose "didn''t find this host so we need to add an empty rowB...." 
                $row = New-Object System.Object
 
                $row | Add-Member -MemberType NoteProperty -Name "Server" -Value $server
                #$row | Add-Member -MemberType NoteProperty -Name "Data Center" -Value $datacenter
                $row | Add-Member -MemberType NoteProperty -Name "Occurred Time" -Value ""
                $row | Add-Member -MemberType NoteProperty -Name "Operational Status" -Value ""
                $row | Add-Member -MemberType NoteProperty -Name "Application" -Value ""
                $row | Add-Member -MemberType NoteProperty -Name "Business Criticality" -Value ""
                $row | Add-Member -MemberType NoteProperty -Name "Supported by" -Value ""
                $row | Add-Member -MemberType NoteProperty -Name "Manager" -Value ""
                $row | Add-Member -MemberType NoteProperty -Name "Support Team" -Value ""
                $row | Add-Member -MemberType NoteProperty -Name "ESX Message" -Value $fullMsg
                $row | Add-Member -MemberType NoteProperty -Name "Host Status" -Value $hostStatus
                $csvContents += $row                
            }
        }

        #lets write the report...
        $csvContents | Export-Csv -Path $CSVReport -NoTypeInformation
    }
    else
    {
        Write-Host "List of Servers Failed over count is [$($TheList.Count)], exiting with nothing more to do...."     
    }
    
    #see if we need to send email...
    if($($TheList.count) -gt 0 )
    {
        Write-Host "Sending email...."
        #
        #$mailBody = $mailBody + "`r`n" + "$_ Doesn't have a MD5 file"
        $mailBody = "ESX Failure, please review the attached file for the servers that were restarted on another ESX Cluster"
        $mailBody = ($mailBody.split("`r`n") -join "<br/>")
        Send-MailMessage -To $mailtolist -From $mailfromuser -Subject $mailSubject -SmtpServer $SMTPServer -port $SMTPPort -Body $mailBody  -BodyAsHtml -Attachments $CSVReport
    } 
    else 
    {
        Write-Host "No need to send email today..."
    }
    
    #check for EDI failure... MBK Commented out for future release
    #checkEDIFailure 
    # --------------------- End Main ---------------------

}
catch
{
    Write-Warning $_.Exception.ToString();
    $exit_code = 99
}

finally
{

    # Cleanup
    Remove-Module -Name SRE-Functions -ErrorAction Ignore
    Remove-Module -Name Get-BSCServersInfo -ErrorAction Ignore

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}

