﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	06/19/2020
	 Updated on:	06/19/2020
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	SelfHeal_NetworXPricerRecycleHungJvm.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server, WINF313P or WINF4028p. 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script run a python script on a server using the credentials provided.


Date:      Who:            Changes:
-----------------------------------
06/19/2020 Murry Kane    Initial
07/22/2020 Murry Kane    removed hard-coded wapp2048s to $server
12/16/2020 Murry Kane    Changed code to not need EnvList.csv but rather go after CMDB
07/14/2021 Murry Kane    Needed a code change to the CMDB lookup after 2019 upgrade for facets

    Example

    ./{Directory}\SelfHeal_NetworXPricerRecycleHungJvm.ps1 -CI NX8@wapp4143p -PythonVersion "3" -Cred {credential}
    ./{Directory}\SelfHeal_NetworXPricerRecycleHungJvm.ps1 -CI WF2@wapp4141p -PythonVersion "2" -Cred {credential}
#>
[CmdletBinding()]
Param(
    [Parameter(Position=0)]
    [string]$CI,
    [Parameter(Position=1)]
    [ValidateSet("2","3")]
    [string]$PythonVersion = "2",
    [Parameter(Position=2)]
    [System.Management.Automation.PSCredential]$Cred
)


function Get-ServerList {
    try {
        $SNowCred = Get-ServiceNowCredential

        $UriBase = Get-ServiceNowUriBase
        Write-Host "URI Base $UriBase"

        # Query Server to App Relationship Table
        Write-Host "Querying ServiceNow API for getting the FileNet Content Collector server(s)"
        $Uri = "$UriBase/api/now/table/cmdb_rel_ci?sysparm_query=parent.sys_class_name%3Dcmdb_ci_app_server_websphere%5Eparent.name%3D$CI%5Echild.sys_class_name%3Dcmdb_ci_websphere_cell&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=child&sysparm_limit=1000"

        Write-Host "Using URI [$Uri]"

        $Result = Query-ServiceNowApi -Uri $Uri -SNowCred $SNowCred

        Write-Host "Result is " + $result
        $CellName = ($Result).child | select -Unique
        Write-Host "Cell Name is $CellName"

        $Uri2 = "$UriBase/api/now/table/cmdb_rel_ci?sysparm_query=child.name%3D$CellName%5Echild.operational_status%3D1%5Echild.sys_class_name%3Dcmdb_ci_websphere_cell%5Eparent.nameSTARTSWITHdmgr%5Eparent.install_status%3D11&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=parent&sysparm_limit=1000"
        Write-Host "Using URI2 [$Uri2]"

        $Result2 = Query-ServiceNowApi -Uri $Uri2 -SNowCred $SNowCred
        Write-Host "Result2 is " + $Result2    

        $Servers = $result2 | ForEach-Object { (($_).parent -split "@")[1] } | select -Unique

        return $Servers
    }
    catch {
        return $null
    }
}


try
{
    # Set some basic variables
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    $PyScriptStop = "stopOneAppServer.py"
    $PyScriptStart = "startOneAppServer.py"
    $LocalDomain = (Get-ChildItem Env:'USERDOMAIN' -ErrorAction Ignore).Value

    # Import functions and get server info
    Import-Module SRE-Functions -Force -WarningAction SilentlyContinue
    Import-Module Get-BSCServersInfo -WarningAction SilentlyContinue
    Import-Module SnowFunctions -Force -WarningAction SilentlyContinue

    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(Get-Date -Format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning "Error: SRE Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Modify Input parameters as needed....
    if ($ISE) 
    {
        # Get the required input if not supplied when running from ISE
        if(-not($CI)) 
        {
            do
            {
                $CI = (Read-Host "Input your Configuration Item for the HUNG IBM JVM (WF8@wapp4129p, etc): ")
            }
            until ($CI -ne '')
        }
        if(-not($Cred)) 
        {
            do
            {
                $Cred = Get-Credential
            }
            until ($Cred -ne '')
        }
    }

    # Validate inputs
    if (-not $CI)
    {
        $exit_code = 30
        Write-Warning "Configuration Item for the HUNG IBM JVM is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    if (-not $Cred)
    {
        $exit_code = 35
        Write-Warning "Credential is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "SRE HOME Directory is $SRE_HOME"
    Write-Host "Script name is: $currentScriptName"
    Write-Host "ISE is [$ISE]"
    Write-Host "CI is [$CI]"
    Write-Host "Username is [$($Cred.UserName)]"

    #need to seperate CI based on '@' to get server and JVM instance
    if( $CI.IndexOf('@') -gt -1 )
    {
        $jvm_inst = ($CI -split "@")[0]
        $server = ($CI -split "@")[1]
        Write-Host "JVM Instance is [$jvm_inst] running on server [$server]"
    }
    else
    {
        $exit_code = 39
        Write-Warning "Configuration Item for the HUNG IBM JVM is not [JVM instance]@[Server Name] format with [$CI], exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE        
    }    

    #if ([string]::IsNullOrEmpty($server))
    if (-not $server)
    {
        $exit_code = 40
        Write-Warning "Configuration Item [$CI] we could not get Server Name, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE  
    }
     
    # Validate server exists
    $EC1 = isValidServer($Server)

    if ($EC1 -ne 0)
    {
        $exit_code = $EC1
        Write-Warning "Invalid server [$Server]. Exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    
    # ----------------------- Main -----------------------

    # Let's validate we are not trying to cross domains (NPE to PROD or vise-versa)
    $EC2 = validateDomain -Server $Server -RunOnLocalHost

    if ($EC2 -ne 0)
    {
        $exit_code = $EC2
        Write-Warning "Cannot run Python across domains. Exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    #Lets determine the DMGR server for this application server instance
    #$environment = get-BSCServersInfo -WhichProperty ServerName -PropValue $Server -ColumnReturn EnvName
    #$dmgrServer = get-BSCServersInfo -Environment $environment -WhichProperty SuperRole -PropValue dmgr -ColumnReturn ServerName
    
    #get the server(s) to manage...
    $dmgrServer = Get-ServerList
    Write-Host "List of DMGR Server(s) is: [$dmgrserver]"

    if (-not $dmgrServer)
    {
        $exit_code = 45
        Write-Warning "We Could NOT determine Deployment Manger for CI [$CI], exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE 
    }
    else
    {
        Write-Host "For CI is [$CI] using Deployment Manager(s) [$dmgrServer]"
    }

    # Set up PS Session
    Write-Host "Starting PS Session on [$dmgrServer] as user [$($Cred.UserName)]"
    $Session = New-PSSession -ComputerName $dmgrServer -Credential $Cred -Verbose

    # Let's validate the Python script exists and automation is enabled on remote server
    $PythonScripts = @($PyScriptStop,$PyScriptStart)

    $ReasonToExit, $PythonScriptPaths = Invoke-Command -Session $Session -ScriptBlock ${function::ValidateRemotePythonSession} -ArgumentList (,$PythonScripts)
    
    if ($ReasonToExit -ne $null)
    {
        $exit_code = 40
        Write-Warning $ReasonToExit
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Assign Full Script Paths
    $PyScriptStopPath = $PythonScriptPaths[0]
    $PyScriptStartPath = $PythonScriptPaths[1]

    
    # Let's validate that the correct version of Python is installed on the server
    Write-Host "Searching for Python $PythonVersion executable on server [$Server]."
    $ReasonToExit, $PythonExe = Invoke-Command -Session $Session -ScriptBlock ${function:Get-PythonExecutablePath} -ArgumentList $PythonVersion
    
    if ($ReasonToExit -ne $null)
    {
        $exit_code = 50
        Write-Warning $ReasonToExit
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    
    # ---------- Stop Cluster ---------- #
    $ReasonToExit = RunPythonAsJob -Session $Session -PythonExe $PythonExe -PythonScriptName $PyScriptStop -PythonScriptPath $PyScriptStopPath -PythonArgs "--appserver=$jvm_inst --terminate"

    if ($ReasonToExit -ne $null)
    {
        $exit_code = 55
        Write-Warning $ReasonToExit
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    
    # ---------- Start Cluster --------- #
    $ReasonToExit = RunPythonAsJob -Session $Session -PythonExe $PythonExe -PythonScriptName $PyScriptStart -PythonScriptPath $PyScriptStartPath -PythonArgs "--appserver=$jvm_inst --waittime=300"

    if ($ReasonToExit -ne $null)
    {
        $exit_code = 55
        Write-Warning $ReasonToExit
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    # --------------------- End Main ---------------------

}
catch
{
    Write-Warning $_.Exception.ToString();
    $exit_code = 99
}
finally
{
    # Cleanup
    Remove-Module -Name SRE-Functions
    Remove-Module -Name Get-BSCServersInfo
    Remove-Module -Name SnowFunctions
    $Session | Remove-PSSession -ErrorAction SilentlyContinue

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}
