﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	09/06/2019
	 Updated on:	09/06/2019
	 Created by:   	Kyle Parrott
	 Organization: 	Blue Shield of California
	 Filename:     	SelfHeal_RunPythonScript.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server, WINF313P or WINF4028p. 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script run a python script on a server using the credentials provided.


Date:      Who:            Changes:
-----------------------------------
09/06/2019 Kyle Parrott    Initial

    Example

    ./{Directory}\SelfHeal_StartCdm.ps1 -Server localhost -PythonVersion "3" -Cred {credential}
    ./{Directory}\SelfHeal_StartCdm.ps1 -Server WAPP0123 -PythonVersion "2" -Cred {credential}
#>
[CmdletBinding()]
Param(
    [Parameter(Position=0)]
    [string]$Server,
    [Parameter(Position=1)]
    [ValidateSet("2","3")]
    [string]$PythonVersion = "2",
    [Parameter(Position=2)]
    [System.Management.Automation.PSCredential]$Cred
)
#2034n
try
{
    # Set some basic variables
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    $PyScriptStop = "stopAllAppServers.py"
    $PyScriptStart = "startAllClusters.py"

    # Import functions
    Import-Module SRE-Functions -Force

    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(Get-Date -Format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning "Error: SRE Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Modify Input parameters as needed....
    if ($ISE) 
    {
        # Get the required input if not supplied when running from ISE
        if(-not($Server)) 
        {
            do
            {
                $Server = (Read-Host "Input your Server (wapp4059p, etc): ")
            }
            until ($Server -ne '')
        }
        if(-not($Cred)) 
        {
            do
            {
                $Cred = Get-Credential
            }
            until ($Cred -ne '')
        }
    }


    # Validate inputs
    if (-not $Server)
    {
        $exit_code = 30
        Write-Warning "Server is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    if (-not $Cred)
    {
        $exit_code = 35
        Write-Warning "Credential is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "SRE HOME Directory is $SRE_HOME"
    Write-Host "Script name is: $currentScriptName"
    Write-Host "ISE is [$ISE]"
    Write-Host "Server is [$Server]"
    Write-Host "Username is [$($Cred.UserName)]"

     
    # Validate server exists
    $EC1 = isValidServer($Server)

    if ($EC1 -ne 0)
    {
        $exit_code = $EC1
        Write-Warning "Invalid server [$Server]. Exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    
    # ----------------------- Main -----------------------

    # Let's validate we are not trying to cross domains (NPE to PROD or vise-versa)
    $EC2 = validateDomain -Server $Server -RunOnLocalHost

    if ($EC2 -ne 0)
    {
        $exit_code = $EC2
        Write-Warning "Cannot run Python across domains. Exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    
    # Set up PS Session
    Write-Host "Starting PS Session on [$Server] as user [$($Cred.UserName)]"
    $Session = New-PSSession -ComputerName $Server -Credential $Cred -Verbose

    # Let's validate the Python script exists and automation is enabled on remote server
    $PythonScripts = @($PyScriptStop,$PyScriptStart)

    $ReasonToExit, $PythonScriptPaths = Invoke-Command -Session $Session -ScriptBlock ${function::ValidateRemotePythonSession} -ArgumentList (,$PythonScripts)
    
    if ($ReasonToExit -ne $null)
    {
        $exit_code = 40
        Write-Warning $ReasonToExit
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Assign Full Script Paths
    $PyScriptStopPath = $PythonScriptPaths[0]
    $PyScriptStartPath = $PythonScriptPaths[1]

    
    # Let's validate that the correct version of Python is installed on the server
    Write-Host "Searching for Python $PythonVersion executable on server [$Server]."
    $ReasonToExit, $PythonExe = Invoke-Command -Session $Session -ScriptBlock ${function:Get-PythonExecutablePath} -ArgumentList $PythonVersion
    
    if ($ReasonToExit -ne $null)
    {
        $exit_code = 45
        Write-Warning $ReasonToExit
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    
    # ---------- Stop Cluster ---------- #
    $ReasonToExit = RunPythonAsJob -Session $Session -PythonExe $PythonExe -PythonScriptName $PyScriptStop -PythonScriptPath $PyScriptStopPath -PythonArgs "--action=ALL --terminate"

    if ($ReasonToExit -ne $null)
    {
        $exit_code = 50
        Write-Warning $ReasonToExit
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    
    # ---------- Start Cluster --------- #
    $ReasonToExit = RunPythonAsJob -Session $Session -PythonExe $PythonExe -PythonScriptName $PyScriptStart -PythonScriptPath $PyScriptStartPath

    if ($ReasonToExit -ne $null)
    {
        $exit_code = 55
        Write-Warning $ReasonToExit
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    # --------------------- End Main ---------------------

}
catch
{
    Write-Warning $_.Exception.ToString();
    $exit_code = 99
}
finally
{
    # Cleanup
    Remove-Module -Name SRE-Functions
    $Session | Remove-PSSession -ErrorAction SilentlyContinue

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}
