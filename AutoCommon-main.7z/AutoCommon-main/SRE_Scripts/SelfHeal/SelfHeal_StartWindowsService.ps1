﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	07/29/2019
	 Updated on:	07/29/2019
	 Created by:   	Murry Kane / Kyle Parrott
	 Organization: 	Blue Shield of California
	 Filename:     	SelfHeal_StartWindowsService.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server, WINF313P or WINF4028p. 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script will start a windows service that has failed/stopped.


Date:      Who:            Changes:
-----------------------------------
07/29/2019 Kyle Parrott    Initial
07/31/2019 Kyle Parrott    Updated to accomadate new SRE directories/functions.
08/19/2019 Kyle Parrott    Updated to use Get-SREServiceControl
08/28/2019 Murry Kane      Updated to get-credential
05/11/2021 Murry Kane      updated to use checkJobAndLog

    Example

    ./{Directory}\SelfHeal_StartWindowsService.ps1 -Server wapp4059p -ServiceToControl WinRM -Cred {credential}
#>

[CmdletBinding()]
Param(
    [Parameter(Position=0)]
    [string]$Server,
    [Parameter(Position=1)]
    [string]$ServiceToControl,
    [Parameter(Position=2)]
    [System.Management.Automation.PSCredential]$Cred
)

try
{
    # Set some basic variables
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    
    # Import functions
    Import-Module SRE-Functions -Force

    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning "WARNING: SRE Management Server Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Modify Input parameters as needed....
    if ($ISE) {
        # Get the required input if not supplied when running from ISE
        if(-not($Server)) {
            do
            {
                $Server = (Read-Host "Input your Server (wapp4059p, etc): ")
            }
            until ($Server -ne '')
        }
        if(-not($ServiceToControl)) {
            do 
            {
                $ServiceToControl = (Read-Host "Input your Service to Control (Wcmsvc, etc): ")
            }
            until ($ServiceToControl -ne '')
        }
        if(-not($Cred)) {
            do 
            {
                $Cred = Get-Credential -Message "Please provide the username/password for the SRE Script"
            }
            until ($Cred -ne [System.Management.Automation.PSCredential]::Empty)
        }
    }


    # Validate inputs
    if (-not $Server)
    {
        $exit_code = 31
        Write-Warning "Server is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    if (-not $ServiceToControl)
    {
        $exit_code = 32
        Write-Warning "Service to control is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    if (-not $Cred)
    {
        $exit_code = 33
        Write-Warning "Credential is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "SRE HOME Directory is $SRE_HOME"
    Write-Host "Script name is: $currentScriptName"
    Write-Host "ISE is [$ISE]"
    Write-Host "Server is [$Server]"
    Write-Host "Service to control is [$ServiceToControl]"
    Write-Host "Username is [$($Cred.UserName)]"

    # Validate server exists
    $EC1 = isValidServer($Server)

    if ($EC1 -ne 0)
    {
        $exit_code = $EC1
        Write-Warning "Invalid server [$Server]. Exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # ----------------------- Main -----------------------

    # Import Module
    Import-Module -Name Get-SREServiceControl -Force

    # Let's validate we are not trying to cross domains (NPE to PROD or vise-versa)
    $EC2 = validateDomain -Server $Server -RunOnLocalHost

    if ($EC2 -ne 0)
    {
        $exit_code = $EC2
        Write-Warning "Cannot start service across domains. Exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Now that the validations are complete, let's start the service
    Write-Host "Working on server [$Server] for service [$ServiceToControl]"

    # Set up PS Session and jobs to start service
    $Session = New-PSSession -ComputerName $Server -Credential $Cred -Verbose
    $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-SREServiceControl} -ArgumentList $ServiceToControl,"Start",120 -AsJob
    #$Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-SREServiceControl} -ArgumentList $ServiceToControl,"Check",120 -AsJob

    # Wait for job to complete and output the results
    #$RC1 = checkJobAndLogKeepingExitCode -Session $Session -Jobs $Jobs -ExitCodeType 2
    $RC1 = checkJobAndLog -Session $Session -Jobs $Jobs -ExitCodeType 2
    #Wait-Job $Jobs
    #$RC1 = $Jobs | receive-job
    $RCode1 = $($RC1)[$($RC1.Count-1)]

    # Check exit status of jobs
    if ($RCode1 -ne 0)
    {
        $exit_code = $RCode1
        Write-Warning "ERROR: Failures during [$ServiceToControl] start... RC = $RCode1"
    }
    else 
    {
        Write-Host "All good on job. [$ServiceToControl] successfully started on server [$Server]"
    }

    # --------------------- End Main ---------------------

}
catch
{
    Write-Warning $_.Exception.ToString();
    $exit_code = 99
}

finally
{

    # Cleanup
    Remove-Module -Name Get-SREServiceControl -ErrorAction Ignore
    Remove-Module -Name SRE-Functions -ErrorAction Ignore

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}