﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	07/29/2019
	 Updated on:	07/29/2019
	 Created by:   	Murry Kane 
	 Organization: 	Blue Shield of California
	 Filename:     	Installation_Tidal.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server, WINF2286n (dev) 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script will install Tidal on a remote server


Date:      Who:            Changes:
-----------------------------------
11/18/2019 Murry Kane    Initial


    Example

    ./{Directory}\Installation_Tidal.ps1 -Server winf2286n -Cred $Cred
#>

[CmdletBinding()]
Param(
    [Parameter(Position=0)]
    [string]$Server,
    [Parameter(Position=1)]
    [System.Management.Automation.PSCredential]$Cred
)

try
{
    # Set some basic variables
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    
    # Import functions
    Import-Module SRE-Functions -Force -WarningAction SilentlyContinue
    Import-Module SRE-InstallTidal -Force -WarningAction SilentlyContinue

    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning "WARNING: SRE Management Server Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Modify Input parameters as needed....
    if ($ISE) {
        # Get the required input if not supplied when running from ISE
        if(-not($Server)) {
            do
            {
                $Server = (Read-Host "Input your Server (wapp4059p, etc): ")
            }
            until ($Server -ne '')
        }
        if(-not($Cred)) {
            do 
            {
                $Cred = Get-Credential -Message "Please provide the username/password for the SRE Script"
            }
            until ($Cred -ne [System.Management.Automation.PSCredential]::Empty)
        }
    }


    # Validate inputs
    if (-not $Server)
    {
        $exit_code = 31
        Write-Warning "Server is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    if (-not $Cred)
    {
        $exit_code = 33
        Write-Warning "Credential is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "SRE HOME Directory is $SRE_HOME"
    Write-Host "Script name is: $currentScriptName"
    Write-Host "ISE is [$ISE]"
    Write-Host "Server is [$Server]"
    Write-Host "Username is [$($Cred.UserName)]"
    #$Tidal_File = "D:\apps\Tools\InstallTidal.ps1"
    #$Tidal_Remote = "D:\apps\InstallTidal.ps1"

    # Validate server exists
    $EC1 = isValidServer($Server)

    if ($EC1 -ne 0)
    {
        $exit_code = $EC1
        Write-Warning "Invalid server [$Server]. Exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # ----------------------- Main -----------------------


    # Let's validate we are not trying to cross domains (NPE to PROD or vise-versa)
    $EC2 = validateDomain -Server $Server -RunOnLocalHost

    if ($EC2 -ne 0)
    {
        $exit_code = $EC2
        Write-Warning "Cannot start service across domains. Exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    <#
    if (-not(test-path $Tidal_File))
    {
        $exit_code = 99
        Write-Warning "Cannot find the Tidal Install scripts, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    #>

    # Now that the validations are complete, let's start the service
    Write-Host "Working on server [$Server] for Tidal Install..."

    # Set up PS Session and jobs to start service
    $Session = New-PSSession -ComputerName $Server -Credential $Cred -Verbose
    $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::SRE-InstallTidal} -ArgumentList $Cred -AsJob

    # Wait for job to complete and output the results
    $RC1 = checkJobAndLog -Session $Session -Jobs $Jobs 

    $RCode1 = $($RC1)[$($RC1.Count-1)]

    # Check exit status of jobs
    if ($RCode1 -ne 0)
    {
        $exit_code = $RCode1
        Write-Warning "ERROR: Failures during Tidal Install... RC = $RCode1"
    }
    else 
    {
        Write-Host "All good on job, Successfully Installed Tidal on server [$Server]"
    }

    # --------------------- End Main ---------------------

}
catch
{
    Write-Warning $_.Exception.ToString();
    $exit_code = 99
}

finally
{

    # Cleanup
    Remove-Module -Name SRE-Functions -ErrorAction Ignore
    Remove-Module -Name SRE-InstallTidal -ErrorAction Ignore

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}