﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	11/16/2021
	 Updated on:	11/16/2021
	 Created by:   	Jeff Angstadt
	 Organization: 	Blue Shield of California
	 Filename:     	SRE-ElementsDeleteElasticIndexesV2.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server, WINF313P or WINF4028p. 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script will run the SRE-ElementsDeleteElasticIndexesV2 script script on a TMS server.  Designed for Tidal batch job or running from command line or manually entering responses.


Date:      Who:            Changes:
-----------------------------------
11/16/2021 Jeff Angstadt    Initial

    Example

    Tidal example: -ExecutionPolicy Bypass -File 'D:\apps\jenkins\AutoCommon\powershell\SRE_Scripts\SelfHeal\SRE-ElementsDeleteElasticIndexesV2.ps1' -ElementsAppServer wapp1357h -Environment H70-ElementsMonthsToKeep 3 -elasticUrl 'http://wapp1357h.dev.bscal.local:9200'
    Command line:  ./{Directory}\SRE-ElementsDeleteElasticIndexesV2.ps1' -ElementsAppServer wapp1357h -Environment H70-ElementsMonthsToKeep 3 -elasticUrl 'http://wapp1357h.dev.bscal.local:9200'
    ISE:           ./{Directory}\SRE-ElementsDeleteElasticIndexesV2.ps1'
#>

[CmdletBinding()]
Param(
    [Parameter(Position=0,Mandatory = $True)][ValidateNotNullOrEmpty()][String]$ElementsAppServer, #= "wapp1357h",
    [Parameter(Position=1,Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Environment, # = "H70" ,
    [Parameter(Position=2,Mandatory = $True)][ValidateNotNullOrEmpty()][String]$ElementsMonthsToKeep, # = "3",
    [Parameter(Position=3,Mandatory = $True)][ValidateNotNullOrEmpty()][String]$elasticUrl # = "http://wapp1357h.dev.bscal.local:9200" ,  #to test http://wapp1357h.dev.bscal.local:9200
    #[Parameter(Position=4,Mandatory = $True)][System.Management.Automation.PSCredential]$Cred

)
<#
$ElementsAppServer = "wapp1357h"
$Environment = "H70"
$ElementsMonthsToKeep = "3"
$elasticUrl = "http://wapp1357h.dev.bscal.local:9200"   #to test http://wapp1357h.dev.bscal.local:9200
$Cred = 0
#>
try
{
    # Set some basic variables
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    
    # Import functions
    Import-Module SRE-Functions -Force -WarningAction Ignore

    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(Get-Date -Format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning "Error: SRE Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    
    $Server=$ElementsAppServer
    # Modify Input parameters as needed....
    if ($ISE) 
    {
        # Get the required input if not supplied when running from ISE
        if(-not($Server)) 
        {
            do
            {
                $Server = (Read-Host "Input your Elements App Server (wapp4059p, etc): ")
            }
            until ($Server -ne '')
        }
        if(-not($Environment)) 
        {
            do
            {
                $Environment = (Read-Host "Input your Environment (eventually app server will be derived from this) : ")
            }
            until ($Environment -ne '')
        }
        if(-not($ElementsMonthsToKeep)) 
        {
            do 
            {
                $ElementsMonthsToKeep = (Read-Host "How many months of indexes do you want to keep: ")
            }
            until ($ElementsMonthsToKeep -ne '')
        }
        if(-not($elasticUrl)) 
        {
            do 
            {
                $elasticUrl = (Read-Host "Enter your elasticUrl, (example= http://wapp1357h.dev.bscal.local:9200): ")
            }
            until ($elasticUrl -ne '')
        }
         <#
        if(-not($Cred)) 
        {
            do
            {
                $Cred = Get-Credential
            }
            until ($Cred -ne '')
        }
        #>
    }


    # Validate inputs
    if (-not $Server)
    {
        $exit_code = 31
        Write-Warning "Server is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    if (-not $Environment)
    {
        $exit_code = 32
        Write-Warning "Environment is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    if (-not $ElementsMonthsToKeep)
    {
        $exit_code = 33
        Write-Warning "ElementsMonthsToKeep is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    if (-not $elasticUrl)
    {
        $exit_code = 34
        Write-Warning "elasticUrl is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    if (-not $Cred)
    {
        #MBK lets get the needed credential...
        $domain = Get-WMIObject Win32_ComputerSystem | Select-Object -ExpandProperty domain
        if ($domain -eq "bsc.bscal.com")
        {
            if(Test-Path -Path d:\Installs\Users\AD-svcsre_prod.txt)
            {
                $usernameline = get-content -Path D:\Installs\Users\svctms_prod.txt | Select-String -Pattern USERNAME 
                $passwordline = get-content -Path D:\Installs\Users\svctms_prod.txt | Select-String -Pattern PASSWORD
            }
            else
            {
                $exit_code = 35
                Write-Warning "Credential is required and file not found to retrieve it, exiting!"
                ExitWithCode -exitcode $exit_code -ISEFlag $ISE               
            }
        }
        else
        {
            if(Test-Path -Path d:\Installs\Users\svctms_dev.txt)
            {
                $usernameline = get-content -Path D:\Installs\Users\svctms_dev.txt | Select-String -Pattern USERNAME
                $passwordline = get-content -Path D:\Installs\Users\svctms_dev.txt | Select-String -Pattern PASSWORD  
            }
            else
            {
                $exit_code = 35
                Write-Warning "Credential is required and file not found to retrieve it, exiting!"
                ExitWithCode -exitcode $exit_code -ISEFlag $ISE  
            }
        }


        $username = $usernameline.ToString().Substring(9, $usernameline.ToString().length-9)
        $password = $passwordline.ToString().Substring(9, $passwordline.ToString().length-9)
        $udecrypted = Decrypt-String "$username" "U_MyStrongPassword"
        $pdecrypted = Decrypt-String "$password" "P_MyStrongPassword"
        $ThePass = ConvertTo-SecureString –String $pdecrypted –AsPlainText -Force
        $Cred = New-Object –TypeName System.Management.Automation.PSCredential –ArgumentList $udecrypted, $ThePass

    }

    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "SRE HOME Directory is $SRE_HOME"
    Write-Host "Script name is: $currentScriptName"
    Write-Host "ISE is [$ISE]"
    Write-Host "Server is [$Server]"
    Write-Host "Elements App Server is [$ElementsAppServer]"
    Write-Host "Environment is [$Environment]"
    Write-Host "Elements Months To Keep is [$ElementsMonthsToKeep]"
    Write-Host "elasticUrl is [$elasticUrl]"
    Write-Host "Username is [$($Cred.UserName)]"

     
    # Validate server exists
    $EC1 = isValidServer($Server)

    if ($EC1 -ne 0)
    {
        $exit_code = $EC1
        Write-Warning "Invalid server [$Server]. Exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    
    # ----------------------- Main -----------------------

    # Let's validate we are not trying to cross domains (NPE to PROD or vise-versa)
    $EC2 = validateDomain -Server $Server -RunOnLocalHost

    if ($EC2 -ne 0)
    {
        $exit_code = $EC2
        Write-Warning "Cannot start service across domains. Exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Prep our variables for use in the job
    $MaxMonthToKeep = Get-Date (Get-Date).AddMonths(-$ElementsMonthsToKeep) -Format yyyy.MM
    Write-Host $MaxMonthToKeep
    $fMaxDate = Get-Date($MaxMonthToKeep)
    Write-Host $fMaxDate

    $indicesUrl = "$($elasticUrl)/_cat/indices?format=json"
    Write-Host "Getting the elasticsearch indices from $indicesUrl"
    #$indicesResponse = Invoke-RestMethod $indicesUrl -Method Get -TimeoutSec 120
   
    # Now that the validations are complete, let's run the delete elastic indexes script
    Write-Host "Attempting to run delete elastic indexes script on server [$Server]"

    # Set up PS Session
    $Session = New-PSSession -ComputerName $Server -Credential $Cred -Verbose

    # Run delete elastic indexes script
    Write-Host "Getting the elasticsearch indices from $indicesUrl"
    #Invoke-Command -Session $Session -ScriptBlock { $indicesResponse = Invoke-RestMethod $indicesUrl -Method Get -TimeoutSec 120 } -AsJob

    #$session = New-PSSession -credential $creds -ComputerName $host
    $result = Invoke-Command -session $Session -ScriptBlock {Invoke-RestMethod -Uri $args[0] -Method Get -TimeoutSec 120} -ArgumentList $indicesUrl -AsJob
    $tempjob = Get-Job -Id $result.Id
    Wait-Job -Job $tempjob
    $indicesResponse = Get-Job -Id $result.Id | Receive-Job


#Step4: Sort indices based on size descending
Write-Host "Sorting indices based on size in descending order"
$indicesObjects = @()
foreach($indexInfo in $indicesResponse)
{
    if($indexInfo.'store.size'.Contains('kb'))
    {
        $size = $indexInfo.'store.size'.Replace("kb", "")  -as [int]
        $sizeInMb = $size / 2014 -as [int]
        $size = $size * 1024
    }
    elseif($indexInfo.'store.size'.Contains('mb'))
    {
        $size = $indexInfo.'store.size'.Replace("mb", "")  -as [int]
        $sizeInMb = $size
        $size = $size * 1024 * 1024
    }
    $indicesObject = New-Object -TypeName PsObject -Property @{
	    index = $indexInfo.index
	    size =  $size
	    sizeInMb =  $sizeInMb
    }
    $indicesObjects += $indicesObject
}

#Step5: Show the indices summary to the user
Write-Host "Summary of the indices and size in MB"
$indicesObjects | Sort-Object -Property size -Descending | Select-Object -Property index, sizeInMb | ForEach {[PSCustomObject]$_} | Format-Table -AutoSize

#Step6: Run logic on each index and delete if the index is greater than the cutoff months
foreach($indicesObject in $indicesObjects | Sort-Object -Property size -Descending)
{
    	$url = $elasticUrl + "/" + $indicesObject.index
        $i = $($indicesObject.index)

     try
	    {
		    #Write-Host `n $indicesObject.index #$temp1 $p
            if ($i -like '*activity*' -Or $i -like '*kibana*'){
                Write-Host 'Skipping this one '$indicesObject.index #| Out-File -Append $LOG_FILE
            Continue
            }
            else{
                $n = $($indicesObject.index).Split('-')[1]
                $indexdate = Get-date($n)

                if ($indexdate -lt $fMaxDate){
                    Write-Host 'Yes - ' $indicesObject.index ' - ' $indexdate.ToString("yyyy.MM") ' > ' $fMaxDate.ToString("yyyy.MM") ' this file would be deleted'
                    Write-Host "$indicesObject.index  would be deleted"
                    
                    #get contents of the job to be deleted for the log file                   
                    #original        $response = Invoke-RestMethod $url -Method Get -TimeoutSec 120 #-Method Delete
                    $response = Invoke-Command -session $Session -ScriptBlock {Invoke-RestMethod -Uri $args[0] -Method Get -TimeoutSec 120} -ArgumentList $Url -AsJob
                    $tempjob = Get-Job -Id $response.Id
                    Wait-Job -Job $tempjob
                    $responseindice = Get-Job -Id $response.Id | Receive-Job
                    Write-Host "Deleted index "$indicesObject.index " contents `n $responseindice"
                    #cleanup by deleting the GET job
                    Write-Host "Job removed " $response.Id
                    $deletedeindice = Get-Job -Id $response.Id | Remove-Job

                    #deleting the index                                                                                Make this delete when through testing
                    $dresponse = Invoke-Command -session $Session -ScriptBlock {Invoke-RestMethod -Uri $args[0] -Method Get -TimeoutSec 120} -ArgumentList $Url -AsJob
                    $dtempjob = Get-Job -Id $dresponse.Id
                    Wait-Job -Job $dtempjob
                    $dresponseindice = Get-Job -Id $dresponse.Id | Receive-Job
                                        
                    #cleanup by deleting the DELETE job
                    Write-Host "Job removed " $dresponse.Id
                    $deletethejob = Get-Job -Id $dresponse.Id | Remove-Job

                    }
                else{
                    Write-Host 'No - ' $indicesObject.index ' - ' $indexdate.ToString("yyyy.MM") ' < ' $fMaxDate.ToString("yyyy.MM") ' this index would NOT be deleted' #| Out-File -Append $LOG_FILE
                    }
                  }
              }
    catch
	    {
		    LogError "Failed to get the index '$($indicesObject.index)' from '$($elasticUrl)'"
	    }
}
#Step7: Cleanup by removing the Jobs and PSSessions
    Get-Job  | Remove-Job
    Get-PSSession | Remove-PSSession -ErrorAction SilentlyContinue

}
catch
{
    Write-Warning $_.Exception.ToString();
    $exit_code = 99
}

finally
{

    # Cleanup
    Remove-Module -Name SRE-Functions

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}
