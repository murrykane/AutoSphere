﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	05/26/2020
	 Updated on:	05/26/2020
	 Created by:   	Kyle Kane
	 Organization: 	Blue Shield of California
	 Filename:     	VDI_PowerState_Unknown.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server, WINF313P or WINF4028p. 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script will restart the VM related to the PowerState Unknown alert.
        This alert occurs when vCenter stops talking w/ Citrix XenDesktop infrastructure
        Do NOT run this unless you intend to restart the environment.


Date:      Who:            Changes:
-----------------------------------
05/26/2020 Kyle Parrott      Initial

    Example

    ./{Directory}\VDI_PowerState_Unknown.ps1 -Server <serverName> -Cred <PSCredential> 
#>

[CmdletBinding()]
Param(
    [Parameter(Mandatory=$true,Position=0)]
    [string]$Server,
    [Parameter(Mandatory=$true,Position=1)]
    [System.Management.Automation.PSCredential]$Cred
    )


function Restart-vCenter($Server,$VCenterServer) {
    try {
        Write-Host "Restarting [$Server] using VCenter [$VCenterServer]"
        $Con = Connect-VIServer -Server $VCenterServer -Credential $Cred
        Write-Host "Connected to [$VCenterServer]"
        Get-VM -Name $Server | Restart-VMGuest -Confirm:$false
        Write-Host "Issued command to restart [$Server]"
        Disconnect-VIServer -Server $Con -Confirm:$false
        Write-Host "Disconnected from [$VCenterServer]"
        return $true
    }
    catch {
        Write-Warning $_.Exception.ToString()
        return $false
    }
}

function Send-VCenterRebootEmail($Server,$VCenterServer) {
    try {
        #$To = "kyle.parrott@blueshieldca.com"
        #$To = "ITServerEngineering@blueshieldca.com"
        $To = "ITInfrastructurePlatformEngineering@blueshieldca.com"
        $From = "IT-SiteReliabilityEngineering@blueshieldca.com"
        $Subject = "Self-Heal Restarting [$Server] for Power State Unknown Alert"
        $SmtpServer = "emailrelay.bsc.bscal.com"
        $Port = "25"
        $Body = "Hello,</br></br>Please note that [$Server] is being restarted using VCenter [$VCenterServer] as part of the self-heal for VDI Power State Unknown.</br></br>Please reach out to IT-SiteReliabilityEngineering@blueshieldca.com with any questions."

        Write-Host "Sending email notification to [$To]"

        Send-MailMessage -To $To -From $From -Subject $Subject -SmtpServer $SmtpServer -Port $Port -Body $Body -BodyAsHtml

        Write-Host "Successfully sent email notification"
    }
    catch {
        Write-Warning "ERROR: Failed to send email to [$To]"
        Write-Warning $_.Exception.ToString();
    }
}

function Get-DeliveryControllerServerSession($Colo,$Cred) {
    try {
        #$SacDCServers = @("wcin108p","wcin109p","wcin154p") # Decommed 8/26/2020
        $SacDCServers = @("wapp4829p","wapp4830p","wapp4831p")
        $LasDCServers = @("wcin125p","wcin126p","wcin158p")

        if ($Colo -eq "sac") {
            $DCServers = $SacDCServers
        }
        else {
            $DCServers = $LasDCServers
        }

        foreach ($DCServer in $DCServers) {
            if (Test-Connection -ComputerName $DCServer -Quiet) {
                $DCSession = New-PSSession -ComputerName $DCServer -Credential $Cred
                return $DCSession
            }
            else {
                Write-Warning "Delivery controller [$DCServer] failed test connection."
            }
        }

        return $null
    }
    catch {
        Write-Warning $_.Exception.ToString()
        return $null
    }
}



function Validate-Powerstate($DCSession) {
    try {      
        Invoke-Command -Session $DCSession -ScriptBlock { asnp citrix* } | Out-Null
        $Threshold = 200
        $Powerstate = Invoke-Command -Session $DCSession -ScriptBlock { (Get-BrokerMachine -PowerState unknown -maxrecordcount 5000).count}
        Write-Host "Power state unknown count is [$Powerstate] and threshold is [$Threshold]"
        if ($PowerState -ge $Threshold) {
            return $false
        } 
        else {
            return $true
        }
    }
    catch {
        Write-Warning $_.Exception.ToString()
        return $false
    }
}



try
{
    # Set some basic variables
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    
    # Import functions
    Import-Module SRE-Functions -Force -WarningAction SilentlyContinue

    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning "Error: SRE Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }


    # Modify Input parameters as needed...
    if ($ISE) {
        # get the required input if not supplied when running from ISE
        if(-not($Server)) {
            do
            {
                $Server = (Read-Host "Input the server name (ex: winf2286n): ")
            }
            until ($Server -ne '')
        }
        if(-not($Cred)) {
            do
            {
                $Cred = Get-Credential -ErrorAction SilentlyContinue
            }
            until ($Cred -ne '')
        }
    }

    # Validate inputs
    if (-not $Server)
    {
        $exit_code = 30
        Write-Warning "Server is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    if (-not $Cred)
    {
        $exit_code = 35
        Write-Warning "Credential is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "SRE HOME Directory is $SRE_HOME"
    Write-Host "Script name is: $currentScriptName"
    Write-Host "ISE is [$ISE]"
    Write-Host "Server is [$Server]"
    Write-Host "Username is [$($Cred.UserName)]"

    #ALL the main code should go below here 
    #######################################
    
    # Set COLO / Validate Server
    if ($Server -eq "wcin107p") {
        $Colo = "sac"
        $VCenterServer = "winf235p"
    }
    elseif ($Server -eq "wcin124p") {
        $Colo = "las"
        $VCenterServer = "winf240p"
    }
    else {
        Write-Warning "ERROR: Invalid server [$Server] passed to script."
        $exit_code = 10
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Restart vCenter
    if (Restart-vCenter -Server $Server -VCenterServer $VCenterServer) {
        Write-Host "Successfully restarted VMGuests for [$Server]"
        Send-VCenterRebootEmail -Server $Server -VCenterServer $VCenterServer
    }
    else {
        Write-Warning "ERROR: Unable to restart VMGuests for [$Server]"
        $exit_code = 15
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Set Delivery Controller Server
    Write-Host "Determining which delivery controller to run powerstate unknown validation on for colo [$Colo]"
    $DCSession = Get-DeliveryControllerServerSession -Colo $Colo -Cred $Cred
    
    if ($DCSession -eq $null) {
        Write-Warning "ERROR: Unable to create remoting session on delivery conroller."
        $exit_code = 18
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    
    $DCServer = $DCSession.ComputerName

    if ($DCServer -eq $null) {
        Write-Warning "ERROR: Unable to identify an available delivery conroller."
        $exit_code = 20
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    else {
        Write-Host "Selected delivery controller [$DCServer]"
    }

    $SleepTime = 300 # 5 mins
    $Loop = 1
    $MaxLoops = 3

    Write-Host "Validating that the powerstate unknown issue has been resolved for vCenter [$Server] using delivery controller [$DCServer]"

    While ($Loop -le $MaxLoops) {
        Write-Host "Starting Attempt $Loop/$MaxLoops"
        Write-Host "Sleeping for [$SleepTime] seconds prior to attempting to validate the issue has been resolved..."
        Start-Sleep -Seconds $SleepTime

        if (Validate-Powerstate -DCSession $DCSession) {
            Write-Host "Successfully resolved powerstate unknown issue"
            break
        }
        elseif ($Loop -eq $MaxLoops) {
            Write-Warning "ERROR: Unable to validate powerstate unknown count is below the threshold."
            $exit_code = 25
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE
        }
        else {
            Write-Warning "WARNING: Validation failed for attempt $Loop/$MaxLoops"
        }
        $Loop += 1
    }

    #end main code#########################


}
catch
{
    Write-Warning $_.Exception.ToString();
    $exit_code = 99
}

finally
{

    #cleanup
    Remove-Module -Name SRE-Functions
    $DCSession | Remove-PSSession -ErrorAction Continue

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}