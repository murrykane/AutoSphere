print "hello world"

print "Hi"

print "test line break \n"

print "next line"

raise "Exception!!!"

exit(7)