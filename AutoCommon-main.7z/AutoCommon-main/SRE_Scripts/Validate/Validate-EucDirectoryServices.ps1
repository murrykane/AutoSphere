﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	05/07/2020
	 Updated on:	05/07/2020
	 Created by:   	Kyle Parrott
	 Organization: 	Blue Shield of California
	 Filename:     	Template.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server, WINF313P or WINF4028p. 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script runs the 'AD Services Daily Status' scheduled task in order to 
        peform a health check for EUC directory services.


Date:      Who:            Changes:
-----------------------------------
05/07/2020 Kyle Parrott      Initial
09/13/2021 Vitaliy Fanin     Updated server from winf363p to winf40412p

    Example

    ./{Directory}\Validate-EucDirectoryServices.ps1 
#>

[CmdletBinding()]
Param(
  [Parameter(Mandatory=$false,Position=0)]
  [string]$Server="winf40412p"
)

function Start-HealthCheck() {
    try {
        $Log = ""
        function Write-Log($Output) {
            Write-Host $Output
            $Global:Log += "`r`n" + $Output
        }
        
        $TaskPath="\Directory Services\"
        $TaskName="AD Services Daily Status"


        Write-Log "Attempting to run scheduled task '$TaskPath$TaskName'"
        
        # Wait on Scheduled Task
        #--------------------------------------------------------------------

        $Task = Get-ScheduledTask -TaskName $TaskName -TaskPath $TaskPath

        if ($Task.TaskName.Count -eq 0) {
            Write-Log "ERROR: No scheduled task found."
            return @(10,$Log)
        }

        if ($Task.TaskName.Count -ne 1) {
            Write-Log "ERROR: More than one scheduled task found."
            return @(20,$Log)
        }

        # Start Task
        $Task | Start-ScheduledTask

        $StartTime=Get-Date
        $Timeout=1800 # 30 mins
        $InitialSleepTime = 5
        $SleepTime = 15

        # Wait for task to start
        Start-Sleep -Seconds $InitialSleepTime

        While ((Get-ScheduledTask -TaskName $TaskName).State -ne "Ready") {
            $TimeElapsed = [math]::Round(((Get-Date) - $StartTime).TotalSeconds)
        
            if ($TimeElapsed -gt $Timeout) {
                Write-Log "ERROR: Timeout exceeded while waiting for scheduled task."
                return @(30,$Log)
            }

            Write-Log "Wating on scheduled task... Timeout is [$Timeout] seconds. Time elapsed is [$TimeElapsed] seconds"
            Write-Log "Sleeping for [$SleepTime] seconds"
            Start-Sleep -Seconds $SleepTime
        }

        Write-Log "Scheduled task is complete"
        #--------------------------------------------------------------------

        # Get Report
        $Date = Get-Date -Format "yyyy-MM-dd"
        $ReportPath = "D:\Reports\BSC-services-status-$Date.htm"

        Write-Log "Getting content for report [$ReportPath]"
        $ReportContent = Get-Content $ReportPath

        if ([string]::IsNullOrEmpty($ReportContent)) {
            Write-Log "Report content was empty for [$ReportPath]"
            return @(40,$Log)
        }
        elseif ($ReportContent -match "lightpink") {
            Write-Log "ERROR: The report contained at least one error message!"
            return @(1,$Log)
        }
        elseif ($ReportContent -match "yellow") {
            Write-Log "ERROR: The report contained at least one yellow warning message!"
            return @(2,$Log)
        }
        else {
            Write-Log "Health check was successful."
            return @(0,$Log)
        }
    }
    catch {
        Write-Log "Unexpected Error:`n$($_.Exception.ToString())"
        return @(100,$Log)
    }
}

try
{
    # Set some basic variables
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    
    # Import functions
    Import-Module SRE-Functions -Force -WarningAction SilentlyContinue

    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning "Error: SRE Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }


    # Modify Input parameters as needed...
    if ($ISE) {
        # get the required input if not supplied when running from ISE
        if(-not($Server)) {
            do
            {
                $Server = (Read-Host "Input the server name (ex: winf2286n): ")
            }
            until ($Server -ne '')
        }
    }

    # Validate inputs
    if (-not $Server)
    {
        $exit_code = 30
        Write-Warning "Server is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "SRE HOME Directory is $SRE_HOME"
    Write-Host "Script name is: $currentScriptName"
    Write-Host "ISE is [$ISE]"
    Write-Host "Server is [$Server]"
    Write-Host "Username is [$env:USERNAME]"

    #ALL the main code should go below here 
    #######################################

    $Session = New-PSSession -ComputerName $Server
    
    $exit_code,$Log = Invoke-Command -Session $Session -ScriptBlock ${function:Start-HealthCheck}

    Write-Host "=============================== Start Remote Job Log ==============================="
    Write-Host $Log 
    Write-Host "================================ End Remote Job Log ================================"

    #end main code#########################
}
catch
{
    Write-Warning $_.Exception.ToString();
    $exit_code = 99
}

finally
{

    #cleanup
    Remove-Module -Name SRE-Functions
    Remove-PSSession -Session $Session -ErrorAction SilentlyContinue

    Write-Host "All done with: $currentScriptName"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}