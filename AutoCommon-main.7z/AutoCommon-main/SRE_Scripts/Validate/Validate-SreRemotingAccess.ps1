﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	05/07/2020
	 Updated on:	05/07/2020
	 Created by:   	Kyle Parrott
	 Organization: 	Blue Shield of California
	 Filename:     	Template.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server, WINF313P or WINF4028p. 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script queries service now for all production, operational windows servers and then loops through them to create a PSSession.
        It creates a log of any servers that we are unable to create a PSSession on to validate user access levels


Date:      Who:            Changes:
-----------------------------------
05/07/2020 Kyle Parrott      Initial

    Example

    ./{Directory}\Validate-SreRemotingAccess.ps1 
#>

# Quick way to test PSSession connection success rate on our windows environment
function Get-ServerList {
   $SNowCred = Get-ServiceNowCredential

    $UriBase = Get-ServiceNowUriBase

    # Query Server to App Relationship Table
    $Uri = "$UriBase/api/now/table/cmdb_ci_win_server?sysparm_query=used_for%3DProduction%5Eoperational_status%3D1&sysparm_fields=name&sysparm_limit=2000"

    $Result = Query-ServiceNowApi -Uri $Uri -SNowCred $SNowCred

    $Servers = $Result.name

    return $Servers
}

$Servers = Get-ServerList
$BadServers = @()

$ServersLength = $Servers.Length
$Cnt = 1

foreach ($Server in $Servers) {
    try {
        Write-Host "[$Cnt] of [$ServersLength] : Testing Connection to [$Server]"
        $Session = New-PSSession -ComputerName $Server -ErrorAction Stop
        $Cnt += 1
        $Session | Remove-PSSession -ErrorAction Continue
    }
    catch {
        Write-Warning "Could not connect to [$Server]"
        $BadServers += @($Server)
        $Cnt += 1
    }
}

$FileName = "D:\apps\logs\ServersWithErrors$(get-date -format s | foreach {$_ -replace ":", "-"}).txt"

$BadServers | Out-File -FilePath $FileName -Force