﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	07/28/2020
	 Updated on:	07/28/2020
	 Created by:    Meghana Kalluri
	 Organization: 	Blue Shield of California
	 Filename:     	PromiseHealthValidation.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server, WINF313P or WINF4028p. 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
        IOS-220
        This automation will monitor the URL for Promise Health and validate that it is up and running. The Tidal Job for this will run daily
        as well as on post maintenance weekends to validate health.


Date:      Who:            Changes:
-----------------------------------
07/28/2020 Meghana Kalluri Initial

    Example

    ./{Directory}\PromiseHealthValidation.ps1
#>

$websites = "https://promise.blueshieldca.com/ca/providersearch?version=2020&lob=medi-cal"

$AllProtocols = [System.Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12'
[System.Net.ServicePointManager]::SecurityProtocol = $AllProtocols

[System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
add-type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
        ServicePoint srvPoint, X509Certificate certificate,
        WebRequest request, int certificateProblem) {
        return true;
    }
}
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy


function Ignore-SSLCertificates
{
    $Provider = New-Object Microsoft.CSharp.CSharpCodeProvider
    $Compiler = $Provider.CreateCompiler()
    $Params = New-Object System.CodeDom.Compiler.CompilerParameters
    $Params.GenerateExecutable = $false
    $Params.GenerateInMemory = $true
    $Params.IncludeDebugInformation = $false
    $Params.ReferencedAssemblies.Add("System.DLL") > $null
    $TASource=@'
        namespace Local.ToolkitExtensions.Net.CertificatePolicy
        {
            public class TrustAll : System.Net.ICertificatePolicy
            {
                public bool CheckValidationResult(System.Net.ServicePoint sp,System.Security.Cryptography.X509Certificates.X509Certificate cert, System.Net.WebRequest req, int problem)
                {
                    return true;
                }
            }
        }
'@ 
    $TAResults=$Provider.CompileAssemblyFromSource($Params,$TASource)
    $TAAssembly=$TAResults.CompiledAssembly
    ## We create an instance of TrustAll and attach it to the ServicePointManager
    $TrustAll = $TAAssembly.CreateInstance("Local.ToolkitExtensions.Net.CertificatePolicy.TrustAll")
    [System.Net.ServicePointManager]::CertificatePolicy = $TrustAll
}

#for DMGR Consoles need to ignore SSL errors....
Ignore-SSLCertificates


try
{
    # Set some basic variables
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    
    # Import functions
    Import-Module SRE-Functions -Force

    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning "Error: SRE Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }


    # Modify Input parameters as needed...


    #validate inputs


    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "SRE HOME Directory is $SRE_HOME"
    Write-Host "Script name is: $currentScriptName"
    Write-Host "ISE is [$ISE]"

    #ALL the main code should go below here 
    #######################################
    Foreach($s in $servers) {
        Test-Connection -Cn $s -BufferSize 32 -ea 0 
        if(!(Test-Connection -Cn $s -BufferSize 32 -Count 1 -ea 0 -quiet)) {
            "Server $s can not be reached"
            $exit_code++
        }
        else {
            "Server $s is up and running"
        }
    }
    Foreach($w in $websites) {
        Write-Host "Sending HTTP Request to URL $w"
        try {
            $HTTP_Request = [System.Net.WebRequest]::Create($w)
            $HTTP_Response = $HTTP_Request.GetResponse()
            $HTTP_Status = [int]$HTTP_Response.StatusCode
            If ($HTTP_Status -eq 200) {
                Write-Host "URL $w is OK!"
            }
        }
        catch {
            Write-Host "Exception was caught for URL $w. This site might be down."
            $exit_code++
        }
        If ($HTTP_Response -eq $null) { } 
        Else { $HTTP_Response.Close() }
    }
    #end main code#########################


}
catch
{
    Write-Warning $_.Exception.ToString();
    $exit_code = 99
}

finally
{

    #cleanup
    Remove-Module -Name SRE-Functions

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}