﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	05/20/2020
	 Updated on:	05/20/2020
	 Created by:   	Kyle Parrott
	 Organization: 	Blue Shield of California
	 Filename:     	Validate-SymantecDlp.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server, WINF313P or WINF4028p. 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script will run a validation / health check of Symantec DLP.
        Created per IOS-110 in JIRA.


Date:      Who:            Changes:
-----------------------------------
05/20/2020 Kyle Parrott     Initial

    Example

    ./{Directory}\Validate-SymantecDlp.ps1
#>

function Get-SymantecDlpServerList {
    try {
        $SNowCred = Get-ServiceNowCredential

        $UriBase = Get-ServiceNowUriBase

        # Query Server to App Relationship Table
        Write-Host "Querying ServiceNow API for Symantec DLP servers from the u_srvr_to_app_rel table"
        $Uri = "$UriBase/api/now/table/u_srvr_to_app_rel?sysparm_query=u_application.name%3DSymantec%20Data%20Loss%20Prevention%20(DLP)%5Eu_server.install_status%3D11&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=u_server&sysparm_limit=1000"
        $Result = Query-ServiceNowApi -Uri $Uri -SNowCred $SNowCred

        $Servers = $Result.u_server

        # Filter Server List
        Write-Host "Filtering server list to only production servers"
        $Uri = Get-ServiceNowServerQueryUri -Servers $Servers
        $Result = Query-ServiceNowApi -Uri $Uri -SNowCred $SNowCred

        # Only Windows production servers
        $Servers = $($Result | Where-Object { $_.sys_class_name -eq "cmdb_ci_win_server" -and $_.used_for -eq "Production"}).name

        # No wsql servers
        $Servers = $Servers | Where-Object { $_ -NotLike "wsql*" }

        return $Servers
    }
    catch {
        return $null
    }
}

function Test-DlpService {
    try {
        $Services = Get-Service -Name "SymantecDLP*"
        
        foreach ($Service in $Services) {
            $ServiceName = $Service.Name
            $Status = $Service.Status
        
            Write-Host "Found service [$ServiceName]"

            if ($Status -ne "Running") {
                return 1
            }
        }

        return 0
    }
    catch {
        return 2
    }
}

function Test-SymantecDlpServer($Server) {
    try {
        Write-Host $Header
        Write-Host "Starting validation for server [$Server]"
        
        # Check IP Address is Resolvable
        $ec = isValidServer -Server $Server
        if ($ec -ne 0) {
            return 1
        }

        if (Test-Connection -ComputerName $Server -Quiet) {
            $Session = New-PSSession -ComputerName $Server


            Write-Host "Validating state of Symantec DLP Service"
            
            $ec = Invoke-Command -Session $Session -ScriptBlock ${function:Test-DlpService}

            $Session | Remove-PSSession

            if ($ec -eq 0) {
                Write-Host "All Symantec DLP services are running"
            }
            else {
                Write-Warning "Service is NOT running for server [$Server]. Test-DlpService returned code [$ec]"
                return 5
            }

            Write-Host "Successfully completed validation for server [$Server]"
            Write-Host $Header
            
            return 0
        }
        else {
            Write-Warning "ERROR: Test connection failed for server [$Server]"
            return 10
        }
    }
    catch {
        Write-Warning $_.Exception.ToString();
        return 20
    }
}

function Test-WebUri($Uri) {
    try {
        $Response = Invoke-WebRequest -Uri $Uri -TimeoutSec 10 -UseBasicParsing
        if([string]::IsNullOrEmpty($Response.StatusCode)) {
            $ec = 998
        }
        else {
            $ec = $Response.StatusCode
        } 

        return $ec
    }
    catch {
        return $ec = 999
    }
}

try
{
    # Set some basic variables
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    
    # Import functions
    Import-Module SRE-Functions -Force -WarningAction SilentlyContinue
    Import-Module SnowFunctions -Force -WarningAction SilentlyContinue

    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning "Error: SRE Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "SRE HOME Directory is $SRE_HOME"
    Write-Host "Script name is: $currentScriptName"
    Write-Host "ISE is [$ISE]"

    #============================= Main =============================#
    $Header = "===================================================================================="

    $Servers = Get-SymantecDlpServerList

    if ($Servers -eq $null) {
        $exit_code = 60
        Write-Warning "ERROR: The server list is null. Exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    Write-Host "Validating the following Symantec DLP Servers: $($Servers -Join ',')"

    foreach ($Server in $Servers) {
        $ec = Test-SymantecDlpServer -Server $Server
        
        if ($ec -ne 0) {
            Write-Warning "Unable to validate server [$Server] - returned code [$ec]"
            $exit_code += 1
        }
    }
    
    # Validate Web Portal
    $Uri = "https://wapp4299p/ProtectManager/Logon"
    Write-Host $Header
    Write-Host "Validating the following website [$Uri]"
    
    $ec = Test-WebUri -Uri $Uri

    if ($ec -eq 200) {
        Write-Host "Successfully validated website [$Uri]"
    }
    else {
        Write-Warning "ERROR: Failed to validate website [$Uri]. Returned code [$ec]."
        $exit_code += 1
    }

    Write-Host $Header
    #=========================== End Main ===========================#


}
catch
{
    Write-Warning $_.Exception.ToString();
    $exit_code = 99
}

finally
{
    #cleanup
    Remove-Module -Name SRE-Functions
    Remove-Module -Name SnowFunctions

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}