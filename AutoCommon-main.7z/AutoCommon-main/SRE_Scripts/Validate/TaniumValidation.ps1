﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	04/07/2020
	 Updated on:	04/07/2020
	 Created by:   	Jupp Valdez
	 Organization: 	Blue Shield of California
	 Filename:     	Template.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server, WINF313P or WINF4028p. 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
        IOS-116
        The automation will validate that ENC Tanium Servers pingable
        wsec4000p/wsec4001p
        The automation will validate that ENC Tanium URLs are reachable
        https://wsec4000p.bsc.bscal.com/#/login/
        The Automation will run a basic ENC Tanium query or set of queries and ensure valid results are returned


Date:      Who:            Changes:
-----------------------------------
04/07/2020 Jupp Valdez     Initial

    Example

    ./{Directory}\TaniumValidation.ps1
#>

$servers = "wsec4000p","wsec4001p"
$websites = "https://wsec4000p.bsc.bscal.com/#/login/"
#The URL for https://wsec4001p.bsc.bscal.com/#/login/ is currently unreachable as there is no GUI for the site.

#Fix to try to bypass SSL certificates as Ryan Thrift says the certificate for wsec4000p needs to be updated
$AllProtocols = [System.Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12'
[System.Net.ServicePointManager]::SecurityProtocol = $AllProtocols

[System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
add-type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(
        ServicePoint srvPoint, X509Certificate certificate,
        WebRequest request, int certificateProblem) {
        return true;
    }
}
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy


function Ignore-SSLCertificates
{
    $Provider = New-Object Microsoft.CSharp.CSharpCodeProvider
    $Compiler = $Provider.CreateCompiler()
    $Params = New-Object System.CodeDom.Compiler.CompilerParameters
    $Params.GenerateExecutable = $false
    $Params.GenerateInMemory = $true
    $Params.IncludeDebugInformation = $false
    $Params.ReferencedAssemblies.Add("System.DLL") > $null
    $TASource=@'
        namespace Local.ToolkitExtensions.Net.CertificatePolicy
        {
            public class TrustAll : System.Net.ICertificatePolicy
            {
                public bool CheckValidationResult(System.Net.ServicePoint sp,System.Security.Cryptography.X509Certificates.X509Certificate cert, System.Net.WebRequest req, int problem)
                {
                    return true;
                }
            }
        }
'@ 
    $TAResults=$Provider.CompileAssemblyFromSource($Params,$TASource)
    $TAAssembly=$TAResults.CompiledAssembly
    ## We create an instance of TrustAll and attach it to the ServicePointManager
    $TrustAll = $TAAssembly.CreateInstance("Local.ToolkitExtensions.Net.CertificatePolicy.TrustAll")
    [System.Net.ServicePointManager]::CertificatePolicy = $TrustAll
}

#for DMGR Consoles need to ignore SSL errors....
Ignore-SSLCertificates


try
{
    # Set some basic variables
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    
    # Import functions
    Import-Module SRE-Functions -Force

    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning "Error: SRE Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }


    # Modify Input parameters as needed...


    #validate inputs


    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "SRE HOME Directory is $SRE_HOME"
    Write-Host "Script name is: $currentScriptName"
    Write-Host "ISE is [$ISE]"

    #ALL the main code should go below here 
    #######################################
    Foreach($s in $servers) {
        Test-Connection -Cn $s -BufferSize 32 -ea 0 
        if(!(Test-Connection -Cn $s -BufferSize 32 -Count 1 -ea 0 -quiet)) {
            "Server $s can not be reached"
            $exit_code++
        }
        else {
            "Server $s is up and running"
        }
    }
    Foreach($w in $websites) {
        Write-Host "Sending HTTP Request to URL $w"
        try {
            $HTTP_Request = [System.Net.WebRequest]::Create($w)
            $HTTP_Response = $HTTP_Request.GetResponse()
            $HTTP_Status = [int]$HTTP_Response.StatusCode
            If ($HTTP_Status -eq 200) {
                Write-Host "URL $w is OK!"
            }
        }
        catch {
            Write-Host "Exception was caught for URL $w. This site might be down."
            $exit_code++
        }
        If ($HTTP_Response -eq $null) { } 
        Else { $HTTP_Response.Close() }
    }
    #end main code#########################


}
catch
{
    Write-Warning $_.Exception.ToString();
    $exit_code = 99
}

finally
{

    #cleanup
    Remove-Module -Name SRE-Functions

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}