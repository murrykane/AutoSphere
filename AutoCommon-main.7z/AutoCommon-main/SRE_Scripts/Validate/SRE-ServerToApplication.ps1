﻿<#	
	.NOTES
	===========================================================================
	 Created on:    01/07/2020
	 Updated on:	01/07/2020
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:      SRE-ServerToApplication.ps1

	The scripts being built in this grouping are for SRE Production Support
	The majority will be run from the Primary SRE Server, WINF2286N, WINF3095P or WINF3096p.
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script will collect data needed for a application to server mapping for the provided list of servers

MODIFICATIONS
_____________________________________________________________________________________________________________________________
    Date        By            Reason
    09/01/2020  Murry Kane    Initial
    03/102/2021 Murry Kane    Used PScustomObject to speed up array processing 
                              added switch to skip ping test for large amount of CI CMDB processing 
_____________________________________________________________________________________________________________________________
    PARMS

    Server List   - Vcenter Server this will most likely be one of the following: WCIN107P, wcin124P, WINF235P, WINF236P, WINF240P, AND WINF242P

    .Examples 

    SRE-ServerToApplication.ps1 -Servers winf4545p,wapp4545p,wapp4241p,wappXXX,wappXXXX,etc....
    SRE-ServerToApplication.ps1 -FileName d:\temp\ServersToMap.csv

#>

[CmdletBinding()]
Param(
    [Parameter(Position=0)]
    [string[]]$Servers,
    [Parameter(Position=1)]
    [string]$FileList,
    [Parameter(Position=2)]
    [bool]$SkipPing = $false
)

try
{

    # Set some basic variables
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    $csvContents = @()

    # Import functions
    Import-Module SRE-Functions -Force -WarningAction Ignore
    Import-Module SnowFunctions -Force -WarningAction SilentlyContinue

    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"
    $CSVReport = "D:\Reports\ServerToApplicaiton_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".csv"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning "WARNING: SRE Management Server Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Modify Input parameters as needed....
    if ($ISE) {
        # Get the required input if not supplied when running from ISE
        if(-not($Servers) -and -not($FileList)) {
            do
            {
                $Servers = (Read-Host "Input your Server List(WAPP###P or WINF###P, etc): ")
                $FileList = (Read-Host "Input your Server File Name(d:\temp\ServerList.csv): ")
            }
            until ($Servers -ne '' -or $FileList -ne '')
        }
    }

    
    # Validate inputs
    if (-not $Servers -and -not $FileList)
    {
        $exit_code = 31
        Write-Warning "Server list or File List is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    if(-not $Servers)
    {
        if(Test-Path $FileList -PathType Leaf)
        {
            Write-Host "Validated file exits, getting list of servers from it"
            $Servers = Get-Content -Path $FileList
        }   
        else
        {
            $exit_code = 38
            Write-Warning "Server list file [$FileList], does not exist, exiting!"
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE
        }     
    }

    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "SRE HOME Directory is $SRE_HOME"
    Write-Host "Script name is: $currentScriptName"
    Write-Host "ISE is [$ISE]"
    Write-Host "Server list is [$Servers]"
    Write-Host "Servers file list is [$FileList]"
    Write-Host "Report is: [$CSVReport]"


    # ----------------------- Main -----------------------

    $SNowCred = Get-ServiceNowCredential
    Write-Host "SNOW Cred is [$($SnowCred.UserName)]"

    $UriBase = Get-ServiceNowUriBase
    Write-Host "SNOW Base is [$UriBase]"

    # Query Server to App Relationship Table
    Write-Host "Querying ServiceNow API for server to application mapping (u_srvr_to_app_rel table)"
    #$Uri = "$UriBase/api/now/table/u_srvr_to_app_rel?sysparm_query=u_application.name%3DSymantec%20Data%20Loss%20Prevention%20(DLP)%5Eu_server.install_status%3D11&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=u_server&sysparm_limit=1000"
    $Uri = "$UriBase/api/now/table/u_srvr_to_app_rel?sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=u_server%2Cu_server.sys_class_name%2Cu_server.ref_cmdb_ci_hardware.used_for%2Cu_server.ref_cmdb_ci_computer.os%2Cu_server.ref_cmdb_ci_computer.os_version%2Cu_server.ref_cmdb_ci_hardware.hardware_status%2Cu_application%2Cu_application.ref_cmdb_ci_appl.u_number%2Cu_application.ref_cmdb_ci_appl.u_business_criticality%2Cu_application.install_status%2Cu_application.supported_by%2Cu_application.managed_by%2Cu_application.owned_by%2Cu_application.support_group&sysparm_limit=20000"
        
    $Result = Query-ServiceNowApi -Uri $Uri -SNowCred $SNowCred
    #$Result is an array of objects for every CDMB Server to Applicaiton mapping...

    #lets build the custom object to be used for the report
    $cmdbArray = @()
    For ($i=0; $i -le $Result.Count; $i++) {
        $lsrvr = $Result[$i].u_server 
        $usedfor = $Result[$i].'u_server.ref_cmdb_ci_hardware.used_for'
        $appl = $Result[$i].'u_application'
        $crit = $Result[$i].'u_application.ref_cmdb_ci_appl.u_business_criticality'
        $supportby = $Result[$i].'u_application.supported_by'
        $managedby = $Result[$i].'u_application.managed_by'
        $supportgrp = $Result[$i].'u_application.support_group'
        $row = New-Object System.Object
        $row | Add-Member -MemberType NoteProperty -Name "Server" -Value $lsrvr
        $row | Add-Member -MemberType NoteProperty -Name "OpStatus" -Value $usedfor
        $row | Add-Member -MemberType NoteProperty -Name "Appl" -Value $appl                 
        $row | Add-Member -MemberType NoteProperty -Name "BusCrit" -Value $crit
        $row | Add-Member -MemberType NoteProperty -Name "Supp" -Value $supportby
        $row | Add-Member -MemberType NoteProperty -Name "Manager" -Value $managedby
        $row | Add-Member -MemberType NoteProperty -Name "Team" -Value $supportgrp
        $cmdbArray += $row
    }

    ################################
    $Servers |  foreach-object -Process { 
        $server = $_.toString()
        write-host "Working on Server: [$server]"

        # first add a column to denote health of failed over server....
        $hostStatus = 'Skipped'
        if(-not $SkipPing)
        {
            $hostStatus = 'Offline'
            if (Test-Connection $server -BufferSize 16 -Count 1 -ea 0 -quiet) 
            {
                $hostStatus = 'Online'
            }
        }
        else
        {
            $hostStatus = 'Skipped'
        }

        $foundRecs = $cmdbArray | where Server -eq $server
        if($foundRecs.count -gt 0)
        {
            write-host "need to add the records to the list... records found is $($foundRecs.count)"
            $foundRecs | ForEach-Object -Process {
                $row = New-Object System.Object
                Write-Verbose "working on row..."
                $row | Add-Member -MemberType NoteProperty -Name "Server" -Value $_.Server
                $row | Add-Member -MemberType NoteProperty -Name "Operational Status" -Value $_.OpStatus
                $row | Add-Member -MemberType NoteProperty -Name "Application" -Value $_.Appl
                $row | Add-Member -MemberType NoteProperty -Name "Business Criticality" -Value $_.BusCrit
                $row | Add-Member -MemberType NoteProperty -Name "Supported by" -Value $_.Supp
                $row | Add-Member -MemberType NoteProperty -Name "Manager" -Value $_.Manager
                $row | Add-Member -MemberType NoteProperty -Name "Support Team" -Value $_.Team
                $row | Add-Member -MemberType NoteProperty -Name "Host Status" -Value $hostStatus
                $csvContents += $row               
            }
        }
        else
        {
            write-host "not found [$server] adding an empty row...." 
            $row = New-Object System.Object

            $row | Add-Member -MemberType NoteProperty -Name "Server" -Value $server
            $row | Add-Member -MemberType NoteProperty -Name "Operational Status" -Value ""
            $row | Add-Member -MemberType NoteProperty -Name "Application" -Value ""
            $row | Add-Member -MemberType NoteProperty -Name "Business Criticality" -Value ""
            $row | Add-Member -MemberType NoteProperty -Name "Supported by" -Value ""
            $row | Add-Member -MemberType NoteProperty -Name "Manager" -Value ""
            $row | Add-Member -MemberType NoteProperty -Name "Support Team" -Value ""
            $row | Add-Member -MemberType NoteProperty -Name "Host Status" -Value $hostStatus
            $csvContents += $row                
        }
    }
    
}
catch
{
    Write-Warning $_.Exception.ToString();
    if($exit_code -lt 1 )
    {
        $exit_code = 99
    }
}

finally
{

    #lets write the report...
    $csvContents | Export-Csv -Path $CSVReport -NoTypeInformation

    # Cleanup
    Remove-Module -Name SRE-Functions -ErrorAction Ignore
    Remove-Module -name SnowFunctions -ErrorAction Ignore

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}

