﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	08/12/2019
	 Updated on:	08/12/2019
	 Created by:   	Jupp Valdez/Meghana Kalluri
	 Organization: 	Blue Shield of California
	 Filename:     	SRE-EDIJVMCheck.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server, WINF313P or WINF4028p. 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		IOS-221
        EDI JVM Settings must have a max size setting
        This script looks under each EDI profile and checks the startup.ini file to make sure it contains -Xmx"$String$"
        If -Xmx"$String$" is not found in the startup.ini file, an error is reported for that profile.


Date:      Who:                             Changes:
---------------------------------------------------
08/12/2019 Jupp Valdez/Meghana Kalluri      Initial
09/28/2020 Murry Kane                       Added an exclusion list of profiles to not check
05/04/2021 Murry Kane                       Added additional Exception list of profiles
                                            Changed logic to a remote function passed via PSSession
05/14/2021 Murry Kane                       Updated per Jira story IOS-373 3 profiles from override
                                              -- 'BSC834LA_County','BSC_EDI20_Outbound_277CA','BSCOutboundTrigger'


    .Example

    ./{Directory}\SRE-EDIJVMCheck.ps1 -Environment EDIP01,HIXP02
#>

[CmdletBinding()]
Param(
   [string[]]$Environment
	
)

try
{
    # Set some basic variables
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    
    # Import functions
    Import-Module SRE-Functions -Force

    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning "Error: SRE Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }


    # Modify Input parameters as needed...
    if ($ISE) {
        # get the required input if not supplied when running from ISE
        if(-not($Environment)) {
            $Environment = @()
            do 
            {
                $input = (Read-Host "Input your Environment (EDIEDIP02, EDIHIXP02, EDIN32): ")
                if ($input -ne '') {$Environment += $input}
            }
            until ($input -eq '')
        }
    }

    #validate inputs
    if (-not($Environment)) 
    {
        $exit_code = 32
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }


    function remoteCheckJVMsStartup
    {

        $VerbosePreference = 'Continue'
        Write-Verbose "Server name: $env:computername"
        $BadProfiles = @()
        $finalPaths = $Null

        $ExcludeProfiles = @( 
                 'BSC_27X_Testing_Drop',
                 'BSC_CMS_270_271',
                 'BSC_274_SD'

        )



        $GetActiveEDIServicesStartParms = Get-WmiObject win32_service | ?{$_.Name -like 'edi*' -or $_.Name -like 'bscedi*' -and $_.startmode -like 'Manual' -and $_.PathName -like '*Service.conf' } | select PathName 
        if ( $GetActiveEDIServicesStartParms -ne $Null )
        {
            $GetActiveEDIServicesStartPaths = $GetActiveEDIServicesStartParms.PathName | ForEach-Object { $_.split(' ')[2] } | ForEach-Object { Split-Path $_}
            $finalPaths = $GetActiveEDIServicesStartPaths | ForEach-Object { $_.substring(0,$_.lastindexof('\')) }
        }
        else
        {
            $finalPaths = $Null
        }

        For ($i=0; $i -lt $finalPaths.count; $i++) {
            $leafName = $($finalPaths[$i]) | split-path -leaf
            Write-Verbose "Working on Profile [$($finalPaths[$i])] with file name [$leafName]"

            if ($ExcludeProfiles -contains $leafName)
            {
                Write-verbose "Excluding profile $($finalPaths[$i]) as it's in the exclude list..."
            }
            else
            {
                $checkpath = join-path -path $($finalPaths[$i]) -childpath "\etc\startup.ini"
                write-verbose "Check path is $checkpath"
                if (test-path $checkpath) {
                    write-verbose 'The location exists, now checking for -Xmx"$String$"'
                    $SEL = Select-String -Path $checkpath -Pattern '-Xmx[0-9]'
                    if($SEL -ne $null) {
                        write-verbose '-Xmx"$String$" was found. Java Min/Max Settings is present in JVM Startup settings.'
                    }
                    else {
                        write-error "-Xmx was not found on server [$env:computername] for profile [$($finalPaths[$i])]. Java Min/Max Settings is not present in JVM Startup settings. This causes issue with the application."
                        #$BadProfiles += "$($Servers[$i]) with Profile $($profiles[$p])"
                        #$exit_code = $exit_code + 1
                   
                    }
                }
            }
        }
        #turn off verbose
        $VerbosePreference = 'SilentlyContinue'

        #end function
        #############
    }


    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "SRE HOME Directory is $SRE_HOME"
    Write-Host "Script name is: $currentScriptName"
    Write-Host "ISE is [$ISE]"
    Write-Host "Environment is [$Environment]"


    #ALL the main code should go below here 
    #######################################


    Import-Module Get-BSCServersInfo

    #$servers = get-bscserversinfo -Environment $Environment -WhichProperty app -PropValue EDI -ColumnReturn ServerName 
    $servers = get-bscserversinfo -Environment $Environment -WhichProperty role -PropValue EDIXE -ColumnReturn ServerName


    #check if servers is empty, then exit
    if(([string]::IsNullOrEmpty($servers))) 
    {
        Write-Error "Could not determine a list of servers for environment [$Environment], exiting!"
        $exit_code = 13
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    #now that we have the servers, let validate we are not trying to cross Domains (NPE to PROD or vise-versa)
    $Platform = get-bscserversinfo -Environment $Environment -WhichProperty ServerName -PropValue $Servers -ColumnReturn Platform
    #$Domain = (Get-ADDomain).Name  #mbk its expensive call...
    $Domain = (Get-ChildItem Env:'USERDOMAIN' -ErrorAction Ignore).Value
    Write-Verbose "Platform for these servers is [$Platform], Active Directory Domain is [$Domain]"
    if ($Platform -eq 'PROD' -and $Domain -ne 'BSC')
    {
        #we can't run run from NONE PROD domain to prod servers...
        Write-Error "WE CAN'T run a script from a NONE PROD Active Directory Domain ($Domain) to Production Servers(Platform [$Platform]), exiting script!"
        $exit_code = 20
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    elseif ($Platform -ne 'PROD' -and $Domain -eq 'BSC')
    {
        Write-Error "WE CAN'T run from a PROD Active Directory Domain ($Domain) to NONE Production Servers(Platorm [$Platform]), exiting script!"
        $exit_code = 21
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    else
    {
        Write-Host "Running script in Active Directory Domain [$Domain] for server types of [$Platform]"
    }

    Write-Host "Servers are: [$Servers]"

    if(-not ([string]::IsNullOrEmpty($servers))) 
    {
        Write-Host "Working on Servers [$servers] for profiles missing min/max JVM settings"
        Write-Host "Building PSSessions on [$Servers] Servers"
        $Session = New-PSSession -ComputerName $Servers -Verbose

        #first check for wrong count of connected servers...
        if($($Session.count) -ne $($Servers.count))
        {
            Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
            Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
            $exit_code = 19
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }

        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::remoteCheckJVMsStartup} -AsJob
        #wait for job to complete and output results
        $rc1 = checkJobAndLog -Session $Session -Jobs $Jobs 
        $RCode1 = $($rc1)[1]
        if ($RCode1 -ne 0)
        {
            Write-Error "Failures duing Validation Checks with RC: $RCode1"
            $exit_code = $RCode1
        }
        else
        {
            Write-Host "All good on job(s) RC: $RCode1"
        }
    }

}
catch
{
    Write-Warning $_.Exception.ToString();
    if($exit_code -lt 1 )
    {
        $exit_code = 99
    }
}

finally
{

    #cleanup
    Remove-Module -Name SRE-Functions
    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}