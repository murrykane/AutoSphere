﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	07/26/2019
	 Updated on:	07/26/2019
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	SRE-EDITracingCheck.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server, WINF313P or WINF4028p. 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script will check if EDI Tracing is turned on, if so it will exit badly to notify
        support


Date:      Who:            Changes:
-----------------------------------
01/08/2019 Murry Kane      Initial
12/03/2020 Murry Kane      Added report at end of bad profiles 

    .Example

    ./{Directory}\SRE-EDITracingCheck.ps1 -Environment EDIP01,HIXP02
#>

[CmdletBinding()]
Param(
   [string[]]$Environment
	
)

try
{
    # Set some basic variables
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    
    # Import functions
    Import-Module SRE-Functions -Force

    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning "Error: SRE Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }


    # Modify Input parameters as needed...
    if ($ISE) {
        # get the required input if not supplied when running from ISE
        if(-not($Environment)) {
            $Environment = @()
            do 
            {
                $input = (Read-Host "Input your Environment (FACP02, FACN32, FACN31): ")
                if ($input -ne '') {$Environment += $input}
            }
            until ($input -eq '')
        }
    }

    #validate inputs
    if (-not($Environment)) 
    {
        $exit_code = 32
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }


    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "SRE HOME Directory is $SRE_HOME"
    Write-Host "Script name is: $currentScriptName"
    Write-Host "ISE is [$ISE]"
    Write-Host "Environment is [$Environment]"
    $BadProfiles = @()

    #ALL the main code should go below here 
    #######################################


    Import-Module Get-BSCServersInfo

    $servers = get-bscserversinfo -Environment $Environment -WhichProperty app -PropValue EDI -ColumnReturn ServerName 


    #check if servers is empty, then exit
    if(([string]::IsNullOrEmpty($servers))) 
    {
        Write-Error "Could not determine a list of servers for environment [$Environment], exiting!"
        $exit_code = 13
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    #now that we have the servers, let validate we are not trying to cross Domains (NPE to PROD or vise-versa)
    $Platform = get-bscserversinfo -Environment $Environment -WhichProperty ServerName -PropValue $Servers -ColumnReturn Platform
    #$Domain = (Get-ADDomain).Name  #mbk its expensive call...
    $Domain = (Get-ChildItem Env:'USERDOMAIN' -ErrorAction Ignore).Value
    Write-Verbose "Platform for these servers is [$Platform], Active Directory Domain is [$Domain]"
    if ($Platform -eq 'PROD' -and $Domain -ne 'BSC')
    {
        #we can't run run from NONE PROD domain to prod servers...
        Write-Error "WE CAN'T run a script from a NONE PROD Active Directory Domain ($Domain) to Production Servers(Platform [$Platform]), exiting script!"
        $exit_code = 20
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    elseif ($Platform -ne 'PROD' -and $Domain -eq 'BSC')
    {
        Write-Error "WE CAN'T run from a PROD Active Directory Domain ($Domain) to NONE Production Servers(Platorm [$Platform]), exiting script!"
        $exit_code = 21
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    else
    {
        Write-Host "Running script in Active Directory Domain [$Domain] for server types of [$Platform]"
    }


    Write-Host "Servers are: [$Servers]"
    $errorCnt = 0

    For ($i=0; $i -lt $Servers.count; $i++) {
        Clear-Variable -name fullpath,profiles -ErrorAction Ignore
        $fullpath = join-path -path $Servers[$i] -childpath "D$\Edifecs\XEServer\profiles"
        $fullpath = "\\" + $fullpath
        $profiles = Get-ChildItem -path $fullpath -Directory -ErrorAction Ignore
        Write-Host "Profiles for $($Servers[$i]) is [$profiles]"
        for ($p=0; $p -lt $profiles.count; $p++ ) {
            write-host "working on profile $($profiles[$p])"
            $checkpath = join-path -path $fullpath -childpath "$($profiles[$p])\workspace"
            write-host "Check path is $checkpath"
            if (test-path $checkpath)
            {
                write-host "The location exists, now checking for tracing...."
                $checktracing = join-path -path $checkpath -childpath "tracer"
                if(test-path $checktracing)
                {
                    write-error "ERROR: Tracing is turned on for location [$checktracing]"
                    $BadProfiles += "$($Servers[$i]) with Profile $($profiles[$p]) location [$checktracing]"
                    $exit_code = $exit_code + 1
                }
                else
                {
                    write-host "INFO: Tracing is off for this profile..."
                }
            }
        }
    }
    #lets get the profiles per instance....
    

    #end main code#########################


}
catch
{
    Write-Warning $_.Exception.ToString();
    $exit_code = 99
}

finally
{

    #cleanup
    Remove-Module -Name SRE-Functions
    if ( $BadProfiles.Length -gt 0 )
    {
        Write-Host "-------------Report of Profiles without MAX setting for EDI ---------------------------------"
        $BadProfiles | ForEach-Object {Write-Host $_}
        Write-Host "---------------------------------------------------------------------------------------------"
    }
    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}