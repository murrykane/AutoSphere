#****************************************
# install or add MS Dot Net feature
#
#****************************************
#install-dotnet.ps1
#installs dot net Framework

import-module "ServerManager"
add-windowsfeature "AS-NET-Framework"