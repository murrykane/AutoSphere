#****************************************
# install  Oracle Client 11g
#
#****************************************
#install-oracleclient11g.ps1
#installs oraclie client 11g
#usage:Takes two inputs: media NAS UNC Path and install response file

$UNCPath=$args[0]
$responseFile=$args[1]
$mediaLocation=$args[2]

write-host " $UNCPATH "
write-host " $responseFile "
write-host " $responseFile "
##$mediaPath = "D:\TEMP\win64_11gR2_client\client"
$mediaPath = "$mediaLocation\media\Oracle\11.2.0.3\64-bit\client"


$ScriptFullPath = $MyInvocation.MyCommand.Path
$ScriptDir = Split-Path $ScriptFullPath

$driveLetter = Invoke-Expression "${ScriptDir}\map-drive.ps1 MAP $UNCPath"


cd $driveLetter
cd $mediaPath

import-module "ServerManager"
add-windowsfeature "AS-NET-Framework"
start-process -filepath ".\setup.exe" -argumentlist "-nowait","-force","-waitforcompletion","-noconfig","-silent","-responseFile",(get-item $responseFile).FullName -wait

Invoke-Expression "${ScriptDir}\map-drive.ps1 UNMAP $driveLetter"