function ps_unzip {

	param([String] $aDirectory, [String] $aZipfile)

	$shell_app=new-object -com shell.application 

	$filename = $aZipfile

	$zip_file = $shell_app.namespace($filename)

	$destination = $shell_app.namespace($aDirectory) 

	$destination.Copyhere($zip_file.items())

}



# main
ps_unzip $args[0] $args[1]