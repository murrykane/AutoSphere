#****************************************
# install  Oracle Client 11g
#
#****************************************
#install-oracleclient11g.ps1
#installs oraclie client 11g
#usage:Takes two inputs: media NAS UNC Path and install response file

$UNCPath=$args[0]
$responseFile=$args[1]
$mediaLocation=$args[2]

$mediaPath = "$mediaLocation\media\Oracle\11.2.0.3\32-bit\p10404530_112030_WINNT_3of6\client"
#$mediaPath = "D:\TEMP\11.2.0.3\32-bit\p10404530_112030_WINNT_3of6\client"


$ScriptFullPath = $MyInvocation.MyCommand.Path
$ScriptDir = Split-Path $ScriptFullPath

$driveLetter = Invoke-Expression "${ScriptDir}\map-drive.ps1 MAP $UNCPath"


cd $driveLetter
cd $mediaPath

import-module "ServerManager"
add-windowsfeature "AS-NET-Framework"
start-process -filepath ".\setup.exe" -argumentlist "-nowait","-force","-waitforcompletion","-noconfig","-silent","-responseFile",(get-item $responseFile).FullName -wait

Invoke-Expression "${ScriptDir}\map-drive.ps1 UNMAP $driveLetter"