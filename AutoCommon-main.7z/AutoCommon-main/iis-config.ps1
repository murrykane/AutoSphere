#****************************************
# install or add MS Dot Net feature
#
#****************************************
#IIS-config.ps1
#Configures IIS with various properties
#Usage:  IIS-config.ps1 [Property] [Value]
#Example:  IIS-config.ps1 DefaultTimeout 360
#             Sets the default web timeout at 360 seconds

$Property=$args[0]
$Value=$args[1]

Import-Module "WebAdministration"

if ($Property -eq "DefaultTimeout")
{
	Write-Host "Setting default IIS timeout to 360 seconds."
	set-webconfigurationproperty "/system.applicationHost/sites/siteDefaults[1]/limits[1]" -name connectionTimeout -value (New-TimeSpan -sec $Value)
}

