
function ps_zip {
     param([String] $aDirectory, [String] $aZipfile)

     [string]$pathToZipExe = "D:\apps\jenkins\AutoCommon\lib\zip.exe";
   
     [Array]$arguments =  "$aZipfile", "-r", "$aDirectory";
     & $pathToZipExe $arguments;
}


#main
ps_zip $args[0] $args[1]
  











