#****************************************
# install  MS XML Parser
#
#****************************************
#install-msxml4.ps1
#installs MS XML Parser 4.0 SP 3
#usage:Takes an input of the media root and maps it to P drive


$UNCPath=$args[0]
$version=$args[1]


$ScriptFullPath = $MyInvocation.MyCommand.Path
$ScriptDir = Split-Path $ScriptFullPath

$driveLetter = Invoke-Expression "${ScriptDir}\map-drive.ps1 MAP $UNCPath"

if($version -eq 4)
{
	$mediaPath = "Microsoft\MSXML 4.0 Service Pack 3"
}
else
{
	$mediaPath = "Microsoft\MSXML 6.0"

}

cd $driveLetter
cd $mediaPath

if($version -eq 4)
{
	start-process -filepath "`"$($env:SystemRoot)\System32\msiexec.exe`"" -argumentlist "/i","msxml.msi","/qb-","REBOOT=ReallySuppress" -wait
	start-process -filepath ".\msxml4-KB973685-enu.exe" -argumentlist "/passive","/norestart" -wait
}
if($version -eq 6)
{
	start-process -filepath "`"$($env:SystemRoot)\System32\msiexec.exe`"" -argumentlist "/i","msxml6_x86.msi","/qb-","REBOOT=ReallySuppress" -wait
}


Invoke-Expression "${ScriptDir}\map-drive.ps1 UNMAP $driveLetter"