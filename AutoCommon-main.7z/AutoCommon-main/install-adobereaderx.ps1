#****************************************
# install  install-adobereaderx.ps1 
#
#****************************************
#install-adobereaderx.ps1
#installs Adobe Reader X, v10.1.0 
#usage:Takes an input of the media root and maps it to P drive

$UNCPath=$args[0]
$ENV=$args[1]
$mediaPath = "Adobe"

$ScriptFullPath = $MyInvocation.MyCommand.Path
$ScriptDir = Split-Path $ScriptFullPath

$driveLetter = Invoke-Expression "${ScriptDir}\map-drive.ps1 MAP $UNCPath"

cd $driveLetter
cd $mediaPath

if (Test-Path D:\apps\autoScript\AutoFacets\xml\facets\$env.xml)
{
$xml = [xml](get-content D:\apps\autoScript\AutoFacets\xml\facets\$env.xml)
$installpath=$xml.facets.interactive.adobe.reader.installdir 
write-host "Target installation dir = $installpath"
cd bsc
start-process -filepath "./setup" -argumentlist "/sALL" -wait
}
else
{
write-host "Configuration file $env.xml NOT FOUND. Defaut target installation directory will be used."
start-process -filepath ".\AdbeRdr1010_en_US.exe" -argumentlist "/sAll","/rs","/msi EULA_ACCEPT=YES","/quiet" -wait
}

Invoke-Expression "${ScriptDir}\map-drive.ps1 UNMAP $driveLetter"