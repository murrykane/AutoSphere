#****************************************
# install or add MS Dot Net feature
#
#****************************************
#enableRoles.ps1
#enables Windows roles
#
#Usage:  enableRoles.ps1 [Role Name]
#Example:  enableRoles.ps1 ASPNET3
#             Installs NET 3 Framework role
#Example 2:  enableRoles.ps1 ASPNET4 \\ainj117d\softwaremedia\media
#             This was put into place because we decided to put .net into this script as well but 
#			  .net 4 is not specifically a role. 

$Role=$args[0]
$Media=$args[1]

import-module "ServerManager"

if ($Role -eq "ASPNET3")
{
	$Feature = Get-WindowsFeature "AS-NET-Framework"
	if ($Feature.Installed -eq "True" )
	{
		Write-Host "Skipping NET Framework install because it is already installed. "
	}
	else
	{
		Write-Host "Installing NET 3 Framework"
		add-windowsfeature "AS-NET-Framework"
	}
}

if ($Role -eq "ASPNET4")
{
	Write-Host "Installing NET 4 Framework"
	Write-Host "$Media\Microsoft\NET_Framework_4.0\dotNetFx40_Full_x86_x64.exe /q /norestart"
	start-process -filepath "$Media\Microsoft\NET_Framework_4.0\dotNetFx40_Full_x86_x64.exe" -argumentlist "/q", "/norestart" -wait
}

if ($Role -eq "COMNET")
{
	$Feature = Get-WindowsFeature "AS-Ent-Services"
	if ($Feature.Installed -eq "True" )
	{
		Write-Host "Skipping COM+ Network Service install because it is already installed. "
	}
	else
	{
		Write-Host "Installing COM+ Network Service"
		add-windowsfeature "AS-Ent-Services"
	}
}

if ($Role -eq "IISCLIENTCERT")
{
	$Feature = Get-WindowsFeature "AS-Ent-Services"
	if ($Feature.Installed -eq "True" )
	{
		Write-Host "Skipping IIS Client Certificate Authentication install because it is already installed. "
	}
	else
	{
		Write-Host "Installing IIS Client Certificate Authentication"
		add-windowsfeature "Web-Cert-Auth"
	}
}

if ($Role -eq "IIS")
{
	$Feature = Get-WindowsFeature "Web-Server"
	if ($Feature.Installed -eq "True" )
	{
		Write-Host "Skipping IIS install because it is already installed. "
	}
	else
	{
		Write-Host "Installing IIS"
		add-windowsfeature "Web-Server", "Web-Static-Content", "Web-Default-Doc", "Web-Dir-Browsing", "Web-Http-Errors", "Web-Asp-Net", "Web-Net-Ext", "Web-ISAPI-Ext", "Web-ISAPI-Filter", "Web-Http-Logging", "Web-Request-Monitor", "Web-Filtering", "Web-Stat-Compression", "Web-Mgmt-Console"	
	}
	
}
