﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	05/15/2019
	 Updated on:	05/15/2019
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	ISL_HGW_All_Services_Validate_ALL.ps1

	This script is Non-Prod specific.  Environments are hard coded to Non-Prod envs. 
	However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		Todo: This script will either accept a single argument or prompt if running in ISE for
        a given Facets environment. It will then verify GPS version information
        Currently only runs in ISE, but argument options are commented out and easily added.


Date:      Who:            Changes:
-----------------------------------
05/15/2019 Murry Kane      Initial
10/07/2021 Jeff Angstadt   Modify for ALL environment variations


    Example

    ./{Directory}\Backup-CP.ps1 -Environment FACN52 
    ./{Directory}\Backup-CP.ps1 -Environment FACP01
#>
<#
[CmdletBinding()]

Param(
  #[Parameter(Mandatory=$True,Position=1)]
   [string[]]$Environment,
   [string[]]$Roles
	
)
#>

    $exit_code = 0
    $rcode1 = 0
    $LOG_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\logs'
    $PAM_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts'
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    $SleepTimer = 5
    # turn off verbose
    $VerbosePreference = 'SilentlyContinue'
    $ACTIONS = "running, stopped"
    #initialize $Servers
    $Servers = @()
    $Roles = @()
    $Environment = @()
    $Serverlist = @()
    $input = @()
    $State = @()


    Write-Host "Script name is: $currentScriptName"

    if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS)))
    {
        $LOG_DIR = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS
    }
    else
    {
        $LOG_DIR = $PAM_HOME_DIR_DEFAULT 
    }

    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    #get PAM home dir
    if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME)))
    {
        $PAM_HOME = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME
    }
    else
    {
        $PAM_HOME = $PAM_HOME_DIR_DEFAULT 
    }


    if ($Host.Name -eq "Windows PowerShell ISE Host") {
        $ISE=$true
    } else {
        $ISE=$false
    }
    if ($ISE) {
        # get the required input
        if(-not($Environment)) {
            $Environment = @()
            $Serverlist = @()
            do 
            {
                $input = (Read-Host "Which Environments to run in (ALL, ALLN, ALLH, ALLS)")
                if ($input -ne '') {$Environment += $input}
            }
            until ($input -eq '')
        }
        if(-not($Roles)) {
            $Roles = @()
            do 
            {
                $input = (Read-Host "Input your Role (ISL, HIPAA, BATCH, etc): ")
                if ($input -ne '') {$Roles += $input}
            }
            until ($input -eq '')
        }
        if(-not($State)) {
            #Prompt User to get Running/Stopped
            do {
                $State = Read-Host -Prompt "Input your check state ($ACTIONS):"
                $State = $State.ToLower()
               }
                until ($ACTIONS.Contains($State))
        }
    }

    #lets start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    Write-Host "Log File is $LOG_FILE"
    Write-Host "Environment is [$Environment]"
    Write-Host "PAM HOME Directory is $PAM_HOME"
    Write-Host "Roles are [$Roles]"

    #define our envs
    $DefinedEnvAll = @()
    $DefinedEnvN = @()
    $DefinedEnvH = @()
    $DefinedEnvS = @()

    $DefinedEnvAll = "FACN14", "FACN15", "FACN16", "FACN25", "FACN26", "FACN27", "FACN28", "FACN29", "FACN31", "FACN32", "FACN51", "FACN52", "FACH63", "FACH64", "FACH70", "FACH71", "FACH72", "FACH80", "FACH81", "FACH90", "FACS02"
    $DefinedEnvN = "FACN14", "FACN15", "FACN16", "FACN25", "FACN26", "FACN27", "FACN28", "FACN29", "FACN31", "FACN32", "FACN51", "FACN52"
    $DefinedEnvH = "FACH63", "FACH64", "FACH70", "FACH71", "FACH72", "FACH80", "FACH81", "FACH90"
    $DefinedEnvS = "FACS02"
    $ServicesToControl = @('facets*','W3SVC', 'FaWinSvcHost')
    #$state = "running"

function Get-EnvServers {
    #import functions
    Import-Module Functions -Force
    Import-Module Get-BSCServersInfo
    Import-Module -Name Get-PAMServiceControl

    foreach ($envs in $Environment)
    {
    if ($envs -eq 'ALL')
    { $EnvsT = $DefinedEnvAll
        foreach ($EnvN in $EnvsT) {
      $Serverlist += get-bscserversinfo -Environment $EnvN -WhichProperty Role -PropValue $Roles -ColumnReturn ServerName
      #Invoke-Command -ComputerName $_ -ScriptBlock { Cmd.exe /c "GPRESULT /SCOPE COMPUTER /Z > d:\Temp\gpresult-%COMPUTERNAME%.txt" } } $Servers = get-bscservers -Environment $Environment -WhichProperty Role -PropValue $TargetRole -Names
         write-host Adding $EnvN Servers: $Serverlist
     }
    }
    elseif ($envs -eq 'ALLN')
    { $EnvsT = $DefinedEnvN
        foreach ($EnvN in $EnvsT) {
      $Serverlist += get-bscserversinfo -Environment $EnvN -WhichProperty Role -PropValue $Roles -ColumnReturn ServerName
      #Invoke-Command -ComputerName $_ -ScriptBlock { Cmd.exe /c "GPRESULT /SCOPE COMPUTER /Z > d:\Temp\gpresult-%COMPUTERNAME%.txt" } } $Servers = get-bscservers -Environment $Environment -WhichProperty Role -PropValue $TargetRole -Names
         write-host Adding $EnvN Servers: $Serverlist
     }
    }
    elseif ($envs -eq 'ALLH')
    { $EnvsT = $DefinedEnvH
        foreach ($EnvH in $EnvsT) {
      $Serverlist += get-bscserversinfo -Environment $EnvH -WhichProperty Role -PropValue $Roles -ColumnReturn ServerName
      #Invoke-Command -ComputerName $_ -ScriptBlock { Cmd.exe /c "GPRESULT /SCOPE COMPUTER /Z > d:\Temp\gpresult-%COMPUTERNAME%.txt" } } $Servers = get-bscservers -Environment $Environment -WhichProperty Role -PropValue $TargetRole -Names
         write-host Adding $EnvH Servers: $Serverlist
        }
    }
    elseif ($envs -eq 'ALLS')
    { $EnvsT = $DefinedEnvS
        foreach ($EnvS in $EnvsT) {
      $Serverlist += get-bscserversinfo -Environment $EnvS -WhichProperty Role -PropValue $Roles -ColumnReturn ServerName
      #Invoke-Command -ComputerName $_ -ScriptBlock { Cmd.exe /c "GPRESULT /SCOPE COMPUTER /Z > d:\Temp\gpresult-%COMPUTERNAME%.txt" } } $Servers = get-bscservers -Environment $Environment -WhichProperty Role -PropValue $TargetRole -Names
         write-host Adding $EnvS Servers: $Serverlist
        }
    }
  }
Return $Serverlist
}
$AllServers = @()
$AllServers = Get-EnvServers
try
 {

    $SleepTimer = 5

    Write-Host "Servers are: [$AllServers]"

#    $command = {
          <#Get-ItemProperty -Path "hklm:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\{a7e869f1-1ec2-4deb-bb4a-6d81cff967e5}" | Select DisplayName, DisplayVersion `
                                  ; Get-ItemProperty -Path "hklm:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\{3b05065e-975b-4e39-b06a-3516f5eb0f3f}" | Select DisplayName, DisplayVersion `
                                  ; Get-ItemProperty -Path "hklm:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\{e1458f3a-cf36-456f-8b53-6c320cb53007}" | Select DisplayName, DisplayVersion `

        ; Write-Output "$env:COMPUTERNAME $OUTPUT `n" 
        #>
 if(-not ([string]::IsNullOrEmpty($AllServers))) 
    {
        Write-Host "Working on Servers [$AllServers] for Services [$($servicesToControl)]"
        Write-Host "Building PSSessions on [$AllServers] Servers"
        $Session = New-PSSession -ComputerName $AllServers -Verbose

        #first check for wrong count of connected servers...
        if($($Session.count) -ne $($AllServers.count))
        {
            Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
            Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
            $exit_code = 19
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }

        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,$State,180 -AsJob
        #wait for job to complete and output results
        $rc1 = checkJobAndLog -Session $Session -Jobs $Jobs 
        $RCode1 = $($rc1)[1]
        if ($RCode1 -ne 0)
        {
            Write-Error "Failures duing Validation Checks with RC: $RCode1"
            $exit_code = $RCode1
        }
        else
        {
            Write-Host "All good on job(s) RC: $RCode1"
        }
    }
#end of command statement} 
<#    else
    {
        Write-Host "Servers are empty, skipping servers [$servers] for Services [$($servicesToControl)]"
    }
#>

}
catch
{
    Write-Warning $_.Exception.ToString();
    if($exit_code -lt 1 )
    {
        $exit_code = 99
    }
}

finally
{

    #cleanup
    #Remove-Variable * #-ErrorAction SilentlyContinue #; Remove-Module *; $error.Clear();
    Remove-Module -Name Get-BSCServersInfo
    Remove-Module -Name Get-PAMServiceControl
    Remove-Module -Name Functions

    if ($RCode1 -ne 0)
    {
        $exit_code = $RCode1
        Write-Error "Failures duing Validations : $exit_code"
    }


    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
 }

