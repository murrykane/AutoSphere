﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	11/13/2017
	 Updated on:	11/13/2017
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	RestartFilenetServices.ps1

	The scripts being built in this grouping are for PAM Production Support
	The majority will be run from the Primary PAM Server, WINF313P. However,
	it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script Starts all ISL_HGW Services

MODIFICATIONS
_____________________________________________________________________________________________________________________________
    Date       By            Reason
    01/30/2019 Murry Kane    Moved into SVN
    05/08/2019 Murry Kane    Modified start timeout time to 800 seconds
    03/29/2021 Murry Kane    Adding logic to get server list from CMDB
                             added logic to kill any left over processes after services are stopped
                                - account owner is 'facets_thg_prod'
                                - process name is 'CerComHost.exe' or 'dllhost.exe' or 'ErSys0FrmServicesRuntime64.exe'
                             added try/catch/finally 
    04/01/2021 Murry Kane    Added FaWinSvcHost to services to manage
    06/29/2021 Murry Kane    After 2019 upgrade the 'runs on:runs' was changed to 'depends on', it was determined to remove
                             this from the query all together
    04/12/2022 Murry Kane    CMDB changed the HIPAA gateway entries and needs a code change 
    Example

    ./{PATH}\ISL_HGW_All_Services_START.ps1 -Environment FACN32,FACN31
    ./{PATH}\ISL_HGW_All_Services_START.ps1 -Environment FACN32

#>

[CmdletBinding()]
Param(
   #[Parameter(Mandatory=$True,Position=1)]
   [string[]]$Environment,
   [Parameter(Mandatory=$False, Position=2)][switch]$uselocaldomain
)

$LOG_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\Logs'
$PAM_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts'
$ACTIONS = 'running','stopped'
$exit_code = 0
$currentScriptName = $MyInvocation.MyCommand.Name
$filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
# turn off verbose
$VerbosePreference = 'SilentlyContinue'
$Domain = (Get-ChildItem Env:'USERDOMAIN' -ErrorAction Ignore).Value

function Get-ServerList {
    try {

        #lets see if we we are going against production or 2015 CMDB
        $SnowCred = ''
        $UriBase = ''

        if(-not $uselocaldomain)
        {
            $SNowCred = Get-ServiceNowCredential
            $UriBase = Get-ServiceNowUriBase
        }
        else
        {
            Write-Host "-UseLocalDomain option passed to script, using local domain to determine which ServiceNow Instance to connect with"
            $SNowCred = Get-ServiceNowCredential -uselocaldomain
            $UriBase = Get-ServiceNowUriBase -uselocaldomain                
        }

        if([string]::IsNullOrWhiteSpace($SNowCred) -or [string]::IsNullOrWhiteSpace($UriBase))
        {
            $exit_code = 4
            Write-Warning "We could not get credentials to make the REST call to ServiceNow" 
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }
        else
        {
            Write-Host "URI Base $UriBase"
        }

        # Query Server to App Relationship Table
        Write-Host "Querying ServiceNow API for getting the application server(s)"
        #$Uri = "$UriBase/api/now/table/cmdb_rel_ci?sysparm_query=parent.nameSTARTSWITH$($CMDBEnvironment)Facets%20HIPAA%20Gateway%5EORparent.nameSTARTSWITH$($CMDBEnvironment)Facets%20ISL%5Eparent.install_statusIN11%5Echild.install_statusIN11%5Echild.nameSTARTSWITHFacets%20App%20Server%5EORchild.nameSTARTSWITHFacets%20Interactive%5Echild.sys_class_name%3Dcmdb_ci_app_server&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=child&sysparm_limit=1000"
        $Uri = "$UriBase/api/now/table/cmdb_rel_ci?sysparm_query=parent.nameSTARTSWITH$($CMDBEnvironment)Facets%20HIPAA%20Gateway%5EORparent.nameSTARTSWITH$($CMDBEnvironment)Facets%20ISL%5EORparent.nameSTARTSWITH$($CMDBEnvironment)HIPAA%20Gateway%5Eparent.install_statusIN11%5Echild.install_statusIN11%5Echild.nameSTARTSWITHFacets%20App%20Server%5EORchild.nameSTARTSWITHFacets%20Interactive%5EORchild.nameSTARTSWITHFacets%20HIPAA%20Gateway%5Echild.sys_class_name%3Dcmdb_ci_app_server&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=child&sysparm_limit=1000"


        Write-Host "Using URI [$Uri]"

        $Result = Query-ServiceNowApi -Uri $Uri -SNowCred $SNowCred

        Write-Host "Result is " + $result   
        $Servers = $result | ForEach-Object { (($_).child -split "@")[1] } | select -Unique

        return $Servers
    }
    catch {
        return $null
    }
}


try
{

    #import functions
    Import-Module -name SRE-Functions -Force -WarningAction SilentlyContinue
    Import-Module -name SnowFunctions -Force -WarningAction SilentlyContinue
    import-module -name Get-PAMServiceControl -Verbose -WarningAction SilentlyContinue
    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')" WARNING: SRE Management Server Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    if ($Host.Name -eq "Windows PowerShell ISE Host") {
        $ISE=$true
    } else {
        $ISE=$false
    }
    if ($ISE) {
        # get the required input
        if(-not($Environment)) {
            $Environment = @()
            do 
            {
                $input = (Read-Host "Input your Environment (FACN32, FACP02): ")
                if ($input -ne '') {$Environment += $input}
            }
            until ($input -eq '')
        } 
    }

    $Environment = $Environment.ToUpper()
    Write-Host "Log File is: [$LOG_FILE]"
    Write-Host "Environment is [$Environment]"

    $ServicesToControl = @('facets*','W3SVC', 'FaWinSvcHost')
    $CMDBEnvironment = ''
    if($Environment -match "FACP02")
    {
        Write-Host "Production run of script, stripping Environment Name [$Environment] from CMDB lookup..."
        $CMDBEnvironment = ''
    }
    else
    {
        $CMDBEnvironment = ($($Environment) + '_')
    }

    #get server list from CMDB
    $servers = Get-ServerList

    if(-not ([string]::IsNullOrEmpty($servers))) 
    {
        Write-Host "Working on Servers [$servers] for Services [$($servicesToControl)]"
        Write-Host "Building PSSessions on [$Servers] Servers"
        $Session = New-PSSession -ComputerName $Servers -Verbose

        #first check for wrong count of connected servers...
        if($($Session.count) -ne $($Servers.count))
        {
            Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
            Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
            $exit_code = 19
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }

        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,start,800 -AsJob
        #wait for job to complete and output results
        $rc1 = checkJobAndLog -Session $Session -Jobs $Jobs 
        $RCode1 = $($rc1)[1]
        if ($RCode1 -ne 0)
        {
            Write-Error "Failures duing Validation Checks with RC: $RCode1"
            $exit_code = $RCode1
        }
        else
        {
            Write-Host "All good on job(s) RC: $RCode1"
        }
    }
    else
    {
        Write-Host "Servers are empty, skipping servers [$servers] for Services [$($servicesToControl)]"
    }

}
catch
{
    Write-Warning $_.Exception.ToString();
    if($exit_code -lt 1 )
    {
        $exit_code = 99
    }
}
finally
{
    #cleanup now...
    Remove-Module -Name Get-PAMServiceControl  -ErrorAction SilentlyContinue
    Remove-Module -Name SnowFunctions -ErrorAction SilentlyContinue
    Remove-Module -Name SRE-Functions -ErrorAction SilentlyContinue

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"

    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}
