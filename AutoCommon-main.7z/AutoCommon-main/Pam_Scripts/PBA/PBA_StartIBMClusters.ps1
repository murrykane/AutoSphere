﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	12/20/2021
	 Updated on:	12/20/2021
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	PBA_StartIBMClusters.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server, WINF313P or WINF4028p. 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script run a python script to start the IBM Websphere Clusters for PBA


Date:      Who:            Changes:
-----------------------------------
12/20/2021 Murry Kane    Initial


    Example

    ./{Directory}\PBA_StartIBMClusters.ps1 -PythonVersion "3" -Cred {credential}
    ./{Directory}\PBA_StartIBMClusters.ps1 -PythonVersion "2" -Cred {credential}
#>
[CmdletBinding()]
Param(
    [Parameter(Position=0)]
    [string]$Env,
    [Parameter(Position=1)]
    [string]$Service,
    [Parameter(Position=2)]
    [ValidateSet("2","3")]
    [string]$PythonVersion = "2"
)


function Get-ServerList {
    try {
        $SNowCred = Get-ServiceNowCredential

        $UriBase = Get-ServiceNowUriBase
        Write-Host "URI Base $UriBase"

        # Query Server to App Relationship Table
        Write-Host "Querying ServiceNow API for getting the FileNet Content Collector server(s)"
        #$Uri = "$UriBase/api/now/table/cmdb_rel_ci?sysparm_query=parent.sys_class_name%3Dcmdb_ci_app_server_websphere%5Eparent.name%3D$CI%5Echild.sys_class_name%3Dcmdb_ci_websphere_cell&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=child&sysparm_limit=1000"
        # https://blueshieldca.service-now.com/cmdb_rel_ci_list.do?sysparm_query=child.sys_class_name%3Dcmdb_ci_websphere_cell%5Echild.nameSTARTSWITHfacp02%5Eparent.sys_class_name%3Dcmdb_ci_app_server_websphere%5Eparent.install_status%3D11%5Eparent.nameSTARTSWITHpba%5EORparent.nameSTARTSWITHdmgr&sysparm_view=
        $Uri = "$UriBase/api/now/table/cmdb_rel_ci?sysparm_query=child.sys_class_name%3Dcmdb_ci_websphere_cell%5Echild.nameSTARTSWITH$Env%5Eparent.sys_class_name%3Dcmdb_ci_app_server_websphere%5Eparent.install_status%3D11%5Eparent.nameSTARTSWITH$Service%5EORparent.nameSTARTSWITHdmgr&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=parent&sysparm_limit=1000"

        Write-Host "Using URI [$Uri]"

        $Result = Query-ServiceNowApi -Uri $Uri -SNowCred $SNowCred

        Write-Host "Result is " + $result
        $ListName = ($Result).Parent | select -Unique
        Write-Host "The List is: $ListName" 

        #$Servers = $result | ForEach-Object { (($_).parent -split "@")[1] } | select -Unique

        $DmgrServers = @()
        $PBAServers = @()
        $result | ForEach-Object -Process {
            $cmdb_start = (($_).parent -split "@")[0]
            $cmdb_end = (($_).parent -split "@")[1]
            Write-Host "Start value $cmdb_start and end value $cmdb_end"
            if($cmdb_start -match "dmgr")
            {
                #Write-Host "match on primary"
                $DmgrServers += $cmdb_end
            }
            else
            {
                #Write-Host "no match"
                $PBAservers += $cmdb_end
            }
        }

        $DmgrServers = $DmgrServers | Select -Unique
        $PBAServers = $PBAServers | Select -Unique

        return $DmgrServers,$PBAservers  
            
    }
    catch {
        return $null
    }
}


try
{
    # Set some basic variables
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    $PyScriptStart = "startAllClusters.py"
    $LocalDomain = (Get-ChildItem Env:'USERDOMAIN' -ErrorAction Ignore).Value

    # Import functions and get server info
    Import-Module SRE-Functions -Force -WarningAction SilentlyContinue
    Import-Module SnowFunctions -Force -WarningAction SilentlyContinue

    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(Get-Date -Format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning "Error: SRE Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Modify Input parameters as needed....
    if ($ISE) 
    {
        if(-not($Env)) {
            $Env = @()
            do 
            {
                $input = (Read-Host "Input your Environment (FACP02, FACS02): ")
                if ($input -ne '') {$Env += $input}
            }
            until ($input -eq '')
        } 
        if(-not($Service)) {
            $Service = @()
            do 
            {
                $input = (Read-Host "Input your Service (PBA, PBA1, PBA2): ")
                if ($input -ne '') {$Service += $input}
            }
            until ($input -eq '')
        } 
    }

    if (-not $Env)
    {
        $exit_code = 8
        Write-Warning "Environment is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    if (-not $Service)
    {
        $exit_code = 9
        Write-Warning "Service is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "SRE HOME Directory is $SRE_HOME"
    Write-Host "Script name is: $currentScriptName"
    Write-Host "ISE is [$ISE]"
    Write-Host "Using Environment [$Env] with Service [$Service]"
 
    #get server list from CMDB
    $DMGRServers, $PBAservers = Get-ServerList

    Write-Host "Primary DMGR's is [$DMGRServers]"
    Write-Host "PBA Application Servers is [$PBAservers]"
    $Server = $null
    $Server = (Compare-Object -IncludeEqual -ExcludeDifferent $DmgrServers $PBAServers).InputObject
    #if ([string]::IsNullOrEmpty($server))
    if (-not $server)
    {
        $exit_code = 40
        Write-Warning "PBA Deployment Server could not be determined, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE  
    }
     
    # Validate server exists
    $EC1 = isValidServer($Server)

    if ($EC1 -ne 0)
    {
        $exit_code = $EC1
        Write-Warning "Invalid server [$Server]. Exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    
    # ----------------------- Main -----------------------

    # Set up PS Session
    Write-Host "Determined PBA Deployment server to be [$Server] creating remote session"
    $Session = New-PSSession -ComputerName $Server -Verbose

    #first check for wrong count of connected servers...
    if($($Session.count) -ne $($Server.count))
    {
        Write-Warning "Could not connect to all servers that are needed for this environment ($Env) using local AD domain ($LocalDomain), exiting!"
        Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
        $exit_code = 19
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
    }

    $ReasonToExit, $PythonScriptPath = Invoke-Command -Session $Session -ScriptBlock ${function::ValidateRemotePythonSession} -ArgumentList ($PyScriptStart)
    
    if ($ReasonToExit -ne $null)
    {
        $exit_code = 40
        Write-Warning $ReasonToExit
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
 
    # Let's validate that the correct version of Python is installed on the server
    Write-Host "Searching for Python $PythonVersion executable on server [$Server]."
    $ReasonToExit, $PythonExe = Invoke-Command -Session $Session -ScriptBlock ${function:Get-PythonExecutablePath} -ArgumentList $PythonVersion
    
    if ($ReasonToExit -ne $null)
    {
        $exit_code = 50
        Write-Warning $ReasonToExit
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    
    # ---------- Start Clusters --------- #
    $ReasonToExit = RunPythonAsJob -Session $Session -PythonExe $PythonExe -PythonScriptName $PyScriptStart -PythonScriptPath $PythonScriptPath 

    if ($ReasonToExit -ne $null)
    {
        $exit_code = 55
        Write-Warning $ReasonToExit
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    # --------------------- End Main ---------------------

}
catch
{
    Write-Warning $_.Exception.ToString();
    if($exit_code -lt 1 )
    {
        $exit_code = 99
    }
}
finally
{
    # Cleanup
    Remove-Module -Name SRE-Functions
    Remove-Module -Name SnowFunctions
    $Session | Remove-PSSession -ErrorAction SilentlyContinue

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}
