﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	11/13/2017
	 Updated on:	11/13/2017
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	EDI_Services_VALIDATE.ps1

	The scripts being built in this grouping are for PAM Production Support
	The majority will be run from the Primary PAM Server, WINF313P. However,
	it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script Checks all ISL_HGW_CWS Services and validates to a provided
        input parameter that all services are in that state, otherwise exits
        badly.

MODIFICATIONS
_____________________________________________________________________________________________________________________________
    Date       By            Reason
    01/30/2019 Murry Kane    Needed to remove the MQ* check for stopped but must be checked for running
    02/14/2019 Murry Kane    Added new argument to denote PATCHING or CORE weekend recycles
                               - This argument is required and will determine full recyle for partial 
                                 a) infra = Patching weekend also known and infrastructure maintenance (reboots and patching of servers)
                                 b) core = This is CORE/Maintenace release where application code is pushed to the environment and no reboots are performed
    07/01/2019 Murry Kane    Was missing the ETL servers for checks on CORE weekends 
    03/08/2021 Murry Kane    Added try/catch/finally
    03/10/2021 Murry Kane    Added check for sessions equals count of servers to manage per loop
    03/19/2021 Murry Kane    If import-module can't be imported stop script

    Example

    ./{PATH}\EDI_Services_VALIDATE.ps1 -State running -Environment EDIN01,HIXN01 -MaintType core
    ./{PATH}\EDI_Services_VALIDATE.ps1 -State stopped -Environment EDIP02,HIXP02 -MaintType infra
#>

[CmdletBinding()]
Param(
  #[Parameter(Mandatory=$True,Position=1)]
   [string[]]$Environment,
   [string]$State,
   [string]$MaintType
	
)

$ACTIONS = 'running','stopped'
$exit_code = 0
$LOG_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\logs'
$PAM_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts'
$currentScriptName = $MyInvocation.MyCommand.Name
$filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
$SleepTimer = 5
$MAINTVALUES = 'core','infra'

try
{
    Write-Host "Script name is: $currentScriptName"

    if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS)))
    {
        $LOG_DIR = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS
    }
    else
    {
        $LOG_DIR = $PAM_HOME_DIR_DEFAULT 
    }

    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    #get PAM home dir
    if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME)))
    {
        $PAM_HOME = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME
    }
    else
    {
        $PAM_HOME = $PAM_HOME_DIR_DEFAULT 
    }

    #lets start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append
    #turn off Verbose logging
    $VerbosePreference = 'SilentlyContinue'


    if ($Host.Name -eq "Windows PowerShell ISE Host") {
        $ISE=$true
    } else {
        $ISE=$false
    }
    if ($ISE) {
        # get the required input
        if(-not($State)) {
            #Prompt User to get Running/Stopped
            do {
                $State = Read-Host -Prompt "Input your check state ($ACTIONS):"
                $State = $State.ToLower()
               }
                until ($ACTIONS.Contains($State))
        } 
        if(-not($Environment)) {
            $Environment = @()
            do 
            {
                $input = (Read-Host "Input your Environment (EDIP02, EDIN01, HIXN01): ")
                if ($input -ne '') {$Environment += $input}
            }
            until ($input -eq '')
        }
        if(-not($MaintType)) {
            do {
                $MaintType = (Read-Host -Prompt "Input your Maintenance Type ($MAINTVALUES): ")
                $MaintType = $MaintType.ToLower()
               }
                until ($MAINTVALUES.Contains($MaintType))
        }
    }

    if (-not($State))
    {
        $exit_code = 14
        Write-Error "State is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    else
    {
        $State = $State.toLower()
    }

    if (-not($MaintType))
    {
        $exit_code = 15
        Write-Error "Maintenace Type is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    else
    {
        $MaintType = $MaintType.ToLower()
        if($MAINTVALUES.Contains($MaintType))
        {
            Write-Host "Valid Maintenace Type [$MaintType] passed"
        }
        else
        {
            Write-Error "Invalid Maintenace Type [$MaintType] passed, exiting!"
            $exit_code = 16
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE
        } 
    }

    Write-Host "PAM HOME Directory is $PAM_HOME"
    Write-Host "Log File is $LOG_FILE"
    Write-Host "Environment is [$Environment]"
    Write-Host "Maitenance Type is [$MaintType]"

    #import functions
    Import-Module Functions -Force -WarningAction SilentlyContinue -ErrorAction Stop

    Import-Module Get-BSCServersInfo -WarningAction SilentlyContinue -ErrorAction Stop
    #$servers = get-bscserversinfo -Environment $Environment -WhichProperty app -PropValue EDI -ColumnReturn ServerName

    # first see if CORE or INFRA
    $ServicesToControl = ''
    $Servers = ''

    if($MaintType -eq 'infra')
    {
        Write-Host "Including IBM* as this is Patching Weekend"
        $servers = get-bscserversinfo -Environment $Environment -WhichProperty app -PropValue EDI -ColumnReturn ServerName 
    }
    else
    {
        Write-Host "Excluding IBM* as this in not patching weekend"
        $servers = get-bscserversinfo -Environment $Environment -WhichProperty Role -PropValue EDIXE,EDIETL -ColumnReturn ServerName 
    }

    #check if servers is empty, then exit
    if(([string]::IsNullOrEmpty($servers))) 
    {
        Write-Error "Could not determine a list of servers for environment [$Environment], exiting!"
        $exit_code = 13
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    #now that we have the servers, let validate we are not trying to cross Domains (NPE to PROD or vise-versa)
    $Platform = get-bscserversinfo -Environment $Environment -WhichProperty ServerName -PropValue $Servers -ColumnReturn Platform
    #$Domain = (Get-ADDomain).Name  #mbk its expensive call...
    $Domain = (Get-ChildItem Env:'USERDOMAIN' -ErrorAction Ignore).Value
    Write-Verbose "Platform for these servers is [$Platform], Active Directory Domain is [$Domain]"
    if ($Platform -eq 'PROD' -and $Domain -ne 'BSC')
    {
        #we can't run run from NONE PROD domain to prod servers...
        Write-Error "WE CAN'T run a script from a NONE PROD Active Directory Domain ($Domain) to Production Servers(Platform [$Platform]), exiting script!"
        $exit_code = 20
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    elseif ($Platform -ne 'PROD' -and $Domain -eq 'BSC')
    {
        Write-Error "WE CAN'T run from a PROD Active Directory Domain ($Domain) to NONE Production Servers(Platorm [$Platform]), exiting script!"
        $exit_code = 21
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    else
    {
        Write-Host "Running script in Active Directory Domain [$Domain] for server types of [$Platform]"
    }


    Write-Host "Servers are: [$Servers]"

    $State = $State.ToLower()
    if($ACTIONS.Contains($State)) 
    {
        Write-Host "Valid option passed for -State with: [$State]"
    }
    else     
    {
        Write-Error "The value you supplied for -State is not valid. It must be either: running or stopped!"
        $exit_code = 33
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    $ServicesToControl = ''

    if($state -eq 'stopped')
    {
        Write-Host "Removing MQ from the check of services for stopped state"
        $ServicesToControl = @('EDI*', 'IBM*', 'HIX*', 'BSCEDI*', 'EAMService')
    }
    else
    {
        Write-Host "Including MQ for the check of services in running state"
        $ServicesToControl = @('EDI*', 'IBM*', 'HIX*', 'MQ_*', 'BSCEDI*', 'EAMService')
    }


    #import the PAM Service Module
    import-module -name Get-PAMServiceControl.psm1 -Verbose -WarningAction SilentlyContinue -ErrorAction Stop


    if(-not ([string]::IsNullOrEmpty($servers))) 
    {
        Write-Host "Working on Servers [$servers] for Services [$($servicesToControl)]"
        Write-Host "Building PSSessions on [$Servers] Servers"
        $Session = New-PSSession -ComputerName $Servers -Verbose

        #first check for wrong count of connected servers...
        if($($Session.count) -ne $($Servers.count))
        {
            Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
            Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
            $exit_code = 19
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }

        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,$state,180 -AsJob
        #wait for job to complete and output results
        $rc1 = checkJobAndLog -Session $Session -Jobs $Jobs 
        $RCode1 = $($rc1)[1]
        if ($RCode1 -ne 0)
        {
            Write-Error "Failures duing Validation Checks with RC: $RCode1"
            $exit_code = $RCode1
        }
        else
        {
            Write-Host "All good on job(s) RC: $RCode1"
        }
    }
    else
    {
        Write-Host "Servers are empty, skipping EDI XE servers [$servers] for Services [$($servicesToControl)]"
    }
}
catch
{
    Write-Warning $_.Exception.ToString();
    if($exit_code -lt 1 )
    {
        $exit_code = 99
    }
}
finally
{
    #cleanup now...
    Remove-Module -Name Get-PAMServiceControl -ErrorAction SilentlyContinue
    Remove-Module -Name Get-BSCServersInfo -ErrorAction SilentlyContinue
    Remove-Module -Name Functions -ErrorAction SilentlyContinue																		

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"

    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}