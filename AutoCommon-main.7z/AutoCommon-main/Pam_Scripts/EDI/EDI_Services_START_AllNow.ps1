﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	11/13/2017
	 Updated on:	11/13/2017
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	EDI_Services_START_AllNow.ps1

	The scripts being built in this grouping are for PAM Production Support
	The majority will be run from the Primary PAM Server, WINF313P. However,
	it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script Checks all EDI Services and validates to a provided
        input parameter that all services are in that state, otherwise exits
        badly.

MODIFICATIONS
_____________________________________________________________________________________________________________________________
    Date       By            Reason
    12/06/2018 Murry Kane    Added function for waiting for PSESSION's and output the results along
                             with 2 loops 
                                - 1st loop does MQ and EdifecsTMServiceManager ONLY
                                - 2nd loop does all other EDI* profiles, IBM Websphere and EAMService (like original job)

    12/30/2018 Murry Kane    Added 3rd loop for EAMService and any left overs....
    03/10/2021 Murry Kane    Added check for sessions equals count of servers to manage per loop
    03/19/2021 Murry Kane    If import-module can't be imported stop script

_____________________________________________________________________________________________________________________________
    Example

    ./{PATH}\EDI_Services_START_AllNow.ps1 -Environment EDIN01,HIXN01
    ./{PATH}\EDI_Services_START_AllNow.ps1 -Environment EDIP02,HIXP02
#>

[CmdletBinding()]
Param(
  #[Parameter(Mandatory=$True,Position=1)]
   [string[]]$Environment
	
)

$exit_code = 0
$LOG_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\logs'
$PAM_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts'
$currentScriptName = $MyInvocation.MyCommand.Name
$filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
$SleepTimer = 5
#turn off verbose...
$VerbosePreference = 'SilentlyContinue'

Write-Host "Script name is: $currentScriptName"

if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS)))
{
    $LOG_DIR = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS
}
else
{
    $LOG_DIR = $PAM_HOME_DIR_DEFAULT 
}

$LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

#get PAM home dir
if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME)))
{
    $PAM_HOME = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME
}
else
{
    $PAM_HOME = $PAM_HOME_DIR_DEFAULT 
}


#lets start logging what occures from here forward....
Start-Transcript -path $LOG_FILE -append
#turn off Verbose logging
$VerbosePreference = 'SilentlyContinue'


#import functions
Import-Module Functions -Force -WarningAction SilentlyContinue -ErrorAction Stop


if ($Host.Name -eq "Windows PowerShell ISE Host") {
    $ISE=$true
} else {
    $ISE=$false
}
if ($ISE) {
    # get the required input
    if(-not($Environment)) {
        $Environment = @()
        do 
        {
            $input = (Read-Host "Input your Environment (EDIP02, EDIN01, HIXN01): ")
            if ($input -ne '') {$Environment += $input}
        }
        until ($input -eq '')
    }
}

if (-not($Environment)) 
{
    Write-Error "Environment is required, exiting!"
    $exit_code = 33
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}

Write-Host "PAM HOME Directory is $PAM_HOME"
Write-Host "Log File is $LOG_FILE"
Write-Host "Environment is [$Environment]"

try
{

    Import-Module -name Get-BSCServersInfo -WarningAction SilentlyContinue -ErrorAction Stop
    $servers = get-bscserversinfo -Environment $Environment -WhichProperty app -PropValue EDI -ColumnReturn ServerName 

    #check if servers is empty, then exit
    if(([string]::IsNullOrEmpty($servers))) 
    {
        Write-Error "Could not determine a list of servers for environment [$Environment], exiting!"
        $exit_code = 13
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    #now that we have the servers, let validate we are not trying to cross Domains (NPE to PROD or vise-versa)
    $Platform = get-bscserversinfo -Environment $Environment -WhichProperty ServerName -PropValue $Servers -ColumnReturn Platform
    #$Domain = (Get-ADDomain).Name  #mbk its expensive call...
    $Domain = (Get-ChildItem Env:'USERDOMAIN' -ErrorAction Ignore).Value
    Write-Verbose "Platform for these servers is [$Platform], Active Directory Domain is [$Domain]"
    if ($Platform -eq 'PROD' -and $Domain -ne 'BSC')
    {
        #we can't run run from NONE PROD domain to prod servers...
        Write-Error "WE CAN'T run a script from a NONE PROD Active Directory Domain ($Domain) to Production Servers(Platform [$Platform]), exiting script!"
        $exit_code = 20
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    elseif ($Platform -ne 'PROD' -and $Domain -eq 'BSC')
    {
        Write-Error "WE CAN'T run from a PROD Active Directory Domain ($Domain) to NONE Production Servers(Platorm [$Platform]), exiting script!"
        $exit_code = 21
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    else
    {
        Write-Host "Running script in Active Directory Domain [$Domain] for server types of [$Platform]"
    }


    #Now do all
    $ServicesToControl = @('EDI*', 'IBM*', 'HIX*', 'MQ_*', 'BSCEDI*', 'EAMService', 'KNTC*', 'KQ7C*', 'KYNA*')

    #import PAM Service Module
    import-module -name Get-PAMServiceControl.psm1 -Verbose -WarningAction SilentlyContinue -ErrorAction Stop

    Write-Host "Building PSSessions on [$Servers] Servers"
    $Session = New-PSSession -ComputerName $Servers -Verbose

    #first check for wrong count of connected servers...
    if($($Session.count) -ne $($Servers.count))
    {
        Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
        Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
        $exit_code = 19
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
    }

    $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'start',300 -AsJob

    #wait for job to complete and output results
    $rc = checkJobAndLog -Session $Session -Jobs $Jobs
    $RCode = $($rc)[1]

    if ($RCode -ne 0)
    {
        Write-Host "ERROR: Failures.... RC = $RCode"
        $exit_code = $RCode
    }
    else
    {
        Write-Host "All good on job(s)... RC = $RCode"
    }

}
catch
{
    Write-Warning $_.Exception.ToString();
    if($exit_code -lt 1 )
    {
        $exit_code = 99
    }
}
finally
{
    #cleanup now...
    Remove-Module -Name Get-PAMServiceControl -ErrorAction SilentlyContinue
    Remove-Module -Name Get-BSCServersInfo -ErrorAction SilentlyContinue
    Remove-Module -Name Functions -ErrorAction SilentlyContinue																		

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"

    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}

