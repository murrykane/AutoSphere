﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	11/13/2017
	 Updated on:	11/13/2017
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	EDI_Services_PipeLine-START.ps1

	The scripts being built in this grouping are for PAM Production Support
	The majority will be run from the Primary PAM Server, WINF313P. However,
	it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script starts only the specific pipeline(s) passed for EDI which will stop either Claims/Inquiry/Enrollment for a given
        region.

MODIFICATIONS
_____________________________________________________________________________________________________________________________
    Date       By            Reason
    03/11/2019 Murry Kane    Original
    01/13/2021 Murry Kane    Removed all APM stop/start from code, adding try/catch/finally to code
    03/08/2021 Murry Kane    Added back APM stop/start for NPE only
    03/10/2021 Murry Kane    Added check for sessions equals count of servers to manage per loop
    03/19/2021 Murry Kane    If import-module can't be imported stop script
_____________________________________________________________________________________________________________________________
    Example


    ./{PATH}\EDI_Services_Pipeline-START.ps1 -Environment EDIN01,HIXN01 -Pipeline ediinq
    ./{PATH}\EDI_Services_Pipeline-START.ps1 -Environment EDIP02,HIXP02 -Pipeline ediinq,edienr
    ./{PATH}\EDI_Services_Pipeline-START.ps1 -Environment EDIP02,HIXP02 -Pipeline edienr,ediclaim
#>

[CmdletBinding()]
Param(
  #[Parameter(Mandatory=$True,Position=1)]
   [string[]]$Environment,
   [string[]]$Pipeline
	
)

$exit_code = 0
$LOG_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\logs'
$PAM_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts'
$currentScriptName = $MyInvocation.MyCommand.Name
$filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
$SleepTimer = 5
$PIPEVALUES = 'ediinq','ediclaim', 'edienr'

Write-Host "Script name is: $currentScriptName"

if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS)))
{
    $LOG_DIR = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS
}
else
{
    $LOG_DIR = $PAM_HOME_DIR_DEFAULT 
}

$LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

#get PAM home dir
if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME)))
{
    $PAM_HOME = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME
}
else
{
    $PAM_HOME = $PAM_HOME_DIR_DEFAULT 
}


#lets start logging what occures from here forward....
Start-Transcript -path $LOG_FILE -append
#turn off Verbose logging
$VerbosePreference = 'SilentlyContinue'

#import functions
Import-Module Functions -Force -WarningAction SilentlyContinue -ErrorAction Stop

try
{
    if ($Host.Name -eq "Windows PowerShell ISE Host") {
        $ISE=$true
    } else {
        $ISE=$false
    }
    if ($ISE) {
        # get the required input
        if(-not($Environment)) {
            $Environment = @()
            do 
            {
                $input = (Read-Host "Input your Environment (EDIP02, EDIN01, HIXN01): ")
                if ($input -ne '') {$Environment += $input}
            }
            until ($input -eq '')
        }
        if(-not($Pipeline)) {
            $Pipeline = @()
            $input = ''
            $stopval = 'value'
            do {
                $input = (Read-Host -Prompt "Input your Pipeline ($PIPEVALUES): ")
                if ($input -ne '') 
                {
                    $input = $input.ToLower()
                    if($PIPEVALUES.Contains($input) -AND (-not $Pipeline.Contains($input)))
                    {
                        $Pipeline += $input
                    }
                }
                else
                {
                    if($Pipeline -ne '')
                    {
                        $stopval = ''
                    }
                }
                Write-Verbose "Input is [$input] and Pipeline [$Pipeline]"
            }
            until ($stopval -eq '')
        } 
    }

    if (-not($Environment)) 
    {
        $exit_code = 32
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    if (-not($Pipeline))
    {
        $exit_code = 33
        Write-Error "Pipeline is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    else
    {
        $Pipeline = $Pipeline.ToLower()
        $pipeTrue = $true
        foreach ($v in $Pipeline)
        {
          if ($PIPEVALUES -notcontains $v)
          {
            $pipeTrue = $false
            break
          }
        }

    
        if($pipeTrue)
        {
            Write-Host "Valid Pipeline [$Pipeline] passed"
        }
        else
        {
            Write-Error "Invalid Pipeline [$Pipeline] passed, exiting!"
            $exit_code = 34
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE
        } 
    
    }

    Write-Host "PAM HOME Directory is $PAM_HOME"
    Write-Host "Log File is $LOG_FILE"
    Write-Host "Environment is [$Environment]"
    Write-Host "Pipeline is [$Pipeline]"

    #import PAM Service Module
    Import-Module Get-PAMServiceControl -Verbose -WarningAction SilentlyContinue -ErrorAction Stop

    #import-module -name Get-BSCServersInfo
    Import-Module Get-BSCServersInfo -WarningAction SilentlyContinue -ErrorAction Stop


    ######################################################################################################################################################
    # Servers for the given pipeline(s) only
    #
    $servers = get-bscserversinfo -Environment $Environment -WhichProperty SuperRole -PropValue $Pipeline -ColumnReturn ServerName 
    #$ServicesToControl = @('EDI*', 'IBM*', 'BSCEDI*', 'EAMService')
    $ServicesToControl = @('EdifecsTMServiceManager')

    #check if servers is empty, then exit
    if(([string]::IsNullOrEmpty($servers))) 
    {
        Write-Error "Could not determine a list of servers for Pipeline [$Pipeline] for environment [$Environment], exiting!"
        $exit_code = 13
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    #now that we have the servers, let validate we are not trying to cross Domains (NPE to PROD or vise-versa)
    $Platform = get-bscserversinfo -Environment $Environment -WhichProperty ServerName -PropValue $servers -ColumnReturn Platform
    #$Domain = (Get-ADDomain).Name  #mbk its expensive call...
    $Domain = (Get-ChildItem Env:'USERDOMAIN' -ErrorAction Ignore).Value
    Write-Verbose "Platform for these servers is [$Platform], Active Directory Domain is [$Domain]"
    if ($Platform -eq 'PROD' -and $Domain -ne 'BSC')
    {
        #we can't run run from NONE PROD domain to prod servers...
        Write-Error "WE CAN'T run a script from a NONE PROD Active Directory Domain ($Domain) to Production Servers(Platform [$Platform]), exiting script!"
        $exit_code = 20
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    elseif ($Platform -ne 'PROD' -and $Domain -eq 'BSC')
    {
        Write-Error "WE CAN'T run from a PROD Active Directory Domain ($Domain) to NONE Production Servers(Platorm [$Platform]), exiting script!"
        $exit_code = 21
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    else
    {
        Write-Host "Running script in Active Directory Domain [$Domain] for server types of [$Platform]"
    }


    if(-not ([string]::IsNullOrEmpty($servers))) 
    {
        Write-Host "Working on EDI [$Pipeline] servers [$servers] for Services [$($servicesToControl)]"

        #pipeline(s) only
        Write-Verbose "Building PSSessions on [$Servers] Servers"
        $Session = New-PSSession -ComputerName $Servers -Verbose

        #first check for wrong count of connected servers...
        if($($Session.count) -ne $($Servers.count))
        {
            Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
            Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
            $exit_code = 19
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }

        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'start',100 -AsJob
        #$Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'check',100 -AsJob
        #wait for job to complete and output results
        $rc1 = checkJobAndLog -Session $Session -Jobs $Jobs
        $RCode1 = $($rc1)[1]
        if ($RCode1 -ne 0)
        {
            $exit_code = $RCode1
            Write-Error "ERROR: Failures during start.... RC = $RCode1"
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE
        }
        else
        {
            Write-Host "All good on job(s) Start... RC = $RCode1"
        }

        $ServicesToControl = @('EDI*', 'IBM*', 'BSCEDI*', 'EAMService')

        Write-Host "Working on EDI [$Pipeline] servers [$servers] for Services [$($servicesToControl)]"

        #pipeline(s) only
        Write-Verbose "Building PSSessions on [$Servers] Servers"
        $Session = New-PSSession -ComputerName $Servers -Verbose
        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'start',100 -AsJob
        #$Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'check',100 -AsJob
        #wait for job to complete and output results
        $rc2 = checkJobAndLog -Session $Session -Jobs $Jobs
        $RCode2 = $($rc2)[1]
        if ($RCode2 -ne 0)
        {
            $exit_code = $RCode1 + $RCode2
            Write-Error "ERROR: Failures during start.... RC = $RCode2"
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE
        }
        else
        {
            Write-Host "All good on job(s) Start... RC = $RCode2"
        }


    }
    else
    {
        Write-Host "Servers is empty, skipping EDI for servers [$servers] for Services [$($servicesToControl)]"
    }
    #done 
    ######################################################################################################################################################


    ######################################################################################################################################################
    #
    #Only do this is failures occurred in last loop....
    #
    if($RCode2 -ne 0)
    {
        #MBK Added a 8th loop to see if that fixes the issues with long stops for everything
        Write-Host "Sleeping for a short time of [30] seconds...."
        Start-Sleep -Seconds 30

        if(-not ([string]::IsNullOrEmpty($servers))) 
        {
            Write-Host "Building PSSessions on [$Servers] Servers"
            $Session = New-PSSession -ComputerName $Servers -Verbose
            $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'start',100 -AsJob
            #$Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'check',100 -AsJob

            #wait for job to complete and output results
            $rc8 = checkJobAndLog -Session $Session -Jobs $Jobs
            $RCode8 = $($rc8)[1]

            if ($RCode8 -ne 0)
            {
                Write-Error "ERROR: Failures during LOOP 8.... RC = $RCode8"
            }
            else
            {
                Write-Host "All good on retry... RC = $RCode8"
            }
        }
        $exit_code = $RCode8
    }

    ######################################################################################################################################################
    #
    #Start all Monitoring for all EDI servers for the given environment
    #
    $servers = get-bscserversinfo -Environment $Environment -WhichProperty SuperRole -PropValue $Pipeline -ColumnReturn ServerName 
    $ServicesToControl = @('KNTC*', 'KQ7C*', 'KYNA*')

    if(-not ([string]::IsNullOrEmpty($servers))) 
    {
        if($Platform -ne 'PROD')
        {
            Write-Host "Working on EDI Monitoring enable for servers [$servers] for Services [$($servicesToControl)]"
            Write-Host "Building PSSessions on [$Servers] Servers"
            $Session = New-PSSession -ComputerName $Servers -Verbose
            $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'start',100 -AsJob
            #$Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'check',100 -AsJob

            #wait for job to complete and output results
            $mc1 = checkJobAndLog -Session $Session -Jobs $Jobs
            $MCode1 = $($mc1)[1]
            if ($MCode1 -ne 0)
            {
                Write-Error "ERROR: Failures during Monitoring Enable for All EDI.... RC = $MCode1"
                #MBK add to retry counter.....
            }
            else
            {
                Write-Host "All good on job(s) Monitoring Start... RC = $MCode1"
            }
         }
         else
         {
            Write-Host "We are running in production, we will skip the startup of the APM services for monitoring"
         }
    }
    else
    {
        Write-Host "Servers are empty, skipping Monitoring start on servers [$servers] for Services [$($servicesToControl)]"
    }
    ######################################################################################################################################################

}
catch
{
    Write-Warning $_.Exception.ToString();
    if($exit_code -lt 1 )
    {
        $exit_code = 99
    }
}
finally
{
    #cleanup now...
    Remove-Module -Name Get-PAMServiceControl -WarningAction SilentlyContinue
    Remove-Module -Name Get-BSCServersInfo -WarningAction SilentlyContinue
    Remove-Module -Name Functions -WarningAction SilentlyContinue

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"

    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}



