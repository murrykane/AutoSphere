﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	11/13/2017
	 Updated on:	11/13/2017
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	EDI_Services_STOP.ps1

	The scripts being built in this grouping are for PAM Production Support
	The majority will be run from the Primary PAM Server, WINF313P. However,
	it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script Stops all EDI Services and validates to a provided
        input parameter that all services are in that state, otherwise exits
        badly.

MODIFICATIONS
_____________________________________________________________________________________________________________________________
    Date       By            Reason
    12/06/2018 Murry Kane    Added function for waiting for PSESSION's and output the results along
                             with 2 loops 
                                - 1st loop does MQ and EdifecsTMServiceManager ONLY
                                - 2nd loop does all other EDI* profiles, IBM Websphere and EAMService (like original job)

    12/30/2018 Murry Kane    Added 3rd loop for EAMService and any left overs....
    01/07/2019 Murry Kane    Added a 4th loop only if errors are found on the 3rd loop
    01/17/2019 Murry Kane    Added 5 loops to correct stop order
    01/31/2019 Murry Kane    Added logic to disable monitoring before any stops are issued
                             REmoved MQ based on discussions with MQ team
    02/14/2019 Murry Kane    Combined the XE and ETL servers into 1 loop for EDI*XE* and EDI*ETL*
                             Added new argument to denote PATCHING or CORE weekend recycles
                               - This argument is required and will determine full recyle for partial 
                                 a) infra = Patching weekend also known and infrastructure maintenance (reboots and patching of servers)
                                 b) core = This is CORE/Maintenace release where application code is pushed to the environment and no reboots are performed
    02/16/2019 Murry Kane    Added logic to rename the TM.LOG files with date/time stamp
    03/01/2019 Murry Kane    Changed stop seconds from 200 to 60 seconds for each service
    07/01/2019 Murry Kane    Was missing the ETL servers for checks on CORE weekends
    07/14/2019 Murry Kane    Added logic for the new upgrade server EDIWEB (IBM stand alone server)
	09/03/2019 Ed Gonzales   updated userid to include svc-edifecs line 489-490
    09/24/2019 Murry Kane    change needed for match instead of -eq for userid (svc-edifecs) line 512-514
    09/26/2019 Vitaliy F.    Updated the stop process section to run parallel instead of serially by moving code to function and using PSSessions
    09/30/2019 Murry Kane    Changed the checkandLog to checkRemoteJobAndLog for the stop-process on EDI running processes
    01/13/2021 Murry Kane    Removed all APM stop/start from code, adding try/catch/finally to code
    03/08/2021 Murry Kane    formatting clean up and the stopping/starting of APM Agents is only for NPE environments, skipped for production
    03/10/2021 Murry Kane    Added check for sessions equals count of servers to manage per loop
    03/19/2021 Murry Kane    If import-module can't be imported stop script
                             added -force to the rename of the TM.log file 

_____________________________________________________________________________________________________________________________
    Example

    ./{PATH}\EDI_Services_STOP.ps1 -Environment EDIN01,HIXN01 -MaintType infra
    ./{PATH}\EDI_Services_STOP.ps1 -Environment EDIP02,HIXP02 -MaintType core
#>

[CmdletBinding()]
Param(
  #[Parameter(Mandatory=$True,Position=1)]
   [string[]]$Environment,
   [string]$MaintType
	
)

$exit_code = 0
$LOG_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\logs'
$PAM_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts'
$currentScriptName = $MyInvocation.MyCommand.Name
$filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
$SleepTimer = 5
$MAINTVALUES = 'core','infra'

Write-Host "Script name is: $currentScriptName"

if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS)))
{
    $LOG_DIR = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS
}
else
{
    $LOG_DIR = $PAM_HOME_DIR_DEFAULT 
}

$LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

#get PAM home dir
if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME)))
{
    $PAM_HOME = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME
}
else
{
    $PAM_HOME = $PAM_HOME_DIR_DEFAULT 
}

#lets start logging what occures from here forward....
Start-Transcript -path $LOG_FILE -append
#turn off logging
$VerbosePreference = 'SilentlyContinue'


#import functions
Import-Module Functions -Force -WarningAction SilentlyContinue -ErrorAction Stop

function stopEdiProcesses
{
    #turn on verbose
    $VerbosePreference = 'Continue'
    Write-Verbose "Server name: $env:computername"

    #stop processes section
    $userid = 'svc-edifecs2','svc-edifecs'

    $owners = @{}
    #populate @Owners
    try
    {
        Get-WmiObject -Class win32_process -ErrorAction SilentlyContinue |% {$owners[$_.handle] = $_.getowner().user} -ErrorAction SilentlyContinue
    }
    catch
    {
        Write-Verbose "Process no longer exists....."
    }
    $ps = get-process -ErrorAction SilentlyContinue | select processname,Id,@{l="Owner";e={$owners[$_.id.tostring()]}} -ErrorAction SilentlyContinue

    foreach($p in $ps) {
        if(-not ([string]::IsNullOrEmpty($($p.Owner))) -and -not([string]::IsNullOrEmpty($($p.Id))))
        {
            #MIGHT need to put if java.exe and System owner then stop-process......
            if($userid -match $($p.Owner)) {
                Write-Verbose "Attempting stop of the process [$($p.ProcessName)] Process ID [$($p.Id)] Owner [$($p.Owner)]"
                (gwmi win32_process -Filter "Handle=$($p.Id)" -ErrorAction SilentlyContinue).Terminate()
            }
            else
            {
                Write-Verbose "Skipping process [$($p.ProcessName)] Process ID [$($p.Id)]. Owner [$($p.Owner)].  Owner mismatch!"
            }
        }
    }

    #turn off verbose
    $VerbosePreference = 'SilentlyContinue'
    
}

function renameTMLogs
{

    param
    (
        [parameter(ValueFromPipeline=$true)]$hostnames
    )

    $ServerCount = $hostnames.Count
    Write-Host "Working on rename TM Service Logs for servers [$hostnames] Count of Servers is [$ServerCount]"

    $DateStamp = $(get-date -f yyyy-MM-dd-HH-mm-ss)
    $TMLog = 'D$\Edifecs\TM\ServiceManager\logs\TM.log'
    $TMNewLog = 'TM-' + $DateStamp + '.log'
    $RenameCounter = 0

    foreach ($hostname in $hostnames)
    {
        $file = "\\$hostname\$TMLog"
        $renameFile = $TMNewLog
        write-host "Renaming TM File: [$file] to [$TMNewLog]"
        if (Test-Path $file)
        {
            Try
            {
                Rename-Item -force -Path $file -NewName $renameFile -ErrorAction stop
                $RenameCounter += 1
            }
            catch
            {
                Write-Error "Failed to rename [$file] to [$renameFile]!"
            }
              
        }
        else
        {
            Write-Warning "$hostname : can't read file: $file"
        }
    }


    #Return found count.
    Write-Host "Returning with count of [$RenameCounter] for number of TM log(s) that were renamed"
    return $RenameCounter

}

try
{

    if ($Host.Name -eq "Windows PowerShell ISE Host") {
        $ISE=$true
    } else {
        $ISE=$false
    }
    if ($ISE) {
        # get the required input
        if(-not($Environment)) {
            $Environment = @()
            do 
            {
                $input = (Read-Host "Input your Environment (EDIP02, EDIN01, HIXN01): ")
                if ($input -ne '') {$Environment += $input}
            }
            until ($input -eq '')
        }
        if(-not($MaintType)) {
            do {
                $MaintType = (Read-Host -Prompt "Input your Maintenance Type ($MAINTVALUES): ")
                $MaintType = $MaintType.ToLower()
               }
                until ($MAINTVALUES.Contains($MaintType))
        } 
    }

    if (-not($Environment)) 									 
    {
        $exit_code = 33
        Write-Error "Enviroment is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    if (-not($MaintType))
    {
																		   
        $exit_code = 34
        Write-Error "Maintenance Type is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    else
    {
        $MaintType = $MaintType.ToLower()
        if($MAINTVALUES.Contains($MaintType))						  
        {
            Write-Host "Valid Maintenace Type [$MaintType] passed"																											   
        }
        else
        {
            Write-Error "Invalid Maintenace Type [$MaintType] passed, exiting!"																				
            $exit_code = 34
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE
        } 
    }

    Write-Host "PAM HOME Directory is $PAM_HOME"
    Write-Host "Log File is $LOG_FILE"
    Write-Host "Environment is [$Environment]"
    Write-Host "Maitenance Type is [$MaintType]"

    #import Module
    Import-Module Get-BSCServersInfo -WarningAction SilentlyContinue -ErrorAction Stop
    Import-Module Get-PAMServiceControl -Verbose -WarningAction SilentlyContinue -ErrorAction Stop


    ######################################################################################################################################################
    # first see if CORE or INFRA
    # Validate we are not crossing domains for NPE/PROD
														  
    $Servers = ''																																			  																																				
    if($MaintType -eq 'infra')			  
    {
        Write-Host "Including TM/SB as this is Patching Weekend"
        $servers = get-bscserversinfo -Environment $Environment -WhichProperty app -PropValue EDI -ColumnReturn ServerName 
    }
    else
    {
        Write-Host "Excluding TM/SB as this in not patching weekend"
        $servers = get-bscserversinfo -Environment $Environment -WhichProperty Role -PropValue EDIXE,EDIETL -ColumnReturn ServerName 
    }

    #check if servers is empty, then exit
    if(([string]::IsNullOrEmpty($servers))) 					  
    {
        Write-Error "Could not determine a list of servers for environment [$Environment], exiting!"
        $exit_code = 13
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE																												  
    }

    #now that we have the servers, let validate we are not trying to cross Domains (NPE to PROD or vise-versa)
    $Platform = get-bscserversinfo -Environment $Environment -WhichProperty ServerName -PropValue $Servers -ColumnReturn Platform
    #$Domain = (Get-ADDomain).Name  #mbk its expensive call...
    $Domain = (Get-ChildItem Env:'USERDOMAIN' -ErrorAction Ignore).Value
    Write-Verbose "Platform for these servers is [$Platform], Active Directory Domain is [$Domain]"
    if ($Platform -eq 'PROD' -and $Domain -ne 'BSC')
    {
        #we can't run run from NONE PROD domain to prod servers...
        Write-Error "WE CAN'T run a script from a NONE PROD Active Directory Domain ($Domain) to Production Servers(Platform [$Platform]), exiting script!"
        $exit_code = 20
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    elseif ($Platform -ne 'PROD' -and $Domain -eq 'BSC')
    {
        Write-Error "WE CAN'T run from a PROD Active Directory Domain ($Domain) to NONE Production Servers(Platorm [$Platform]), exiting script!"
        $exit_code = 21
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    else
    {
        Write-Host "Running script in Active Directory Domain [$Domain] for server types of [$Platform]"
    }

    ######################################################################################################################################################
    # Lets stop APM from a monitoring perspective only if we are running for NPE 
    #
    $ServicesToControl = @('KNTC*', 'KQ7C*', 'KYNA*')

    if(-not ([string]::IsNullOrEmpty($servers))) 
    {
        if($Platform -ne 'PROD')
        {
            Write-Host "Working on EDI Monitoring disable for servers [$servers] for Services [$($servicesToControl)]"
            Write-Host "Building PSSessions on [$Servers] Servers"
            $Session = New-PSSession -ComputerName $Servers -Verbose

            #first check for wrong count of connected servers...
            if($($Session.count) -ne $($Servers.count))
            {
                Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
                Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
                $exit_code = 19
                ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
            }

            $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'stop',60 -AsJob
            #$Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'check',100 -AsJob

            #wait for job to complete and output results
            $mc1 = checkJobAndLog -Session $Session -Jobs $Jobs
            $MCode1 = $($mc1)[1]
            if ($MCode1 -ne 0)
            {
                Write-Error "ERROR: Failures during Monitoring Disable for All EDI.... RC = $MCode1"
                #MBK add to retry counter.....
            }
            else
            {
                Write-Host "All good on job(s) Monitoring Stop... RC = $MCode1"
            }
        }
        else
        {
            Write-Host "We are running in Production and will skip the APM monitoring services stop"
        }
    }
    else
    {
        Write-Host "Servers are empty, skipping Monitoring stop on servers [$servers] for Services [$($servicesToControl)]"
    }

    ######################################################################################################################################################


    ######################################################################################################################################################
    ######################################################################################################################################################
    #
    #do EDI XE/ETL servers first
    #
    $servers = ''
    $ServicesToControl = ''

    if($MaintType -eq 'infra')
    {
        Write-Host "Including IBM* as this is Patching Weekend"
        $ServicesToControl = @('EDI*', 'BSCEDI*', 'IBM*', 'HIX*', 'EAMService') 
        $servers = get-bscserversinfo -Environment $Environment -WhichProperty role -PropValue EDIXE,EDIETL -ColumnReturn ServerName 
    }
    else
    {
        Write-Host "Excluding IBM* as this in not patching weekend"
        $ServicesToControl = @('EDI*', 'BSCEDI*', 'EAMService')
        $servers = get-bscserversinfo -Environment $Environment -WhichProperty role -PropValue EDIXE,EDIETL -ColumnReturn ServerName 
    }

    if(-not ([string]::IsNullOrEmpty($servers))) 						 
    {
        Write-Host "Working on EDI servers [$servers] for Services [$($servicesToControl)]"
        Write-Host "Building PSSessions on [$Servers] Servers"
        $Session = New-PSSession -ComputerName $Servers -Verbose

        #first check for wrong count of connected servers...
        if($($Session.count) -ne $($Servers.count))
        {
            Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
            Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
            $exit_code = 19
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }

        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'stop',60 -AsJob
        #$Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'check',100 -AsJob

        #wait for job to complete and output results
        $rc1 = checkJobAndLog -Session $Session -Jobs $Jobs
        $RCode1 = $($rc1)[1]
        if ($RCode1 -ne 0)
        {
            Write-Error "ERROR: Failures during Loop 1 EDI stop.... RC = $RCode1"
            #MBK add to retry counter.....
        }
        else
        {
            Write-Host "All good on job(s) LOOP 1 EDI Stop... RC = $RCode1"
        }

    }
    else
    {
        Write-Host "Servers are empty, skipping EDI servers [$servers] for Services [$($servicesToControl)]"
    }
																																																
    ######################################################################################################################################################
    ######################################################################################################################################################
    #ETL Servers for EDI*/bscedi* and IBM* ... LOOP 2
    #TM/SB Servers for EDI*ETL* and EDI*ETL and IBM* ... LOOP 3
    #
    $servers = get-bscserversinfo -Environment $Environment -WhichProperty role -PropValue EDITM,EDISB,EDIWEB -ColumnReturn ServerName 

    $ServicesToControl = ''
																
    if($MaintType -eq 'infra')
    {
        Write-Host "Including IBM* as this is Patching Weekend"
        $ServicesToControl = @('EDI*', 'BSCEDI*', 'IBM*', 'HIX*', 'EAMService') 
    }
    else
    {
        Write-Host "Excluding IBM* as this in not patching weekend"
        $ServicesToControl = @('EDI*', 'BSCEDI*', 'EAMService')
    }

    if(-not ([string]::IsNullOrEmpty($servers)) -and ($MaintType -eq 'infra')) 
    {
        Write-Host "Working on EDI TM/SB for servers [$servers] for Services [$($servicesToControl)]"																				   
        Write-Host "Building PSSessions on [$Servers] Servers"
        $Session = New-PSSession -ComputerName $Servers -Verbose

        #first check for wrong count of connected servers...
        if($($Session.count) -ne $($Servers.count))
        {
            Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
            Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
            $exit_code = 19
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }

        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'stop',60 -AsJob
        #$Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'check',100 -AsJob

        #wait for job to complete and output results
        $rc2 = checkJobAndLog -Session $Session -Jobs $Jobs
        $RCode2 = $($rc2)[1]

        if ($RCode2 -ne 0)
        {
            Write-Host "ERROR: Failures during LOOP 2 TM/SB Servers stop.... RC = $RCode2"
            #MBK later abort....
        }
        else
        {
            Write-Host "All good on job(s) LOOP 2 EDI TM/SB Servers stop... RC = $RCode2"
        }
    }
    else
    {
        if($MaintType -eq 'core')
        {
            Write-Host "Skipping TM/SB EDI Servers as this is Maitenance [$MaintType] Release"
        }
        else
        {
            Write-Host "Servers is empty, skipping EDI TM/SB for servers [$servers] for Services [$($servicesToControl)]"
        }
    }

    ######################################################################################################################################################
    #
    #
    #All Servers for EDI*/bscedi* and IBM* ... LOOP 7
    # first see if CORE or INFRA
    $ServicesToControl = ''
    $Servers = ''

    if($MaintType -eq 'infra')
    {
        Write-Host "Including IBM* as this is Patching Weekend"
        $servers = get-bscserversinfo -Environment $Environment -WhichProperty app -PropValue EDI -ColumnReturn ServerName 
        $ServicesToControl = @('EDI*', 'IBM*', 'HIX*', 'BSCEDI*', 'EAMService')
    }
    else
    {
        Write-Host "Excluding IBM* as this in not patching weekend"
        $servers = get-bscserversinfo -Environment $Environment -WhichProperty Role -PropValue EDIXE,EDIETL -ColumnReturn ServerName 
        $ServicesToControl = @('EDI*', 'BSCEDI*', 'EAMService')
    }

    if(-not ([string]::IsNullOrEmpty($servers))) 
    {
        Write-Host "Working on EDI All servers [$servers] for Services [$($servicesToControl)]"
        Write-Host "Building PSSessions on [$Servers] Servers"
        $Session = New-PSSession -ComputerName $Servers -Verbose

        #first check for wrong count of connected servers...
        if($($Session.count) -ne $($Servers.count))
        {
            Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
            Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
            $exit_code = 19
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }

        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'stop',60 -AsJob
        #$Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'check',100 -AsJob

        #wait for job to complete and output results
        $rc7 = checkJobAndLog -Session $Session -Jobs $Jobs
        $RCode7 = $($rc7)[1]

        if ($RCode7 -ne 0)
        {
            Write-Host "ERROR: Failures during LOOP 7 EDI Stop .... RC = $RCode7"
            #mbk add to counter....
        }
        else
        {
            Write-Host "All good on job(s) EDI Stop... RC = $RCode7"
        }
    }
    else					   
    {
        Write-Host "Servers is empty, skipping EDI All servers [$servers] for Services [$($servicesToControl)]"
    }
										   
    ##Stop EDI Processes
    if(-not ([string]::IsNullOrEmpty($servers))) 
    {
        Write-Host "Working on stopping EDI Processes for servers [$servers]"
        Write-Host "Building PSSessions on [$Servers] Servers"
        $Session = New-PSSession -ComputerName $Servers -Verbose

        #first check for wrong count of connected servers...
        if($($Session.count) -ne $($Servers.count))
        {
            Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
            Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
            $exit_code = 19
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }

        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::stopEdiProcesses} -AsJob

        #wait for job to complete and output results
        #$mc2 = checkJobAndLog -Session $Session -Jobs $Jobs
        $mc2 = checkRemoteJobAndLog -Session $Session -Jobs $Jobs
        $MCCount = $($mc2).Count
        $ProcCnt = $MCCount -2
        Write-Host "Stop process removed [$ProcCnt] proceses from all servers"
        #MBK subtract 1 for array position
        $MCCount = $MCCount -1 
        $MCode2 = $($mc2)[$MCCount]
        if ($MCode2 -ne 0)
        {
            Write-Error "ERROR: Failures during Process Stop for EDI.... RC = $MCode2"
            #MBK add to retry counter.....
        }
        else
        {
            Write-Host "All good on job(s) Process Stop... RC = $MCode2"
        }
    }
    else
    {
        Write-Host "Servers are empty, skipping Process stop on servers [$servers]"															 
    }
 
    Write-Host "All Done with process stops for remaining java/other processing running as EDI accounts"

    ######################################################################################################################################################
    #
    #Only do this is failures occurred in last loop....
    #
    if($RCode7 -ne 0)
    {
        #MBK Added a 8th loop to see if that fixes the issues with long stops for everything
        Write-Host "Sleeping for a short time of [30] seconds...."
        Start-Sleep -Seconds 30

        if(-not ([string]::IsNullOrEmpty($servers))) 
        {
            Write-Host "Building PSSessions on [$Servers] Servers"
            $Session = New-PSSession -ComputerName $Servers -Verbose

            #first check for wrong count of connected servers...
            if($($Session.count) -ne $($Servers.count))
            {
                Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
                Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
                $exit_code = 19
                ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
            }

            $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'stop',60 -AsJob
            #$Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'check',100 -AsJob

            #wait for job to complete and output results
            $rc8 = checkJobAndLog -Session $Session -Jobs $Jobs
            $RCode8 = $($rc8)[1]

            if ($RCode8 -ne 0)
            {
                Write-Error "ERROR: Failures during LOOP 8.... RC = $RCode8"
            }
            else
            {
                Write-Host "All good on retry... RC = $RCode8"
            }
        }
        $exit_code = $RCode8
    }

    #Last step, lets rename the TM.LOG files if INFRA weekends only!
    if ($MaintType -eq 'infra')
    {
        $servers = get-bscserversinfo -Environment $Environment -WhichProperty role -PropValue EDITM,EDISB -ColumnReturn ServerName 
        Write-Host "Working on rename of TM log(s) since this is a INFRA release for servers [$servers]"
        $RC = renameTMLogs -hostnames $servers 

        Write-Host "Rename for TM log(s) returned with count of [$RC]"
        if ($RC -ge $($Servers.Count))
        {
            Write-Host "Good TM/STANDBY TM log(s) rename...."
        }
        else
        {
            #$exit_code = 79
            #Write-Error "ERROR: TM/STANDBY TM log rename did not work, exiting!"
            #ExitWithCode -exitcode $exit_code -ISEFlag $ISE
            Write-Warning "TM/STANDBY TM Log(s) rename did not work!"
        }
    }
}
catch
{
    Write-Warning $_.Exception.ToString();
    if($exit_code -lt 1 )
    {
        $exit_code = 99
    }
}
finally
{
    #cleanup now...
    Remove-Module -Name Get-PAMServiceControl  -ErrorAction SilentlyContinue
    Remove-Module -Name Get-BSCServersInfo  -ErrorAction SilentlyContinue
    Remove-Module -Name Functions  -ErrorAction SilentlyContinue

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"

    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}