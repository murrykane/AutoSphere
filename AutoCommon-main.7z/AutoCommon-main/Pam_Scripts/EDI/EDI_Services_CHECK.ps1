﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	11/13/2017
	 Updated on:	11/13/2017
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	EDI_Services_CHECK.ps1

	The scripts being built in this grouping are for PAM Production Support
	The majority will be run from the Primary PAM Server, WINF313P. However,
	it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script Checks all EDI Services and validates to a provided
        input parameter that all services are in that state, otherwise exits
        badly.

MODIFICATIONS
_____________________________________________________________________________________________________________________________
    Date       By            Reason
    03/11/2019 Murry Kane    Original
    03/08/2021 Murry Kane    added try/catch/finally
    03/10/2021 Murry Kane    Added check for sessions equals count of servers to manage per loop
    03/19/2021 Murry Kane    If import-module can't be imported stop script
    04/14/2022 Murry Kane    testing new repo
_____________________________________________________________________________________________________________________________

    Example

    ./{PATH}\EDI_Services_CHECK.ps1 -Environment HIXN01,EDIN01
    ./{PATH}\EDI_Services_CHECK.ps1 -Environment HIXP01,EDIP01
#>

[CmdletBinding()]
Param(
  #[Parameter(Mandatory=$True,Position=1)]
   [string[]]$Environment
	
)

#turn off verbose
$VerbosePreference = 'SilentlyContinue'
$exit_code = 0
$LOG_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\logs'
$PAM_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts'
$currentScriptName = $MyInvocation.MyCommand.Name
$filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
$SleepTimer = 5

try
{
    Write-Host "Script name is: $currentScriptName"


    if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS)))
    {
        $LOG_DIR = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS
    }
    else
    {
        $LOG_DIR = $PAM_HOME_DIR_DEFAULT 
    }

    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    #get PAM home dir
    if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME)))
    {
        $PAM_HOME = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME
    }
    else
    {
        $PAM_HOME = $PAM_HOME_DIR_DEFAULT 
    }


    #import functions
    Import-Module Functions -Force -WarningAction SilentlyContinue -ErrorAction Stop

    if ($Host.Name -eq "Windows PowerShell ISE Host") {
        $ISE=$true
    } else {
        $ISE=$false
    }


    #lets start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    if ($ISE) {
        # get the required input
        if(-not($Environment)) {
            $Environment = @()
            do 
            {
                $input = (Read-Host "Input your Environment (EDIP02, EDIN01, HIXN01): ")
                if ($input -ne '') {$Environment += $input}
            }
            until ($input -eq '')
        }
    }

    if (-not($Environment)) { Throw "You Must supply a value for -Environment" }


    Write-Host "Log File is $LOG_FILE"
    Write-Host "PAM HOME Directory is $PAM_HOME"
    Write-Host "Environment is [$Environment]"

    Import-Module -name Get-BSCServersInfo -WarningAction SilentlyContinue -ErrorAction Stop
    $servers = get-bscserversinfo -Environment $Environment -WhichProperty app -PropValue EDI -ColumnReturn ServerName

    #check if servers is empty, then exit
    if(([string]::IsNullOrEmpty($servers))) 
    {
        Write-Error "Could not determine a list of servers for environment [$Environment], exiting!"
        $exit_code = 13
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    #now that we have the servers, let validate we are not trying to cross Domains (NPE to PROD or vise-versa)
    $Platform = get-bscserversinfo -Environment $Environment -WhichProperty ServerName -PropValue $Servers -ColumnReturn Platform
    #$Domain = (Get-ADDomain).Name  #mbk its expensive call...
    $Domain = (Get-ChildItem Env:'USERDOMAIN' -ErrorAction Ignore).Value
    Write-Verbose "Platform for these servers is [$Platform], Active Directory Domain is [$Domain]"
    if ($Platform -eq 'PROD' -and $Domain -ne 'BSC')
    {
        #we can't run run from NONE PROD domain to prod servers...
        Write-Error "WE CAN'T run a script from a NONE PROD Active Directory Domain ($Domain) to Production Servers(Platform [$Platform]), exiting script!"
        $exit_code = 20
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    elseif ($Platform -ne 'PROD' -and $Domain -eq 'BSC')
    {
        Write-Error "WE CAN'T run from a PROD Active Directory Domain ($Domain) to NONE Production Servers(Platorm [$Platform]), exiting script!"
        $exit_code = 21
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    else
    {
        Write-Host "Running script in Active Directory Domain [$Domain] for server types of [$Platform]"
    }


    $ServicesToControl = @('EDI*', 'IBM*', 'HIX*', 'MQ*', 'BSCEDI*', 'EAMService')
    $SleepTimer = 5
    import-module -name Get-PAMServiceControl.psm1 -Verbose -WarningAction SilentlyContinue -ErrorAction Stop
 
    if(-not ([string]::IsNullOrEmpty($servers))) 
    {
        Write-Host "Working on Servers [$servers] for Services [$($servicesToControl)]"
        Write-Host "Building PSSessions on [$Servers] Servers"
        $Session = New-PSSession -ComputerName $Servers -Verbose

        #first check for wrong count of connected servers...
        if($($Session.count) -ne $($Servers.count))
        {
            Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
            Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
            $exit_code = 19
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }

        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,check,180 -AsJob
        #wait for job to complete and output results
        $rc1 = checkJobAndLog -Session $Session -Jobs $Jobs 
        $RCode1 = $($rc1)[1]
        if ($RCode1 -ne 0)
        {
            Write-Error "Failures duing Validation Checks with RC: $RCode1"
            $exit_code = $RCode1
        }
        else
        {
            Write-Host "All good on job(s) RC: $RCode1"
        }
    }
    else
    {
        Write-Host "Servers are empty, skipping EDI XE servers [$servers] for Services [$($servicesToControl)]"
    }

}
catch
{
    Write-Warning $_.Exception.ToString();
    if($exit_code -lt 1 )
    {
        $exit_code = 99
    }
}
finally
{
    #cleanup now...
    Remove-Module -Name Get-PAMServiceControl -WarningAction SilentlyContinue
    Remove-Module -Name Get-BSCServersInfo -WarningAction SilentlyContinue
    Remove-Module -Name Functions -WarningAction SilentlyContinue

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"

    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}


