﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	11/13/2017
	 Updated on:	10/08/2020
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	EDI_Services_START.ps1

	The scripts being built in this grouping are for PAM Production Support
	The majority will be run from the Primary PAM Server, WINF313P. However,
	it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script Checks all EDI Services and validates to a provided
        input parameter that all services are in that state, otherwise exits
        badly.

MODIFICATIONS
_____________________________________________________________________________________________________________________________
    Date       By            Reason
    12/06/2018 Murry Kane    Added function for waiting for PSESSION's and output the results along
                             with 2 loops 
                                - 1st loop does MQ and EdifecsTMServiceManager ONLY
                                - 2nd loop does all other EDI* profiles, IBM Websphere and EAMService (like original job)

    12/30/2018 Murry Kane    Added 3rd loop for EAMService and any left overs....
    01/07/2019 Murry Kane    Added a 4th loop only if errors are found on the 3rd loop
    01/28/2019 Murry Kane    Added more logic based on this email from EDI team:


                    1.	Murry to ensure the script follows the follow sequence :- 
                    a.	    Start/Validate  MQ Services on all the three MQ's 
 
                    b.	Start Service manager in Primary 
                    Wait until it starts completely. Check TM logs to confirm the SM is up and running  
 
                    c.	Start Service manager in Standby
                    Wait until it starts completely. Check TM logs to confirm the SM is up and running   
 
                    d.	Start all the services in Primary  (with 5 sec delay)
 
                    e.	Start all the services in Standby (with 5 sec delay)
 
                    f.	Start IBM Services in Primary
 
                    g.	Start all the Service Manager on all the XES, ETL
 
                    h.	Start all the ETL Services (with 5 sec delay)
                    Wait until all started
 
                    i.	Start all the XEngine Services  (with 5 sec delay)

    01/31/2019 Murry Kane    Added logic to enable monitoring after everything is started
    02/14/2019 Murry Kane    Combined the XE and ETL servers into 1 loop for EDI*XE* and EDI*ETL*
                             Added new argument to denote PATCHING or CORE weekend recycles
                               - This argument is required and will determine full recyle for partial 
                                 a) infra = Patching weekend also known and infrastructure maintenance (reboots and patching of servers)
                                 b) core = This is CORE/Maintenace release where application code is pushed to the environment and no reboots are performed
    05/07/2019 Murry Kane    Removed the TM.log check for Integrated/CORE releases
    07/01/2019 Murry Kane    Was missing the ETL servers for checks on CORE weekends
    07/14/2019 Murry Kane    Added logic for the new upgrade server EDIWEB (IBM stand alone server) also added 1b loop to start the TM Config Service on TM server
    10/08/2020 Murry Kane    Added logic to call the JVM Max Heap setting to be present in the EDI profiles before starting, if any are found
                             it will prevent the starting of EDI. 
    10/13/2020 Murry Kane    REmoved 10/08/2020 code, is still there in but commented out. EDI team has to many profiles missing MAX setting
    01/13/2021 Murry Kane    Removed all APM stop/start from code, adding try/catch/finally to code
    03/08/2021 Murry Kane    formatting clean up and the stopping/starting of APM Agents is only for NPE environments, skipped for production
                             removed MQ check as this no longer runs on Windows Servers and now runs on Linux Appliances 
    03/10/2021 Murry Kane    Added check for sessions equals count of servers to manage per loop
                             increased time to wait for TM started for TM.LOG review from 10 minutes to 15
    03/19/2021 Murry Kane    If import-module can't be imported stop script

_____________________________________________________________________________________________________________________________
    Example


    ./{PATH}\EDI_Services_START.ps1 -Environment EDIN01,HIXN01 -MaintType infra
    ./{PATH}\EDI_Services_START.ps1 -Environment EDIP02,HIXP02 -MaintType core
#>

[CmdletBinding()]
Param(
  #[Parameter(Mandatory=$True,Position=1)]
   [string[]]$Environment,
   [string]$MaintType
	
)

$exit_code = 0
$LOG_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\logs'
$PAM_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts'
$currentScriptName = $MyInvocation.MyCommand.Name
$filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
$SleepTimer = 5
$MAINTVALUES = 'core','infra'

Write-Host "Script name is: $currentScriptName"

if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS)))
{
    $LOG_DIR = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS
}
else
{
    $LOG_DIR = $PAM_HOME_DIR_DEFAULT 
}

$LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

#get PAM home dir
if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME)))
{
    $PAM_HOME = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME
}
else
{
    $PAM_HOME = $PAM_HOME_DIR_DEFAULT 
}


#lets start logging what occures from here forward....
Start-Transcript -path $LOG_FILE -append
#turn off Verbose logging
$VerbosePreference = 'SilentlyContinue'

#import functions
Import-Module Functions -Force -WarningAction SilentlyContinue -ErrorAction Stop

function ValidateTMStarted
{

    param
    (
        [parameter(ValueFromPipeline=$true)]$hostnames,
        [parameter(ValueFromPipeline=$true)]$timeFlag
    )

    $ServerCount = $hostnames.Count
    Write-Host "Working on determine TM Service started for servers [$hostnames] Count of Servers is [$ServerCount] and Validate Recent start [$timeFlag]"

    if($timeFlag)
    {
        Write-Host "Recent start of the TM log expected...."
        $lowerLimit = [datetime]::Now.AddMinutes(-5)  #figure the service started at most 5 minutes ago....
    }
    else
    {
        Write-Host "TM server could have started last Patching Cycle, going back 45 days...."
        $lowerLimit = [datetime]::Now.AddDays(-45)  #figure the service started at least 45 days ago....
    }

    #lets get date stamps for now plus 15 minutes from now
    $upperLimit = [datetime]::Now.AddMinutes(15)  #quit checking after this time.....

    $TMLog = 'D$\Edifecs\TM\ServiceManager\logs\TM.log'
    $searchtext = "TaskManager started."
    $FoundCounter = 0
    $FoundServers = @()

    Write-Host "Start Check Time  : $lowerLimit"
    write-host "Exit checking time: $upperLimit"

    Do { 
        $TimeNow = Get-Date
        Write-Host "Current Time is: $TimeNow"
        if ($TimeNow -ge $upperLimit) 
        {
           Write-host "It's time to finish chekcing for TM Startup..."
        } 
        else 
        {
           Write-Host "Not done yet, it's only $TimeNow"
        }

        foreach ($hostname in $hostnames)
        {
            $file = "\\$hostname\$TMLog"
            write-host "Checking TM File: [$file]"
            if (Test-Path $file)
            {
                $TMLogContent = Get-Content $file

                foreach ($line in $TMLogContent)
                { 
                    $dateAsStr = ($line -split '\s',3)[0]
                    $timeAsStr = ($line -split '\s',3)[1]
                    $timeAsStrNew = ($timeAsStr -split ',',2)[0]
                    $theDate = "$dateAsStr $timeAsStrNew"
                    try 
                    {
                        Write-Verbose "date is [$thedate]"
                        if([string]::IsNullOrEmpty($dateAsStr) -OR [string]::IsNullOrEmpty($timeAsStr)) 
                        {
                            Write-Verbose "Skipping line "
                        }
                        else
                        {
                            $date = [datetime]::Parse($theDate) 
                            Write-Verbose "Date is $date"
                            if (($lowerLimit -lt $date) -and ($date -lt $upperLimit))
                            {
                                #$line #output the current item because it belongs to the requested time frame
                                #see if we find a line with Up TM...
                                if($line | Select-String $searchtext -quiet)
                                {
                                    Write-Verbose "FOUND IT!!!! with [$line]"
                                    if($FoundServers.Contains($hostname))
                                    {
                                        Write-Host "Already added started TM Service to array for server [$hostname]!"
                                    }
                                    else
                                    {
                                        Write-Host "FOUND IT!!!! with [$line] for host [$hostname]"
                                        $FoundServers += $hostname
                                        $FoundCounter += 1
                                    }
                                }
                                else
                                {
                                    Write-Verbose "not in line...."
                                }
                        
                            }
                        }
                    }
                    catch
                    {
                        #date is malformed (maybe the line is empty or there is a typo), skip it
                        write-Verbose "Catch statement called..."
                    }

                }
            }
            else
            {
                Write-Error "$hostname : can't read file: $file"
            }
        }
        #lets sleep 30 seconds for next loop....
        if($foundCounter -ge $ServerCount)
        {
            #enough started....
            Write-Host "All TM Service's started sucessfully"
            #lets force the exit....
            $TimeNow = $upperLimit
        }
        else
        {
            Write-Host "Sleeping for 30 seconds for next loop..."
            Start-Sleep -Seconds 30
        }
    }
    Until ($TimeNow -ge $upperLimit)

    #Return found count.
    Write-Host "Returning with count of [$FoundCounter] for number of servers started for TM service"
    return $FoundCounter

}

#Main
try
{

    if ($Host.Name -eq "Windows PowerShell ISE Host") {
        $ISE=$true
    } else {
        $ISE=$false
    }
    if ($ISE) {
        # get the required input
        if(-not($Environment)) {
            $Environment = @()
            do 
            {
                $input = (Read-Host "Input your Environment (EDIP02, EDIN01, HIXN01): ")
                if ($input -ne '') {$Environment += $input}
            }
            until ($input -eq '')
        }
        if(-not($MaintType)) {
            do {
                $MaintType = (Read-Host -Prompt "Input your Maintenance Type ($MAINTVALUES): ")
                $MaintType = $MaintType.ToLower()
               }
                until ($MAINTVALUES.Contains($MaintType))
        } 
    }

    if (-not($Environment)) 
    {
        $exit_code = 32
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    if (-not($MaintType))								 
    {
        $exit_code = 33
        Write-Error "Maintenance Type is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    else
    {
        $MaintType = $MaintType.ToLower()
        if($MAINTVALUES.Contains($MaintType))
        {
            Write-Host "Valid Maintenace Type [$MaintType] passed"
        }
        else
        {
            Write-Error "Invalid Maintenace Type [$MaintType] passed, exiting!"
            $exit_code = 34
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE
        } 
    }

    Write-Host "PAM HOME Directory is $PAM_HOME"
    Write-Host "Log File is $LOG_FILE"
 
    Write-Host "Environment is [$Environment]"
    Write-Host "Maitenance Type is [$MaintType]"

    #import PAM Service Module
    Import-Module Get-PAMServiceControl -Verbose -WarningAction SilentlyContinue -ErrorAction Stop
    #import-module -name Get-BSCServersInfo
    Import-Module Get-BSCServersInfo -WarningAction SilentlyContinue -ErrorAction Stop

    ######################################################################################################################################################
    # Loop 1 is for MQ Servers Only it will only start MQ_* services
    #
    $servers = get-bscserversinfo -Environment $Environment -WhichProperty role -PropValue EDITM -ColumnReturn ServerName 
    $ServicesToControl = @('EdifecsTMConfigServer')

    #check if servers is empty, then exit
    if(([string]::IsNullOrEmpty($servers))) 
    {
        Write-Error "Could not determine a list of servers for environment [$Environment], exiting!"
        $exit_code = 13
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    #now that we have the servers, let validate we are not trying to cross Domains (NPE to PROD or vise-versa)
    $Platform = get-bscserversinfo -Environment $Environment -WhichProperty ServerName -PropValue $Servers -ColumnReturn Platform
    #$Domain = (Get-ADDomain).Name  #mbk its expensive call...
    $Domain = (Get-ChildItem Env:'USERDOMAIN' -ErrorAction Ignore).Value
    Write-Verbose "Platform for these servers is [$Platform], Active Directory Domain is [$Domain]"
    if ($Platform -eq 'PROD' -and $Domain -ne 'BSC')
    {
        #we can't run run from NONE PROD domain to prod servers...
        Write-Error "WE CAN'T run a script from a NONE PROD Active Directory Domain ($Domain) to Production Servers(Platform [$Platform]), exiting script!"
        $exit_code = 20
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    elseif ($Platform -ne 'PROD' -and $Domain -eq 'BSC')
    {
        Write-Error "WE CAN'T run from a PROD Active Directory Domain ($Domain) to NONE Production Servers(Platorm [$Platform]), exiting script!"
        $exit_code = 21
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    else
    {
        Write-Host "Running script in Active Directory Domain [$Domain] for server types of [$Platform]"
    }

    <#
    #### Request to validate profiles have MAX JVM setting before starting...######
    $ScriptBase = Split-Path $MyInvocation.InvocationName | Split-Path -Parent | Split-Path -Parent 
    Write-Host "Script BASE is $ScriptBase"
    $ScriptPath = Join-Path -Path $ScriptBase -ChildPath "\SRE_Scripts\Validate"
    Write-Host "ScriptPath is $ScriptPath" 
    Write-Host "Calling Script to check JVM max setting is present for Environments [$Environment]"

    & "$ScriptPath\SRE-EDIJVMCheck.ps1" -Environment $Environment
    if($?) 
    {
	    Write-Host "All Profiles have the JVM Max Setting, we will continue with EDI Startup"
    } 
    else 
    {
        #this means we have introduced profile without a JVM Max setting which will cause issues
        # we will not continue with startup
        $exit_code = 36
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    ##############################################################################
    #>																																		 

    ######################################################################################################################################################
    #
    # now do EDITMConfigServer service on TM app Server ..... This change is for new edifecs Upgrade 8.8 loop 1b 
    #
    $servers = get-bscserversinfo -Environment $Environment -WhichProperty role -PropValue EDITM -ColumnReturn ServerName 
    $ServicesToControl = @('EdifecsTMConfigServer')

    if(-not ([string]::IsNullOrEmpty($servers))) 
    {
        Write-Host "Working on EDI TM servers [$servers] for Services [$ServicesToControl]"
        Write-Host "Building PSSessions on [$Servers] Servers"
        $Session = New-PSSession -ComputerName $Servers -Verbose

        #first check for wrong count of connected servers...
        if($($Session.count) -ne $($Servers.count))
        {
            Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
            Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
            $exit_code = 19
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }

        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'start',100 -AsJob
        #$Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'check',100 -AsJob

        #wait for job to complete and output results
        $rc2 = checkJobAndLog -Session $Session -Jobs $Jobs
        $RCode2 = $($rc2)[1]

        if ($RCode2 -ne 0)
        {
            $exit_code = $RCode2
            Write-Host "ERROR: Failures during LOOP 1b TM Server EdifecsTMConfigServer start.... RC = $RCode2"
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE
        }
        else
        {
            Write-Host "All good on job(s) LOOP 1b TM Server EdifecsTMConfigServer start... RC = $RCode2"
        }
    }
    else
    {
        Write-Host "Servers is empty, skipping EDI TM for servers [$servers] for Services [$($servicesToControl)]"
    }
 
    ######################################################################################################################################################
    ######################################################################################################################################################
    #
    # now do TM Server(s) only and only TMServerManager service .... loop 2 
    #
    $servers = get-bscserversinfo -Environment $Environment -WhichProperty role -PropValue EDITM -ColumnReturn ServerName 
    $ServicesToControl = @('EdifecsTMServiceManager')

    if(-not ([string]::IsNullOrEmpty($servers))) 							   
    {
        Write-Host "Working on EDI TM servers [$servers] for Services [$ServicesToControl]"
        Write-Host "Building PSSessions on [$Servers] Servers"
        $Session = New-PSSession -ComputerName $Servers -Verbose

        #first check for wrong count of connected servers...
        if($($Session.count) -ne $($Servers.count))
        {
            Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
            Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
            $exit_code = 19
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }

        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'start',100 -AsJob
        #$Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'check',100 -AsJob

        #wait for job to complete and output results
        $rc2 = checkJobAndLog -Session $Session -Jobs $Jobs
        $RCode2 = $($rc2)[1]

        if ($RCode2 -ne 0)
        {
            $exit_code = $RCode2
            Write-Host "ERROR: Failures during LOOP 2 TM Server TMServerManager start.... RC = $RCode2"
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE
        }
        else
        {
            Write-Host "All good on job(s) LOOP 2 TM Server TMServerManager start... RC = $RCode2"
        }
    }
    else
    {
        Write-Host "Servers is empty, skipping EDI TM for servers [$servers] for Services [$($servicesToControl)]"
    }
    ######################################################################################################################################################


    ######################################################################################################################################################
    #
    # Loop 3 does TM Server(s) STANDBY's for TM ServiceManager service only
    #
    $servers = get-bscserversinfo -Environment $Environment -WhichProperty role -PropValue EDISB -ColumnReturn ServerName 
    $ServicesToControl = @('EdifecsTMServiceManager')

    #if(-not ([string]::IsNullOrEmpty($servers)) -and ($MaintType -eq 'infra'))) 
    if(-not ([string]::IsNullOrEmpty($servers)))
    {
        Write-Host "Working on EDI TM STANDBY server(s) [$servers] for Services [$ServicesToControl]"
        Write-Host "Building PSSessions on [$Servers] Servers"
        #sleep for 3 minutes to allow Primary to come up first....
        if ( $MaintType -eq "infra" )
        {
            $sleepTime = 180
            Write-Host "Sleeping for $sleepTime Seconds before moving onto the SB servers to allow Primary to come up..."
            Start-Sleep -Seconds $sleepTime
        }
        else
        {
            Write-Host "Skipping Sleep since we are only doing a CORE release and we shouldn't have started the TM Servers...."
        }

        $Session = New-PSSession -ComputerName $Servers -Verbose

        #first check for wrong count of connected servers...
        if($($Session.count) -ne $($Servers.count))
        {
            Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
            Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
            $exit_code = 19
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }

        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'start',100 -AsJob
        #$Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'check',100 -AsJob

        #wait for job to complete and output results
        $rc3 = checkJobAndLog -Session $Session -Jobs $Jobs
        $RCode3 = $($rc3)[1]

        if ($RCode3 -ne 0)
        {
            Write-Error "ERROR: Failures during LOOP 3 TM Server Secondaries TMServerManager start.... RC = $RCode3"
            #MBK later abort????
        }
        else
        {
            Write-Host "All good on job(s) LOOP 3 TM Server Secondaries TMServerManager start ... RC = $RCode3"
        }
    }
    else
    {
        Write-Host "Servers is empty, skipping EDI TM STANDBY for servers [$servers] for Services [$($servicesToControl)]"
																				 
													   
    }

    ######################################################################################################################################################
    ####################################################
    #MBK need to validate TM services started correctly!
    # lets get both SB and TM servers
    $servers = get-bscserversinfo -Environment $Environment -WhichProperty role -PropValue EDISB,EDITM -ColumnReturn ServerName 

    if(-not ([string]::IsNullOrEmpty($servers)))
    {
        if ($MaintType -eq 'infra')
        {
            $RC = ValidateTMStarted -hostnames $servers -timeFlag $true
        }
        else
        {
            #MBK removing check for Integrated/CORE start
            #$RC = ValidateTMStarted -hostnames $servers -timeFlag $false
            $RC = $($Servers.Count)
            Write-Host "Skipping check for TM started via TM.log as we are not starting TM servers...."
        }

        Write-Host "Validation for TM Services on STANDBY Started with count of servers [$RC]"
        if ($RC -ge $($Servers.Count))
        {
            Write-Host "Good TM/STANDBY Service start...."
        }
        else
        {
            $exit_code = 69
            Write-Error "ERROR: TM/STANDBY Service did not start correctly, exiting!"
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE
        }
    }
    else
    {
        $exit_code = 99
        Write-Error "Servers is empty, skipping EDI TM/STANDBY for servers [$servers] for Services [$($servicesToControl)] for TM.LOG Validation can't be verified!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    ####################################################

    ######################################################################################################################################################
    #
    #TM Servers and TM Server STANDBY for EDI*/bscedi* and IBM* ... LOOP 4
    #
    $servers = get-bscserversinfo -Environment $Environment -WhichProperty role -PropValue EDITM,EDISB -ColumnReturn ServerName 
    $ServicesToControl = @('EDI*', 'IBM*', 'HIX*', 'BSCEDI*')

    if(-not ([string]::IsNullOrEmpty($servers))) 
    {
        Write-Host "Working on EDI TM and TM STANDBY servers [$servers] for Services [$ServicesToControl]"
        Write-Host "Building PSSessions on [$Servers] Servers"
        $Session = New-PSSession -ComputerName $Servers -Verbose

        #first check for wrong count of connected servers...
        if($($Session.count) -ne $($Servers.count))
        {
            Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
            Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
            $exit_code = 19
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }

        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'start',200 -AsJob
        #$Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'check',200 -AsJob

        #wait for job to complete and output results
        $rc4 = checkJobAndLog -Session $Session -Jobs $Jobs
        $RCode4 = $($rc4)[1]

        if ($RCode4 -ne 0)
        {
            Write-Host "ERROR: Failures during LOOP 4 TM/Standby Servers EDI*.... RC = $RCode4"
            #mbk add to counter....
        }
        else
        {
            Write-Host "All good on job(s) TM/Standby Server EDI*... RC = $RCode4"
        }
    }
    else
    {
        Write-Host "Servers is empty, skipping EDI TM/STANDBY for servers [$servers] for Services [$($servicesToControl)]"
    }
    ######################################################################################################################################################

    ######################################################################################################################################################
    #
    #
    #TM Servers and TM Server STANDBY for EDI*/bscedi* and IBM* ... LOOP 5
    #

    #ETL Servers for EDI*/bscedi* and IBM* ... LOOP 5
    $servers = get-bscserversinfo -Environment $Environment -WhichProperty role -PropValue EDIETL,EDISB,EDIXE,EDITM -ColumnReturn ServerName 														   
    $ServicesToControl = @('EdifecsTMServiceManager')
 

    if(-not ([string]::IsNullOrEmpty($servers))) 
    {
        Write-Host "Working on EDI All servers [$servers] for Services [$ServicesToControl]"
        Write-Host "Building PSSessions on [$Servers] Servers"
        $Session = New-PSSession -ComputerName $Servers -Verbose

        #first check for wrong count of connected servers...
        if($($Session.count) -ne $($Servers.count))
        {
            Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
            Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
            $exit_code = 19
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }

        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'start',100 -AsJob
        #$Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'check',100 -AsJob

        #wait for job to complete and output results
        $rc5 = checkJobAndLog -Session $Session -Jobs $Jobs
        $RCode5 = $($rc5)[1]

        if ($RCode5 -ne 0)
        {
            Write-Host "ERROR: Failures during LOOP 5 All Servers for [$ServicesToControl] .... RC = $RCode5"
            #mbk add to counter....
        }
        else
        {
            Write-Host "All good on job(s) EDI All Servers for service [$ServicesToControl]... RC = $RCode5"
        }
    }
    else
    {
        Write-Host "Servers is empty, skipping All EDI servers [$servers] for Services [$ServicesToControl]"
    }
 
    ######################################################################################################################################################
    #
    #All Servers for EDI ETL/XE for EDI*/bscedi* and IBM* ... LOOP 6
    #
    $servers = get-bscserversinfo -Environment $Environment -WhichProperty role -PropValue EDIETL,EDIXE -ColumnReturn ServerName 
    #$ServicesToControl = @('EDI*', 'IBM*', 'HIX*', 'BSCEDI*')
																																				 

    # first see if CORE or INFRA
    $ServicesToControl = ''
						

    if($MaintType -eq 'infra')
    {
        Write-Host "Including IBM* as this is Patching Weekend"
        $ServicesToControl = @('EDI*', 'IBM*', 'HIX*', 'BSCEDI*')
    }
    else
    {
        Write-Host "Excluding IBM* as this in not patching weekend"
        $ServicesToControl = @('EDI*', 'BSCEDI*')
    }
 

    if(-not ([string]::IsNullOrEmpty($servers))) 
    {
        Write-Host "Working on EDI XE/ETL servers [$servers] for Services [$ServicesToControl]"
        Write-Host "Building PSSessions on [$Servers] Servers"
        $Session = New-PSSession -ComputerName $Servers -Verbose

        #first check for wrong count of connected servers...
        if($($Session.count) -ne $($Servers.count))
        {
            Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
            Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
            $exit_code = 19
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }

        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'start',100 -AsJob
        #$Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'check',100 -AsJob

        #wait for job to complete and output results
        $rc6 = checkJobAndLog -Session $Session -Jobs $Jobs
        $RCode6 = $($rc6)[1]

        if ($RCode6 -ne 0)
        {
            Write-Host "ERROR: Failures during LOOP 6 ETL Servers EDI* and IBM* .... RC = $RCode6"
            #mbk add to counter....
        }
        else
        {
            Write-Host "All good on job(s) ETL Server EDI* and IBM*... RC = $RCode6"
        }
    }
    else
    {
        Write-Host "Servers is empty, skipping EDI XE servers [$servers] for Services [$ServicesToControl]"
					   
    }

    ######################################################################################################################################################
    #
    #All Servers for EDI*/bscedi* and IBM* and MQ* ... LOOP 7
    #
    $servers = get-bscserversinfo -Environment $Environment -WhichProperty app -PropValue EDI -ColumnReturn ServerName 
    $ServicesToControl = @('EDI*', 'IBM*', 'HIX*', 'BSCEDI*', 'MQ_*', 'EAMService')
																													
    if(-not ([string]::IsNullOrEmpty($servers))) 				
    {
        Write-Host "Working on EDI All servers [$servers] for Services [$ServicesToControl]"
        Write-Host "Building PSSessions on [$Servers] Servers"
        $Session = New-PSSession -ComputerName $Servers -Verbose

        #first check for wrong count of connected servers...
        if($($Session.count) -ne $($Servers.count))
        {
            Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
            Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
            $exit_code = 19
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }

        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'start',200 -AsJob
        #$Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'check',100 -AsJob

        #wait for job to complete and output results
        $rc7 = checkJobAndLog -Session $Session -Jobs $Jobs
        $RCode7 = $($rc7)[1]

        if ($RCode7 -ne 0)
        {
            Write-Host "ERROR: Failures during LOOP 7 EDI All Servers EDI* and IBM* and MQ* and BSCEDI* .... RC = $RCode7"
            #mbk add to counter....
        }
        else
        {
            Write-Host "All good on job(s) EDI All Servers EDI* and IBM* and MQ* and BSCEDI*... RC = $RCode7"
        }
    }
    else
    {
        Write-Host "Servers is empty, skipping EDI All servers [$servers] for Services [$ServicesToControl]"
    }

    ######################################################################################################################################################
    ######################################################################################################################################################
    #
    # One MORE loop is anything failed on previous attempt.....
    #
    if($RCode7 -ne 0)
    {
        if(-not ([string]::IsNullOrEmpty($servers))) 
        {
            #MBK Added a 8th loop to see if that fixes the issues with long starts for everything
            #$ServicesToControl = @('EDI*', 'IBM*', 'HIX*', 'MQ_*', 'BSCEDI*')
            Write-Host "Sleeping for a short time of [30] seconds...."
            Start-Sleep -Seconds 30

            Write-Host "Working on EDI All servers [$servers] for Services [$ServicesToControl]"
            Write-Host "Building PSSessions on [$Servers] Servers"
            $Session = New-PSSession -ComputerName $Servers -Verbose

            #first check for wrong count of connected servers...
            if($($Session.count) -ne $($Servers.count))
            {
                Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
                Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
                $exit_code = 19
                ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
            }

            $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'start',100 -AsJob
            #$Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'check',100 -AsJob

            #wait for job to complete and output results
            $rc8 = checkJobAndLog -Session $Session -Jobs $Jobs
            $RCode8 = $($rc8)[1]										 

            if ($RCode8 -ne 0)
            {
                Write-Error "ERROR: Failures during LOOP 8.... RC = $RCode8"
            }
            else
            {
                Write-Host "All good on retry... RC = $RCode8"
            }
        }
        else
        {
            Write-Host "Servers is empty, skipping 8th loop...."
            $exit_code = 99
        }

        $exit_code = $RCode8																	
    }


    ######################################################################################################################################################
    #
    #Start all Monitoring for all EDI servers for the given environment
    #
    $servers = get-bscserversinfo -Environment $Environment -WhichProperty app -PropValue EDI -ColumnReturn ServerName 
    $ServicesToControl = @('KNTC*', 'KQ7C*', 'KYNA*')

    if(-not ([string]::IsNullOrEmpty($servers))) 
    {
        if($Platform -ne 'PROD')
        {
            Write-Host "Working on EDI Monitoring enable for servers [$servers] for Services [$($servicesToControl)]"
            Write-Host "Building PSSessions on [$Servers] Servers"
            $Session = New-PSSession -ComputerName $Servers -Verbose

            #first check for wrong count of connected servers...
            if($($Session.count) -ne $($Servers.count))
            {
                Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
                Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
                $exit_code = 19
                ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
            }

            $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'start',100 -AsJob
            #$Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'check',100 -AsJob

            #wait for job to complete and output results
            $mc1 = checkJobAndLog -Session $Session -Jobs $Jobs
            $MCode1 = $($mc1)[1]
            if ($MCode1 -ne 0)
            {
                Write-Error "ERROR: Failures during Monitoring Enable for All EDI.... RC = $MCode1"
                #MBK add to retry counter.....
            }
            else
            {
                Write-Host "All good on job(s) Monitoring Start... RC = $MCode1"
            }
         }
         else
         {
            Write-Host "We are running in production, we will skip the startup of the APM services for monitoring"
         }
    }
    else
    {
        Write-Host "Servers are empty, skipping Monitoring start on servers [$servers] for Services [$($servicesToControl)]"
    }
    ######################################################################################################################################################


}
catch
{
    Write-Warning $_.Exception.ToString();
    if($exit_code -lt 1 )
    {
        $exit_code = 99
    }
}
finally
{
    #cleanup now...
    Remove-Module -Name Get-PAMServiceControl -ErrorAction SilentlyContinue
    Remove-Module -Name Get-BSCServersInfo -ErrorAction SilentlyContinue
    Remove-Module -Name Functions -ErrorAction SilentlyContinue																		

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"

    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}



