﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	12/22/2021
	 Updated on:	12/22/2021
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	AvayaIC_Services_Control.ps1

	The scripts being built in this grouping are for PAM/SRE Production Support
	The majority will be run from the Primary PAM/SRE Server, WINF4594P/etc. However,
	it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script Starts controls AvayaIC (Avaya Interaction Center) Application - stop/start/validate

MODIFICATIONS
_____________________________________________________________________________________________________________________________
    Date       By            Reason
    12/22/2021 Murry Kane    Initial
    Example

    ./{PATH}\AvayaIC_Services_Control.ps1 -Environment PROD,NPE -Action start/stop/running/stopped
    ./{PATH}\AvayaIC_Services_Control.ps1 -Environment NPE -Action stop

#>

[CmdletBinding()]
Param(
   #[Parameter(Mandatory=$True,Position=1)]
   [string[]]$Environment,
   [string]$Action,
   [Parameter(Mandatory=$False, Position=2)][switch]$uselocaldomain
)

$LOG_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\Logs'
$PAM_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts'
$exit_code = 0
$currentScriptName = $MyInvocation.MyCommand.Name
$filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
# turn off verbose
$VerbosePreference = 'SilentlyContinue'
$Domain = (Get-ChildItem Env:'USERDOMAIN' -ErrorAction Ignore).Value
$ACTIONS = 'stop','start','restart','stopped','running'
$AppName = "Avaya Interaction Center"

function Get-ServerList {
    try {

        #lets see if we we are going against production or 2015 CMDB
        $SnowCred = ''
        $UriBase = ''

        if(-not $uselocaldomain)
        {
            $SNowCred = Get-ServiceNowCredential
            $UriBase = Get-ServiceNowUriBase
        }
        else
        {
            Write-Host "-UseLocalDomain option passed to script, using local domain to determine which ServiceNow Instance to connect with"
            $SNowCred = Get-ServiceNowCredential -uselocaldomain
            $UriBase = Get-ServiceNowUriBase -uselocaldomain                
        }

        if([string]::IsNullOrWhiteSpace($SNowCred) -or [string]::IsNullOrWhiteSpace($UriBase))
        {
            $exit_code = 4
            Write-Warning "We could not get credentials to make the REST call to ServiceNow" 
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }
        else
        {
            Write-Host "URI Base $UriBase"
        }

        # Query Server to App Relationship Table
        Write-Host "Querying ServiceNow API for getting the application server(s)"
        $Uri = "$UriBase/api/now/table/cmdb_rel_ci?sysparm_query=parent.nameSTARTSWITH$CMDBEnvironment%5Etype.nameSTARTSWITHRuns%20on%3A%3ARuns%5Eparent.install_status%3D11%5Echild.install_status%3D11%5Echild.sys_class_name%3Dcmdb_ci_app_server%5Echild.nameLIKEInteraction%20Center&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=child&sysparm_limit=1000"
        Write-Host "Using URI [$Uri]"

        $Result = Query-ServiceNowApi -Uri $Uri -SNowCred $SNowCred
        Write-Host "Result is " + $result   

        $PrimaryServer = @()
        $Servers = @()
        $result | ForEach-Object -Process {
            $cmdb_start = (($_).child -split "@")[0]
            $cmdb_end = (($_).child -split "@")[1]
            #Write-Host "Start value $cmdb_start and end value $cmdb_end"
            if($cmdb_start -match "primary")
            {
                #Write-Host "match on primary"
                $PrimaryServer += $cmdb_end
            }
            else
            {
                #Write-Host "no match"
                $servers += $cmdb_end
            }
            #else
            #{
            #    Write-Host "Server [$cmdb_end] will not be added to any array as it does not match primary/secondary criteria"
            #}
        }

        return $PrimaryServer,$servers
    }
    catch {
        return $null
    }
}

function Start-App {
    param
    (
        [parameter(ValueFromPipeline=$true)]$PrimaryServer,
        [parameter(ValueFromPipeline=$true)]$AppServers,
        [parameter(ValueFromPipeline=$true)]$action,
        [parameter(ValueFromPipeline=$true)]$AllServices,
        [parameter(ValueFromPipeline=$true)]$environment,
        [parameter(ValueFromPipeline=$true)]$Domain,
        [parameter(ValueFromPipeline=$true)]$ISE
    )

    $exit_code = 0

    #first start main process
    if($PrimaryServer.count -gt 0)
    {
        $result = Get-ActionToPerform -servers $PrimaryServer -action $Action -ServicesToControl $AllServices -environment $Environment -Domain $Domain -ISE $ISE 
        if ($result)
        {
            Write-Host "Completed [$Action] for $AppName Primary Application service"
        }
        else
        {
            #Write-Error "Failures duing Validation Checks"
            $exit_code = 28
            return $exit_code
        } 

        ## NPE does not have secondaries, so check if count > 0
        if($AppServers.count -gt 0)
        {
            if($PrimaryServer.count -gt 0)
            {
                #need to sleep 2 minutes
                Write-Host "Sleeping for 2 minutes before moving onto secondary servers"
                Start-Sleep -Seconds 120  
            }
            #need to start the rest on all servers
            $theServers = $PrimaryServer + $AppServers
            $result = Get-ActionToPerform -servers $theServers -action $Action -servicesToControl $AllServices -environment $Environment -Domain $Domain -ISE $ISE 
            if ($result)
            {
                Write-Host "Completed [$Action] for $AppName Application secondary servers"
            }
            else
            {
                #Write-Error "Failures duing Validation Checks"
                $exit_code = 28
                return $exit_code
            }
        }
    }

}

function Stop-App {
    param
    (
        [parameter(ValueFromPipeline=$true)]$AppServers,
        [parameter(ValueFromPipeline=$true)]$PrimaryServer,
        [parameter(ValueFromPipeline=$true)]$action,
        [parameter(ValueFromPipeline=$true)]$Allservices,
        [parameter(ValueFromPipeline=$true)]$environment,
        [parameter(ValueFromPipeline=$true)]$Domain,
        [parameter(ValueFromPipeline=$true)]$ISE
    )

    $exit_code = 0
    $error_count = 0

    #1st we will stop non-primarys
    if($AppServers.count -gt 0)
    {

        #now all services if there...
        $result = Get-ActionToPerform -servers $AppServers -action $Action -servicesToControl $AllServices -environment $Environment -Domain $Domain -ISE $ISE 
        if ($result)
        {
            Write-Host "Completed [$Action] for $AppName Application All Instances for services [$AllServices]"
        }
        else
        {
            Write-Warning "Failures duing attempted stop for services [$AllServices]"
            $error_count += 1
        }

        Write-Host "Attempting to stop any lefover processes on non-primary Application instances"
        #get connection to servers
        $Session = New-PSSession -ComputerName $AppServers -Verbose
        #clean up processes left....
        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::stopProcesses} -AsJob
        $rc1 = checkJobAndLog -Session $Session -Jobs $Jobs -ExitCodeType 2
        $RCode1 = $($rc1)[1]
        if ($RCode1 -ne 0)
        {
            Write-Warning "Failures duing process clean up: $RCode1"
            $exit_code = $RCode1
            return $exit_code
        }
        else
        {
            Write-Host "All good on process clean up with RC: $RCode1"
        }

        #now if there was a failure before lets try and stop 1 more time...
        if($error_count -gt 0)
        {
            Write-Host "Attempting last stop action since there was a failure on previous attempts..."
            $result = Get-ActionToPerform -servers $AppServers -action $Action -servicesToControl $AllServices -environment $Environment -Domain $Domain -ISE $ISE 
            if ($result)
            {
                Write-Host "Completed [$Action] for $AppName Application All Instances for services [$AllServices]"
            }
            else
            {
                Write-Warning "Failures duing attempted stop for services [$AllServices]"
                $exit_code = 23
                return $exit_code
            }
        }
    }

    #reset counter...
    $error_count = 0

    #next do primary (this should be the last server to do)
    if($PrimaryServer.count -gt 0)
    {
        #now just the primary
        $result = Get-ActionToPerform -servers $PrimaryServer -action $Action -ServicesToControl $AllServices -environment $Environment -Domain $Domain -ISE $ISE 
        if ($result)
        {
            Write-Host "Completed [$Action] for $AppName Primary Application for Services [$AllServices]"
        }
        else
        {
            Write-Host "Failures duing attempted Primary stop for services [$AllServices]"
            $error_count += 1
        }
        
        Write-Host "Attempting to stop any lefover processes on Primary Application instances"
        #get connection to servers
        $Session = New-PSSession -ComputerName $PrimaryServer -Verbose
        #clean up processes left....
        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::stopProcesses} -AsJob
        $rc1 = checkJobAndLog -Session $Session -Jobs $Jobs -ExitCodeType 2
        $RCode1 = $($rc1)[1]
        if ($RCode1 -ne 0)
        {
            Write-Warning "Failures duing process clean up: $RCode1"
            $exit_code = $RCode1
            return $exit_code
        }
        else
        {
            Write-Host "All good on process clean up with RC: $RCode1"
        }

        if($error_count -gt 0)
        {
            Write-Host "Attempting last stop action since there was a failure on previous attempts..."
            $result = Get-ActionToPerform -servers $PrimaryServer -action $Action -ServicesToControl $AllServices -environment $Environment -Domain $Domain -ISE $ISE 
            if ($result)
            {
                Write-Host "Completed [$Action] for $AppName Primary Application for Services [$AllServices]"
            }
            else
            {
                Write-Host "Failures duing attempted Primary stop for services [$AllServices]"
                $exit_code = 28
                return $exit_code
            }
        }
    }

    return $exit_code
}

function stopProcesses
{
    #turn on verbose
    $VerbosePreference = 'Continue'
    Write-Verbose "Server name: $env:computername"

    $ps = get-process -ErrorAction SilentlyContinue | Where-Object {$_.Description -match "Avaya"} -ErrorAction SilentlyContinue

    foreach($p in $ps) {
        if(-not([string]::IsNullOrEmpty($($p.Id))))
        {
            Write-Verbose "Attempting stop of the process [$($p.ProcessName)] Process ID [$($p.Id)]"
            #$p.kill() 
            Stop-Process -id $p.Id -Force -ErrorAction SilentlyContinue
        }
    }

    #turn off verbose
    $VerbosePreference = 'SilentlyContinue'
    
}

function Get-ActionToPerform {
    param
    (
        [parameter(ValueFromPipeline=$true)]$servers,
        [parameter(ValueFromPipeline=$true)]$action,
        [parameter(ValueFromPipeline=$true)]$ServicesToControl,
        [parameter(ValueFromPipeline=$true)]$environment,
        [parameter(ValueFromPipeline=$true)]$Domain,
        [parameter(ValueFromPipeline=$true)]$ISE
    )


    try 
    {

        if(-not ([string]::IsNullOrEmpty($servers))) 
        {
            Write-Host "Working on Servers [$servers] for Services [$ServicesToControl]"
            Write-Host "Building PSSessions on [$Servers] Servers"
            $Session = New-PSSession -ComputerName $Servers -Verbose

            #first check for wrong count of connected servers...
            if($($Session.count) -ne $($Servers.count))
            {
                Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
                Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
                $exit_code = 19
                ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
            }

            $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-SREServiceControl} -ArgumentList $ServicesToControl,$action,100 -AsJob
            #wait for job to complete and output results
            $rc1 = checkJobAndLog -Session $Session -Jobs $Jobs -ExitCodeType 2
            $RCode1 = $($rc1)[1]
            if ($RCode1 -ne 0)
            {
                Write-Warning "Failures duing Validation Checks with RC: $RCode1"
                $exit_code = $RCode1
                return $false
            }
            else
            {
                Write-Host "All good on job(s) RC: $RCode1"
            }
        }
        else
        {
            Write-Host "Servers are empty, skipping servers [$servers] for Services [$($servicesToControl)]"
        }

    }
    catch {
        Write-Warning $_.Exception.ToString();
        return $false
    }
    return $true
}

try
{

    #import functions
    Import-Module -name SRE-Functions -Force -WarningAction SilentlyContinue
    Import-Module -name SnowFunctions -Force -WarningAction SilentlyContinue
    import-module -name Get-SREServiceControl -Verbose -WarningAction SilentlyContinue
    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')" WARNING: SRE Management Server Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    if ($Host.Name -eq "Windows PowerShell ISE Host") {
        $ISE=$true
    } else {
        $ISE=$false
    }
    if ($ISE) {
        # get the required input
        if(-not($Environment)) {
            $Environment = @()
            do 
            {
                $input = (Read-Host "Input your Environment (PROD, NPE): ")
                if ($input -ne '') {$Environment += $input}
            }
            until ($input -eq '')
        } 
        if(-not($Action)) {
            do {
                $Action = (Read-Host -Prompt "Input your Action Type ($ACTIONS): ")
                $Action = $Action.ToLower()
               }
                until ($ACTIONS.Contains($Action))
        }
    }

    $Environment = $Environment.ToUpper()
    Write-Host "Log File is: [$LOG_FILE]"
    Write-Host "Environment is [$Environment]"

    #$AllServices = @('Avaya*')
    $AllServices = @('Avaya IC Orb*')

    $CMDBEnvironment = ''
    if($Environment -match "PROD")
    {
        Write-Host "Production run of script, stripping Environment Name [$Environment] from CMDB lookup..."
        $CMDBEnvironment = 'Avaya%20Interaction%20Center'
    }
    else
    {
        #will have 'NPE' in the parent name for non-prod
        $CMDBEnvironment = "AICN01"
    }


    if (-not($Action))
    {
        $exit_code = 15
        Write-Error "Action is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    else
    {
        $Action = $Action.ToLower()
        if($ACTIONS.Contains($Action))
        {
            Write-Host "Valid Action [$Action] passed"
        }
        else
        {
            Write-Error "Invalid Action [$Action] passed, exiting!"
            $exit_code = 16
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE
        } 
    }

    #get server list from CMDB
    $PrimaryServer, $servers = Get-ServerList

    Write-Host "Primary for $AppName application is: [$PrimaryServer]"
    Write-Host "$AppName Application Servers is: [$servers]"

    if($PrimaryServer.Count -ne 1)
    {
        Write-Warning "We should have exactly 1 primary for the $AppName Application, exiting!"
        $exit_code = 18
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
 
    if(-not ([string]::IsNullOrEmpty($Primaryserver)))
    {

        if($action -eq "running" -or $action -eq "stopped")
        {
            #just combines lists of servers and perform checks...
            $theServers = $PrimaryServer + $Servers
            $result = Get-ActionToPerform -servers $theServers -action $Action  -servicesToControl $AllServices -environment $Environment -Domain $Domain -ISE $ISE 

            if ($result)
            {
                Write-Host "Completed [$Action] for $AppName Application"
            }
            else
            {
                #Write-Error "Failures duing Validation Checks"
                $exit_code = 11
            }
        }
        elseif($action -eq "restart")
        {
            Write-Host "Performing a restart of the $AppName application"
            Write-Host "Performing stop of the $AppName Application"
            $result = Stop-App -Appservers $Servers -PrimaryServer $PrimaryServer -action stop -Allservices $AllServices -environment $Environment -Domain $Domain -ISE $ISE 
            if($result -gt 0)
            {
                $exit_code = $result
                throw "Failures during the stop operation"
            } 
            write-host "Performing start of the $AppName Application"
            $result = Start-App -Appservers $Servers -PrimaryServer $PrimaryServer -action start -Allservices $AllServices -environment $Environment -Domain $Domain -ISE $ISE 
            if($result -gt 0)
            {
                $exit_code = $result
                throw "Failures during the start operation"
            }                
        }
        elseif($action -eq "start")
        {
            write-host "Performing start of the $AppName Application"
            $result = Start-App -Appservers $Servers -PrimaryServer $PrimaryServer -action $Action -Allservices $AllServices -environment $Environment -Domain $Domain -ISE $ISE 
            if($result -gt 0)
            {
                $exit_code = $result
                throw "Failures during the start operation"
            } 
        }  
        elseif($action -eq "stop")
        {
            Write-Host "Performing stop of the $AppName Application"
            $result = Stop-App -Appservers $Servers -PrimaryServer $PrimaryServer -action $Action -Allservices $AllServices -environment $Environment -Domain $Domain -ISE $ISE 
            if($result -gt 0)
            {
                $exit_code = $result
                throw "Failures during the stop operation"
            }                 
        }
    }
    else
    {
        Write-Host "Primary Server is empty, skipping action [$Action] for Services [$($servicesToControl)]"
    }

}
catch
{
    Write-Warning $_.Exception.ToString();
    if($exit_code -lt 1 )
    {
        $exit_code = 99
    }
}
finally
{
    #cleanup now...
    Remove-Module -Name Get-SREServiceControl  -ErrorAction SilentlyContinue
    Remove-Module -Name SnowFunctions -ErrorAction SilentlyContinue
    Remove-Module -Name SRE-Functions -ErrorAction SilentlyContinue

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"

    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}