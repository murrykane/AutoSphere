﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	03/13/2019
	 Updated on:	
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	CWS_START.ps1

	The scripts being built in this grouping are for PAM Production Support
	The majority will be run from the Primary PAM Server, WINF313P. However,
	it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script Starts all Workflow Services

MODIFICATIONS
_____________________________________________________________________________________________________________________________
    Date       By            Reason
    01/30/2019 Murry Kane    Moved into SVN


    Example

    ./{PATH}\Workflow_START.ps1 -Environment FACP02
    ./{PATH}\Workflow_START.ps1 -Environment FACS02

#>

[CmdletBinding()]
Param(
   #[Parameter(Mandatory=$True,Position=1)]
   [string[]]$Environment	
)

$LOG_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\Logs'
$PAM_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts'
$ACTIONS = 'running','stopped'
$exit_code = 0
$currentScriptName = $MyInvocation.MyCommand.Name
$filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
# turn off verbose
$VerbosePreference = 'SilentlyContinue'

Write-Host "Script name is: $currentScriptName"

if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS)))
{
    $LOG_DIR = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS
}
else
{
    $LOG_DIR = $PAM_HOME_DIR_DEFAULT 
}

$LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

#get PAM home dir
if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME)))
{
    $PAM_HOME = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME
}
else
{
    $PAM_HOME = $PAM_HOME_DIR_DEFAULT 
}


#import functions
Import-Module Functions -Force


if ($Host.Name -eq "Windows PowerShell ISE Host") {
    $ISE=$true
} else {
    $ISE=$false
}
if ($ISE) {
    # get the required input
    if(-not($Environment)) {
        $Environment = @()
        do 
        {
            $input = (Read-Host "Input your Environment (FACP01, FACS02): ")
            if ($input -ne '') {$Environment += $input}
        }
        until ($input -eq '')
    } 
}

#lets start logging what occures from here forward....
Start-Transcript -path $LOG_FILE -append


Write-Host "PAM HOME Directory is $PAM_HOME"
Write-Host "Log File is $LOG_FILE"
Write-Host "Environment is [$Environment]"


#import the PAM Service Module
import-module -name Get-PAMServiceControl -Verbose -WarningAction SilentlyContinue
#import the GET BSC Server Module
Import-Module Get-BSCServersInfo

$ServicesToControl = @('IBM*')


#lets get the servers
$Servers = get-bscserversinfo -Environment $Environment -WhichProperty Role -PropValue workflow -ColumnReturn ServerName

#check if servers is empty, then exit
if(([string]::IsNullOrEmpty($servers))) 
{
    Write-Error "Could not determine a list of servers for environment [$Environment], exiting!"
    $exit_code = 13
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}

#now that we have the servers, let validate we are not trying to cross Domains (NPE to PROD or vise-versa)
$Platform = get-bscserversinfo -Environment $Environment -WhichProperty ServerName -PropValue $Servers -ColumnReturn Platform
#$Domain = (Get-ADDomain).Name  #mbk its expensive call...
$Domain = (Get-ChildItem Env:'USERDOMAIN' -ErrorAction Ignore).Value
Write-Verbose "Platform for these servers is [$Platform], Active Directory Domain is [$Domain]"
if ($Platform -eq 'PROD' -and $Domain -ne 'BSC')
{
    #we can't run run from NONE PROD domain to prod servers...
    Write-Error "WE CAN'T run a script from a NONE PROD Active Directory Domain ($Domain) to Production Servers(Platform [$Platform]), exiting script!"
    $exit_code = 20
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}
elseif ($Platform -ne 'PROD' -and $Domain -eq 'BSC')
{
    Write-Error "WE CAN'T run from a PROD Active Directory Domain ($Domain) to NONE Production Servers(Platorm [$Platform]), exiting script!"
    $exit_code = 21
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}
else
{
    Write-Host "Running script in Active Directory Domain [$Domain] for server types of [$Platform]"
}

if(-not ([string]::IsNullOrEmpty($servers))) 
{
    Write-Host "Working on Servers [$servers] for Services [$($servicesToControl)]"
    Write-Host "Building PSSessions on [$Servers] Servers"
    $Session = New-PSSession -ComputerName $Servers -Verbose
    $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,start,600 -AsJob
    #wait for job to complete and output results
    $rc1 = checkJobAndLog -Session $Session -Jobs $Jobs 
    $RCode1 = $($rc1)[1]
    if ($RCode1 -ne 0)
    {
        Write-Error "Failures duing Validation Checks with RC: $RCode1"
        $exit_code = $RCode1
    }
    else
    {
        Write-Host "All good on job(s) RC: $RCode1"
    }
}
else
{
    Write-Host "Servers are empty, skipping servers [$servers] for Services [$($servicesToControl)]"
}


#cleanup
Remove-Module -Name Get-BSCServersInfo
Remove-Module -Name Get-PAMServiceControl
Remove-Module -Name Functions

Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
ExitWithCode -exitcode $exit_code -ISEFlag $ISE