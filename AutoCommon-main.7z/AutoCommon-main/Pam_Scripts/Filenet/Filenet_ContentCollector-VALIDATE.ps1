﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	09/15/2020
	 Updated on:	
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	Filenet_ContentCollector-VALIDATE.ps1

	The scripts being built in this grouping are for PAM Production Support
	The majority will be run from the Primary PAM Server, WINF313P. However,
	it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script validates all FILENET Content Collector Services are either running or stopped

        Use the following CMDB query to find the correct Content Collector for managing the services:

        https://blueshieldca.service-now.com/cmdb_rel_ci_list.do?sysparm_query=parent.nameLIKEFILENET.ICC%5Eparent.install_statusIN11&sysparm_view=

        As of 09/15/2020 this would return the following CMDB entries

        FILENET.ICC.AGENT1@wapp559p
        FILENET.ICC.STAGE.AGENT1@wapp543s
        FILENET.ICC.UAT.AGENT1@wapp531h

        Passing as argument 1 any of the above would get the correspoding server

Examples

  ./{PATH}\Filenet_ContentCollector-VALIDATE.ps1 -Environment FILENET.ICC.AGENT1    (This would run against wapp559p server)


MODIFICATIONS
_____________________________________________________________________________________________________________________________
    Date       By            Reason
    09/15/2020 Murry Kane    Initial
    09/15/2020               CMDB info FILENET.ICC.AGENT1@wapp4777p aka FILENET.ICC.AGENT1* for application instance
                             https://blueshieldca.service-now.com/cmdb_rel_ci_list.do?sysparm_query=parent.nameLIKEFILENET.ICC.AGENT1%5Eparent.install_statusIN11&sysparm_view=


    Example

    ./{PATH}\Filenet_ContentCollector-VALIDATE.ps1 -state running -Environment FILENET.ICC.AGENT1  
    ./{PATH}\Filenet_ContentCollector-VALIDATE.ps1 -state stopped -Environment FILENET.ICC.STAGE
    ./{PATH}\Filenet_ContentCollector-VALIDATE.ps1 -state running -Environment FILENET.ICC.UAT

#>

[CmdletBinding()]
Param(
   #[Parameter(Mandatory=$True,Position=1)]
   [string[]]$Environment,
   [string]$State
)

function Get-FileNetServerList {
    try {
        $SNowCred = Get-ServiceNowCredential

        $UriBase = Get-ServiceNowUriBase
        Write-Host "URI Base $UriBase"

        # Query Server to App Relationship Table
        Write-Host "Querying ServiceNow API for getting the FileNet Content Collector server(s)"
        # https://blueshieldca.service-now.com/cmdb_rel_ci_list.do?sysparm_query=parent.nameSTARTSWITHfilenet.icc%5Eparent.operational_status%3D1%5Eparent.install_status%3D11%5Echild.sys_class_name%3Dcmdb_ci_win_server%5Echild.install_status%3D11%5Echild.operational_status%3D1&sysparm_view=
        # $uri = "$UriBase/api/now/table/cmdb_rel_ci?sysparm_query=parent.nameSTARTSWITHfilenet.icc%5Eparent.operational_status%3D1%5Eparent.install_status%3D11%5Echild.sys_class_name%3Dcmdb_ci_win_server%5Echild.install_status%3D11%5Echild.operational_status%3D1&&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=child&sysparm_limit=1000"

        #$Uri = "$UriBase/api/now/table/cmdb_rel_ci?sysparm_query=parent.nameLIKE$Environment%5Echild.statusISOperational%26child.classISWindows%20Server&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=child&sysparm_limit=10"
        $Uri = "$UriBase/api/now/table/cmdb_rel_ci?sysparm_query=parent.nameLIKE$Environment%5Eparent.operational_status%3D1%5Eparent.install_status%3D11%5Echild.sys_class_name%3Dcmdb_ci_win_server%5Echild.install_status%3D11%5Echild.operational_status%3D1&&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=child&sysparm_limit=1000"
        
        Write-Host "Using URI [$Uri]"

        $Result = Query-ServiceNowApi -Uri $Uri -SNowCred $SNowCred

        Write-Host "Result is " + $result
        $Servers = ($Result).child | select -Unique

        return $Servers
    }
    catch {
        return $null
    }
}

try
{

    $LOG_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\Logs'
    $PAM_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts'
    $ACTIONS = 'running','stopped'
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    # turn off verbose
    $VerbosePreference = 'SilentlyContinue'
    $LocalDomain = (Get-ChildItem Env:'USERDOMAIN' -ErrorAction Ignore).Value


    Write-Host "Script name is: $currentScriptName"

    if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS)))
    {
        $LOG_DIR = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS
    }
    else
    {
        $LOG_DIR = $PAM_HOME_DIR_DEFAULT 
    }

    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    #get PAM home dir
    if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME)))
    {
        $PAM_HOME = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME
    }
    else
    {
        $PAM_HOME = $PAM_HOME_DIR_DEFAULT 
    }


    if ($Host.Name -eq "Windows PowerShell ISE Host") {
        $ISE=$true
    } else {
        $ISE=$false
    }
    if ($ISE) {
        # get the required input
        if(-not($State)) {
        #Prompt User to get Running/Stopped
        do {
            $State = Read-Host -Prompt "Input your check state ($ACTIONS):"
            $State = $State.ToLower()
           }
            until ($ACTIONS.Contains($State))
        } 
        if(-not($Environment)) {
            $Environment = @()
            do 
            {
                $input = (Read-Host "Input your Environment (FILENET.ICC.AGENT1, FILENET.ICC.STAGE, FILENET.ICC.UAT): ")
                if ($input -ne '') {$Environment += $input}
            }
            until ($input -eq '')
        } 
    }

    #lets start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    #import functions
    Import-Module Functions -Force -WarningAction SilentlyContinue
    Import-Module SnowFunctions -Force -WarningAction SilentlyContinue
    import-module -name Get-PAMServiceControl -Verbose -WarningAction SilentlyContinue

    Write-Host "PAM HOME Directory is $PAM_HOME"
    Write-Host "Log File is $LOG_FILE"
    Write-Host "Environment is [$Environment] Running in AD Domain [$LocalDomain]"

    $ServicesToControl = @('IBM*', 'AFU*')

    #validate valid state sent in...
    $State = $State.ToLower()
    if($ACTIONS.Contains($State)) 
    {
        Write-Host "Valid option passed for -State with: [$State]"
    }
    else
    {
        Write-Error "The value you supplied for -State is not valid. It must be either: running or stopped!" 
        $exit_code = 16
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    #get the server(s) to manage...
    $Servers = Get-FileNetServerList
    Write-Host "List of Servers is: [$servers]"

    #validate we will not cross domains...
    foreach ($server in $servers)
    {
        # (Get-ADDomainController).domain.split('.')[0].toUpper()
        Write-Host "Validating domain for server [$server]"
        if(Test-Connection -ComputerName $server -count 1 -Quiet)
        {
            $remoteDomain = invoke-command -ComputerName $server -ScriptBlock{(Get-WmiObject Win32_ComputerSystem).domain.split('.')[0].toUpper()} -ErrorAction Ignore
            if($LocalDomain -ne $remoteDomain)
            {
                Write-Error "WE CAN'T run a script that will cross Domains; Local Domain [$LocalDomain] to server [$server] with domain [$remoteDomain], exiting script!"
                $exit_code = 20
                ExitWithCode -exitcode $exit_code -ISEFlag $ISE
            }
            else
            {
                write-host "Server [$server] is valid for running script against, continuing" 
            }
        }
        else
        {
            Write-Error "Server returned from CMDB does not seem to be online for Server [$server], exiting script!"
            $exit_code = 22
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }
    }

    #check if servers is empty, then exit
    if(([string]::IsNullOrEmpty($servers))) 
    {
        Write-Error "Could not determine a list of servers for environment [$Environment], exiting!"
        $exit_code = 13
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    if(-not ([string]::IsNullOrEmpty($servers))) 
    {
        Write-Host "Working on Servers [$servers] for Services [$($servicesToControl)]"
        Write-Host "Building PSSessions on [$Servers] Servers"
        $Session = New-PSSession -ComputerName $Servers -Verbose
        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,$state,600 -AsJob
        #wait for job to complete and output results
        $rc1 = checkJobAndLog -Session $Session -Jobs $Jobs 
        $RCode1 = $($rc1)[1]
        if ($RCode1 -ne 0)
        {
            Write-Error "Failures duing Validation Checks with RC: $RCode1"
            $exit_code = $RCode1
        }
        else
        {
            Write-Host "All good on job(s) RC: $RCode1"
        }
    }
    else
    {
        Write-Host "Servers are empty, skipping servers [$servers] for Services [$($servicesToControl)]"
    }

}
catch
{
    Write-Warning $_.Exception.ToString();
    $exit_code = 99
}

finally
{
    #cleanup
    Remove-Module -Name SRE-Functions -Force -WarningAction SilentlyContinue
    Remove-Module -Name SnowFunctions -Force -WarningAction SilentlyContinue
    Remove-Module -Name Get-PAMServiceControl -Force -WarningAction SilentlyContinue

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}

