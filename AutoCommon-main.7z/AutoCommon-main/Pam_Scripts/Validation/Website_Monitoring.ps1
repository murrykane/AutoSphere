﻿<##	
	.NOTES
	===========================================================================
	 Created on:   	01/31/2018
	 Updated on:	03/04/2019
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	RestartFilenetServices.ps1

	The scripts being built in this grouping are for PAM Production Support
	The majority will be run from the Primary PAM Server, WINF313P. However,
	it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script Checks all URL's that PAM team supports

    Updates
    date        who           description
    07/10/2018  Murry Kane    Updated for BATCH servers where NODE1 is good with 404 return and NODE2 are good if down
    05/13/2019  Murry Kane    Added an array to not have duplicate entries when bad URL's are found....
    03/03/2020  Kyle Parrott  Moved Check-URL into a function. Added logic to re-try URL 1 time if it fails to be validated
    12/04/2020  Murry Kane    added -UseBasicParsing to invoke-webrequest as first time user gets IE not available and errors out

#> 

$destination  = "D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\Validation\URLCheck.htm"
$copy_destdir = "D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\Validation\logs\"
$URLListFile = "D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\Validation\URLList.PAM.txt" 
$badCounter = 0

#exit 
$URLList = Get-Content $URLListFile  
$Result = @() 
$BADUrls = @()
$date = date

#import functions
Import-Module Functions -Force

$LOG_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\logs'
$PAM_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts'
$currentScriptName = $MyInvocation.MyCommand.Name
$filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
$SleepTimer = 5
$MAINTVALUES = 'core','infra'


Write-Host "Script name is: $currentScriptName"

if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS)))
{
    $LOG_DIR = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS
}
else
{
    $LOG_DIR = $PAM_HOME_DIR_DEFAULT 
}

$LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

#get PAM home dir
if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME)))
{
    $PAM_HOME = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME
}
else
{
    $PAM_HOME = $PAM_HOME_DIR_DEFAULT 
}

#lets start logging what occures from here forward....
Start-Transcript -path $LOG_FILE -append
#turn off Verbose logging
$VerbosePreference = 'SilentlyContinue'

if ($Host.Name -eq "Windows PowerShell ISE Host") {
    $ISE=$true
} else {
    $ISE=$false
}

# fix for some URL pages....  like ThinkSmart URL: https://blueshieldcaplans.com/
$AllProtocols = [System.Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12'
[System.Net.ServicePointManager]::SecurityProtocol = $AllProtocols

function Ignore-SSLCertificates
{
    $Provider = New-Object Microsoft.CSharp.CSharpCodeProvider
    $Compiler = $Provider.CreateCompiler()
    $Params = New-Object System.CodeDom.Compiler.CompilerParameters
    $Params.GenerateExecutable = $false
    $Params.GenerateInMemory = $true
    $Params.IncludeDebugInformation = $false
    $Params.ReferencedAssemblies.Add("System.DLL") > $null
    $TASource=@'
        namespace Local.ToolkitExtensions.Net.CertificatePolicy
        {
            public class TrustAll : System.Net.ICertificatePolicy
            {
                public bool CheckValidationResult(System.Net.ServicePoint sp,System.Security.Cryptography.X509Certificates.X509Certificate cert, System.Net.WebRequest req, int problem)
                {
                    return true;
                }
            }
        }
'@ 
    $TAResults=$Provider.CompileAssemblyFromSource($Params,$TASource)
    $TAAssembly=$TAResults.CompiledAssembly
    ## We create an instance of TrustAll and attach it to the ServicePointManager
    $TrustAll = $TAAssembly.CreateInstance("Local.ToolkitExtensions.Net.CertificatePolicy.TrustAll")
    [System.Net.ServicePointManager]::CertificatePolicy = $TrustAll
}

function Check-URL
{
  param
  (
    $Line,
    $FirstUrlCheck
  )


  if($Line.startswith("http"))
  {
      $array = $Line -split "\s+"
      $Uri = $array[0]
      $MethodType = $array[1]
      $URLName = $array[2]
      #Write-Output "Working on URI [ $Uri ] with Method call [ $MethodType ]"
      Write-Progress -Activity "working..."  -CurrentOperation "$Uri -Method $MethodType"
      $time = try
      {
        $request = $null
        ## Request the URI, and measure how long the response took.
        $result1 = Measure-Command { $request = Invoke-WebRequest -Uri $uri -TimeoutSec 7 -Method $MethodType -UseDefaultCredentials -UseBasicParsing }
        $result1.TotalSeconds
  
  
      } 
  
      catch

      {
       <# If the request generated an exception (i.e.: 500 server
       error or 404 not found), we can pull the status code from the
       Exception.Response property #>
       $request = $_.Exception.Response
      }
  } 
  
  #lets add a sort object
  if([string]::IsNullOrEmpty($request.StatusCode))
  {
    $resultCode = 9999
  }
  else
  {
    $resultCode = [int] $request.StatusCode
  } 
  
  #need logic for BATCH servers
  #####################################
  if($Uri.Length -ge 5)
  {
      $last5 = $($Uri.Substring($Uri.Length -5).ToUpper())
      if($last5 -eq "NODE1")
      {
        #write-host "NODE1 Value is $resultCode for uri $Uri"
        if($resultCode -eq 404)
        {
            #switching to good... for NODE1
            #write-host "NODE1 Swithing to 200... for uri $Uri"
            $resultCode = [int] 200
        }
      }

      if($last5 -eq "NODE2")
      {
        #write-host "NODE2 Value is $resultCode for uri $Uri"
        if($resultCode -eq 9999 )
        {
            #write-host "NODE1 Setting to 200... for uri $Uri"
            $resultCode = [int] 200
        }
      }
  }
  #####################################    


  # Here we check if the URL response is not 401 / 200. If it isn't then we re-check the URL
  if (($FirstUrlCheck) -and ($resultCode -ne 200) -and ($resultCode -ne 401) -and ($uri -like "http*"))
  {
    Write-Host "First check of $Uri with method '$MethodType' returned code $resultCode... checking again."
    return $(Check-URL -Line $Line -FirstUrlCheck $false)
  }


  $resultObj = [PSCustomObject] @{
    Time = Get-Date;
    Uri = $uri;
    #StatusCode = [int] $request.StatusCode;
    StatusCode = [int] $resultCode;
    StatusDescription = $request.StatusDescription;
    ResponseLength = $request.RawContentLength;
    TimeTaken =  $time
    $date = date
    URLName = $URLName;
    ResultCode = $resultCode
    }
  
  return $resultObj
}



#for DMGR Consoles need to ignore SSL errors....
Ignore-SSLCertificates

<#  Might be needed later....
add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

Foreach($Line in $URLList)
{
    Write-Output "working.... on $Line"
    $array = $string -split "\s+"
    $Uri = $array[0]
    $MethodType = $array[1]
    Write-Output "Working on URI [ $Uri ] with Method call [ $MethodType ]"
}

#>

#Break

Foreach($UrlLine in $URLList) 
{  
  $result += Check-URL -Line $UrlLine -FirstUrlCheck $true
}

#sort it first......
$result = $result | sort-object -Property ResultCode,URLName -Descending

#Prepare email body in HTML format
if($result -ne $null)
{
    $Outputreport  = "<HTML><TITLE>Website Availability Report</TITLE><BODY background-color:peachpuff><font color =""#99000"" face=""Microsoft Tai le""><H2> Website Availability Report </H2></font><Table border=1 cellpadding=0 cellspacing=0><TR bgcolor=gray align=center><TD><B>URLDescription</B></TD><TD><B>URL</B></TD><TD><B>StatusCode</B></TD><TD><B>StatusDescription</B></TD><TD><B>ResponseLength</B></TD><TD><B>TimeTaken</B></TD</TR>"
    Foreach($Entry in $Result)
    {
        $writeOutput = $false
        if($Entry.uri -like "http*")
        {
            if($Entry.StatusCode -eq 401)
            {
                $Outputreport += "<TR bgcolor=yellow>"
                $writeOutput = $true
            }
            elseif($Entry.StatusCode -ne 200)
            {
                $Outputreport += "<TR bgcolor=red>"
                $writeOutput = $true
                #$badCounter += 1
                #$BADURLs += " " + $Entry.uri 
                #Write-Host "Bad url... maybie.... $Entry.uri"
                if($BADUrls -contains $Entry.uri)
                {
                    Write-Verbose "Entry $Entry.uri is already in the list...."
                }
                else
                {
                    $BADUrls += $Entry.uri
                    $badCounter += 1
                }
            }
            else
            {
                $Outputreport += "<TR bgcolor=#58FA82>"
                $writeOutput = $true
            }
        }
        if ($writeOutput)
        {
            $theEntry = $Entry.uri
            $Outputreport += "<TD align=center>$($Entry.URLName)</TD><TD><B><a href=$($theEntry)>$($theEntry)</a></B></TD> <TD align=center>$($Entry.StatusCode)</TD><TD align=center>$($Entry.StatusDescription)</TD><TD align=center>$($Entry.ResponseLength)</TD><TD align=center>$($Entry.timetaken)</TD>   </TR>"
        }
    }
    
    $Outputreport += "$date </Table></BODY></HTML>"

}

# lets backup the old file.....
# $timer = (Get-Date -Format yyy-MM-dd-hhmmss)
$timer = (Get-Date -Format yyy-MM-dd-hhmmss)
$fileItem = Get-ChildItem -File $destination

$extension = $fileItem.Extension;
$strippedFileName = $fileItem.BaseName;

$copiedFileName = "$copy_destdir$strippedFileName-$timer$extension"
#Write-Output "file to save is $copiedFileName"

$TestPath = Test-Path $destination
if($TestPath)
{
    #write-output "Copying old report..."
    Copy-Item $destination $copiedFileName 
}

#cleanup old reports....
$limit = (Get-Date).AddDays(-7)
# Delete files older than the $limit.
Get-ChildItem -Path $copy_destdir -Recurse -Force | Where-Object { !$_.PSIsContainer -and $_.CreationTime -lt $limit } | Remove-Item -Force 
# Delete any empty directories left behind after deleting the old files.
Get-ChildItem -Path $copy_destdir -Recurse -Force | Where-Object { $_.PSIsContainer -and (Get-ChildItem -Path $_.FullName -Recurse -Force | Where-Object { !$_.PSIsContainer }) -eq $null } | Remove-Item -Force -Recurse


$Outputreport | out-file $destination
#Invoke-Expression $destination # NOT needed since we now run in it in scheduled tasks!

if($badCounter -ge 1)
{
    Write-Host "----------------------------------------------------------------------------------------"
    Write-Host "Appending BAD URL's Report to log...."
    #Write-Host "$BADURLs"
    $BADUrls | foreach { Write-Host "$_" }
    Write-Host "----------------------------------------------------------------------------------------"
}

Write-Host "All done with: $currentScriptName Exiting with [$badCounter]"

ExitWithCode -exitcode $badCounter -ISEFlag $ISE
