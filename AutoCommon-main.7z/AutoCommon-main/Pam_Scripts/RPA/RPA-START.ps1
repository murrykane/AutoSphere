﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	03/03/2021
	 Updated on:	
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	RPA-START.ps1

	The scripts being built in this grouping are for PAM Production Support
	The majority will be run from the Primary PAM Server, WINF313P. However,
	it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script start all RPA Services

        Use the following CMDB query to find the correct RPA Servers for managing the services:

        https://blueshieldca.service-now.com/cmdb_rel_ci_list.do?sysparm_query=parent.nameLIKERPA%RPAH025Eparent.install_statusIN11&sysparm_view=

        As of 09/15/2020 this would return the following CMDB entries

        Robotic Process Automation (RPA)
        Robotic Process Automation Studio (RPA)
        RPAH03_Robotic Process Automation (RPA)
        RPAH01_Robotic Process Automation (RPA)
        RPAH02_Robotic Process Automation (RPA)

        Passing as argument 1 any of the above would get the correspoding server

Examples

  ./{PATH}\RPA-START.ps1 -Environment RPAH03    (This would run against 'RPAH03_Robotic Process Automation (RPA)' servers)


MODIFICATIONS
_____________________________________________________________________________________________________________________________
    Date       By            Reason
    12/08/2020 Murry Kane    Initial



    Example

    ./{PATH}\RPA-START.ps1 -Environment prod
    ./{PATH}\RPA-START.ps1 -Environment RPAH01
    ./{PATH}\RPA-START.ps1 -Environment RPAH02
    ./{PATH}\RPA-START.ps1 -Environment RPAH03
   
#>

[CmdletBinding()]
Param(
   #[Parameter(Mandatory=$True,Position=1)]
   [string[]]$Environment,
   [string]$State
)

function Get-ServerList {
    try {
        $SNowCred = Get-ServiceNowCredential

        $UriBase = Get-ServiceNowUriBase
        Write-Host "URI Base $UriBase"

        # Query Server to App Relationship Table
        Write-Host "Querying ServiceNow API for getting the FileNet Content Collector server(s)"
        
        #$Uri = "$UriBase/api/now/table/cmdb_rel_ci?sysparm_query=parent.nameLIKE$Environment%5Eparent.operational_status%3D1%5Eparent.install_status%3D11%5Echild.sys_class_name%3Dcmdb_ci_win_server%5Echild.install_status%3D11%5Echild.operational_status%3D1&&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=child&sysparm_limit=1000"
        $Uri = "$UriBase/api/now/table/cmdb_rel_ci?sysparm_query=parent.nameSTARTSWITH$CMDB_Value%5Echild.nameSTARTSWITHRPA%5Eparent.sys_class_name%3Dcmdb_ci_appl%5Eparent.operational_status%3D1%5Echild.sys_class_name%3Dcmdb_ci_app_server%5Echild.operational_status%3D1&&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=child&sysparm_limit=1000"
        Write-Host "Using URI [$Uri]"

        $Result = Query-ServiceNowApi -Uri $Uri -SNowCred $SNowCred

        Write-Host "Result is " + $result
        #$ServersList = ($Result).child | select -Unique
        $Servers = $Result.Child | ForEach-Object { $_.split('@')[1] } | select -Unique

        return $Servers
    }
    catch {
        return $null
    }
}

function check-ADDomainCross() 
{
  Param
  (
    [Parameter(Mandatory=$true, Position=0)]
    [string] $ManagementServerDomain
  )
    try 
    {
        #turn on verbose
        $VerbosePreference = 'Continue'
        $server = [System.Net.Dns]::GetHostName()
        Write-Verbose "Validating domain for server [$server]"
        if(Test-Connection -ComputerName $server -count 1 -Quiet)
        {
            $LocalDomain = (Get-WmiObject Win32_ComputerSystem -ErrorAction Ignore).domain.split('.')[0].toUpper()
            if($LocalDomain -ne $ManagementServerDomain)
            #if($LocalDomain -ne "BSC")
            {
                Write-Warning "WE CAN'T run a script that will cross Domains; Local Domain [$LocalDomain] to server [$server] with domain [$ManagementServerDomain], exiting script!"
            }
            else
            {
                Write-Verbose "Server [$server] is valid for running script against, continuing" 
            }
        }
        else
        {
            Write-Warning "Server returned from CMDB does not seem to be online for Server [$server], exiting script!"   
        }

        return

    }
    catch {
        Write-Warning "Unexpected Error:`n$($_.Exception.ToString())"
        return 
    }
}

try
{

    $LOG_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\Logs'
    $PAM_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts'
    $ENVS = @('PROD','RPAH01','RPAH02', 'RPAH03')
    $exit_code = 0
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    # turn off verbose
    $VerbosePreference = 'SilentlyContinue'
    $LocalDomain = (Get-ChildItem Env:'USERDOMAIN' -ErrorAction Ignore).Value


    Write-Host "Script name is: $currentScriptName"

    if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS)))
    {
        $LOG_DIR = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS
    }
    else
    {
        $LOG_DIR = $PAM_HOME_DIR_DEFAULT 
    }

    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    #get PAM home dir
    if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME)))
    {
        $PAM_HOME = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME
    }
    else
    {
        $PAM_HOME = $PAM_HOME_DIR_DEFAULT 
    }


    if ($Host.Name -eq "Windows PowerShell ISE Host") {
        $ISE=$true
    } else {
        $ISE=$false
    }
    if ($ISE) {
        if(-not($Environment)) {
            #prompt to get it
            do 
            {
                $Environment = (Read-Host "Input your Environment ($ENVS ): ")
            }
            until ($ENVS.Contains($Environment.toUpper()))
        }
    }

    #lets start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    #import functions
    Import-Module Functions -Force -WarningAction SilentlyContinue
    Import-Module SnowFunctions -Force -WarningAction SilentlyContinue
    import-module -name Get-PAMServiceControl -Verbose -WarningAction SilentlyContinue

    Write-Host "PAM HOME Directory is $PAM_HOME"
    Write-Host "Log File is $LOG_FILE"
    Write-Host "Environment is [$Environment] Running in AD Domain [$LocalDomain]"

    $ServicesToControl = @('PEGA*')

    if (-not($Environment)) 
    { 
        $exit_code = 8
        Write-Warning "You Must supply a value for CMDB lookup on Citrix XD Delivery Controller" 
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    #validate environment
    $Environment = $Environment.ToUpper()
    if($ENVS -contains $Environment)
    {
        Write-Host "Valid option passed for -Environment with: [$Environment]"
        Switch ($Environment)
        {
           # MBK This is where prod/stage/npe is translated to the values to look up in CMDB
           #order matters!!!
           $ENVS[0] { $CMDB_Value = 'Robotic Process Automation (RPA)'}
           $ENVS[1] { $CMDB_Value = 'RPAH01_Robotic Process Automation (RPA)'}
           $ENVS[2] { $CMDB_Value = 'RPAH02_Robotic Process Automation (RPA)' }
           $ENVS[3] { $CMDB_Value = 'RPAH03_Robotic Process Automation (RPA)' }
           default { $CMDB_Value = '' }  
        } 
        if([string]::IsNullOrWhiteSpace($CMDB_Value))
        {
            $exit_code = 14
            Write-Warning "We could not determine lookup value for CI's in the CMDB!" 
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE 
        }
    }
    else
    {
        Write-Error "The value you supplied for -Environment is not valid. It must be one of the following: [$CitrixENVS]!" 
        $exit_code = 16
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    #get the server(s) to manage...
    $Servers = Get-ServerList
    Write-Host "List of Servers is: [$servers]"

    #check if servers is empty, then exit
    if(([string]::IsNullOrEmpty($servers))) 
    {
        Write-Error "Could not determine a list of servers for environment [$Environment], exiting!"
        $exit_code = 13
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    if(-not ([string]::IsNullOrEmpty($servers))) 
    {

        #first check for domain crossing...
        $Session = New-PSSession -ComputerName $Servers -Verbose -ErrorAction Continue -WarningAction Continue
        if($($Session.count) -ne $($Servers.count))
        {
            Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($localdomain), exiting!"
            Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
            $exit_code = 19
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }


        Write-Host "Working on Servers [$servers] to validate we will not Cross AD Domains"
        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::check-ADDomainCross} -ArgumentList $LocalDomain -AsJob
        $rc1 = checkJobAndLog -Session $Session -Jobs $Jobs -ExitCodeType 2
        $RCode1 = $($rc1)[1]
        if ($RCode1 -ne 0)
        {
            Write-Error "Failures duing Validation Checks with RC: $RCode1"
            $exit_code = $RCode1
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE  
        }
        else
        {
            Write-Host "All good on job(s) RC: $RCode1"
        }

        Write-Host "Working on Servers [$servers] for Services [$($servicesToControl)]"
        Write-Host "Building PSSessions on [$Servers] Servers"
        $Session = New-PSSession -ComputerName $Servers -Verbose
        $Jobs2 = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,start,600 -AsJob
        #wait for job to complete and output results
        $rc2 = checkJobAndLog -Session $Session -Jobs $Jobs2 
        $RCode2 = $($rc2)[1]
        if ($RCode2 -ne 0)
        {
            Write-Error "Failures duing Validation Checks with RC: $RCode2"
            $exit_code = $RCode2
        }
        else
        {
            Write-Host "All good on job(s) RC: $RCode2"
        }
    }
    else
    {
        Write-Host "Servers are empty, skipping servers [$servers] for Services [$($servicesToControl)]"
    }

}
catch
{
    Write-Warning $_.Exception.ToString();
    if($exit_code -lt 1 )
    {
        $exit_code = 99
    }
}

finally
{
    #cleanup
    Remove-Module -Name SRE-Functions -Force -WarningAction SilentlyContinue
    Remove-Module -Name SnowFunctions -Force -WarningAction SilentlyContinue
    Remove-Module -Name Get-PAMServiceControl -Force -WarningAction SilentlyContinue

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}

