<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2014 v4.1.50
	 Created on:   	6/13/2015 6:34 PM
	 Created by:   	Lance Jensen
	 Organization: 	Blue Shield of California
	 Filename:     	Get-BSCServers.psm1

	The Functions in this module are designed to provide Server groupings for automated 
	Functions within IT-PAM and NPA (Non-Production Applications).
	The Module is designed to work from a Management Server that has access to perform
	Remote Administration on Servers Returned
	===========================================================================
	.DESCRIPTION
		This script returns a list of servers matching specific criteria.
#>
<#
	A note on the parameters $Config_File and $EnvList.
	The purpose of adding these as parameters is it gives the user the ability to
	work against test lists as needed. But in general production, the lists used
	should be the defaults as defined below.

Modifications:

12/05/2018  Murry Kane   - Modified for new attributes in file (Citrix Icon, NPE/Prod etc)
                           Used environment variables instead of hard-coding directories

Examples:

import-module Get-BSCServers

$GetAll = get-bscservers -Environment FACN32 -WhichProperty App -PropValue FACETS
$Servers = get-bscservers -Environment FACN32 -WhichProperty App -PropValue FACETS -Names
$Servers = get-bscservers -Environment FACN32 -WhichProperty Role -PropValue IIS -Names 
$Platform = get-bscservers -Environment FACN32 -WhichProperty Role -PropValue IIS -Platform
$CitrixIcon = get-bscservers -Environment FACN32 -WhichProperty Role -PropValue IIS -CitrixIcon

#>

#Set Global Variables common to each Function. This function is internal to the module.



Function Set-GlobalVar
{

    [CmdletBinding()]
	Param
	(
		[Parameter()][string]$EnvList
	)
    
    Write-Debug "Envlist is $EnvList"
    if (-not ([string]::IsNullOrEmpty((Get-ChildItem -ErrorAction Ignore Env:PAM_SERVER_LIST).Value)))
    {
        $EnvList=(Get-ChildItem -ErrorAction Ignore Env:PAM_SERVER_LIST).Value
    }
    else
    {
        if (-not ([string]::IsNullOrEmpty($EnvList)))
        {
            #$EnvList=$EnvList
            Write-Debug "Using ENVLIST Passed with [$EnvList]"
        }
        else
        {
            $EnvList = (Get-ChildItem -ErrorAction Ignore Env:PAM_HOME_DIR).Value + "\Config\EnvironmentLists\EnvList.csv"
        }
    }

}

function get-BSCServers
{
	[CmdletBinding()]
	Param
	(
		[Parameter()][string[]]$Environment = "$__DefaultFacetsEnv",
		[Parameter(Mandatory, ParameterSetName = 'ByProperty')][String]$WhichProperty,
		[Parameter(Mandatory, ParameterSetName = 'ByProperty')][String[]]$PropValue,
		#[Parameter()][string]$EnvList = "EnvList",
        [Parameter()][string]$EnvList,
		[Parameter()][switch]$Names,
        [Parameter()][switch]$Platform,
        [Parameter()][switch]$CitrixIcon

	)
	

<#
	Set Constants
#>
	
	. Set-GlobalVar "$EnvList"
    #. Set-GlobalVar
	
	if ((Test-Path $EnvList) -eq $false)
	{
		Write-Debug "$EnvList does not exist"
		Write-Error -Message "$EnvList does not exist"
		throw "Could Not Complete Operation"
	}
	
	$Servers = @()
	
	foreach ($Value in $PropValue)
	{
		$T_Servers = @()
		
		If ($Environment -ne "__Default" )
		{
			$T_Servers = Import-Csv $EnvList  | Where-Object { $_.EnvName -eq $Environment -and $_.$WhichProperty -eq "$Value" }
		}
		else
		{
			$T_Servers = Import-Csv $EnvList | Where-Object { $_.$WhichProperty -eq "$Value" }
		}
		
		$Props = Get-BSCProperty -EnvList $EnvList
		
		foreach ($Server in $T_Servers)
		{
		
			
			Write-Debug "Starting $SNAME"
			
			$Config_Object = $null
			$Config_Object = New-Object System.Object
			foreach ($Name in $Props)
			{
				$Value= $Name.name
				$Config_Object | Add-Member -Type 'NoteProperty' -Name $value -Value $Server.$value
			}
			
			
			$Servers += $Config_Object
		}
	}
	
	
	#	$servers
	
	if ($Names -eq $true)
	{
		$SList = @()
		foreach ($Server in $Servers)
		{
			$SList += $Server.ServerName
		}
		Return ($SList)
	}
	Elseif($Platform -eq $true)
    {
        $SList = @()
        foreach ($item in $Servers)
        {
            $Value = $Server.Platform
            if($Slist -contains $Value)
            {
                write-debug "Already there for $Value"
            }
            else
            {
                $Slist += $Value
            }
        }
        return $SList
    }
    ElseIf($CitrixIcon -eq $true)
    {
        $SList = @()
        foreach ($item in $Servers)
        {
            $Value = $Server.CitrixIcon
            if($Slist -contains $Value)
            {
                write-debug "Already there for $Value"
            }
            else
            {
                $Slist += $Value
            }
        }
        return $SList
    }
    else 
	{
		return ($Servers)
	}
	
}

function Get-BSCProperty
{
	[CmdletBinding()]
	Param
	(
		[Parameter()][string]$EnvList
	)
	
	#. Set-GlobalVar ($EnvList)
    #. Set-GlobalVar
	#$EnvList
	
	import-csv $EnvList | Get-Member -MemberType NoteProperty
}

