﻿#Functions
function ExitWithCode 
{ 
    param 
    ( 
        $exitcode,
        $ISEFlag
    )

    if([string]::IsNullOrEmpty($ISEFlag))
    {
        write-host "Setting ISE to default TRUE"
        $ISEFlag = True
    }
    if([string]::IsNullOrEmpty($exitcode))
    {
        write-host "Setting exit code to 99"
        $exitcode = 99
    }

    #Write-Host "ISE Flag [$ISEFlag] Exit Code [$exitcode]"
    if($ISEFlag)
    {
        #lets try and stop transcript..
        try{
            stop-transcript|out-null
        }
        catch [System.InvalidOperationException]{}
        if ($exitCode -gt 0)
        {
            Throw("Exiting ISE Script with [$exitcode]")
        }
        else
        {
            Write-Host "Exiting ISE Script with [$exitcode]"
        }
    }
    else
    {
        if ($exitcode -gt 0)
        {
            Write-Error "Exiting powershell Script with [$exitcode]"
        }
        else
        {
            Write-Host "Exiting powershell Script with [$exitcode]"
        }
        $host.SetShouldExit($exitcode)
        exit $exitcode
    }
}

function checkJobAndLog
{
    # ExitCodeTypes:
    # 1 - Only Errors increment the exit code
    # 2 - Errors and Warnings increment the exit code
    # 3 - Errors, Warnings and Verbose output increment the exit code
    param(
        [parameter(ValueFromPipeline=$true)]$Session,
        [parameter(ValueFromPipeline=$true)]$Jobs,
        [ValidateSet(1,2,3)][int]$ExitCodeType = 1
        )
    
    #turn on verbose
    $VerbosePreference = 'Continue'
    
    $SleepTime = 5
    $exit_code = 0
    While ($(Get-Job -State Running).count -gt 0){
        $JobsCount = $Jobs.ChildJobs.Count
        for ($i=0; $i -lt $JobsCount; $i++) {
            $ChildJob = $Jobs.ChildJobs[$i]
            Write-Verbose "Job [$($ChildJob.Name)] Server [$($ChildJob.Location)] State is [$($ChildJob.State)]"
        }
        Write-Verbose "Sleeping for $SleepTime.... Current Date: $(Get-Date -format 'u')"
        Start-Sleep -Seconds $SleepTime
    }
    # just to make sure the above while loop is wrong.....
    Wait-Job $Jobs

    Write-Host "=================================================================================================================================================================="
    $JobCount = $Jobs.ChildJobs.Count
    #Write-Host "Count of child Jobs is $JobCount"
    for ($i=0; $i -lt $JobCount; $i++) {
        #Write-Host "Working on loop instance $i"
        $ChildJob = $Jobs.ChildJobs[$i]
        if($ChildJob.Verbose){
            #Write-Host "....................The below VERBOSE output from remote job................"
            $ChildJob.Verbose | Write-Verbose
            if ($ExitCodeType -gt 2) { $exit_code = $exit_code + 1 }
        }
        if($ChildJob.Output){
            #Write-Host "....................The below WRITE-OUTPUT from remote job................"
            #$ChildJob.Output | Write-Output
        }
        if($ChildJob.Warning){
            Write-Host "....................The below WARNING output from remote job................"
            $ChildJob.Warning | Write-Warning
            Write-Host "Sleeping for 0 seconds to view output" -ForegroundColor Yellow
            #Start-Sleep -Seconds 1
            if ($ExitCodeType -gt 1) { $exit_code = $exit_code + 1 }
        }
        if($ChildJob.Error){
            Write-Host "....................The below ERROR output from remote job................"
            $ChildJob.Error | Write-Error 
            Write-Host "Sleeping for 2 seconds to view output" -ForegroundColor Yellow
            Start-Sleep -Seconds 2
            $exit_code = $exit_code + 1
        }
        Write-Host "=================================================================================================================================================================="
    }

    Remove-Job $Jobs
    remove-pssession $Session
    Get-Job | Remove-Job -force
    #turn off verbose
    $VerbosePreference = 'SilentlyContinue'
    return $exit_code

}


function checkRemoteJobAndLog
{
    
    param(
        [parameter(ValueFromPipeline=$true)]$Session,
        [parameter(ValueFromPipeline=$true)]$Jobs
        )
    
    #turn on verbose
    $VerbosePreference = 'Continue'
    
    $SleepTime = 5
    $exit_code = 0
    While ($(Get-Job -State Running).count -gt 0){
        $JobsCount = $Jobs.ChildJobs.Count
        for ($i=0; $i -lt $JobsCount; $i++) {
            $ChildJob = $Jobs.ChildJobs[$i]
            Write-Verbose "Job [$($ChildJob.Name)] Server [$($ChildJob.Location)] State is [$($ChildJob.State)]"
        }
        Write-Verbose "Sleeping for $SleepTime.... Current Date: $(Get-Date -format 'u')"
        Start-Sleep -Seconds $SleepTime      
    }
    # just to make sure the above while loop is wrong.....
    Wait-Job $Jobs

    $JobCount = $Jobs.ChildJobs.Count
    for ($i=0; $i -lt $JobCount; $i++) {
        Write-Host "=================================================================================================================================================================="
        $ChildJob = $Jobs.ChildJobs[$i]
        Write-Host "Job [$($ChildJob.Name)] ran on server [$($ChildJob.Location)] output below:"
        if($ChildJob.Verbose){
            $ChildJob.Verbose | Write-Verbose
        }
        if($ChildJob.Output){
            $ChildJob.Output | Write-Output
        }
        if($ChildJob.Warning){
            $ChildJob.Warning | Write-Warning
        }
        if($ChildJob.Error){
            $ChildJob.Error | Write-Error 
        }
        Write-Host "=================================================================================================================================================================="
    }

    Remove-Job $Jobs
    remove-pssession $Session
    Get-Job | Remove-Job -force
    #turn off verbose
    $VerbosePreference = 'SilentlyContinue'
    return $exit_code

}

function checkRemotePuppetJobAndLog
{
    
    param(
        [parameter(ValueFromPipeline=$true)]$Session,
        [parameter(ValueFromPipeline=$true)]$Jobs
        )
    
    #turn on verbose
    $VerbosePreference = 'Continue'
    
    $SleepTime = 5
    $exit_code = 0
    While ($(Get-Job -State Running).count -gt 0){
        $JobsCount = $Jobs.ChildJobs.Count
        for ($i=0; $i -lt $JobsCount; $i++) {
            $ChildJob = $Jobs.ChildJobs[$i]
            Write-Verbose "Job [$($ChildJob.Name)] Server [$($ChildJob.Location)] State is [$($ChildJob.State)]"
        }
        Write-Verbose "Sleeping for $SleepTime.... Current Date: $(Get-Date -format 'u')"
        Start-Sleep -Seconds $SleepTime      
    }
    # just to make sure the above while loop is wrong.....
    Wait-Job $Jobs

    $JobCount = $Jobs.ChildJobs.Count
    Write-Host "Count of child Jobs is $JobCount"
    for ($i=0; $i -lt $JobCount; $i++) {
        Write-Host "=================================================================================================================================================================="
        $ChildJob = $Jobs.ChildJobs[$i]
        Write-Host "Job [$($ChildJob.Name)] ran on server [$($ChildJob.Location)] output below:"
        $ChildJob | Receive-Job
        Write-Host "=================================================================================================================================================================="
    }

    Remove-Job $Jobs
    remove-pssession $Session
    Get-Job | Remove-Job -force
    #turn off verbose
    $VerbosePreference = 'SilentlyContinue'
    return $exit_code

}

function scriptStartup
{
    #setting some basic variables and defaults
    $LOG_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\logs'
    $PAM_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts'

    #get some environment variables
    if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS)))
    {
        $LOG_DIR = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS
    }
    else
    {
        $LOG_DIR = $PAM_HOME_DIR_DEFAULT 
    }

    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    #get PAM home dir from environment variables
    if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME)))
    {
        $PAM_HOME = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME
    }
    else
    {
        $PAM_HOME = $PAM_HOME_DIR_DEFAULT 
    }

    #determine if started from within the ISE or command line
    if ($Host.Name -eq "Windows PowerShell ISE Host") {
        $ISE=$true
    } else {
        $ISE=$false
    }

    return @($ISE, $LOG_FILE, $PAM_HOME)
}

function isValidServer
{
    
    param
    (
        [parameter(Mandatory=$true)]
        [string]$Server
    )

    $Address = $null
    $EC = 0

    Write-Verbose "Validating Server [$Server]..."

    try
    {
        $Address = [System.Net.Dns]::GetHostAddresses("$Server").IPAddressToString
        Write-Host "Server [$Server] IP Address is $Address"
        return $EC
    }
    catch
    {
        $EC = 33
        Write-Error "Server [$Server] IP Address could not resolve."
        return $EC
    }
}

function isSelfHealEnabled
{

    param(
        [parameter(Mandatory=$true)]
        [string]$PAM_HOME
    )
    # Exit Code
    $EC = 0

    # Self Heal Config File
    $SelfHealFile = "$PAM_HOME\Config\SelfHeal\SelfHealConfig.txt"

    Write-Verbose "Verifying that Self Healing is enabled..."
    
    try
    {
        $SelfHealConfig = Get-Content $SelfHealFile -ErrorAction Continue
  
        if ($SelfHealConfig -eq "Enabled") 
        {
            $EC = 0
            Write-Verbose "Self-Healing is enabled. Good to continue with script."
            return $EC
        }
        elseif ($SelfHealConfig -eq "Disabled")
        {
            $EC = 51
            Write-Error "Error: Self-Healing Automation has been disabled. Exiting!"
            return $EC
        }
        else 
        {
            $EC = 52
            Write-Error "Error: Unable to determine Self-Healing Configuration. Exiting!"
            return $EC
        }
    }
    catch
    {
        $EC = 53
        Write-Error "Error: Unable to get content of $SelfHealFile."
        return $EC
    }
}


function validateDomain
{
    
    param
    (
        [Parameter(Mandatory=$true)]
        [string]$Server,
        [switch]$RunOnLocalHost
    )
    
    # Set error code
    $EC = 0

    # Get Environment Domain
    $Domain = (Get-ChildItem Env:'UserDomain' -ErrorAction Ignore).Value

    # Get platform (PROD/OTHER)
    $ServerLetter = $Server.Substring($Server.Length - 1,1)

    if ($ServerLetter -eq "p")
    {
        $Platform = "PROD"
    }
    elseif ($RunOnLocalHost)
    {
        # Set to appropriate platform based on domain
        if ($Domain -eq "BSC")
        {
            $Platform = "PROD"
        }
        else
        {
            $Platform = "OTHER"
        }
    }
    else 
    {
        $Platform = "OTHER"
    }

    Write-Verbose "Platform for server [$Server] is [$Platform], Active Directory domain is [$Domain]."

    # Validate we are not trying to cross domains
    if ($Platform -eq "PROD" -and $Domain -ne "BSC")
    {
        $EC = 21
        Write-Error "We cannot run a script from a Non-prod Active Directory domain [$Domain] to a production server [$Server], exiting script!"
        return $EC
    }
    elseif ($Platform -ne "PROD" -and $Domain -eq "BSC")
    {
        $EC = 22
        Write-Error "We cannot run a script from a Prod Active Directory domain [$Domain] to a non-production server [$Server], exiting script!"
        return $EC
    }
    else
    {
        Write-Host "Running script in Active Directory domain [$Domain] for server of type [$Platform]"
        return $EC
    }
}