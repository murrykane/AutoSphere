﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	1/9/2018
	 Updated on:	1/9/2018
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	Get-PAMServiceControl.psm1
 
	===========================================================================
	.DESCRIPTION
	    The module is for routine tasks against Services. It is written with the 
        intention to be used by many scripts and therefore if change is needed for
        how we want to manage services it is change here and all other scripts 
        will get that change.

Date:      Who:            Changes:
-----------------------------------
04/16/2018 Murry Kane      Made new args for 'stopped'/'running' for validating state of services (for Tidal Job)
                           Added new argument 'manual'/'disabled'/'automatic' to set the startup of the service

07/23/2018 Murry Kane      SetStartup type (manual/automatic/disabled) didn't work when they were disabled as they are 
                           not added to the array so you can set them back to manual - added logic to add to array
12/27/2018 Murry Kane      Modified the Write-Error to Write-Warning for when a stop timeout occurs as there is an 
                           attempt to kill the pid (stop-process) if it timesout, that will write-error if it fails
01/08/2019 Murry Kane      Removed logic to include disabled services when action was manual/automatic/disabled which 
                           means if we ever need to do anything with a disabled service it will not work with this module
#>
<# 
 .Synopsis
  This will control Service's on a given server

 .Description
  To control services on a server

 .Parameter 1 - ServiceInput
  The list of objects for services that you want to manage (Get-Service objects)

 .Parameter 2 - CHECK|STOP|START
  This determines if it CHECKS or STOP's or START's the given passed services

 .Parameter 3 - 300   (Optional PARM, default is 120)
  The Time to Wait (seconds) when stopping or starting services before moving onto next service

 .Parameter 4 - ServerName (Optional PARM, default is localhost)
  This is the server that the services will be checked,stopped,started 

 .Example
   # Check Services list on default server winf313p (localhost)
   PAM-ServiceControl -ServiceInput @('facets*','w3svc','adws') -Action check

 .Example
   # Start Services list on default server winf313p (localhost)
   Get-PAMServiceControl -ServiceInput @('facets*','w3svc','adws') -Action start

 .Example
   # Stop Services list on default server winf313p (localhost)
   Get-PAMServiceControl -ServiceInput @('facets*','w3svc','adws') -Action stop

 .Example
   # Start Services list on server wisl120p 
   Get-PAMServiceControl -ServiceInput @('facets*','w3svc','adws') -Action start -Server wisl120p

 .Example
   # Stop Services list on server wisl120p
   Get-PAMServiceControl -ServiceInput @('facets*','w3svc','adws') -Action stop -Server wisl120p

 .Example
   # Check Services list on server wisl120p
   Get-PAMServiceControl -ServiceInput @('facets*','w3svc','adws') -Action check -Server wisl120p
  
 .Example From a calling script importing the module and using one to many servers with New-PSSession

    $Servers = @('WISL117P','WISl118P')
    $ServicesToControl = @('facets*','W3SVC')

    #import the PAM Service Module
    import-module -name Get-PAMServiceControl.psm1 -Verbose -WarningAction SilentlyContinue

    Write-Host "Building PSSessions on [$Servers] Servers"
    $Session = New-PSSession -ComputerName $Servers -Verbose
    $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,'check',180 -AsJob

    #This will issue the function against both servers WISL117p and WISL118P as a job

#>

function Get-PAMServiceControl {
    param(
        [parameter(
            Position=0,
            Mandatory=$true
            #ValueFromPipeline=$true,
            #ValueFromPipelineByPropertyName=$true
            )] 
        [Object] $ServiceInput,
    
        [parameter(
            Position=1,
            Mandatory=$true
            #ValueFromPipeline=$true,
            #ValueFromPipelineByPropertyName=$true
            )]
        [string] $Action,
    
        [parameter(
            Position=2
        #    #Mandatory=$true
        #    #ValueFromPipeline=$true,
        #    #ValueFromPipelineByPropertyName=$true
            )]
            $SleepTime = 120,
    
        [parameter(
            Position=3       
        #    #Mandatory=$true
        #    #ValueFromPipeline=$true,
        #    #ValueFromPipelineByPropertyName=$true
            )]
            #$Server = $env:computername
            #$Server = Hostname
            $Server = (Get-WmiObject -Class Win32_ComputerSystem -Property Name).Name
    
        )
    
        
    
        $VerbosePreference = 'Continue'
        #$Server = $env:computername # since its now an optional parm to the module
    
        function Custom-GetDependServices ($Name, $ServerName) {
            #Write-Verbose "Server [$ServerName] Name of `$ServiceInput: [$($Name.Name)]"
            #Write-Verbose "Server [$ServerName] Number of dependents: [$($Name.DependentServices.Count)]"
            If ($Name.DependentServices.Count -gt 0)
            {
                #Write-Verbose "Server [$ServerName] Dependent Services are: [$($Name.DependentServices)]"
                ForEach ($DepService in $Name.DependentServices)
                {
                    #Write-Verbose "Server [$ServerName] Dependent of [$($Name.Name)]: is: [$($DepService.Name)]"
                    If ($DepService.Status -eq "Running")
                    {
                        #Write-Verbose "Server [$ServerName]  [$($DepService.Name)] is running."
                        $CurrentService = Get-Service -ComputerName $ServerName -Name $($DepService.Name)
                        #Write-Verbose "Server [$ServerName]  Dependent Service is: [$($CurrentService.Name)]"
                        # get dependancies of running service
                        Custom-GetDependServices -Name $CurrentService -ServerName $ServerName              
                    }
                    Else
                    {
                        #Write-Verbose "Server [$ServerName]  [$($DepService.Name)] is stopped."
                        $CurrentService = Get-Service -ComputerName $ServerName -Name $($DepService.Name)
                        #Write-Verbose "Server [$ServerName]  Dependent Service is [$($CurrentService.Name)]"
                        # get dependancies of running service
                        Custom-GetDependServices -Name $CurrentService -ServerName $ServerName 
                    }
                
                }
            }
            #lets determine if is disabled before adding to array!
            #MBK 01/08/2018 removed the second half of this logic...
            #if ((Get-WmiObject Win32_Service | Where-Object {$_.Name -like $name.Name}).StartMode -eq 'Disabled' -and -not ($Action -eq 'manual' -Or $Action -eq 'automatic' -Or $Action -eq 'disabled'))
            if ((Get-WmiObject Win32_Service | Where-Object {$_.Name -like $name.Name}).StartMode -eq 'Disabled')
            {
                Write-Verbose "Status is [UNKNOWN] on Server [$ServerName] for Service [$($name.Name)] which is Disabled, NOT adding to array!"
            }
            else
            {
                #Write-Verbose "Server [$ServerName]  Service is [$($Name.Name)]"
                if ($ServicesToAction.Contains($Name.Name) -eq $false)
                {
                    #Write-Verbose "Server [$ServerName]  Adding service to array as: [$($Name.Name)]"
                    $ServicesToAction.Add($name.Name) > $null
                }
            }
            return 
        }
    
        function Stop-ServiceWithTimeout ([string] $name, [string] $ServerName, [int] $timeoutSeconds) {
            $timespan = New-Object -TypeName System.Timespan -ArgumentList 0,0,$timeoutSeconds
            $svc = Get-Service -ComputerName $ServerName -Name $name
            if ($svc -eq $null) 
            {
                Write-Warning "Server [$ServerName] for Service [$name] is NULL for finding the service!" 
                return $false 
            }
            if ($svc.Status -eq [ServiceProcess.ServiceControllerStatus]::Stopped) { 
                Write-Verbose "Service [$($svc.name)] on Server [$ServerName] is already stopped, no need to stop it!" 
                return $true 
            }
            Write-Verbose "Attempting stop of Service [$($svc.Name)] on server [$ServerName]" 
            try
            {
                $svc.Stop()
                $svc.WaitForStatus([ServiceProcess.ServiceControllerStatus]::Stopped, $timespan)
            }
            catch [ServiceProcess.TimeoutException] {
                #Write-Error "Timeout stopping service [$($svc.Name)] on server [$ServerName]"
                Write-Warning "Timeout stopping service [$($svc.Name)] on server [$ServerName]"
                return $false
            }
            catch 
            {
                $ErrorMessage = $_.Exception.Message
                Write-Warning "Failed to stop service [$($svc.Name)] on server [$ServerName] with message: [$ErrorMessage]"
                return $false
            }
            return $true
        }
    
        function Start-ServiceWithTimeout ([string] $name, [string] $ServerName, [int] $timeoutSeconds) {
            #Write-Verbose "Entering Start-Service with Timeout..."
            $timespan = New-Object -TypeName System.Timespan -ArgumentList 0,0,$timeoutSeconds
            $svc = Get-Service -ComputerName $ServerName -Name $name
            if ($svc -eq $null) { 
                Write-Warning "Server [$ServerName] for Service [$name] is NULL for finding the service!"
                return $false 
            }
            if ($svc.Status -eq [ServiceProcess.ServiceControllerStatus]::Running) { 
                Write-Verbose "Service [$($svc.name)] on Server [$ServerName] is already running, no need to start it!" 
                return $true 
            }
            Write-Verbose "Attempting start of Service [$($svc.Name)] on server [$ServerName]"
            try 
            {
                $svc.Start()
                $svc.WaitForStatus([ServiceProcess.ServiceControllerStatus]::Running, $timespan)
            }
            catch [ServiceProcess.TimeoutException] 
            {
                write-error "Timeout starting service [$($svc.Name)] on server [$ServerName]"
                return $false
            }
            catch 
            {
                $ErrorMessage = $_.Exception.Message
                Write-Error "Failed to start service [$($svc.Name)] on server [$ServerName] with message: [$ErrorMessage]"
                return $false
            }
            return $true
        }
    
        function kill-ServicePID ( [string] $name, [string] $ServerName ) {
            
            $Service = Get-Service -ComputerName $ServerName -Name $name
    
            Write-Verbose "Working on server: [$ServerName] for Service [$name] to get the PID of the service"
            #need method to kill process id
            $servicePID = (Get-WMIObject Win32_Service -ComputerName $server | Where-Object{$_.name -eq $($Service.Name)}).ProcessID
            if([string]::IsNullOrEmpty($servicePID)) 
            {
                Write-Warning "We could not find the PID for the service in qustion on the remote Filenet Server... did it die on its own???" -ForegroundColor Yellow
                #since its not running return true
                return $true
            }
            else
            {
                try{
                    #lets kill it...
                    Write-Verbose "Attempting to kill service process PID of [$servicePID] on Server [$ServerName] for Service [$name]"
                    if ($ServerName -eq (Get-WmiObject -Class Win32_ComputerSystem -Property Name).Name)
                    {
                        Write-Verbose "Server: [$ServerName] for Service [$name] Running on localhost"
                        #$RC = Invoke-Command -ComputerName localhost { Stop-Process -Id $args[0] -Force -PassThru } -ArgumentList $servicePID
                        Stop-Process -Id $servicePID -Force -PassThru
                    }
                    else
                    {
                        Write-Verbose "Server: [$ServerName] for Service [$name] NOT Running on localhost"
                        Invoke-Command -ComputerName $ServerName { Stop-Process -Id $args[0] -Force -PassThru } -ArgumentList $servicePID
                    }
                    <#
                    Write-Verbose "Complete with the kill process"
                    #Start-Sleep -Seconds 3
                    if ($RC){
                        Write-Verbose "Complete with the kill process"
                    }
                    else{
                        Write-Error "ERROR: FAILED to KILL PID [$servicePID] for the given Service [$name] on server: [$ServerName]"
                        return $false
                    }
                    #>
                }
                catch {
                    $ErrorMessage = $_.Exception.Message
                    $FailedItem = $_.Exception.ItemName
                    Write-Error "Failed to KILL PID [$servicePID] on Server [$ServerName] for the given Service [$name] with item [$FailedItem] with: [$ErrorMessage]"
                    return $false
                }
            }
            return $true
    
        }
           
        function Check-Service ([string] $name, [string] $ServerName) {
            #Write-Verbose "Entering Check-Service with Timeout..."
            #$timespan = New-Object -TypeName System.Timespan -ArgumentList 0,0,$timeoutSeconds
            $svc = Get-Service -ComputerName $ServerName -Name $name
            if ($svc -eq $null) { 
                Write-Warning "Server [$ServerName] for Service [$name] is NULL for Checking the service!"
                return $false 
            }
            $svcStatus = $svc.Status
    
            #Write-Verbose "Service [$($svc.name)] on Server [$ServerName] status is [$svcStatus]" 
            Write-Verbose "Status is [$svcStatus] on Server [$ServerName] for Service [$($svc.name)]" 
            return $true
        }
    
        function Validate-Service ([string] $name, [string] $ServerName, [string] $State) {
            #Write-Verbose "Entering Check-Service with Timeout..."
            #$timespan = New-Object -TypeName System.Timespan -ArgumentList 0,0,$timeoutSeconds
            $svc = Get-Service -ComputerName $ServerName -Name $name
            if ($svc -eq $null) { 
                Write-Warning "Server [$ServerName] for Service [$name] is NULL for Checking the service!"
                return $false 
            }
            $svcStatus = $svc.Status
    
            #Write-Verbose "Service [$($svc.name)] on Server [$ServerName] status is [$svcStatus]" 
            Write-Verbose "Status is [$svcStatus] on Server [$ServerName] for Service [$($svc.name)]" 
            if ($svc.Status -eq [ServiceProcess.ServiceControllerStatus]::$State) { 
                return $true
            }
            else
            {
                Write-Error "Status is [$svcStatus] on Server [$ServerName] for Service [$($svc.name)] WHICH IS NOT CORRECT!" 
                return $false
            }
        }
    
        function setStartupType ([string] $name, [string] $ServerName, [string] $State) {
    
            #Write-Verbose "Entering set Service Startup Type... with Name [$svc] ServerName [$ServerName] and State [$state]"
    
            $svcName = Get-Service -ComputerName $ServerName -Name $name
            if ($svcName -eq $null) { 
                Write-Warning "Server [$ServerName] for Service [$name] is NULL for setting the startup type!"
                return $false 
            }
            Write-Verbose "Setting startup type [$state] on server [$ServerName] for Service [$($svcName.Name)]"
            $svcName | Set-Service -StartupType $State
            return $true
    
        }
    
    
        $ValidStatus = @("Check", "Stop", "Start", "running", "stopped", "manual", "automatic", "disabled")
        if ($ValidStatus -Contains $Action) {
            Write-Output "Performing Action [$Action] which is a valid Action"
        }
        else {
            Write-Error "Invalid Action passed to Module!"
            return
        }
    
        #Lets Get the Services now
        # first see if local host is passed host if not use the -Server option if the array is size of 1 (one server....)
        #if($env:computername -eq $Server)
        if($Server -eq (Get-WmiObject -Class Win32_ComputerSystem -Property Name).Name)
        {
            Write-Output "Server: [$Server] for Service [$ServiceInput] Server Passed to Module is LOCALHOST" 
            $ServiceObjects = Get-Service -Name $ServiceInput -ErrorAction 'silentlycontinue'
        }
        else
        {
            if($($Server.count) -eq 1)
            {
                Write-Output "Server: [$Server] for Service [$ServiceInput] Server Passed to Module is a Single Server and not LOCALHOST"
                $ServiceObjects = Get-Service -Name $ServiceInput -ComputerName $Server -ErrorAction 'silentlycontinue'
            }
            else
            { 
                Write-Warning "Server: [$Server] for Service [$ServiceInput] Server Passed is an Array of more than 1, bad things will happen!"
                #$ServiceObjects = Get-Service -Name $ServiceInput -ErrorAction 'silentlycontinue'
                return
            }
        }
    
        Write-Output "Server Name is: [$Server] String Objects to find [$ServiceInput] Sleep Time is [$SleepTime]"
        Write-Output "For Server [$Server] Action [$Action] Found Service's:"
        Write-Output "############################################"
        foreach($theService in $ServiceObjects)
        {
            Write-Output "     - [$($theService.Name)]"
        }
        Write-Output "############################################"
    
        if ( ($($ServiceObjects.Count) -lt 1) -and ([string]::IsNullOrEmpty($ServiceObjects)))
        {
            Write-Warning "[$Server] Services found to manage is 0 for Action [$Action] Input Services [$ServiceInput]!"
            Write-Output "Service Objects count [$($ServerObjects.Count)] with: [$ServiceInput]"
            return
        }
        else
        {
            Write-Output "Count of services is [$($ServiceObjects.Count)]"
        }
    
        $ServiceObjects | ForEach-Object {
            [System.Collections.ArrayList]$ServicesToAction = @()
            $theService = $_
            Write-Output "Working on Service [$($theService.Name)]"
            Custom-GetDependServices -Name $theService -ServerName $Server
            if ( $Action -eq 'start')
            {
                #reverse them to start them....
                $ServicesToAction.Reverse()
            }
    
            Write-Output "Size of Service Array is $($ServicesToAction.Count) "
            if ( $($ServicesToAction.Count) -lt 1 )
            {
                Write-Output "WARNING: [$Server] Services found to manage is 0 for Action [$Action] for Service [$($theService.Name)]"
                # continue #BAD don't use continue!
            }
            else
            {
                foreach($ServiceToAction in $ServicesToAction)
                {
                    Write-Output "For [$Server] Service [$ServiceToAction] Action [$Action]"
            
                    if ( $Action -eq 'start') 
                    { 
                        $RC = Start-ServiceWithTimeout -name $ServiceToAction -ServerName $Server -timeoutSeconds $SleepTime
                    }
                    if ( $Action -eq 'stop') 
                    { 
                        $RC = Stop-ServiceWithTimeout -name $ServiceToAction -ServerName $Server -timeoutSeconds $SleepTime
                    }
                    if ( $Action -eq 'check') 
                    { 
                        $RC = Check-Service -name $ServiceToAction -ServerName $Server 
                    }
                    if ( $Action -eq 'stopped') 
                    { 
                        #write-Output "Running special STOPPED version....."
                        $RC = Validate-Service -name $ServiceToAction -ServerName $Server -State $Action
                    }
                    if ( $Action -eq 'running') 
                    { 
                        #write-Output "Running special RUNNING version....."
                        $RC = Validate-Service -name $ServiceToAction -ServerName $Server -State $Action
                    }
                    if ($Action -eq 'manual' -Or $Action -eq 'automatic' -Or $Action -eq 'disabled' )
                    {
                        write-output "Running set startup type on services...."
                        $RC = setStartupType -name $ServiceToAction -ServerName $Server -State $Action
                    }
                      
                    # lets check the results....
                    if ($RC)
                    {
                        Write-Output "Performed Successfull Action [$Action] on service: [$ServiceToAction] on Server [$Server]"
                    }
                    else
                    {
                        Write-Warning "Failed to Action [$Action] on the service: [$ServiceToAction] on Server [$Server]!" 
                        if ( $Action -eq 'stop') {
                            Write-Output "Attempting KILL of the service PID"
                            $RC = kill-ServicePID -name $ServiceToAction -ServerName $Server
                            if ($RC)
                            {
                                Write-Output "Performed Successfull KILL on service: [$ServiceToAction] on Server [$Server]"
    
                            }
                            else
                            {
                                Write-Error "FAILED: To KILL Service: [$ServiceToAction] on Server [$Server]"
                            }
                        }
                    }
            
                 }  
             }      
        }
    
        return
    
     }