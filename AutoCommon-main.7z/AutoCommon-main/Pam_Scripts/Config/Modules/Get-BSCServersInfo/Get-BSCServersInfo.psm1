<#	
	.NOTES
	===========================================================================
	 Created on:   	12/09/2018 
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	Get-BSCServersInfo.psm1

	The Functions in this module are designed to provide Server groupings for automated 
	Functions within IT-PAM and NPA (Non-Production Applications).
	The Module is designed to work from a Management Server that has access to perform
	Remote Administration on Servers Returned
	===========================================================================
	.DESCRIPTION
		This script returns a list of servers matching specific criteria.
        This script returns a list of services for the same given servers
        This script returns Citrix Icon information for a given environment
        This script returns NPE/STAGE/PROD for a given environment
#>
<#


Modifications:

12/05/2018  Murry Kane   - Modified for new attributes in file (Citrix Icon, NPE/Prod etc)
                           Used environment variables instead of hard-coding directories

Examples:

import-module Get-BSCServersInfo

$GetAll = get-bscserversinfo -Environment FACN32 -WhichProperty App -PropValue FACETS -ColumnReturn all
$Servers = get-bscserversinfo -Environment FACN32 -WhichProperty App -PropValue FACETS -ColumnReturn ServerName
$Servers = get-bscserversinfo -Environment FACN32 -WhichProperty Role -PropValue IIS -ColumnReturn ServerName
$Platform = get-bscserversinfo -Environment FACN32 -WhichProperty Role -PropValue IIS -ColumnReturn Platform
$CitrixIcon = get-bscserversinfo -Environment FACN32 -WhichProperty Role -PropValue IIS -ColumnReturn CitrixIcon
$Servers = get-bscserversinfo -Environment FACP02 -Platform NPE -WhichProperty App -PropValue islcws,cws,HIPAA -ColumnReturn ServerName -EnvList 'D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\Config\EnvironmentLists\EnvList2.csv'

#>

#Set Global Variables common to each Function. This function is internal to the module.
Function Set-GlobalVar
{

    [CmdletBinding()]
	Param
	(
		[Parameter()][string]$EnvList
	)
    
    #Write-host "Envlist is $EnvList"

    $PAM_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts'

    if (-not ([string]::IsNullOrEmpty($EnvList)))
    {
        #$EnvList=$EnvList
        Write-Verbose "Using ENVLIST Passed with [$EnvList]"
    }
    else
    {
        if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_ENVLIST).PAM_ENVLIST)))
        {
            $EnvList=(Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_ENVLIST).PAM_ENVLIST
        }
        else
        {
            if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME)))
            {
                $EnvList=(Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME + "\Config\EnvironmentLists\EnvList.csv"
            }
            else
            {
                $EnvList = $PAM_HOME_DIR_DEFAULT + "\Config\EnvironmentLists\EnvList.csv"
            }
        }
    }

}

function get-BSCServersInfo
{
	[CmdletBinding()]
	Param
	(
		[Parameter()][string[]]$Environment = "$__DefaultFacetsEnv",
        [Parameter()][string[]]$SuperRole = "$__DefaultSuperRole",
        [Parameter()][string[]]$Role = "$__DefaultRole",
        [Parameter()][string[]]$App = "$__DefaultApp",
        [Parameter()][string[]]$Component = "$__DefaultComponent",
        [Parameter()][string[]]$MQClient = "$__DefaultMQClient",
        [Parameter()][string[]]$Database = "$__DefaultDatabase",
        [Parameter()][string[]]$Tidal = "$__DefaultTidal",
        [Parameter()][string[]]$Platform = "$__DefaultPlatform",
		[Parameter(Mandatory, ParameterSetName = 'ByProperty')][String]$WhichProperty,
		[Parameter(Mandatory, ParameterSetName = 'ByProperty')][String[]]$PropValue,
        [Parameter(Mandatory, ParameterSetName = 'ByProperty')][String]$ColumnReturn,
        [Parameter()][string]$EnvList

	)
	

<#
	Set Constants
#>
	#$VerbosePreference = 'SilentlyContinue'
    #$DebugPreference = 'SilentlyContinue'
    #$VerbosePreference = 'Continue'
    #DebugPreference = 'Continue'

    $theFilter = ""

	. Set-GlobalVar "$EnvList"

	
	if ((Test-Path $EnvList) -eq $false)
	{
		Write-Verbose "$EnvList does not exist"
		Write-Error -Message "$EnvList does not exist"
		throw "Could Not Complete Operation"
	}
	
	$Servers = @()
    $FilterCSV = @()
    $All_Info = Import-Csv $EnvList

    #Write-Host "CSV file is $EnvList"
    # EnvList filters
	If ($Environment -ne "__Default")
	{
        Write-Verbose "filtering by Enviornment"
        #if more than one environment is sent in...
        foreach ($Value in $Environment)
	    {
            Write-Verbose "Working on Enviornment value [$Value]"
            if($FilterCSV.Count -le 0)
            {
                Write-Verbose "filter is empty starting it..."
                $FilterCSV += $All_Info | Where-object { $_.'EnvName' -eq $Value }               
            }
            else
            {
                Write-Verbose "filter is not empty, appending too it"
                $FilterCSV += $All_Info | Where-object { $_.'EnvName' -eq $Value }
            }
        }
	}

    #Filter by Platform (PROD/NPE/STAGE)
    if ($Platform -ne "__Default" )
    {
        Write-Verbose "filtering by Platform"
        foreach($Value in $Platform)
        {
            if($FilterCSV.Count -le 0)
            {
                Write-Verbose "filter is empty starting it..."
                $FilterCSV = $All_Info | Where-object { $_.'Platform' -eq $Value }               
            }
            else
            {
                Write-Verbose "filter is not empty, appending too it"
                $FilterCSV = $FilterCSV | Where-object { $_.'Platform' -eq $Value }
            }
        }
    }

    #Filter by SuperRole
    if ($SuperRole -ne "__Default" )
    {
        Write-Verbose "filtering by SuperRole"
        foreach($Value in $SuperRole)
        {
            if($FilterCSV.Count -le 0)
            {
                Write-Verbose "filter is empty starting it..."
                $FilterCSV = $All_Info | Where-object { $_.'SuperRole' -eq $Value }               
            }
            else
            {
                Write-Verbose "filter is not empty, appending too it"
                $FilterCSV = $FilterCSV | Where-object { $_.'SuperRole' -eq $Value }
            }
        }
    }

    #Filter by Column Role
    if ($Role -ne "__Default" )
    {
        Write-Verbose "filtering by Role"
        foreach($Value in $Role)
        {
            if($FilterCSV.Count -le 0)
            {
                Write-Verbose "filter is empty starting it..."
                $FilterCSV = $All_Info | Where-object { $_.'Role' -eq $Value }               
            }
            else
            {
                Write-Verbose "filter is not empty, appending too it"
                $FilterCSV = $FilterCSV | Where-object { $_.'Role' -eq $Value }
            }
        }
    }

    #Filter by App
    if ($App -ne "__Default" )
    {
        Write-Verbose "filtering by App"
        foreach($Value in $App)
        {
            if($FilterCSV.Count -le 0)
            {
                Write-Verbose "filter is empty starting it..."
                $FilterCSV = $All_Info | Where-object { $_.'App' -eq $Value }               
            }
            else
            {
                Write-Verbose "filter is not empty, appending too it"
                $FilterCSV = $FilterCSV | Where-object { $_.'App' -eq $Value }
            }
        }
    }

    #Filter by Component
    if ($Component -ne "__Default" )
    {
        Write-Verbose "filtering by Component"
        foreach($Value in $Component)
        {
            if($FilterCSV.Count -le 0)
            {
                Write-Verbose "filter is empty starting it..."
                $FilterCSV = $All_Info | Where-object { $_.'Component' -eq $Value }               
            }
            else
            {
                Write-Verbose "filter is not empty, appending too it"
                $FilterCSV = $FilterCSV | Where-object { $_.'Component' -eq $Value }
            }
        }
    }

    #Filter by MQClient
    if ($MQClient -ne "__Default" )
    {
        Write-Verbose "filtering by MQClient"
        foreach($Value in $MQClient)
        {
            if($FilterCSV.Count -le 0)
            {
                Write-Verbose "filter is empty starting it..."
                $FilterCSV = $All_Info | Where-object { $_.'MQClient' -eq $Value }               
            }
            else
            {
                Write-Verbose "filter is not empty, appending too it"
                $FilterCSV = $FilterCSV | Where-object { $_.'MQClient' -eq $Value }
            }
        }
    }
   
    
    #Filter by Database
    if ($Database -ne "__Default" )
    {
        Write-Verbose "filtering by Database"
        foreach($Value in $Database)
        {
            if($FilterCSV.Count -le 0)
            {
                Write-Verbose "filter is empty starting it..."
                $FilterCSV = $All_Info | Where-object { $_.'Database' -eq $Value }               
            }
            else
            {
                Write-Verbose "filter is not empty, appending too it"
                $FilterCSV = $FilterCSV | Where-object { $_.'Database' -eq $Value }
            }
        }
    }

	

    #filter by prop values passed in (can be an array)
	foreach ($Value in $PropValue)
	{
		
        #lets get it now
        if($FilterCSV.Count -le 0)
        {
            Write-Verbose "Filter string is empty, using only column passed...."
            $T_Servers = $All_Info  | Where-Object { $_.$WhichProperty -eq "$Value" }
        }
        else
        {
            Write-Verbose "Filter is [$Value]"
            $T_Servers = $FilterCSV  | Where-Object { $_.$WhichProperty -eq "$Value" }
        }
        
		$Props = Get-BSCProperty -EnvList $EnvList

        #make sure the passed returncolumn exists in csv!
        $Flag=$false
        foreach ($Name in $Props)
        {
            Write-Verbose "Name is $Name"
            $Value = $Name.Name
            Write-Verbose "Value is $Value"
            if ( $Value -eq $ColumnReturn )
            {
                Write-Verbose " Its equal....."
                $Flag=$true
            }

        }
        if($ColumnReturn -eq "all")
        {
            $Flag=$true
        }

        if($Flag)
        {
            Write-Verbose "we are good...."
        }
        else
        {
            Write-Error "Passed value $ColumnReturn NOT FOUND!"
            throw "Could Not Complete Operation"
        }


		foreach ($Server in $T_Servers)
		{
		
			
			Write-Verbose "Starting $SNAME"
			
			$Config_Object = $null
			$Config_Object = New-Object System.Object
			foreach ($Name in $Props)
			{
				$Value= $Name.name
                #only add value if its not empty!
                Write-Verbose "Value is $Value and Server.Value $Server.$value"
				$Config_Object | Add-Member -Type 'NoteProperty' -Name $value -Value $Server.$value
			}
			
			
			$Servers += $Config_Object
		}
	}
	
    if($ColumnReturn -eq "all")
    {
		return ($Servers)
    }
    else
    {
		$SList = @()
		foreach ($Item in $Servers)
		{
			$Value = $Item.$ColumnReturn
            if(-not ([string]::IsNullOrEmpty($value)))
            {
                if($SList -contains $Value)
                {
                    Write-Verbose "its already in list..... value $Value"
                }
                else
                {
                    $SList += $Value
                }
            }
            else
            {
                Write-Verbose "Not adding null value"
            }
		}
		Return ($SList)            
    }	
}

function Get-BSCProperty
{
	[CmdletBinding()]
	Param
	(
		[Parameter()][string]$EnvList
	)
	
	import-csv $EnvList | Get-Member -MemberType NoteProperty
}
