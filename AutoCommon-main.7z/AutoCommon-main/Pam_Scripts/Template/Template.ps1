﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	07/26/2019
	 Updated on:	07/26/2018
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	Template.ps1

	The scripts being built in this grouping are for Production Support
	The majority will be run from the Primary Jump/Management Server, WINF313P or WINF4028p. 
    However, it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script is a template for building any other script, it has the base setup that
        should be common to all scripts.


Date:      Who:            Changes:
-----------------------------------
01/08/2019 Murry Kane      Initial
07/30/2019 Kyle Parrott    Added scriptStartup

    Example

    ./{Directory}\Template.ps1 -Environment FACN52 
#>

[CmdletBinding()]
Param(
    # Modify Input parameters as needed....
    #[Parameter(Mandatory=$True,Position=1)]
    [string[]]$Environment,
    [string[]]$Roles,
    [string]$PuppetEnv
	
)

try
{
    # Import functions
    Import-Module Functions -Force

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Set some basic variables
    $exit_code = 0
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    $currentScriptName = $MyInvocation.MyCommand.Name
    $ISE, $LOG_FILE, $PAM_HOME = scriptStartup

    Write-Host "Script name is: $currentScriptName"

    # Modify Input parameters as needed....
    if ($ISE) {
        # Get the required input if not supplied when running from ISE
        if(-not($Environment)) {
            $Environment = @()
            do 
            {
                $input = (Read-Host "Input your Environment (FACP02, FACN32, FACN31): ")
                if ($input -ne '') {$Environment += $input}
            }
            until ($input -eq '')
        }
        if(-not($Roles)) {
            $Roles = @()
            do 
            {
                $input = (Read-Host "Input your Role (ISL, HIPAA, BATCH, etc): ")
                if ($input -ne '') {$Roles += $input}
            }
            until ($input -eq '')
        }
        if(-not($PuppetEnv)) {
            do
            {
                $PuppetEnv = (Read-Host "Input your Puppet Environment to use (facets_cp, etc): ")
            }
            until ($PuppetEnv -ne '')
        }
    }


    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Validate inputs
    if (-not($Environment)) 
    {
        $exit_code = 32
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    if (-not($Roles))
    {
        $exit_code = 33
        Write-Error "Maintenance Type is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    if (-not($PuppetEnv))
    {
        $exit_code = 34
        Write-Error "Puppet Environment is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    # Output some information....
    Write-Host "Log File is $LOG_FILE"
    Write-Host "Environment is [$Environment]"
    Write-Host "PAM HOME Directory is $PAM_HOME"
    Write-Host "Roles are [$Roles]"
    Write-Host "Puppet Environment is [$PuppetEnv]"

    # ALL the main code should go below here 
    ########################################

    # end main code#########################


}
catch
{
    #$FailedItem = $_.Exception.ItemName
    #$ErrorMessage = $_.Exception.Message
    Write-Error $_.Exception.ToString();
    $exit_code = 99
}

finally
{

    # Cleanup
    Remove-Module -Name Get-BSCServersInfo
    Remove-Module -Name Get-PAMServiceControl
    Remove-Module -Name Functions

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}