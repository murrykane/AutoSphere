﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	12/07/2021
	 Updated on:	12/07/2021
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	Verint_Services_Control.ps1

	The scripts being built in this grouping are for PAM/SRE Production Support
	The majority will be run from the Primary PAM/SRE Server, WINF4594P/etc. However,
	it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script Starts controls Verint Application - stop/start/validate

MODIFICATIONS
_____________________________________________________________________________________________________________________________
    Date       By            Reason
    12/07/2021 Murry Kane    Initial
    Example

    ./{PATH}\Verint_Services_Control.ps1 -Environment VERINTP01,VERINTH01 -Action start/stop/running/stopped
    ./{PATH}\Verint_Services_Control.ps1 -Environment VERINTH01 -Action stop

#>

[CmdletBinding()]
Param(
   #[Parameter(Mandatory=$True,Position=1)]
   [string[]]$Environment,
   [string]$Action,
   [Parameter(Mandatory=$False, Position=2)][switch]$uselocaldomain
)

$LOG_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\Logs'
$PAM_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts'
$exit_code = 0
$currentScriptName = $MyInvocation.MyCommand.Name
$filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
# turn off verbose
$VerbosePreference = 'SilentlyContinue'
$Domain = (Get-ChildItem Env:'USERDOMAIN' -ErrorAction Ignore).Value
$ACTIONS = 'stop','start','restart','stopped','running'

function Get-ServerList {
    try {

        #lets see if we we are going against production or 2015 CMDB
        $SnowCred = ''
        $UriBase = ''

        if(-not $uselocaldomain)
        {
            $SNowCred = Get-ServiceNowCredential
            $UriBase = Get-ServiceNowUriBase
        }
        else
        {
            Write-Host "-UseLocalDomain option passed to script, using local domain to determine which ServiceNow Instance to connect with"
            $SNowCred = Get-ServiceNowCredential -uselocaldomain
            $UriBase = Get-ServiceNowUriBase -uselocaldomain                
        }

        if([string]::IsNullOrWhiteSpace($SNowCred) -or [string]::IsNullOrWhiteSpace($UriBase))
        {
            $exit_code = 4
            Write-Warning "We could not get credentials to make the REST call to ServiceNow" 
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }
        else
        {
            Write-Host "URI Base $UriBase"
        }

        # Query Server to App Relationship Table
        Write-Host "Querying ServiceNow API for getting the application server(s)"
        $Uri = "$UriBase/api/now/table/cmdb_rel_ci?sysparm_query=child.nameSTARTSWITHVerint%5Eparent.name%3D$CMDBEnvironment%5Eparent.install_status%3D11%5Echild.install_status%3D11%5Eparent.sys_class_name%3Dcmdb_ci_appl%5Echild.sys_class_name%3Dcmdb_ci_app_server%5Echild.nameLIKEApp%20Server&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=child&sysparm_limit=1000"
        Write-Host "Using URI [$Uri]"

        $Result = Query-ServiceNowApi -Uri $Uri -SNowCred $SNowCred
        Write-Host "Result is " + $result   

        $PrimaryServer = @()
        $Servers = @()
        $result | ForEach-Object -Process {
            $cmdb_start = (($_).child -split "@")[0]
            $cmdb_end = (($_).child -split "@")[1]
            #Write-Host "Start value $cmdb_start and end value $cmdb_end"
            if($cmdb_start -match "primary")
            {
                #Write-Host "match on primary"
                $PrimaryServer += $cmdb_end
            }
            else
            {
                #Write-Host "no match"
                $servers += $cmdb_end
            }
        }

        return $PrimaryServer,$servers
    }
    catch {
        return $null
    }
}

function Start-App {
    param
    (
        [parameter(ValueFromPipeline=$true)]$PrimaryServer,
        [parameter(ValueFromPipeline=$true)]$AppServers,
        [parameter(ValueFromPipeline=$true)]$action,
        [parameter(ValueFromPipeline=$true)]$AllServices,
        [parameter(ValueFromPipeline=$true)]$PrimaryService,
        [parameter(ValueFromPipeline=$true)]$WatchDogService,
        [parameter(ValueFromPipeline=$true)]$environment,
        [parameter(ValueFromPipeline=$true)]$Domain,
        [parameter(ValueFromPipeline=$true)]$ISE
    )

    $exit_code = 0

    #first start main process
    if($PrimaryServer.count -gt 0)
    {
        $result = Get-ActionToPerform -servers $PrimaryServer -action $Action -ServicesToControl $PrimaryService -environment $Environment -Domain $Domain -ISE $ISE 
        if ($result)
        {
            Write-Host "Completed [$Action] for Verint Primary Application service"
        }
        else
        {
            #Write-Error "Failures duing Validation Checks"
            $exit_code = 28
            return $exit_code
        }
        #need to sleep 2 minutes
        Write-Host "Sleeping for 1 minute before checking Web Site"
        Start-Sleep -Seconds 60   
        #need to validate URL....
        $result = checkWebSite -PrimaryServer $PrimaryServer
        if($result -gt 0)
        {
            $exit_code = $result
            Write-Warning "We could not Connect to the website for Verint Application, exiting!"
            return $exit_code
        }
        #need to start the rest on all servers
        $theServers = $PrimaryServer + $AppServers
        $result = Get-ActionToPerform -servers $theServers -action $Action -servicesToControl $AllServices -environment $Environment -Domain $Domain -ISE $ISE 
        if ($result)
        {
            Write-Host "Completed [$Action] for Verint Application"
        }
        else
        {
            #Write-Error "Failures duing Validation Checks"
            $exit_code = 28
            return $exit_code
        }
    }

}

function Stop-App {
    param
    (
        [parameter(ValueFromPipeline=$true)]$AppServers,
        [parameter(ValueFromPipeline=$true)]$PrimaryServer,
        [parameter(ValueFromPipeline=$true)]$action,
        [parameter(ValueFromPipeline=$true)]$Allservices,
        [parameter(ValueFromPipeline=$true)]$Primaryservice,
        [parameter(ValueFromPipeline=$true)]$WatchDogservice,
        [parameter(ValueFromPipeline=$true)]$AllButPrimaryServices,
        [parameter(ValueFromPipeline=$true)]$environment,
        [parameter(ValueFromPipeline=$true)]$Domain,
        [parameter(ValueFromPipeline=$true)]$ISE
    )

    $exit_code = 0
    $error_count = 0

    #1st we will stop non-primarys
    if($AppServers.count -gt 0)
    {
        #watchdog service only first
        $result = Get-ActionToPerform -servers $AppServers -action $Action -servicesToControl $WatchDogService -environment $Environment -Domain $Domain -ISE $ISE 
        if ($result)
        {
            Write-Host "Completed [$Action] for Verint WatchDog Instances for services [$WatchDogService]"
        }
        else
        {
            Write-Warning "Failures duing attempted stop for service [$WatchDogService]"
        }
        #now all but primary service
        $result = Get-ActionToPerform -servers $AppServers -action $Action -servicesToControl $AllButPrimaryServices -environment $Environment -Domain $Domain -ISE $ISE 
        if ($result)
        {
            Write-Host "Completed [$Action] for Verint Application All but Primary for Services [$AllButPrimaryServices]"
        }
        else
        {
            Write-Warning "Failures duing attempted stop for services [$AllButPrimaryService]"
        }

        #now all services if there...
        $result = Get-ActionToPerform -servers $AppServers -action $Action -servicesToControl $AllServices -environment $Environment -Domain $Domain -ISE $ISE 
        if ($result)
        {
            Write-Host "Completed [$Action] for Verint Application All Instances for service [$WatchDogService]"
        }
        else
        {
            Write-Warning "Failures duing attempted stop for services [$AllServices]"
            $error_count += 1
        }

        Write-Host "Attempting to stop any lefover processes on non-primary Application instances"
        #get connection to servers
        $Session = New-PSSession -ComputerName $AppServers -Verbose
        #clean up processes left....
        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::stopProcesses} -AsJob
        $mc2 = checkRemoteJobAndLog -Session $Session -Jobs $Jobs
        $MCCount = $($mc2).Count
        $ProcCnt = $MCCount -2
        Write-Host "Stop process removed [$ProcCnt] proceses from all servers"
        #MBK subtract 1 for array position
        $MCCount = $MCCount -1 
        $MCode2 = $($mc2)[$MCCount]
        if ($MCode2 -ne 0)
        {
            Write-WARNING "WARNING: Failures during Process Stop for Verint.... RC = $MCode2"
            $exit_code = 33
            return $exit_code
        }
        else
        {
            Write-Host "All good on job(s) Process Stop... RC = $MCode2"
        }

        #now if there was a failure before lets try and stop 1 more time...
        if($error_count -gt 0)
        {
            Write-Host "Attempting last stop action since there was a failure on previous attempts..."
            $result = Get-ActionToPerform -servers $AppServers -action $Action -servicesToControl $AllServices -environment $Environment -Domain $Domain -ISE $ISE 
            if ($result)
            {
                Write-Host "Completed [$Action] for Verint Application All Instances for service [$AllServices]"
            }
            else
            {
                Write-Warning "Failures duing attempted stop for services [$AllServices]"
                $exit_code = 23
                return $exit_code
            }
        }
    }

    #reset counter...
    $error_count = 0

    #next do primary (this should be the last server to do)
    if($PrimaryServer.count -gt 0)
    {
        #watchdog first
        $result = Get-ActionToPerform -servers $PrimaryServer -action $Action -ServicesToControl $WatchDogService -environment $Environment -Domain $Domain -ISE $ISE 
        if ($result)
        {
            Write-Host "Completed [$Action] for Verint Primary Application for services [$WatchDogService]"
        }
        else
        {
            Write-Warning "Failures duing attempted stop for service [$WatchDogService]"
        }
        #now all but primary
        $result = Get-ActionToPerform -servers $PrimaryServer -action $action -ServicesToControl $AllButPrimaryServices -environment $environment -Domain $Domain -ISE $ISE
        if ($result)
        {
            Write-Host "Completed [$Action] for Verint Primary Application for Services [$AllButPrimaryServices]"
        }
        else
        {
            Write-Warning "Failures duing attempted Primary stop for services [$AllButPrimaryServices]"
        }
        
        #now just the primary
        $result = Get-ActionToPerform -servers $PrimaryServer -action $Action -ServicesToControl $AllServices -environment $Environment -Domain $Domain -ISE $ISE 
        if ($result)
        {
            Write-Host "Completed [$Action] for Verint Primary Application for Services [$AllServices]"
        }
        else
        {
            Write-Host "Failures duing attempted Primary stop for services [$AllServices]"
            $error_count += 1
        }
        

        Write-Host "Attempting to stop any lefover processes on Primary Application instances"
        #get connection to servers
        $Session = New-PSSession -ComputerName $PrimaryServer -Verbose
        #clean up processes left....
        $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::stopProcesses} -AsJob
        $mc2 = checkRemoteJobAndLog -Session $Session -Jobs $Jobs
        $MCCount = $($mc2).Count
        $ProcCnt = $MCCount -2
        Write-Host "Stop process removed [$ProcCnt] proceses from all servers"
        #MBK subtract 1 for array position
        $MCCount = $MCCount -1 
        $MCode2 = $($mc2)[$MCCount]
        if ($MCode2 -ne 0)
        {
            Write-WARNING "WARNING: Failures during Process Stop for Verint.... RC = $MCode2"
            $exit_code = 34
            return $exit_code
        }
        else
        {
            Write-Host "All good on job(s) Process Stop... RC = $MCode2"
        }

        if($error_count -gt 0)
        {
            Write-Host "Attempting last stop action since there was a failure on previous attempts..."
            $result = Get-ActionToPerform -servers $PrimaryServer -action $Action -ServicesToControl $AllServices -environment $Environment -Domain $Domain -ISE $ISE 
            if ($result)
            {
                Write-Host "Completed [$Action] for Verint Primary Application for Services [$AllServices]"
            }
            else
            {
                Write-Host "Failures duing attempted Primary stop for services [$AllServices]"
                $exit_code = 28
                return $exit_code
            }
        }
    }

    return $exit_code
}

function stopProcesses
{
    #turn on verbose
    $VerbosePreference = 'Continue'
    Write-Verbose "Server name: $env:computername"

    #stop processes section
    $userid = 'svc_verintlab','svc_verint'

    $owners = @{}
    #populate @Owners
    try
    {
        Get-WmiObject -Class win32_process -ErrorAction SilentlyContinue |% {$owners[$_.handle] = $_.getowner().user} -ErrorAction SilentlyContinue
    }
    catch
    {
        Write-Verbose "Process no longer exists....."
    }
    $ps = get-process -ErrorAction SilentlyContinue | select processname,Id,@{l="Owner";e={$owners[$_.id.tostring()]}} -ErrorAction SilentlyContinue

    foreach($p in $ps) {
        if(-not ([string]::IsNullOrEmpty($($p.Owner))) -and -not([string]::IsNullOrEmpty($($p.Id))))
        {
            #MIGHT need to put if java.exe and System owner then stop-process......
            if($userid -match $($p.Owner)) {
                Write-Verbose "Attempting stop of the process [$($p.ProcessName)] Process ID [$($p.Id)] Owner [$($p.Owner)]"
                (gwmi win32_process -Filter "Handle=$($p.Id)" -ErrorAction SilentlyContinue).Terminate()
            }
            else
            {
                Write-Verbose "Skipping process [$($p.ProcessName)] Process ID [$($p.Id)]. Owner [$($p.Owner)].  Owner mismatch!"
            }
        }
    }

    #turn off verbose
    $VerbosePreference = 'SilentlyContinue'
    
}

function Get-ActionToPerform {
    param
    (
        [parameter(ValueFromPipeline=$true)]$servers,
        [parameter(ValueFromPipeline=$true)]$action,
        [parameter(ValueFromPipeline=$true)]$ServicesToControl,
        [parameter(ValueFromPipeline=$true)]$environment,
        [parameter(ValueFromPipeline=$true)]$Domain,
        [parameter(ValueFromPipeline=$true)]$ISE
    )


    try 
    {

        if(-not ([string]::IsNullOrEmpty($servers))) 
        {
            Write-Host "Working on Servers [$servers] for Services [$ServicesToControl]"
            Write-Host "Building PSSessions on [$Servers] Servers"
            $Session = New-PSSession -ComputerName $Servers -Verbose

            #first check for wrong count of connected servers...
            if($($Session.count) -ne $($Servers.count))
            {
                Write-Warning "Could not connect to all servers that are needed for this environment ($environment) using local AD domain ($Domain), exiting!"
                Write-Warning "One of the following: attempt to cross AD domains OR server is not up OR you don't have access to the server via WinRM"
                $exit_code = 19
                ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
            }

            $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-SREServiceControl} -ArgumentList $ServicesToControl,$action,100 -AsJob
            #wait for job to complete and output results
            $rc1 = checkJobAndLog -Session $Session -Jobs $Jobs -ExitCodeType 2
            $RCode1 = $($rc1)[1]
            if ($RCode1 -ne 0)
            {
                Write-Warning "Failures duing Validation Checks with RC: $RCode1"
                $exit_code = $RCode1
                return $false
            }
            else
            {
                Write-Host "All good on job(s) RC: $RCode1"
            }
        }
        else
        {
            Write-Host "Servers are empty, skipping servers [$servers] for Services [$($servicesToControl)]"
        }

    }
    catch {
        Write-Warning $_.Exception.ToString();
        return $false
    }
    return $true
}

function Ignore-SSLCertificates
{
    $Provider = New-Object Microsoft.CSharp.CSharpCodeProvider
    $Compiler = $Provider.CreateCompiler()
    $Params = New-Object System.CodeDom.Compiler.CompilerParameters
    $Params.GenerateExecutable = $false
    $Params.GenerateInMemory = $true
    $Params.IncludeDebugInformation = $false
    $Params.ReferencedAssemblies.Add("System.DLL") > $null
    $TASource=@'
        namespace Local.ToolkitExtensions.Net.CertificatePolicy
        {
            public class TrustAll : System.Net.ICertificatePolicy
            {
                public bool CheckValidationResult(System.Net.ServicePoint sp,System.Security.Cryptography.X509Certificates.X509Certificate cert, System.Net.WebRequest req, int problem)
                {
                    return true;
                }
            }
        }
'@ 
    $TAResults=$Provider.CompileAssemblyFromSource($Params,$TASource)
    $TAAssembly=$TAResults.CompiledAssembly
    ## We create an instance of TrustAll and attach it to the ServicePointManager
    $TrustAll = $TAAssembly.CreateInstance("Local.ToolkitExtensions.Net.CertificatePolicy.TrustAll")
    [System.Net.ServicePointManager]::CertificatePolicy = $TrustAll
}

function checkWebSite {
param
(
    [parameter(ValueFromPipeline=$true)]$PrimaryServer
)

    [string] $_URL = "https://$PrimaryServer/wfo/control/signin"
    $exit_code = 10

    # fix for some URL pages....  like ThinkSmart URL: https://blueshieldcaplans.com/
    $AllProtocols = [System.Net.SecurityProtocolType]'Ssl3,Tls,Tls11,Tls12'
    [System.Net.ServicePointManager]::SecurityProtocol = $AllProtocols
    Ignore-SSLCertificates

    $upperLimit = [datetime]::Now.AddMinutes(20)  #quit checking after this time.....
    write-host "Exit checking time: $upperLimit"

    Do { 
        $TimeNow = Get-Date
        Write-Host "Current Time is: $TimeNow"
        if ($TimeNow -ge $upperLimit) 
        {
           Write-host "It's time to finish checking for Verint Startup..."
           #$TimeNow = $upperLimit  #this is to stop the loop
        } 
        else 
        {
           Write-Host "Not done yet, it's currently: $TimeNow"
        }

        try {
            $request = Invoke-WebRequest -Uri $_URL -TimeoutSec 5 -Method Options -UseDefaultCredentials -UseBasicParsing
            if ($request.StatusCode -eq "200") {
                write-host "Site - [$_URL] is up (Return code: $($request.StatusCode))"
                $exit_code = 0
                $TimeNow = $upperLimit  #this is to stop the loop
            }
            else {
                write-host "Site - [$_URL] is down" 
            }
        } 
        catch 
        {
            write-host "Site [$_URL] is not accessable, Try again Later"
        }

        #lets sleep 30 seconds for next loop....
        Write-Host "Sleeping for 30 seconds for next loop..."
        Start-Sleep -Seconds 30
    }
    Until ($TimeNow -ge $upperLimit)

    return $exit_code
}

try
{

    #import functions
    Import-Module -name SRE-Functions -Force -WarningAction SilentlyContinue
    Import-Module -name SnowFunctions -Force -WarningAction SilentlyContinue
    import-module -name Get-SREServiceControl -Verbose -WarningAction SilentlyContinue
    # Start up Script
    $ISE, $LOG_DIR, $SRE_HOME, $SRE_Automation_Enabled = scriptStartup
    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    # Turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    # Let's start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    # Verify Self-Healing is Enabled
    if ($SRE_Automation_Enabled -ne "Enabled")
    {
        $exit_code = 86
        Write-Warning (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')" WARNING: SRE Management Server Automation has been disabled."
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    if ($Host.Name -eq "Windows PowerShell ISE Host") {
        $ISE=$true
    } else {
        $ISE=$false
    }
    if ($ISE) {
        # get the required input
        if(-not($Environment)) {
            $Environment = @()
            do 
            {
                $input = (Read-Host "Input your Environment (PROD, NPE): ")
                if ($input -ne '') {$Environment += $input}
            }
            until ($input -eq '')
        } 
        if(-not($Action)) {
            do {
                $Action = (Read-Host -Prompt "Input your Action Type ($ACTIONS): ")
                $Action = $Action.ToLower()
               }
                until ($ACTIONS.Contains($Action))
        }
    }

    $Environment = $Environment.ToUpper()
    Write-Host "Log File is: [$LOG_FILE]"
    Write-Host "Environment is [$Environment]"

    $AllServices = @('WatchDog','AvPolicyCheckCoreService','ADAM_Directory','TRSTomCat64','Mas Service','MinerTomcat','PlatformBackendServices','RecorderApiService','Wfo*')
    $PrimaryService = @('WFO_ProductionDomain*')
    $WatchDogService = @('WatchDog')
    $AllButPrimaryServices = @('WatchDog','AvPolicyCheckCoreService','ADAM_Directory','TRSTomCat64','Mas Service','MinerTomcat','PlatformBackendServices','RecorderApiService','WfoBranch*')

    $CMDBEnvironment = ''
    if($Environment -match "PROD")
    {
        Write-Host "Production run of script, stripping Environment Name [$Environment] from CMDB lookup..."
        $CMDBEnvironment = 'Verint%20Impact%20360'
    }
    else
    {
        #will have 'NPE' in the parent name for non-prod
        $CMDBEnvironment = "Verint%20Impact%20360%20-%20$Environment"
    }


    if (-not($Action))
    {
        $exit_code = 15
        Write-Error "Action is required, exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    else
    {
        $Action = $Action.ToLower()
        if($ACTIONS.Contains($Action))
        {
            Write-Host "Valid Action [$Action] passed"
        }
        else
        {
            Write-Error "Invalid Action [$Action] passed, exiting!"
            $exit_code = 16
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE
        } 
    }

    #get server list from CMDB
    $PrimaryServer, $servers = Get-ServerList

    Write-Host "Primary for Verint application is [$PrimaryServer]"
    Write-Host "Verint Application Servers is [$servers]"

    if($PrimaryServer.Count -gt 1)
    {
        Write-Warning "We should not get more then 1 primary for the Verint Application, exiting!"
        $exit_code = 18
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
 
    if(-not ([string]::IsNullOrEmpty($Primaryserver)))
    {

        if($action -eq "running" -or $action -eq "stopped")
        {
            #just combines lists of servers and perform checks...
            $theServers = $PrimaryServer + $Servers
            $result = Get-ActionToPerform -servers $theServers -action $Action  -servicesToControl $AllServices -environment $Environment -Domain $Domain -ISE $ISE 

            if ($result)
            {
                Write-Host "Completed [$Action] for Verint Application"
            }
            else
            {
                #Write-Error "Failures duing Validation Checks"
                $exit_code = 11
            }
        }
        elseif($action -eq "restart")
        {
            Write-Host "Performing a restart of the Verint application"
            Write-Host "Performing stop of the Verint Application"
            $result = Stop-App -Appservers $Servers -PrimaryServer $PrimaryServer -action stop -Primaryservice $PrimaryService -Allservices $AllServices -WatchDogservice $WatchDogService -AllButPrimaryServices $AllButPrimaryServices -environment $Environment -Domain $Domain -ISE $ISE 
            if($result -gt 0)
            {
                $exit_code = $result
                throw "Failures during the stop operation"
            } 
            write-host "Performing start of the Verint Application"
            $result = Start-App -Appservers $Servers -PrimaryServer $PrimaryServer -action start -Primaryservice $PrimaryService -Allservices $AllServices -WatchDogservice $WatchDogService -environment $Environment -Domain $Domain -ISE $ISE 
            if($result -gt 0)
            {
                $exit_code = $result
                throw "Failures during the start operation"
            }                
        }
        elseif($action -eq "start")
        {
            write-host "Performing start of the Verint Application"
            $result = Start-App -Appservers $Servers -PrimaryServer $PrimaryServer -action $Action  -Primaryservice $PrimaryService -Allservices $AllServices -WatchDogservice $WatchDogService -environment $Environment -Domain $Domain -ISE $ISE 
            if($result -gt 0)
            {
                $exit_code = $result
                throw "Failures during the start operation"
            } 
        }  
        elseif($action -eq "stop")
        {
            Write-Host "Performing stop of the Verint Application"
            $result = Stop-App -Appservers $Servers -PrimaryServer $PrimaryServer -action $Action -Primaryservice $PrimaryService -Allservices $AllServices -WatchDogservice $WatchDogService -AllButPrimaryservices $AllButPrimaryservices -environment $Environment -Domain $Domain -ISE $ISE 
            if($result -gt 0)
            {
                $exit_code = $result
                throw "Failures during the stop operation"
            }                 
        }
    }
    else
    {
        Write-Host "Primary Server is empty, skipping action [$Action] for Services [$($servicesToControl)]"
    }

}
catch
{
    Write-Warning $_.Exception.ToString();
    if($exit_code -lt 1 )
    {
        $exit_code = 99
    }
}
finally
{
    #cleanup now...
    Remove-Module -Name Get-SREServiceControl  -ErrorAction SilentlyContinue
    Remove-Module -Name SnowFunctions -ErrorAction SilentlyContinue
    Remove-Module -Name SRE-Functions -ErrorAction SilentlyContinue

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"

    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}