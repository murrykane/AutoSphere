﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	11/13/2017
	 Updated on:	12/23/2020
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	RestartFilenetServices.ps1

	The scripts being built in this grouping are for PAM Production Support
	The majority will be run from the Primary PAM Server, WINF313P. However,
	it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script Prompts user to Enable/Disable Maintenance Mode for UAT/PROD within Citrix

    It requires 2 arguments and 1 optional argument 

    1) Citrix ICON to enable/disable Maintenance Mode On
    2) Enable/Disable the ICON for Maintenance mode
    3) Citrix Environment (CMDB name one of the 3 (Citrix XD Non-production, Citrix XD Production, OR Citrix XD Stage))


    Example ./{Directory}/CitrixManageMaintMode.ps1 -Environment Citrix XD Non-production -MaintMode enable 
    Example ./{Directory}/CitrixManageMaintMode.ps1 -Environment Citrix XD Production -MaintMode disable 
    Example ./{Directory}/CitrixManageMaintMode.ps1 -Environment Citrix XD Stage -MaintMode enable 
    Example ./{Directory}/CitrixManageMaintMode.ps1 -Environment Citrix XD Non-production -MaintMode disable  

  Modifications

  12/22/2020  Murry Kane   - made CMDB calls to get the Citrix server to connect too instead of using EnvList.csv
                            #  $strController = "wapp4829p.bsc.bscal.com"	 new one
  01/22/2021  Murry Kane   - for CMDB calls we will hard-code the right values to pass to URL for either
                                prod   = Citrix XD Production
                                stage  = Citrix XD Stage
                                dev    = Citrix XD Non-production 
                             Added optional 3rd parm that will determine to use 2015 or Production ServiceNow for CMDB lookups
#>

[CmdletBinding()]
Param(
  #[Parameter(Mandatory=$True,Position=1)]
   [string[]]$Environment,
	
   #[Parameter(Mandatory=$True, Position=2)]
   [string]$MaintMode,

   [Parameter(Mandatory=$False, Position=3)][switch]$uselocaldomain,
   [Parameter(Mandatory=$False, Position=4)][string]$CitrixName
)


function Get-ServerList {
    try {

        #lets see if we we are going against production or 2015 CMDB
        $SnowCred = ''
        $UriBase = ''

        if(-not $uselocaldomain)
        {
            $SNowCred = Get-ServiceNowCredential
            $UriBase = Get-ServiceNowUriBase
        }
        else
        {
            Write-Host "-UseLocalDomain option passed to script, using local domain to determine which ServiceNow Instance to connect with"
            $SNowCred = Get-ServiceNowCredential -uselocaldomain
            $UriBase = Get-ServiceNowUriBase -uselocaldomain                
        }

        if([string]::IsNullOrWhiteSpace($SNowCred) -or [string]::IsNullOrWhiteSpace($UriBase))
        {
            $exit_code = 4
            Write-Warning "We could not get credentials to make the REST call to ServiceNow" 
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }
        else
        {
            Write-Host "URI Base $UriBase"
        }

        # Query Server to App Relationship Table
        Write-Host "Querying ServiceNow API for getting the Citrix Delivery Controller server(s)"
        #https://blueshieldca.service-now.com/cmdb_rel_ci_list.do?sysparm_query=parent.nameSTARTSWITHCitrix%20XD%20Stage%5Echild.nameSTARTSWITHCitrix%20Delivery%20Controller%5Eparent.sys_class_name%3Dcmdb_ci_appl%5Eparent.install_status%3D11%5Eparent.operational_status%3D1%5Echild.sys_class_name%3Dcmdb_ci_app_server%5Echild.install_status%3D11%5Echild.operational_status%3D1%5Etype%3D60bc4e22c0a8010e01f074cbe6bd73c3&sysparm_view=
        $Uri = "$UriBase/api/now/table/cmdb_rel_ci?sysparm_query=parent.nameSTARTSWITH$CitrixLookup%5Echild.nameSTARTSWITHCitrix%20Delivery%20Controller%5Eparent.sys_class_name%3Dcmdb_ci_appl%5Eparent.install_status%3D11%5Eparent.operational_status%3D1%5Echild.sys_class_name%3Dcmdb_ci_app_server%5Echild.install_status%3D11%5Echild.operational_status%3D1%5Etype%3D60bc4e22c0a8010e01f074cbe6bd73c3&sysparm_display_value=true&sysparm_exclude_reference_link=true&sysparm_fields=child&sysparm_limit=1000"

        Write-Host "Using URI [$Uri]"

        $Result = Query-ServiceNowApi -Uri $Uri -SNowCred $SNowCred

        Write-Host "Result is " + $result   
        $Servers = $result | ForEach-Object { (($_).child -split "@")[1] } | select -Unique

        return $Servers
    }
    catch {
        return $null
    }
}

try
{

    # variables 
    $SleepTimer = 3
    $CitrixLookup = ''
    $ACTIONS = @('ENABLE','DISABLE')
    $CitrixENVS = @('PROD','STAGE','NPE')
    #$ACTIONS = 'ENABLE','DISABLE'
    #$CitrixENVS = 'PROD','STAGE','NPE'
    $exit_code = 0
    $LOG_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\Logs'
    $PAM_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts'
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    # turn off verbose
    $VerbosePreference = 'SilentlyContinue'
    $LocalDomain = (Get-ChildItem Env:'USERDOMAIN' -ErrorAction Ignore).Value

    if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS)))
    {
        $LOG_DIR = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS
    }
    else
    {
        $LOG_DIR = $PAM_HOME_DIR_DEFAULT 
    }

    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    #get PAM home dir
    if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME)))
    {
        $PAM_HOME = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME
    }
    else
    {
        $PAM_HOME = $PAM_HOME_DIR_DEFAULT 
    }



    #import functions
    Import-Module SRE-Functions -Force -WarningAction SilentlyContinue
    Import-Module SnowFunctions -Force -WarningAction SilentlyContinue

    if ($Host.Name -eq "Windows PowerShell ISE Host") {
        $ISE=$true
    } else {
        $ISE=$false
    }

    if ($ISE) {
        # get the required input
        if(-not($MaintMode)) {
            #Prompt User to get UAT/PROD
            do {
                $MaintMode = Read-Host -Prompt "What should we set Maintenace Mode too ($ACTIONS): "
                $MaintMode = $MaintMode.toUpper()
               }
                until ($ACTIONS.Contains($MaintMode))
        }
        if(-not($Environment)) {
            #prompt to get it
            do 
            {
                $Environment = (Read-Host "Input your Environment ($CitrixENVS ): ")
                $Environment = $Environment.toUpper()
            }
            until ($CitrixENVS.Contains($Environment))
        }
        if($CitrixENVS[2] -eq $Environment)
        {
            if(-not($CitrixName)) {
                do
                {
                    $CitrixName = Read-Host -Prompt "What Citrix Delivery Controller Name should we manage in $($CitrixENVS[2]): "
                }
                until (-not [string]::IsNullOrWhiteSpace($CitrixName))
            }
        }
    }

    if (-not($Environment)) 
    { 
        $exit_code = 8
        Write-Warning "You Must supply a value for CMDB lookup on Citrix XD Delivery Controller" 
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    if (-not($MaintMode)) 
    { 
        $exit_code = 9
        Write-Warning "You Must supply a value for -MaintMode" 
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
    #lets validate if NPE that we have a Citrix Delivery Controller name to manage...
    if ($Environment -eq $CitrixENVS[2] -and [string]::IsNullOrWhiteSpace($CitrixName))
    {
        $exit_code = 10
        Write-Warning "You Must supply a value for -CitrixName when running in environment [$($CitrixENVS[2])]" 
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    #validate enable or disable passed only
    $MaintMode = $MaintMode.ToUpper()
    if($ACTIONS.Contains($MaintMode)) 
    {
        Write-Host "Valid option passed for -MaintMode with: [$MaintMode]"
    }
    else
    {
        Write-Error "The value you supplied for -MaintMode is not valid. It must be either: [$ACTIONS]!" 
        $exit_code = 16
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    #validate environment
    $Environment = $Environment.ToUpper()
    if($CitrixENVS -contains $Environment)
    {
        Write-Host "Valid option passed for -Environment with: [$Environment]"
        Switch ($Environment)
        {
           # MBK This is where prod/stage/npe is translated to the values to look up in CMDB
           #order matters!!!
           $CitrixENVS[0] { $CitrixLookup = 'Citrix XD Production'}
           $CitrixENVS[1] { $CitrixLookup = 'Citrix XD Stage'}
           $CitrixENVS[2] { $CitrixLookup = 'Citrix XD Non-production' }
           default { $CitrixLookup = '' }  
        } 
        if([string]::IsNullOrWhiteSpace($CitrixLookup))
        {
            $exit_code = 5
            Write-Warning "We could not determine lookup value for Citrix Controller in the CMDB!" 
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE 
        }
    }
    else
    {
        Write-Error "The value you supplied for -Environment is not valid. It must be one of the following: [$CitrixENVS]!" 
        $exit_code = 16
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    #lets start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    Write-Host "Script name is: $currentScriptName"
    Write-Host "Log File is $LOG_FILE"
    Write-Host "PAM HOME Directory is $PAM_HOME"
    Write-Host "Environment is $Environment"
    Write-Host "Maintenance Mode is $MaintMode"
    Write-Host "CMDB Lookup value for [$environment] is [$CitrixLookup]"
    if(-not [string]::IsNullOrWhiteSpace($CitrixName))
    {
        Write-Host "We will look to manage Citrix Delivery Controller with name [$CitrixName] for Environment [$($CitrixENVS[2])]"
    }

    #mbk call CMDB to get list of controllers
    $Servers = Get-ServerList
    if([string]::IsNullOrWhiteSpace($Servers))
    {
        $exit_code = 4
        Write-Warning "We could not get any Citrix Controllers from the REST call to ServiceNow" 
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
    }

    Write-Host "List of Citrix Delivery Controllers is: [$Servers]"

    $OneServer = $Servers | Get-Random
    Write-Host "Got random Citrix Delivery Controller as: [$OneServer]"

    if (-not $OneServer)
    {
        $exit_code = 45
        Write-Warning "We Could NOT determine Citrix Delivery Controller for [$Environment], exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE 
    }
    else
    {
        Write-Host "For Environment is [$Environment] using Citrix Delivery Controller [$OneServer]"
    }

    #validate we will not cross domains...
    foreach ($server in $OneServer)
    {
        # (Get-ADDomainController).domain.split('.')[0].toUpper()
        Write-Host "Validating domain for server [$server]"
        if(Test-Connection -ComputerName $server -count 1 -Quiet)
        {
            $remoteDomain = invoke-command -ComputerName $server -ScriptBlock{(Get-WmiObject Win32_ComputerSystem).domain.split('.')[0].toUpper()} -ErrorAction Ignore
            if($LocalDomain -ne $remoteDomain)
            {
                Write-Error "WE CAN'T run a script that will cross Domains; Local Domain [$LocalDomain] to server [$server] with domain [$remoteDomain], exiting script!"
                $exit_code = 20
                ExitWithCode -exitcode $exit_code -ISEFlag $ISE
            }
            else
            {
                write-host "Server [$server] is valid for running script against, continuing" 
            }
        }
        else
        {
            Write-Error "Server returned from CMDB does not seem to be online for Server [$server], exiting script!"
            $exit_code = 22
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE            
        }
    }


    # Create new Remote PowerShell session
    $objRemoteSession = New-PSSession -ComputerName $OneServer

    # Use Invoke-Command to import Citrix PowerShell snap-ins on remote server
    Invoke-Command -ScriptBlock {add-pssnapin Citrix.*} -Session $objRemoteSession

    # Import PowerShell session
    Import-PSSession -Session $objRemoteSession -Module Citrix.* -Prefix RM -AllowClobber

    #add logic for NPE to only manage 1 icon name...
    $desktopGroups = ''
    if([string]::IsNullOrWhiteSpace($CitrixName))
    {
        $desktopGroups = Get-RMBrokerDesktopGroup -Filter "(Name -like '*HSA*FAC*')"
    }
    else
    {
        $desktopGroups = Get-RMBrokerDesktopGroup -Filter "(Name -like '$CitrixName')"
    }
    #lets validate it exists above and not NULL
    if([string]::IsNullOrEmpty($desktopGroups))
    {
        $exit_code = 100
        Write-Host "We could not determine any Desktop Groups within Citrix for environment [$Environment], exiting!"
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    #MBK need a for loop for each icon to disable....
    foreach ($desktopGroup in $desktopGroups)
    {
        $CitrixIcon = ($desktopGroup).name 
        Write-Host "Working on desktop group [$CitrixIcon] with [$MaintMode]" -BackgroundColor Blue -ForegroundColor Cyan

        #lets set true/false now for the user input
        if ($MaintMode -match "ENABLE")
        {
            #Write-Host "Setting to TRUE for action [$MaintMode]"
            $CITRIXMODE = $true
        }
        else
        {
            if ($MaintMode -match "DISABLE")
            {
                #Write-Host "Setting to FALSE for action [$MaintMode]"
                $CITRIXMODE = $false
            }
            else
            {
                Throw "Invalid OPTION used for setting Maintenance Mode, exiting!"
            }
        }

        #lets validate it exists above and not NULL
        if([string]::IsNullOrEmpty($CitrixIcon))
        {
            $exit_code = 100
            Write-Host "The supplied Citrix Icon [$CitrixIcon}] could NOT be found, exiting!"
            ExitWithCode -exitcode $exit_code -ISEFlag $ISE   
        }

        #lets change it....
        Set-RMBrokerDesktopGroup -InputObject $desktopGroup -InMaintenanceMode $CITRIXMODE

        #lets refresh to validate....
        $desktopGroupRefresh = Get-RMBrokerDesktopGroup -Filter "(Name -eq '$CitrixIcon')"


        $oldValue = $desktopGroup.InMaintenanceMode
        $newValue = $desktopGroupRefresh.InMaintenanceMode

        #convert true/false to ENABLED/DISABLED
        if($oldvalue -match $true)
        {
            $oldValue = "ENABLED"
        }
        else
        {
            $oldValue = "DISABLED"
        }
        if($newValue -match $true)
        {
            $newValue = "ENABLED"
        }
        else
        {
            $newValue = "DISABLED"
        }

        Write-Host "Maintenace Mode for Group [$CitrixIcon] was: [$oldValue] and is now: [$newValue]" -BackgroundColor Yellow -ForegroundColor Red
    }

}
catch
{
    Write-Warning $_.Exception.ToString();
    $exit_code = 99
}
finally
{
    # Cleanup
    Remove-Module -Name SRE-Functions -ErrorAction SilentlyContinue
    Remove-Module -Name SnowFunctions -ErrorAction SilentlyContinue
    $Session | Remove-PSSession -ErrorAction SilentlyContinue

    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}
