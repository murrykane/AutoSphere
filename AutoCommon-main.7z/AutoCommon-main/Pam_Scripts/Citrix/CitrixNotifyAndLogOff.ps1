﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	11/13/2017
	 Updated on:	11/13/2017
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	RestartFilenetServices.ps1

	The scripts being built in this grouping are for PAM Production Support
	The majority will be run from the Primary PAM Server, WINF313P. However,
	it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script Prompts user to Enable/Disable Maintenance Mode for UAT/PROD within Citrix

    It requires 2 arguments and 1 optional argument 

    1) Citrix ICON to enable/disable Maintenance Mode On
    2) Enable/Disable the ICON for Maintenance mode
    3) Citrix Environment (NPE,STAGE,PROD)


From Shawn Johns
---------------------------------

So Production is split into:
XenDesktop Site: SAC-Prod
Controllers: wcin108p, wcin109p, wcin154p
Delivery Group for FI: PRD-HSA-FACP02

XenDesktop Site: LAS-Prod
Controllers: wcin125p, wcin126p, wcin158p
Delivery Group for FI: xDR-PRD-HSA-FACP02

it may be of value to 1. make sure LAS-Prod has the xDR-PRD-HSA-FACP02 Delivery Group in Maintenance Mode at the start of a change
2. make sure LAS-Prod has that same Delivery Group removed from maintenance mode after the change, and users can access icons there as well

Stage: wcin139s, wcin140s
Non-Prod: wcin139n, wcin140n

The SAC-Prod site is always primary for FI, with all of the machines powered on and users accessing apps there daily

The LAS-Prod site is the DR site, with a separate set of servers maintained there during Facets releases tht need to be checked out / used during releases then powered off, and then only used regularly if there is a Sacramento Datacenter outage 

--------------------------------


    Example ./{Directory}/CitrixNotifyAndLogOff.ps1 -Environment FACP02 -NotifySeconds 10 
    Example ./{Directory}/CitrixNotifyAndLogOff.ps1 -Environment FACP02 -NotifySeconds 1000 
    Example ./{Directory}/CitrixNotifyAndLogOff.ps1 -Environment FACN32 -NotifySeconds 10 
    Example ./{Directory}/CitrixNotifyAndLogOff.ps1 -Environment FACN32 -NotifySeconds 100  
#>

[CmdletBinding()]
Param(
  #[Parameter(Mandatory=$True,Position=1)]
   [string[]]$Environment,
	
   #[Parameter(Mandatory=$True, Position=2)]
   [string]$SleepTime

)

# variables 
$PRODCITRIXICONS = 'UAT-HSA-FACP02', 'PRD-HSA-FACP02'
$SleepTimer = 3
$ACTIONS = @('ENABLE','DISABLE')
$CitrixENVS = 'STAGE','NPE','PROD'
$CitrixSite = 'SAC','LAS'
$exit_code = 0
$LOG_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\Logs'
$PAM_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts'
$currentScriptName = $MyInvocation.MyCommand.Name
$filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
# turn off verbose
$VerbosePreference = 'SilentlyContinue'

if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS)))
{
    $LOG_DIR = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS
}
else
{
    $LOG_DIR = $PAM_HOME_DIR_DEFAULT 
}

$LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

#get PAM home dir
if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME)))
{
    $PAM_HOME = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME
}
else
{
    $PAM_HOME = $PAM_HOME_DIR_DEFAULT 
}



#import functions
Import-Module Functions -Force

if ($Host.Name -eq "Windows PowerShell ISE Host") {
    $ISE=$true
} else {
    $ISE=$false
}

if ($ISE) {
    # get the required input
    if(-not($SleepTime)) {
        #Prompt User to get ENABLE/DISABLE maintenance mode
        do {
            $getTime = Read-Host -Prompt "Time to Sleep between notification and logging off users: "
            if ( $getTime -match '^\d+$')
            {
                #write-host "came here...."
                [int]$SleepTime = $getTime
            }
            else
            {
                #write-host "not int...."
                $SleepTime = ""
            }
           }
            until ($SleepTime -is [Int32])
    } 
    if(-not($Environment)) {
        $Environment = @()
        do 
        {
            $input = (Read-Host "Input your Environment (FACP02, FACN01, FACN32): ")
            if ($input -ne '') {$Environment += $input}
        }
        until ($input -eq '')
    }
}


if (-not($Environment)) 
{ 
    Throw "You Must supply a value for -Environment" 
    if(-Not($ISE)) { ExitWithCode -exitcode 1 } else {exit}
}
if (-not($SleepTime)) 
{ 
    Throw "You Must supply a value for -SleepTime" 
    if(-Not($ISE)) { ExitWithCode -exitcode 2 } else {exit}
}

#lets start logging what occures from here forward....
Start-Transcript -path $LOG_FILE -append

Write-Host "Script name is: $currentScriptName"
Write-Host "Log File is $LOG_FILE"
Write-Host "PAM HOME Directory is $PAM_HOME"
Write-Host "Environment is $Environment"


if ( $SleepTime -match '^\d+$')
{
    [int]$SleepTime = $SleepTime
}
else
{
    Throw "You must supply an integer for -SleepTime"
    if(-Not($ISE)) { ExitWithCode -exitcode 2 } else {exit}
}

#lets get the ICONS to manage and the Platform

Import-Module Get-BSCServersInfo
$CitrixENV = get-bscserversinfo -Environment $Environment -WhichProperty APP -PropValue FACETS -ColumnReturn Platform
$CitrixIcons = get-bscserversinfo -Environment $Environment -WhichProperty APP -PropValue FACETS -ColumnReturn CitrixIcon

$CitrixEnv = $CitrixEnv.toUpper()
Write-Host "Citrix Environment is [$CitrixENV] for Icons [$CitrixIcons]"

#now that we have the icons, let validate we are not trying to cross Domains (NPE to PROD or vise-versa)
$Platform = get-bscserversinfo -Environment $Environment -WhichProperty CitrixIcon -PropValue $CitrixIcons -ColumnReturn Platform
#$Domain = (Get-ADDomain).Name  #mbk its expensive call...
$Domain = (Get-ChildItem Env:'USERDOMAIN' -ErrorAction Ignore).Value
Write-Verbose "Platform for these servers is [$Platform], Active Directory Domain is [$Domain]"
if ($Platform -eq 'PROD' -and $Domain -ne 'BSC')
{
    #we can't run run from NONE PROD domain to prod servers...
    Write-Error "WE CAN'T run a script from a NONE PROD Active Directory Domain ($Domain) to Production Servers(Platform [$Platform]), exiting script!"
    $exit_code = 20
    if(-Not($ISE)) { ExitWithCode -exitcode $exit_code } else {Throw "Exiting, script!"}
}
elseif ($Platform -ne 'PROD' -and $Domain -eq 'BSC')
{
    Write-Error "WE CAN'T run from a PROD Active Directory Domain ($Domain) to NONE Production Servers(Platorm [$Platform]), exiting script!"
    $exit_code = 21
    if(-Not($ISE)) { ExitWithCode -exitcode $exit_code } else {Throw "Exiting, script!"}
}
else
{
    Write-Host "Running script in Active Directory Domain [$Domain] for server types of [$Platform]"
}


#need a foreach for each NPE/STAGE/PROD platform
foreach($Plat in $Platform)
{
    Write-Host "Working on Platform [$Plat]"
    $CitrixIcons = get-bscserversinfo -Environment $Environment -WhichProperty Platform -PropValue $Plat -ColumnReturn CitrixIcon
    #$CitrixIcons = $CitrixIcons.toUpper()
    Write-Host "Citrix Environment is [$Plat] for Icons [$CitrixIcons]"

    #Lets connect to the correct controller based on CitrixEnv passed
    # Initialise variables/Parameters
    if ($CitrixENV -eq 'PROD')
    {
        #PROD 
        $strController = "wcin109p.bsc.bscal.com"	
        Write-Host "Using $CitrixENV Citrix Controller: $strController"
    }
    ElseIf ($CitrixENV -eq 'NPE')
    {
        #NPE Non-Prod: wcin139n, wcin140n
        $strController = "wcin139n.dev.bscal.local"
        Write-Host "Using $CitrixENV Citrix Controller: $strController"
    }
    ElseIf ($CitrixENV -eq 'STAGE')
    {
        #Stage: wcin139s, wcin140s
        $strController = "wcin139s.dev.bscal.local"	
        Write-Host "Using $CitrixENV Citrix Controller: $strController"
    }
    else
    {
        #we should never get here...
        throw "We should not get here, but we do not have a valid Citrix Environment to use!"
        if(-Not($ISE)) { ExitWithCode -exitcode 5 } else {exit}
    }

    # Create new Remote PowerShell session
    $objRemoteSession = New-PSSession -ComputerName $strController 

    # Use Invoke-Command to import Citrix PowerShell snap-ins on remote server
    Invoke-Command -ScriptBlock {add-pssnapin Citrix.*} -Session $objRemoteSession

    # Import PowerShell session
    Import-PSSession -Session $objRemoteSession -Module Citrix.* -Prefix RM -AllowClobber

    $desktopGroup = Get-RMBrokerDesktopGroup -Filter "(Name -eq '$CITRIXDeliveryGroup')"


    $Sessions = Get-RMBrokerSession -filter "DesktopGroupName -eq '$($DesktopGroup.Name)'"

    If ($Sessions.Count -gt 0 )
    {
        Write-Host "We have $($Sessions.Count) sessions to notify..."
    
        foreach ( $Session in $Sessions)
        {
            Write-Host "Working on $($Session.UserName) in state $($Session.SessionState)"
            #notify them to save their work...
            Send-RMBrokerSessionMessage -InputObject $Session -MessageStyle Critical -Title "Maintenance Required" -Text "Maintenance Required, please save your work. The system will be down in $SleepTime seconds!"
        }

        #lets sleep now...
        Write-Host "We are going to sleep $SleepTime seconds before continuing...."
        Start-Sleep $SleepTime
    }

    #kick them off now...


    If ($Sessions.Count -gt 0 )
    {
        Write-Host "We have $($Sessions.Count) sessions to log off..."
    
        foreach ( $Session in $Sessions)
        {
            Write-Host "Working on $($Session.UserName) in state $($Session.SessionState)"
            Stop-RMBrokerSession -InputObject $Session
        }

    }
} #end foreach loop....

Write-Host "All done with: $currentScriptName"

# stop logging
Stop-Transcript

if(-Not($ISE)) { ExitWithCode -exitcode $exit_code }
