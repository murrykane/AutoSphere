﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	05/15/2019
	 Updated on:	05/15/2019
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	Backup-CP.ps1

	The scripts being built in this grouping are for PAM Production Support
	The majority will be run from the Primary PAM Server, WINF313P or WINF4028p. However,
	it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script will either accept a single argument or prompt if running in ISE for
        a given Facets environment. It will then verify GPS version information


Date:      Who:            Changes:
-----------------------------------
05/15/2019 Murry Kane      Initial


    Example

    ./{Directory}\Backup-CP.ps1 -Environment FACN52 
    ./{Directory}\Backup-CP.ps1 -Environment FACP01
#>

[CmdletBinding()]
Param(
  #[Parameter(Mandatory=$True,Position=1)]
   [string[]]$Environment,
   [string[]]$Roles
	
)

try
{

    $exit_code = 0
    $rcode1 = 0
    $LOG_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\logs'
    $PAM_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts'
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    $SleepTimer = 5
    # turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    Write-Host "Script name is: $currentScriptName"

    if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS)))
    {
        $LOG_DIR = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS
    }
    else
    {
        $LOG_DIR = $PAM_HOME_DIR_DEFAULT 
    }

    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    #get PAM home dir
    if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME)))
    {
        $PAM_HOME = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME
    }
    else
    {
        $PAM_HOME = $PAM_HOME_DIR_DEFAULT 
    }


    if ($Host.Name -eq "Windows PowerShell ISE Host") {
        $ISE=$true
    } else {
        $ISE=$false
    }
    if ($ISE) {
        # get the required input
        if(-not($Environment)) {
            $Environment = @()
            do 
            {
                $input = (Read-Host "Input your Environment (FACP02, FACN32, FACN31): ")
                if ($input -ne '') {$Environment += $input}
            }
            until ($input -eq '')
        }
        if(-not($Roles)) {
            $Roles = @()
            do 
            {
                $input = (Read-Host "Input your Role (ISL, HIPAA, BATCH, etc): ")
                if ($input -ne '') {$Roles += $input}
            }
            until ($input -eq '')
        }
    }

    #lets start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    Write-Host "Log File is $LOG_FILE"
    Write-Host "Environment is [$Environment]"
    Write-Host "PAM HOME Directory is $PAM_HOME"
    Write-Host "Roles are [$Roles]"


    #import functions
    Import-Module Functions -Force
    Import-Module Get-BSCServersInfo
    $servers = get-bscserversinfo -Environment $Environment -WhichProperty Role -PropValue $Roles -ColumnReturn ServerName

    #check if servers is empty, then exit
    if(([string]::IsNullOrEmpty($servers))) 
    {
        Write-Error "Could not determine a list of servers for environment [$Environment], exiting!"
        $exit_code = 13
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    #now that we have the servers, let validate we are not trying to cross Domains (NPE to PROD or vise-versa)
    $Platform = get-bscserversinfo -Environment $Environment -WhichProperty ServerName -PropValue $Servers -ColumnReturn Platform
    #$Domain = (Get-ADDomain).Name  #mbk its expensive call...
    $Domain = (Get-ChildItem Env:'USERDOMAIN' -ErrorAction Ignore).Value
    Write-Verbose "Platform for these servers is [$Platform], Active Directory Domain is [$Domain]"
    if ($Platform -eq 'PROD' -and $Domain -ne 'BSC')
    {
        #we can't run run from NONE PROD domain to prod servers...
        Write-Error "WE CAN'T run a script from a NONE PROD Active Directory Domain ($Domain) to Production Servers(Platform [$Platform]), exiting script!"
        $exit_code = 20
        if(-Not($ISE)) { ExitWithCode -exitcode $exit_code } else {Throw "Exiting, script!"}
    }
    elseif ($Platform -ne 'PROD' -and $Domain -eq 'BSC')
    {
        Write-Error "WE CAN'T run from a PROD Active Directory Domain ($Domain) to NONE Production Servers(Platorm [$Platform]), exiting script!"
        $exit_code = 21
        if(-Not($ISE)) { ExitWithCode -exitcode $exit_code } else {Throw "Exiting, script!"}
    }
    else
    {
        Write-Host "Running script in Active Directory Domain [$Domain] for server types of [$Platform]"
    }


    $SleepTimer = 5

    Write-Host "Servers are: [$Servers]"

    $command = {
          Get-ItemProperty "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\3M Grouper Plus System" | Select-Object DisplayName, DisplayVersion, InstallDate | Format-Table –AutoSize `        
        ; Get-ItemProperty "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\3M Medicare Inpatient Psychiatric Facility Pricer Tables Software" | Select-Object DisplayName, DisplayVersion, InstallDate | Format-Table –AutoSize `
        ; Get-ItemProperty "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\3M Medicare Long Term Care Hospital Pricer Tables Software" | Select-Object DisplayName, DisplayVersion, InstallDate | Format-Table –AutoSize `
       # ; Get-ItemProperty "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\3M Medicare Outpatient Pricer Tables Software" | Select-Object DisplayName, DisplayVersion, InstallDate | Format-Table –AutoSize `
        ; Get-ItemProperty "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\3M Medicare Renal Dialysis Facility Pricer Tables Software" | Select-Object DisplayName, DisplayVersion, InstallDate | Format-Table –AutoSize `
        ; Get-Content 'D:\apps\3mhis\GPS\logs\pricerTablesUpdater.log' | Where-Object { $_.Contains("CAIPT") } | Select-Object -Last 1 `
        ; Get-Content 'D:\apps\3mhis\GPS\logs\pricerTablesUpdater.log' | Where-Object { $_.Contains("MIPT") } | Select-Object -Last 1 `
        ; Get-Content 'D:\apps\3mhis\GPS\logs\pricerTablesUpdater.log' | Where-Object { $_.Contains("MASCPT") } | Select-Object -Last 1 `
        ; Get-Content 'D:\apps\3mhis\GPS\logs\pricerTablesUpdater.log' | Where-Object { $_.Contains("MOPT") } | Select-Object -Last 1 `

        ; Write-Output "$env:COMPUTERNAME $OUTPUT `n" 
    }


    #import the PAM Service Module
    import-module -name Get-PAMServiceControl.psm1 -Verbose -WarningAction SilentlyContinue

    #start services
    if(-not ([string]::IsNullOrEmpty($servers))) 
    {
        Write-Host "Working on Servers [$servers]"
        #Write-Host "Building PSSessions on [$Servers] Servers"
        #$Session = New-PSSession -ComputerName $Servers -Verbose
        $Servers | ForEach-Object { Invoke-Command -ComputerName $_ -ScriptBlock $Command }
    }
    else
    {
        Write-Host "Servers are empty, skipping [$servers]"
    }
}
catch
{
    Write-Error $_.Exception.ToString();
    $exit_code = 99
}

finally
{

    #cleanup
    Remove-Module -Name Get-BSCServersInfo
    Remove-Module -Name Get-PAMServiceControl
    Remove-Module -Name Functions

    if ($RCode1 -ne 0)
    {
        $exit_code = $RCode1
        Write-Error "Failures duing Validations : $exit_code"
    }


    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}

