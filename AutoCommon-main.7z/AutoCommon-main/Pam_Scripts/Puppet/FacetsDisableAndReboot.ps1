﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	11/29/2018
	 Updated on:	11/29/2018
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	FacetsDisableAndReboot.ps1

	The scripts being built in this grouping are for PAM Production Support
	The majority will be run from the Primary PAM Server, WINF313P or WINF4028p. However,
	it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script will either accept a single argument or prompt if running in ISE for
        a given Facets environment. It will then check for the environment text file for
        list of servers that it will manage for this script execution. For the list of 
        servers it will disable icons within Citrix and then stop the Facets services
        for the given servers and will then execute reboots for the same servers.


Date:      Who:            Changes:
-----------------------------------
01/08/2019 Murry Kane      Made changes to put into SVN/Jenkins for all operations
                           Main difference is to take environment to detemine which servers to work on
01/27/2021 Murry Kane      Updated for Citrix script change that now uses the CDMB
01/29/2021 Murry Kane      After testing with Ganesh found that the Environment variable is changed in
                           in the citrix script and therefore needs to be saved off with a different 
                           variable name '$SaveEnv' to be used in future calls to EnvList.csv later 
                           in the script
04/23/2021 Murry Kane      Added additional service to manage of FaWinSvcHost

    Example

    ./{Directory}\FacetsDisableAndReboot.ps1 -Environment FACN52 
    ./{Directory}\FacetsDisableAndReboot.ps1 -Environment FACP01
#>

[CmdletBinding()]
Param(
  #[Parameter(Mandatory=$True,Position=1)]
   [string[]]$Environment
	
)

$exit_code = 0
$CitrixENVS = @('PROD','STAGE','NPE')
$LOG_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\logs'
$PAM_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts'
$currentScriptName = $MyInvocation.MyCommand.Name
$filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
$SleepTimer = 5
# turn off verbose
$VerbosePreference = 'SilentlyContinue'

Write-Host "Script name is: $currentScriptName"

if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS)))
{
    $LOG_DIR = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS
}
else
{
    $LOG_DIR = $PAM_HOME_DIR_DEFAULT 
}

$LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

#get PAM home dir
if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME)))
{
    $PAM_HOME = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME
}
else
{
    $PAM_HOME = $PAM_HOME_DIR_DEFAULT 
}


if ($Host.Name -eq "Windows PowerShell ISE Host") {
    $ISE=$true
} else {
    $ISE=$false
}
if ($ISE) {
    # get the required input
    if(-not($Environment)) {
        $Environment = @()
        do 
        {
            $input = (Read-Host "Input your Environment (FACP02, FACN32, FACN31): ")
            if ($input -ne '') {$Environment += $input}
        }
        until ($input -eq '')
    }
    if(-not($CitrixEnv)) {
        #prompt to get it
        do 
        {
            $CitrixEnv = (Read-Host "Input your Citrix Environment ($CitrixENVS ): ")
            $CitrixEnv = $CitrixEnv.toUpper()
        }
        until ($CitrixENVS.Contains($CitrixEnv))
    }
    if($CitrixEnv -eq 'NPE')
    {
        if(-not($CitrixName)) {
            do 
            {
                $CitrixName = (Read-Host "Input your CitrixName (*FAC*, *FACH63*, *FACH80*): ")
            }
            until ($CitrixName -ne '')
        }
    }
}

#check if citrix name is empty
if($CitrixEnv -eq 'NPE')
{
    if(([string]::IsNullOrEmpty($CitrixName))) 
    {
        Write-Error "Could not determine Citrix Name to manage for environment [$Environment], exiting!"
        $exit_code = 14
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }
}
else
{
    if(([string]::IsNullOrEmpty($CitrixName))) 
    {
        #here we will set it to all
        $CitrixName = '*FAC*'
    }
}

if (-not($CitrixEnv)) 
{ 
    $exit_code = 8
    Write-Warning "You Must supply a value for Citrix XD Delivery Controller Environment!" 
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}

#lets start logging what occures from here forward....
Start-Transcript -path $LOG_FILE -append

Write-Host "Log File is $LOG_FILE"
Write-Host "Environment is [$Environment]"
Write-Host "PAM HOME Directory is $PAM_HOME"
Write-Host "Citrix Environment [$CitrixEnv] using Citrix Name [$CitrixName]"

#save for later....
$SaveEnv = $Environment

#import functions
Import-Module Functions -Force


Import-Module Get-BSCServersInfo
$servers = get-bscserversinfo -Environment $Environment -WhichProperty Role -PropValue ISL,ISLCWS,HIPAA,BATCH,WAS -ColumnReturn ServerName

#check if servers is empty, then exit
if(([string]::IsNullOrEmpty($servers))) 
{
    Write-Error "Could not determine a list of servers for environment [$Environment], exiting!"
    $exit_code = 13
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}

#now that we have the servers, let validate we are not trying to cross Domains (NPE to PROD or vise-versa)
$Platform = get-bscserversinfo -Environment $Environment -WhichProperty ServerName -PropValue $Servers -ColumnReturn Platform
#$Domain = (Get-ADDomain).Name  #mbk its expensive call...
$Domain = (Get-ChildItem Env:'USERDOMAIN' -ErrorAction Ignore).Value
Write-Verbose "Platform for these servers is [$Platform], Active Directory Domain is [$Domain]"
if ($Platform -eq 'PROD' -and $Domain -ne 'BSC')
{
    #we can't run run from NONE PROD domain to prod servers...
    Write-Error "WE CAN'T run a script from a NONE PROD Active Directory Domain ($Domain) to Production Servers(Platform [$Platform]), exiting script!"
    $exit_code = 20
    if(-Not($ISE)) { ExitWithCode -exitcode $exit_code } else {Throw "Exiting, script!"}
}
elseif ($Platform -ne 'PROD' -and $Domain -eq 'BSC')
{
    Write-Error "WE CAN'T run from a PROD Active Directory Domain ($Domain) to NONE Production Servers(Platorm [$Platform]), exiting script!"
    $exit_code = 21
    if(-Not($ISE)) { ExitWithCode -exitcode $exit_code } else {Throw "Exiting, script!"}
}
else
{
    Write-Host "Running script in Active Directory Domain [$Domain] for server types of [$Platform]"
}

$ServicesToControl = @('facets*','W3SVC','FaWinSvcHost')
$SleepTimer = 5

Write-Host "Servers are: [$Servers] for Services [$ServicesToControl]"

#Enable Maintenance Mode 
#.$PAM_HOME/Citrix/CitrixManageMaintMode -Environment $Environment -MaintMode Enable 
.$PAM_HOME/Citrix/CitrixManageMaintMode -Environment $CitrixEnv -MaintMode Enable -CitrixName $CitrixName

#import the PAM Service Module
import-module -name Get-PAMServiceControl.psm1 -Verbose -WarningAction SilentlyContinue

#stop services
if(-not ([string]::IsNullOrEmpty($servers))) 
{
    Write-Host "Working on Servers [$servers] for Services [$($servicesToControl)]"
    Write-Host "Building PSSessions on [$Servers] Servers"
    $Session = New-PSSession -ComputerName $Servers -Verbose
    $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,stop,180 -AsJob
    #wait for job to complete and output results
    $rc1 = checkJobAndLog -Session $Session -Jobs $Jobs 
    $RCode1 = $($rc1)[1]
    if ($RCode1 -ne 0)
    {
        Write-Error "Failures duing Validation Checks with RC: $RCode1"
        $exit_code = $RCode1
    }
    else
    {
        Write-Host "All good on job(s) RC: $RCode1"
    }
}
else
{
    Write-Host "Servers are empty, skipping [$servers] for Services [$($servicesToControl)]"
}

#$SaveEnv = $Environment
#Write-Host "Environment is $environment save env is $SaveEnv"
#get services to set to manual
$servers = get-bscserversinfo -Environment $SaveEnv -WhichProperty Role -PropValue ISL,ISLCWS,HIPAA,BATCH -ColumnReturn ServerName
$ServicesToControl = @('facets*','W3SVC')
Write-Host "Servers to set services to manual are: [$Servers] for Services [$ServicesToControl]"
 

#set to manual for the services
if(-not ([string]::IsNullOrEmpty($servers))) 
{
    Write-Host "Working on Servers [$servers] for Services [$($servicesToControl)]"
    Write-Host "Building PSSessions on [$Servers] Servers"
    $Session = New-PSSession -ComputerName $Servers -Verbose
    $Jobs = Invoke-Command -Session $Session -ScriptBlock ${function::Get-PAMServiceControl} -ArgumentList $ServicesToControl,manual,180 -AsJob
    #wait for job to complete and output results
    $rc2 = checkJobAndLog -Session $Session -Jobs $Jobs 
    $RCode2 = $($rc2)[1]
    if ($RCode2 -ne 0)
    {
        Write-Error "Failures duing Validation Checks with RC: $RCode2"
        $exit_code = $RCode2
    }
    else
    {
        Write-Host "All good on job(s) RC: $RCode2"
    }
}
else
{
    Write-Host "Servers are empty, skipping [$servers] for Services [$($servicesToControl)]"
}


################################################
#now do reboots....
$servers = get-bscserversinfo -Environment $SaveEnv -WhichProperty Role -PropValue ISL,ISLCWS,HIPAA,BATCH,Interactive,UFT -ColumnReturn ServerName
Write-Host "Rebooting Facets Servers [$servers]"
#Restart-Computer $Servers -Force -asjob
Write-Host "Building PSSessions on [$Servers] Servers"
$Session = New-PSSession -ComputerName $Servers -Verbose
$Jobs = Invoke-Command -Session $Session -ScriptBlock {Restart-Computer -Force} -AsJob
#$Jobs = Invoke-Command -Session $Session -ScriptBlock {Get-Service -ErrorAction Ignore} -AsJob

#wait for job to complete and output results
$rc3 = checkJobAndLog -Session $Session -Jobs $Jobs 
$RCode3 = $($rc3)[1]
if ($RCode3 -ne 0 -or $RCode1 -ne 0 -or $RCode2 -ne 0 )
{
    $exit_code = $RCode1 + $RCode2 + $RCode3
    Write-Error "Failures duing Validations : $exit_code"
}
else
{
    Write-Host "All good on job(s) RC: $RCode3"
}

#cleanup
Remove-Module -Name Get-BSCServersInfo
Remove-Module -Name Get-PAMServiceControl
Remove-Module -Name Functions

Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
ExitWithCode -exitcode $exit_code -ISEFlag $ISE
