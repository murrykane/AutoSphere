﻿<#	
	.NOTES
	===========================================================================
	 Created on:   	05/15/2019
	 Updated on:	05/15/2019
	 Created by:   	Murry Kane
	 Organization: 	Blue Shield of California
	 Filename:     	Backup-CP.ps1

	The scripts being built in this grouping are for PAM Production Support
	The majority will be run from the Primary PAM Server, WINF313P or WINF4028p. However,
	it is desired to have portability across systems as needed and to have the 
	scripts work.
	===========================================================================
	.DESCRIPTION
		This script will either accept a single argument or prompt if running in ISE for
        a given Facets environment. It will then backup the environment before a Change Pack for 
        recovery puposses if needed


Date:      Who:            Changes:
-----------------------------------
05/15/2019 Murry Kane      Initial


    Example

    ./{Directory}\Backup-CP.ps1 -Environment FACN52 
    ./{Directory}\Backup-CP.ps1 -Environment FACP01
#>

[CmdletBinding()]
Param(
  #[Parameter(Mandatory=$True,Position=1)]
   [string[]]$Environment,
   [string[]]$Roles
	
)

try
{

    $exit_code = 0
    $LOG_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts\logs'
    $PAM_HOME_DIR_DEFAULT='D:\apps\jenkins\AutoCommon\powershell\Pam_Scripts'
    $currentScriptName = $MyInvocation.MyCommand.Name
    $filename = [io.path]::GetFileNameWithoutExtension($currentScriptName)
    $SleepTimer = 5
    # turn off verbose
    $VerbosePreference = 'SilentlyContinue'

    Write-Host "Script name is: $currentScriptName"

    if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS)))
    {
        $LOG_DIR = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_LOGS).PAM_LOGS
    }
    else
    {
        $LOG_DIR = $PAM_HOME_DIR_DEFAULT 
    }

    $LOG_FILE="$LOG_DIR\$filename" + "_" + $(get-date -format s | foreach {$_ -replace ":", "-"}) + ".log"

    #get PAM home dir
    if (-not ([string]::IsNullOrEmpty((Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME)))
    {
        $PAM_HOME = (Get-Itemproperty -path 'hklm:\system\currentcontrolset\control\session manager\environment' -ErrorAction Ignore -Name PAM_HOME).PAM_HOME
    }
    else
    {
        $PAM_HOME = $PAM_HOME_DIR_DEFAULT 
    }


    if ($Host.Name -eq "Windows PowerShell ISE Host") {
        $ISE=$true
    } else {
        $ISE=$false
    }
    if ($ISE) {
        # get the required input
        if(-not($Environment)) {
            $Environment = @()
            do 
            {
                $input = (Read-Host "Input your Environment (FACP02, FACN32, FACN31): ")
                if ($input -ne '') {$Environment += $input}
            }
            until ($input -eq '')
        }
        if(-not($Roles)) {
            $Roles = @()
            do 
            {
                $input = (Read-Host "Input your Role (ISL, HIPAA, BATCH, etc): ")
                if ($input -ne '') {$Roles += $input}
            }
            until ($input -eq '')
        }
    }

    #lets start logging what occures from here forward....
    Start-Transcript -path $LOG_FILE -append

    Write-Host "Log File is $LOG_FILE"
    Write-Host "Environment is [$Environment]"
    Write-Host "PAM HOME Directory is $PAM_HOME"
    Write-Host "Roles are [$Roles]"

    #import functions
    Import-Module Functions -Force
    Import-Module Get-BSCServersInfo
    $Servers = get-bscserversinfo -Environment $Environment -WhichProperty Role -PropValue $Roles -ColumnReturn ServerName
    $GetAll = get-bscserversinfo -Environment $Environment -WhichProperty Role -PropValue $Roles -ColumnReturn all

    $BICServers = @()
    $IISServers = @()
    $THGServers = @()
    $MDServers = @()
    #
    $GetAll | foreach-object {
        if (($($_.Role) -eq "Batch") -or ($($_.Role) -eq "Interactive"))
        {
            $BICServers += $_.ServerName
        }
        if ($($_.Role) -eq "ISL" -or $($_.Role) -eq "ISLCWS") 
        {
            $IISServers += $_.ServerName
        }
        if ($($_.Role) -eq "HIPAA")
        {
            $THGServers += $_.ServerName
        }
        if ($($_.Component) -eq "MD")
        {
            $MDServers += $_.ServerName
        }
    }

    #check if servers is empty, then exit
    if(([string]::IsNullOrEmpty($Servers))) 
    {
        Write-Error "Could not determine a list of servers for environment [$Environment], exiting!"
        $exit_code = 13
        ExitWithCode -exitcode $exit_code -ISEFlag $ISE
    }

    #now that we have the servers, let validate we are not trying to cross Domains (NPE to PROD or vise-versa)
    $Platform = get-bscserversinfo -Environment $Environment -WhichProperty ServerName -PropValue $Servers -ColumnReturn Platform
    #$Domain = (Get-ADDomain).Name  #mbk its expensive call...
    $Domain = (Get-ChildItem Env:'USERDOMAIN' -ErrorAction Ignore).Value
    Write-Verbose "Platform for these servers is [$Platform], Active Directory Domain is [$Domain]"
    if ($Platform -eq 'PROD' -and $Domain -ne 'BSC')
    {
        #we can't run run from NONE PROD domain to prod servers...
        Write-Error "WE CAN'T run a script from a NONE PROD Active Directory Domain ($Domain) to Production Servers(Platform [$Platform]), exiting script!"
        $exit_code = 20
        if(-Not($ISE)) { ExitWithCode -exitcode $exit_code } else {Throw "Exiting, script!"}
    }
    elseif ($Platform -ne 'PROD' -and $Domain -eq 'BSC')
    {
        Write-Error "WE CAN'T run from a PROD Active Directory Domain ($Domain) to NONE Production Servers(Platorm [$Platform]), exiting script!"
        $exit_code = 21
        if(-Not($ISE)) { ExitWithCode -exitcode $exit_code } else {Throw "Exiting, script!"}
    }
    else
    {
        Write-Host "Running script in Active Directory Domain [$Domain] for server types of [$Platform]"
    }

    Write-Host "Servers are: [$Servers]"


    $BACKUP_DIR = "D:\temp\backup"
    $BACKUP_DIRRem = {Get-ChildItem D:\temp\backup}
    $IISPath = "D:\apps\Facets" , "D:\apps\inetpub\wwwroot\FacetsWebServiceLibrary"
    $THGPath = "D:\apps\inetpub\wwwroot\FacetsWebServiceLibrary", "D:\apps\Facets", "D:\apps\TIBCO", "D:\apps\inetpub\wwwroot\GatewayWebApplications"
    $BICPath = "D:\apps\Facets"
    $MDPath = "D:\Apps\Melissa DATA"
    $IISData = {Get-ChildItem D:\apps\inetpub\wwwroot\FacetsWebServiceLibrary\, D:\apps\Facets\ -Recurse | Measure-Object -property length -sum}
    $THGData = {Get-ChildItem D:\apps\inetpub\wwwroot\FacetsWebServiceLibrary\, D:\apps\Facets\, D:\apps\TIBCO\, D:\apps\inetpub\wwwroot\GatewayWebApplications\ -Recurse | Measure-Object -property length -sum}
    $BICData = {Get-ChildItem D:\apps\Facets\ -Recurse | Measure-Object -property length -sum}
    $MDData = {Get-ChildItem 'D:\Apps\Melissa DATA\' -Recurse | Measure-Object -property length -sum}




    ############## Backup Space Check ###################

    If ($NoCheck -ne $true)
    {
 

	    $UserReply = Read-Host -Prompt "Delete content of D:\temp\backup, checking for enough free space to backup to D:\temp\backup on Servers then backup.  Do You Want to Proceed? Enter 'yes' to continue. "
	
	    if ($UserReply -ne "YES")
	        {
		    Write-host "Exiting"
		    exit
	        }

        if ((Invoke-Command -ComputerName $Servers -scriptBlock {Test-Path -path D:\temp\backup -ErrorAction SilentlyContinue}) -eq "true")
            {
            Invoke-Command -ComputerName $Servers -scriptBlock {Remove-Item D:\temp\backup -Recurse -force}
            }
     
     do{       
            $ServCheck = @()
            foreach ($Server in $Servers)
            {
                $ServerRole = get-bscserversinfo -Environment $Environment -WhichProperty ServerName -PropValue $Server -ColumnReturn Role
                $ServerComp = get-bscserversinfo -Environment $Environment -WhichProperty ServerName -PropValue $Server -ColumnReturn Component
                if ($ServerRole -eq "ISL" -or $ServerRole -eq "ISLCWS" )
                {
                    Write-Host "Checking on ISL server $Server"
                    $Dspace=(Invoke-Command -ComputerName $Server {Get-PSDrive D})
                    $SoftFolder=(Invoke-Command -ComputerName $Server $IISData -ErrorAction SilentlyContinue)
                    If ( $SoftFolder.sum -gt $Dspace.free)
                    {
                        $ServCheck += $Server  
                    }
                }
                if ($ServerRole -eq "HIPAA")
                {
                    Write-Host "Checking on HIPAA server $Server"
                    $Dspace=(Invoke-Command -ComputerName $Server {Get-PSDrive D})
                    $SoftFolder=(Invoke-Command -ComputerName $Server $THGData -ErrorAction SilentlyContinue)
                    If ( $SoftFolder.sum -gt $Dspace.free)
                    {
                        $ServCheck += $THGcheck
                    }
                } 
                if ($ServerRole -eq "Batch" -or $ServerRole -eq  "Interactive")
                {
                    Write-Host "Checking on Batch/Interactive server $Server"
                    $Dspace=(Invoke-Command -ComputerName $Server {Get-PSDrive D})
                    $SoftFolder=(Invoke-Command -ComputerName $Server $BICData -ErrorAction SilentlyContinue)
                    If ( $SoftFolder.sum -gt $Dspace.free)
                    {
                        $ServCheck += $BICcheck
                    }
                }   
                #if ($ServerComp -eq "MD")
                #{
                #    Write-Host "Checking on MD server $Server"
                #    $Dspace=(Invoke-Command -ComputerName $Server {Get-PSDrive D})
                #    $SoftFolder=(Invoke-Command -ComputerName $Server $MDData -ErrorAction SilentlyContinue)
                #    If ( $SoftFolder.sum -gt $Dspace.free)
                #    {
                #        $ServCheck += $MDcheck
                #    }                       
                #}
            }
            if ($ServCheck)
            {
                $UserReply2 = Read-Host -Prompt "The backup is too big on $ServCheck do You Want to check again? Enter 'yes' to check again. "

                if ($UserReply2 -ne "YES")
	            {
		            Write-host "Exiting"
		            exit 
	            }
            }
        } until (!$ServCheck)        
          Write-Host "Target servers have enough backup space!"      
              
    }
    
    if ($IISServers)
    {
        Write-Host "Working on ISL servers: [$IISServers]"
        Invoke-Command -ComputerName $IISServers -scriptBlock {New-Item d:\temp\temp33 -type directory}
        Invoke-Command -ComputerName $IISServers -scriptBlock {Copy-Item d:\temp\temp33, D:\apps\inetpub\wwwroot\FacetsWebServiceLibrary\, D:\apps\Facets\ -destination D:\temp\backup\ -ErrorAction SilentlyContinue -Recurse -Force}  
        Invoke-Command -ComputerName $IISServers -scriptBlock {Remove-Item d:\temp\temp33 -Force}
    }
    if ($THGServers)
    {
        Write-Host "Working on HIPAA servers: [$THGServers]"
        Invoke-Command -ComputerName $THGServers -scriptBlock {New-Item d:\temp\temp44 -type directory}
        Invoke-Command -ComputerName $THGServers -scriptBlock {Copy-Item d:\temp\temp44, D:\apps\inetpub\wwwroot\FacetsWebServiceLibrary\, D:\apps\Facets\, D:\apps\TIBCO\, D:\apps\inetpub\wwwroot\GatewayWebApplications\ -destination D:\temp\backup\ -ErrorAction SilentlyContinue -Recurse -Force} 
        Invoke-Command -ComputerName $THGServers -scriptBlock {Remove-Item d:\temp\temp44 -Force}
    }
    if ($BICServers)
    {
        Write-Host "Working on Batch/Interactive servers: [$BICServers]"
        Invoke-Command -ComputerName $BICServers -scriptBlock {New-Item d:\temp\temp55 -type directory}
        Invoke-Command -ComputerName $BICServers -scriptBlock {Copy-Item d:\temp\temp55, D:\apps\Facets\ -destination D:\temp\backup\ -ErrorAction SilentlyContinue -Recurse -Force}
        Invoke-Command -ComputerName $BICServers -scriptBlock {Remove-Item d:\temp\temp55 -Force}
    }
    #if ($MDServers)
    #{
    #    Write-Host "Working on MD servers: [$MDServers]"
    #    Invoke-Command -ComputerName $MDServers -scriptBlock {Copy-Item 'D:\Apps\Melissa DATA\' -destination D:\temp\backup\ -ErrorAction SilentlyContinue -Recurse -Force}
    #}     

    Write-Host "$servers backed-up!" 
    $RCode1 = 0


}
catch
{
    Write-Error $_.Exception.ToString();
    $exit_code = 99
}

finally
{

    #cleanup
    Remove-Module -Name Get-BSCServersInfo
    Remove-Module -Name Functions

    if ($RCode1 -ne 0)
    {
        $exit_code = $RCode1
        Write-Error "Failures duing Validations : $exit_code"
    }


    Write-Host "All done with: $currentScriptName Exiting with [$exit_code]"
    ExitWithCode -exitcode $exit_code -ISEFlag $ISE
}

