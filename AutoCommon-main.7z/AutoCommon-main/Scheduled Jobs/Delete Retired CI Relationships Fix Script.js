//
// *********************************** SETUP ****************************************************************************************************************

var dryRun = true;              // SET THIS TO FALSE TO ACTUALLY DELETE RECORDS

var deleteCount = 5000;            // TOTAL NUMBER OF RECORDS TO BE DELETED

var deleteAll = false;          // SET deleteCount TO 0 AND deleteAll TO TRUE TO DELETE ALL AT ONCE

var chunkSize = 1000;           // HOW MANY RECORDS WILL BE DELETED IN EACH ITERATION UP TO THE deleteCount

var queryString = "parent.operational_status=1^child.install_status=7"

//  ***********************DO NOT EDIT PAST THIS POINT***********************************************************************************************

var deletionsCompleted = 0;             // DO NOT CHANGE

var remainingDeletions = deleteCount;   // DO NOT CHANGE

var loopControl = true;                 // DO NOT CHANGE

var resultString = '\n'

var agg = new GlideAggregate('cmdb_rel_ci');

agg.addQuery(queryString);

agg.addAggregate('COUNT');

agg.query();

 

// LETS FIND OUT HOW MNY ORPHANS NEED TO BE DELETED
if (agg.next()){
        var deletionCandidates = agg.getAggregate("COUNT");
        // In order to avoid using many gs.print() results will be added to a single string and displayed at the end,
        // that makes it easier to read too, as long running / complex queries force many informational messages to the output
        resultString += 'Found : ' + deletionCandidates + ' invalid relationships (CMDB_CI_REL)!' + '\n';
}

if (dryRun){
        resultString += 'To commit the changes, flip the -dryRun- switch to false!\n';
}
else
{
        //let's delete some records
        var orphans = new GlideRecord('cmdb_rel_ci');
        orphans.addQuery(queryString);

        if (deleteCount == 0 && deleteAll){
                orphans.setWorkflow(false);
                orphans.setUseEngines(false);
                orphans.deleteMultiple();
                deletionsCompleted = deletionCandidates;
        }
        else
        {
            while (loopControl){
                //delete n (chunkSize) records at a time
                //check if we have less than chunksize remaining
                if (remainingDeletions < chunkSize){
                    chunkSize = remainingDeletions;
                }
                orphans.setLimit(chunkSize);
                orphans.query();

                var deletedActualCount = orphans.getRowCount();

                orphans.setWorkflow(false);
                orphans.setUseEngines(false);
                orphans.deleteMultiple();
                deletionsCompleted += deletedActualCount;
                remainingDeletions -= deletedActualCount;

                if (remainingDeletions == 0){
                    loopControl = false;
                }

                //safety check
                if (deletionsCompleted >= deletionCandidates){
                    loopControl = false;
                }
            }
        }

        resultString += 'Succesfully deleted ' + deletionsCompleted + ' records!';
}

gs.print(resultString);